<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Anky
 * @author  Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">
	<?php
	if ( have_comments() ) :

		echo '<h2 class="comments-title">';

		$comments_number = get_comments_number();
		$post_title      = get_the_title();

		if ( '1' === $comments_number ) {
			echo esc_html(
				printf(
				/* translators: %s: Post title. */
					_x( 'One Comment to &ldquo;%s&rdquo;', 'comments title', 'anky' ),
					$post_title
				)
			);
		} else {
			echo esc_html(
				sprintf(
				/* translators: 1 Number of comments, 2 Post title. */
					_nx( '%1$s Comment to &ldquo;%2$s&rdquo;', '%1$s Comments to &ldquo;%2$s&rdquo;', '%1$s', 'comments title', 'anky' ),
					number_format_i18n( $comments_number ),
					$post_title
				)
			);
		}

		echo '</h2>';
		?>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'avatar_size'       => 56,
					'style'             => 'ol',
					'short_ping'        => true,
					'reverse_top_level' => true,
					'reverse_children'  => true,
					'reply_text'        => esc_html_x( 'Reply', 'comment', 'anky' ),
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'prev_text' => '<span class="nav-meta"><span class="anky-icon-chevron-left" aria-hidden="true"></span>' . esc_html_x( 'Newer', 'comments', 'anky' ) . '</span>',
				'next_text' => '<span class="nav-meta">' . esc_html_x( 'Older', 'comments', 'anky' ) . '<span class="anky-icon-chevron-right" aria-hidden="true"></span>',
			)
		);

	endif; // Check for have_comments().

	// In case comments are closed but there are some, leave a notification.
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
		echo '<p class="no-comments">' . esc_html__( 'Comments are closed.', 'anky' ) . '</p>';
	endif; // check for comments present but closed.
	comment_form( anky_get_comments_form_args() );
	?>

</div><!-- #comments -->
