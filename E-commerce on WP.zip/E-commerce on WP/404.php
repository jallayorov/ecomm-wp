<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link    https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Anky
 * @author  Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

get_header();
?>

	<main id="primary" class="site-main">
		<div class="anky-container">
			<header class="page-header">
				<h1 class="screen-reader-text"><?php esc_html_e( 'Nothing here', 'anky' ); ?></h1>
				<?php
				anky_the_svg(
					array(
						'icon'   => '404',
						'width'  => 250,
						'height' => 165,
						'class'  => array( 'anky-page-thumbnail' ),
					)
				);
				?>
			</header><!-- .page-header -->

			<div class="error-404 not-found default-max-width">
				<div class="page-content">
					<span class="page-subtitle">404</span>
					<h2 class="page-title"><?php esc_html_e( 'The page you are looking for doesn&rsquo;t exist', 'anky' ); ?></h2>
					<p class="anky-text-muted"><?php esc_html_e( 'The page may have moved or you may have assembled the link incorrectly', 'anky' ); ?></p>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="anky-btn anky-btn-dark"><?php esc_html_e( 'Back home', 'anky' ); ?></a>
				</div><!-- .page-content -->
			</div><!-- .error-404 -->
		</div>
	</main>

<?php
get_footer();
