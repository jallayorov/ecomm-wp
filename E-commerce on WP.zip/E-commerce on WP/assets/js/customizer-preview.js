/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 *
 * @package Anky
 */
/* global wp, jQuery, _wpCustomizeSettings */
(
		function( $, api ) {
			'use strict';
			// Site title and description.
			previewControlText( 'blogname', '.anky-site-title' );
			previewControlText( 'blogdescription', '.site-description' );

			// Global phone number.
			api( 'anky-options[globals-contact-tel-number]', function( value ) {
				value.bind( function( to ) {

					[
						$( '.anky-header-tel-link' ),
						$( '.anky-link-list-item-phone' ),
						$( '.anky-contact-block-item-phone' )
					].forEach( function( elem ) {
						if ( to.length ) {
							$( elem ).
							css( 'display', 'flex' ).
							attr( 'href', 'tel:' + to.replace( /\D/g, '' ) ).
							text( to );
						} else {
							$( elem ).
							css( 'display', 'none' );
						}
					} );

				} );
			} );

			// Global email.
			api( 'anky-options[globals-contact-email]', function( value ) {
				value.bind( function( to ) {
					[
						$( '.anky-contact-block-item-email' ),
						$( '.anky-link-list-item-email' )
					].forEach( function( elem ) {
						if ( to.length ) {
							$( elem ).
							css( 'display', 'flex' ).
							attr( 'href', 'mailto:' + to ).
							text( to );
						} else {
							$( elem ).
							css( 'display', 'none' );
						}
					} );

				} );
			} );

			// Global address.
			api( 'anky-options[globals-contact-address]', function( value ) {
				value.bind( function( to ) {
					[
						$( '.anky-link-list-text' ),
						$( '.anky-contact-block-item-address' )
					].forEach( function( elem ) {
						if ( to.length ) {
							$( elem ).
							css( 'display', 'flex' ).
							text( to );
						} else {
							$( elem ).
							css( 'display', 'none' );
						}
					} );

				} );
			} );

			// Global address map embed.
			api( 'anky-options[globals-contact-address-map-embed]', function( value ) {
				value.bind( function( to ) {
					[
						$( '.anky-contact-block-item-map' )
					].forEach( function( elem ) {
						let currentVal = '';

						if ( - 1 !== to.search( '<iframe' ) ) {
							const doc = new DOMParser().parseFromString( to, 'text/html' );
							if ( doc.body.children[0] ) {
								currentVal = doc.body.children[0].src;
							}
						} else if ( '' !== to ) {
							currentVal = to;
						}

						if ( currentVal.length ) {
							$( elem ).
							css( 'display', 'block' ).
							attr( 'src', currentVal );
						} else {
							$( elem ).
							css( 'display', 'none' );
						}
					} );
				} );
			} );

			// Color Scheme
			api( 'anky-options[globals-color-scheme]', function( value ) {
				value.bind( function( to ) {

					let scheme = getColorScheme( to );

					for ( const value in scheme ) {
						if ( scheme.hasOwnProperty( value ) ) {
							document.documentElement.style.setProperty( value, scheme[value] );
						}
					}
				} );
			} );

			// Excerpt length
			api( 'anky-options[blog-excerpt-length]', function( value ) {
				value.bind( function( to ) {
					document.documentElement.style.setProperty( '--anky-blog-excerpt-length', to );
				} );
			} );

			// upper bar change
			api( 'anky-options[header-upper-bar-layout-type]', function( value ) {
				value.bind( function( to ) {
					$( '.anky-upper-header-bar' ).
					removeClass( function( index, selector ) {
						return selector.replace( /(^|\s)+anky-upper-header-bar\s+/, '' );
					} );
				} );
			} );

			/**
			 * ------------------------------------------------------------------------
			 * Helpers
			 * ------------------------------------------------------------------------
			 */

			/**
			 * Helps to set text preview on simple text controls.
			 * @param optionID ID of the saved option.
			 * @param bindSelector Selector to ping new next value to..
			 * */
			function previewControlText( optionID, bindSelector ) {
				api( optionID, function( value ) {
					value.bind( function( to ) {
						$( bindSelector ).
						text( to );
					} );
				} );
			}

			/**
			 * Retrieve color scheme details.
			 *
			 * @param currentScheme ID of the saved option.
			 *
			 * @return string Color scheme object.
			 */
			function getColorScheme( currentScheme ) {
				let scheme = {};
				if ( 'light' === currentScheme ) {
					scheme = {
						'--anky-colors__primary'          : 'hsl(240, 8%, 9%)',
						'--anky-colors__secondary'        : 'hsl(240, 2%, 50%)',
						'--anky-colors__tertiary'         : 'hsl(240, 3%, 69%)',
						'--anky-colors__accent-primary'   : 'hsl(349, 80%, 45%)',
						'--anky-colors__accent-hover'     : 'hsl(349, 80%, 42%)',
						'--anky-colors__accent-focus'     : 'hsl(349, 80%, 39%)',
						'--anky-colors__inverse'          : 'hsl(0, 0%, 100%)',
						'--anky-colors__border'           : 'hsl(0, 0%, 88%)',
						'--anky-colors__border-hover'     : 'hsl(0, 0%, 80%)',
						'--anky-colors__border-active'    : 'hsl(0, 0%, 72%)',
						'--anky-colors__background'       : 'hsl(0, 0%, 96%)',
						'--anky-colors__background-hover' : 'hsl(0, 0%, 94%)',
						'--anky-colors__background-active': 'hsl(0, 0%, 92%)',
						'--anky-colors__box-shadow'       : 'hsla(240, 8%, 9%, 0.12)',
						'--anky-colors__text-shadow'      : 'hsla(240, 8%, 9%, 0.4)'
					};
				} else if ( 'dark' === currentScheme ) {
					scheme = {
						'--anky-colors__primary'          : 'hsl(0, 0%, 100%)',
						'--anky-colors__secondary'        : 'hsl(240, 2%, 50%)',
						'--anky-colors__tertiary'         : 'hsl(240, 2%, 32%)',
						'--anky-colors__accent-primary'   : 'hsl(349, 80%, 45%)',
						'--anky-colors__accent-hover'     : 'hsl(349, 80%, 42%)',
						'--anky-colors__accent-focus'     : 'hsl(349, 80%, 39%)',
						'--anky-colors__inverse'          : 'hsl(240, 8%, 9%)',
						'--anky-colors__border'           : 'hsl(240, 8%, 19%)',
						'--anky-colors__border-hover'     : 'hsl(240, 8%, 23%)',
						'--anky-colors__border-active'    : 'hsl(240, 8%, 28%)',
						'--anky-colors__background'       : 'hsl(240, 8%, 13%)',
						'--anky-colors__background-hover' : 'hsl(240, 8%, 15%)',
						'--anky-colors__background-active': 'hsl(240, 8%, 17%)',
						'--anky-colors__box-shadow'       : 'hsla(0, 0%, 100%, 0.12)',
						'--anky-colors__text-shadow'      : 'hsla(0, 0%, 100%, 0.4)'
					};
				}
				return scheme;
			}

		}( jQuery, wp.customize )
);

/**
 * Helps to set text preview on simple text controls.
 *
 * @param elem - element on which function triggered.
 */
function ankyCustomizeLink( elem ) {
	wp.customize.preview.send( 'widgetsLink', elem.dataset.customizerLink );
}
