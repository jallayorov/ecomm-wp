/**
 * Scripts within the customizer controls window.
 * @package Anky
 */
/* global wp, jQuery, externals, tinyMCE */
(
		function( $, api, externals ) {
			'use strict';
			const AnkyCustomizer = {

				/**
				 * Run function when customizer is ready.
				 */
				init: function() {
					let context = this;
					api.bind( 'ready', function() {
						context.googleFonts();
						context.switchToControl();
						context.googleMapEmbed();
						context.sortableRepeater();
						context.tinyMCE();
						context.languageSwitcher();
					} );
				},

				/**
				 * Google Font Select Custom Control.
				 */
				googleFonts: function() {
					let fontList = $( '.anky-google-fonts-list' ); // Init the Select2.

					fontList.
					each( function( i, obj ) {
						if ( !$( obj ).
						hasClass( 'select2-hidden-accessible' ) ) {
							$( obj ).
							select2(
									{
										theme: 'classic',
										width: '100%'
									}
							);
						}
					} );

					fontList.
					on( 'change', function() {
						let elementRegularWeight     = $( this ).
								parent().
								parent().
								find( '.anky-font-regular-weight-style' ),
								elementItalicWeight      = $( this ).
								parent().
								parent().
								find( '.anky-fonts-italic-weight-style' ),
								elementBoldWeight        = $( this ).
								parent().
								parent().
								find( '.anky-fonts-bold-weight-style' ),
								selectedFont             = $( this ).
								val(),
								customizerControlName    = $( this ).
								attr( 'data-control-id' ),
								elementItalicWeightCount = 0,
								elementBoldWeightCount   = 0,
								bodyFontControl          = api.control( customizerControlName ), // Get the Google Fonts control object
								indexes                  = $.map( bodyFontControl.params.ankyGoogleFonts, function( obj, index ) { // Find the index of the selected font
									if ( obj.family === selectedFont ) {
										return index;
									}
								} ),
								index                    = indexes[0];

						// Clear Weight/Style dropdowns
						elementRegularWeight.empty();
						elementItalicWeight.empty();
						elementBoldWeight.empty();

						// Make sure Italic & Bold dropdowns are enabled
						elementItalicWeight.prop( 'disabled', false );
						elementBoldWeight.prop( 'disabled', false );

						// For the selected Google font show the available weight/style variants
						$.each( bodyFontControl.params.ankyGoogleFonts[index].variants, function( val, text ) {
							elementRegularWeight.append(
									$( '<option></option>' ).
									val( text ).
									html( text )
							);

							// Regular text
							if ( text.indexOf( 'italic' ) >= 0 ) {
								elementItalicWeight.append(
										$( '<option></option>' ).
										val( text ).
										html( text )
								);
								elementItalicWeightCount ++;
							} else {
								elementBoldWeight.append(
										$( '<option></option>' ).
										val( text ).
										html( text )
								);
								elementBoldWeightCount ++;
							}
						} );

						// Italic text
						if ( elementItalicWeightCount === 0 ) {
							elementItalicWeight.append(
									$( '<option></option>' ).
									val( '' ).
									html( externals.fontUnavailable )
							);
							elementItalicWeight.prop( 'disabled', 'disabled' );
						}

						// Bold text
						if ( elementBoldWeightCount === 0 ) {
							elementBoldWeight.append(
									$( '<option></option>' ).
									val( '' ).
									html( externals.fontUnavailable )
							);
							elementBoldWeight.prop( 'disabled', 'disabled' );
						}

						// Update the font category based on the selected font
						$( this ).
						parent().
						parent().
						find( '.anky-fonts-category' ).
						val( bodyFontControl.params.ankyGoogleFonts[index].category );

						ankyPrepareGoogleFontsControlSelections( $( this ).
																												 parent().
																												 parent() );
					} );

					$( '.anky-google-fonts-select-control select' ).
					on( 'change', function() {
						ankyPrepareGoogleFontsControlSelections(
								$( this ).
								parent().
								parent()
						);
					} );

					function ankyPrepareGoogleFontsControlSelections( $element ) {
						let selectedFont = {
							family       : $element.find( '.anky-google-fonts-list' ).
																			val(),
							regularWeight: $element.find( '.anky-font-regular-weight-style' ).
																			val(),
							italicWeight : $element.find( '.anky-fonts-italic-weight-style' ).
																			val(),
							boldWeight   : $element.find( '.anky-fonts-bold-weight-style' ).
																			val(),
							category     : $element.find( '.anky-fonts-category' ).
																			val()
						};

						// Important! Make sure to trigger change event so Customizer knows it has to save the field
						$element.find( '.customize-control-google-font-selection' ).
										 val( JSON.stringify( selectedFont ) ).
										 trigger( 'change' );
					}
				},

				/**
				 * Trigger Widget sections control focusing.
				 */
				switchToControl: function() {
					api.previewer.bind( 'widgetsLink', function( message ) {
						api.section( message ).
								focus();
					} );
				},

				/**
				 * Formatting the Google Maps embed input.
				 */
				googleMapEmbed: function() {
					$( '#_customize-input-globals-contact-address-map-embed' ).
					on( 'input', function() {
						if ( - 1 !== this.value.search( '<iframe' ) ) {
							const doc = new DOMParser().parseFromString( this.value, 'text/html' );
							if ( doc.body.children[0] ) {
								this.value = doc.body.children[0].src;
							}
						} else {
							this.value = '';
						}
					} ).
					on( 'blur focusout', function() {
						if ( - 1 !== this.value.search( 'https://www.google.com/maps/embed' ) ) {
							this.value = this.value.trim();
						} else {
							this.value = '';
						}
					} );
				},

				/**
				 * Sortable Repeater
				 */
				sortableRepeater: function() {
					const repeaterContainerSelector       = '.anky-sortable-repeater.sortable',
								repeaterCollectionInputSelector = '.anky-customize-control-sortable-repeater',
								repeaterContainer               = $( repeaterContainerSelector ),
								repeaterControl                 = $( '.anky-sortable-repeater-control' );

					// Update the values for all our input fields and initialise the sortable repeater
					repeaterControl.
					each( function() {
						// populate rows if there is an existing customizer value
						let defaultValuesArray = $( this ).
								find( repeaterCollectionInputSelector ).
								val().
								split( ',' ),
								numRepeaterItems   = defaultValuesArray.length;

						if ( numRepeaterItems > 0 ) {
							// Add the first item to existing input field
							$( this ).
							find( '.anky-repeater-input' ).
							val( defaultValuesArray[0] );
							// Create a new row for each new value
							if ( numRepeaterItems > 1 ) {
								let i;
								for ( i = 1; i < numRepeaterItems; ++ i ) {
									ankyAppendRow( $( this ), defaultValuesArray[i] );
								}
							}
						}
					} );

					// Make Repeater fields sortable
					$( this ).
					find( repeaterContainerSelector ).
					sortable(
							{
								update: function( event, ui ) {
									ankyGetAllInputs( $( this ).
																				parent() );
								}
							}
					);

					// Remove item starting from it's parent element
					repeaterContainer.
					on( 'click', '.anky-customize-control-sortable-repeater-delete', function( event ) {
						event.preventDefault();
						let numItems = $( this ).
						parent().
						parent().
						find( '.anky-repeater-row' ).length;

						if ( numItems > 1 ) {
							$( this ).
							parent().
							slideUp( 'fast', function() {
								let currentItem     = $( this ),
										parentContainer = currentItem.
										parents( '.anky-sortable-repeater-control' );
								currentItem.
								remove();
								ankyGetAllInputs( parentContainer );
							} );
						} else {
							$( this ).
							parent().
							find( '.anky-repeater-input' ).
							val( '' );
							ankyGetAllInputs( $( this ).
																		parents( repeaterContainerSelector ) );
						}
					} );

					// Add new item
					$( '.anky-customize-control-sortable-repeater-add' ).
					click( function( event ) {
						event.preventDefault();
						let parent = $( this ).
						parent();
						ankyAppendRow( parent );
						ankyGetAllInputs( parent );
					} );

					// Refresh our hidden field if any fields change
					repeaterContainer.
					change( function() {
						ankyGetAllInputs(
								$( this ).
								parent()
						);
					} );

					// Add https:// to the start of the URL if it doesn't have it
					repeaterContainer.
					on( 'blur', '.anky-repeater-input', function() {
						let url = $( this ),
								val = url.val();
						if ( val && !val.match( /^.+:\/\/.*/ ) ) {
							// Important! Make sure to trigger change event so Customizer knows it has to save the field
							url.val( 'https://' + val ).
									trigger( 'change' );
						}
					} );

					// Append a new row to our list of elements
					function ankyAppendRow( $element, defaultValue = '' ) {
						let newRow = '<div class="anky-repeater-row" style="display:none">' +
												 '<input type="text" value="' + defaultValue + '" class="anky-repeater-input" placeholder="https://" />' +
												 '<span class="wp-ui-text-highlight dashicons dashicons-sort"></span>' +
												 '<button class="button anky-customize-control-sortable-repeater-delete wp-ui-highlight" type="button">' +
												 '<span class="dashicons dashicons-no-alt"></span></button>' +
												 '</div>';

						$element.find( '.sortable' ).
										 append( newRow );
						$element.find( '.sortable' ).
										 find( '.anky-repeater-row:last' ).
										 slideDown( 'slow', function() {
											 $( this ).
											 find( 'input' ).
											 focus();
										 } );
					}

					// Get the values from the repeater input fields and add to our hidden field
					function ankyGetAllInputs( $element ) {
						let inputValues = $element.find( '.anky-repeater-input' ).
																			 map( function() {
																				 return this.value;
																			 } ).
																			 toArray();
						// Add all the values from our repeater fields to the hidden field (which is the one that actually gets saved)
						$element.find( repeaterCollectionInputSelector ).
										 val( inputValues );
						// Important! Make sure to trigger change event so Customizer knows it has to save the field
						$element.find( repeaterCollectionInputSelector ).
										 trigger( 'change' );
					}
				},

				/**
				 * TinyMCE
				 */
				tinyMCE: function() {
					// Init.
					$( '.customize-control-tinymce-editor' ).
					each( function() {
									const controlID     = $( this ).
												attr( 'id' ),
												controlParams = wp.customize.control( controlID ).params;

									wp.editor.initialize(
											controlID, {
												tinymce     : {
													wpautop : true,
													theme   : 'modern',
													skin    : 'lightgray',
													toolbar1: controlParams.ankyTinymceToolbar1,
													toolbar2: controlParams.ankyTinymceToolbar2
												},
												quicktags   : true,
												mediaButtons: controlParams.ankyMediaButtons
											}
									);
								}
					);
					// Save.
					$( document ).
					on( 'tinymce-editor-init', function( event, editor ) {
						editor.on( 'change', function() {
							tinyMCE.triggerSave();
							$( '#' + editor.id ).
							trigger( 'change' );
						} );
					} );
				},

				/**
				 * Inject additional heading into the menu locations section's head container.
				 */
				languageSwitcher: function() {
					api.section( 'language-switcher', function( section ) {
						section.headContainer.prepend(
								wp.template( 'nav-menu-locations-header' )( {l10n: {locationsTitle: externals.switcher}} )
						);
					} );
				}

			};

			// Start.
			AnkyCustomizer.init();

		}( jQuery, wp.customize, externals )
);
