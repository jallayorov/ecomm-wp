/**
 * Theme bundle file containing all components
 *
 * @package Anky
 */
/*globals $*/

window.anky = {
	VERSION           : 'anky_1.0.0',
	MOBILE_BREAK_POINT: 1088,
	ESCAPE_KEYCODE    : 27, // KeyboardEvent.which value for Escape (Esc) key.
	TAB_KEYCODE       : 9 // KeyboardEvent.which value for Switch (Tab) key.
};

(function( $ ) {
'use strict';
$( window ).
on( 'load', function() {
	window.anky.navigation.run();
	window.anky.select2.run();
	window.anky.lightboxInit.run();
	window.anky.helper.commentFormValidate();
	window.anky.helper.imgUnderlineRemove();
	window.anky.modals.run();
	window.anky.navigation.menuHide();
	window.anky.navigation.headerFixOnScroll();
	window.anky.navigation.setDynamicEvents();
	window.anky.languageSwitcher.run();
	window.anky.slider.run();

	$( document ).
	on( 'click', '.anky-js-toggle-password', window.anky.helper.passShowHide );
} );

$( window ).
on( 'resize', function() {
			window.anky.postWidth();
			window.anky.navigation.menuHide();
			window.anky.navigation.setDynamicEvents();
			window.anky.navigation.headerFixOnScroll();
		}
);

$( window ).
on( 'elementor/frontend/init', function() {
			if ( window.elementorFrontend ) {
				elementorFrontend.hooks.addAction( 'init', window.anky.select2.run );
			}
		}
);

/**
 * Helper for most of class instances
 *
 * @package Anky
 */
/*globals $*/
window.anky.helper = {
	getSelectorFromElement: function( element ) {
		let selector = element.getAttribute( 'data-target' );

		if ( !selector || selector === '#' ) {
			const hrefAttr = element.getAttribute( 'href' );
			selector       = hrefAttr && hrefAttr !== '#' ? hrefAttr.trim() : '';
		}

		try {
			return document.querySelector( selector ) ? selector : null;
		} catch ( _ ) {
			return null;
		}
	},

	// Return first focusable element in passed Node or the Node itself if nothing found.
	getFirstFocusableElem: function( elem ) {
		let focusable = $( elem ).
		find( 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])' );

		return (
				'undefined' !== focusable[0]
		) ? focusable[0] : elem;
	},

	getScrollForElement: function( elem, height ) {
		const SELECTOR_SCROLLBAR_DRAGGER = '.anky-scrollbar-dragger';

		// Set fixed height to select2 dropdown wrapper
		$( elem ).
		css( {
					 'height'  : height,
					 'overflow': 'hidden'
				 } );

		let $child          = $( elem ).
				children().
				not( '.anky-scrollbar-container' ),
				select2Width    = 250,
				$childWidth     = $child.outerWidth() < select2Width ? select2Width : $child.outerWidth(),
				elemHeight      = $( elem ).
				outerHeight(),
				$childHeight    = $( $child ).
				outerHeight(),
				divider         = $childHeight / elemHeight,
				dropdownGutters = 32,
				draggerHeight   = elemHeight / divider - dropdownGutters,
				maxScroll       = $childHeight - elemHeight,
				deltaSize       = 0,
				dragPosTop      = 0,
				negativier      = - 1,
				posTop          = 0;

		if ( elemHeight < $childHeight ) {
			$child.css( {
										'position': 'absolute'
									} );
			$( elem ).
			css( {
						 'width': $childWidth
					 } );

			$( elem ).
			on( 'mousewheel DOMMouseScroll', onWheel );

			let event = null,
					touchS;

			$( elem ).
			on( 'touchstart', function( e ) {
				event = e;
			} );

			$( elem ).
			on( 'touchmove', function( e ) {
				e.preventDefault();

				if ( event ) {
					touchS = negativier * (
							e.touches[0].pageY - event.touches[0].pageY
					) / 5;

					scroll( touchS );
				}
			} );

			$( elem ).
			on( 'touched', function() {
				event = null;
			} );

			_addScrollBar( $( elem ), draggerHeight );
		}

		function onWheel( e ) {
			e = e || window.event;

			let deltaS = e.originalEvent.wheelDelta ? e.originalEvent.wheelDelta * (
					- 1.2
			) : e.originalEvent.detail * 20;

			scroll( deltaS );

			e.preventDefault ? e.preventDefault() : (
					e.returnValue = false
			);
		}

		// Scroll dropdown inner list
		function scroll( delta ) {
			deltaSize  = deltaSize + delta;
			posTop     = negativier * deltaSize / 2;
			dragPosTop = negativier * posTop / divider;

			if ( dragPosTop < 0 ) {
				dragPosTop = 0;
				posTop     = 0;
				deltaSize  = 0;
			} else if (
					negativier * posTop
					> maxScroll ) {
				posTop     = negativier * maxScroll;
				dragPosTop = elemHeight - draggerHeight - dropdownGutters;
				deltaSize  = deltaSize - delta;
			}

			$child.css( 'top', posTop );
			$( SELECTOR_SCROLLBAR_DRAGGER ).
			css( 'top', dragPosTop );
		}

		// Dropdown scroll bar
		function _addScrollBar( selector, dragHeight ) {
			let scrollBar = $( '<div class="anky-scrollbar-container"><div class="anky-scrollbar-dragger"></div></div>' );

			if ( !$( selector ).
			hasClass( 'anky-scrollbar-in' ) ) {
				$( selector ).
				addClass( 'anky-scrollbar-in' ).
				append( scrollBar );
				$( SELECTOR_SCROLLBAR_DRAGGER ).
				css( {
							 'height': dragHeight
						 } );
			}
		}
	},

	passShowHide: function( e ) {
		/**
		 * Shows password input`s value
		 *
		 * When user clicks on toggler this functions checks if password input`s type. If it is "password" it changes it to text to make it readable
		 */
		e.preventDefault();

		let $this                = $( this ),
				$thisSpan            = $this.find( 'span' ),
				selectorIconEye      = 'anky-icon-eye',
				selectorIconEyeSlash = 'anky-icon-eye-slash';
		const $passwordInput     = $this.
		parent().
		find( 'input' );

		if ( 'password' === $passwordInput.attr( 'type' ) ) {
			$passwordInput.attr( 'type', 'text' );
			$thisSpan.
			addClass( selectorIconEye ).
			removeClass( selectorIconEyeSlash );
		} else {
			$passwordInput.attr( 'type', 'password' );
			$thisSpan.
			addClass( selectorIconEyeSlash ).
			removeClass( selectorIconEye );
		}
	},

	commentFormValidate: function() {

		// Comment form validate
		let $form      = $( '#commentform' ),
				$submitBtn = $form.find( '#submit' ),
				$fields    = $form.find( 'input[type="text"], #email, textarea' ),
				fieldsArr  = Array.from( $fields );

		$submitBtn.attr( 'disabled', 'disabled' );

		$( $fields ).
		on( 'focusout', function( e ) {
			let valueCheck = false,
					checkValue;

			if ( $( e.currentTarget[0] ).
			is( '#email' ) ) {
				checkValue = false === validateEmail( e.target.value );
			} else {
				checkValue = '' === e.target.value;
			}

			// Disable submit button if fields are empty or remove error styles from fields
			checkValue ? errorInputVal( e.target, $submitBtn ) : e.target.style.borderColor = '';

			for ( let i = 0; i < fieldsArr.length; i ++ ) {
				if ( $( fieldsArr[i] ).
				is( '#email' ) ) {
					valueCheck = validateEmail( fieldsArr[i].value );
				} else {
					valueCheck = '' !== fieldsArr[i].value;
				}

				if ( valueCheck === false ) {
					break;
				}
			}
			valueCheck ? $submitBtn.removeAttr( 'disabled' ) : $submitBtn.attr( 'disabled', 'disabled' );
		} );

		// Add style to inputs, toggle button statement
		function errorInputVal( elem, btn ) {
			elem.style.borderColor = 'red';
			btn.attr( 'disabled', 'disabled' );
		}

		// Email field validate
		function validateEmail( email ) {
			let re = /\S+@\S+\.\S+/;
			return re.test( email );
		}
	},

	imgUnderlineRemove: function() {
		/**
		 * Gives class for img elements which are child element of link but shouldnt have underline that all links have
		 *
		 * Inside content container almost all links should have underline but img links are exception.
		 * This function checks if img`s parent is link. If img`s parent is link than it adds class for this link.

		 */
		let img = $( '.site-main img' );

		img.each( function() {
			let $thisParents = $( this ).
			parents( 'a' );
			if ( $thisParents.length ) {
				$thisParents.
				addClass( 'remove_underline' );
			}
		} );
	},

	enforceFocus: function( e, modal, target ) {
		if ( e.keyCode === window.anky.TAB_KEYCODE ) {
			let focusable = $( modal ).
			find( target );

			if ( focusable.length ) {
				let first = focusable[0];
				let last  = focusable[focusable.length - 1];
				let shift = e.shiftKey;
				if ( shift ) {
					if ( e.target === first ) { // shift-tab pressed on first input in dialog
						last.focus();
						e.preventDefault();
					}
				} else {
					if ( e.target === last ) { // tab pressed on last input in dialog
						first.focus();
						e.preventDefault();
					}
				}
			}
		}
	},

	filterInitCheck: function (elem) {
		let elemHeight = elem.height()
		if (0 == elemHeight) {
			location.reload();
		}
	}
};

/**
 * File lightbox.js.
 *
 * @package Anky
 */
/*globals $*/

window.anky.lightboxInit = {
	FULLSCREEN_BTN: '.fullscreen',
	CLASS_IMG_WRAP: '.blocks-gallery-grid, .format-gallery',
	SELECTOR_MODAL: '.lg-outer',

	run: function() {
		// Lightgallery lightbox initializing
		$( window.anky.lightboxInit.CLASS_IMG_WRAP ).
		each( function( i, obj ) {
			let $lg = $( obj );

			$lg.lightGallery(
					{
						selector               : 'a[href*=".jpg"], a[href*=".png"], a[href*=".gif"]',
						download               : false,
						subHtmlSelectorRelative: true,
						mode                   : 'lg-fade'
					}
			);

			// Adding fullscreen events after lightbox initialized
			$lg.on( 'onAfterOpen.lg', function() {
				let $elem = $( window.anky.lightboxInit.SELECTOR_MODAL )[0];

				$( document ).
				on( 'click', window.anky.lightboxInit.FULLSCREEN_BTN, function() {
					window.anky.lightboxInit.toggleFullscreen( $elem );
				} );

				$lg.
				on( 'onCloseAfter.lg', window.anky.lightboxInit.closeFullscreen );

				$( $elem ).
				on( 'fullscreenchange', window.anky.lightboxInit.closeFullscreen );
			} );
		} );
	},

	// Fullscreen mode toggling
	toggleFullscreen: function( elem ) {
		if ( !document.fullscreenElement ) {
			elem.
			requestFullscreen().
			catch( function( err ) {
				`Error attempting to enable full-screen mode: ${ err.message } (${ err.name })`;
			} );
			$( window.anky.lightboxInit.FULLSCREEN_BTN ).
			addClass( 'opened' );
		} else {
			document.exitFullscreen();
			$( window.anky.lightboxInit.FULLSCREEN_BTN ).
			removeClass( 'opened' );
		}
	},

	// Fullscreen mode close
	closeFullscreen: function() {
		if ( !document.fullscreenElement ) {
			$( window.anky.lightboxInit.FULLSCREEN_BTN ).
			removeClass( 'opened' );
		}
	}
};

/**
 * File search-modal.js.
 *
 * @package Anky
 */
/*globals $*/

window.anky.modals = {
	DATA_KEY               : 'anky.modal',
	EVENT_KEY              : '.anky.modal',
	DATA_API_KEY           : '.data-api',
	EVENT_HIDE             : `hide.anky.modal`,
	EVENT_HIDDEN           : `hidden.anky.modal`,
	EVENT_SHOW             : `show.anky.modal`,
	EVENT_SHOWN            : `shown.anky.modal`,
	EVENT_FOCUSIN          : `focusin.anky.modal`,
	EVENT_CLICK_DISMISS    : `click.dismiss.anky.modal`,
	EVENT_KEYDOWN_DISMISS  : `keydown.dismiss.anky.modal`,
	EVENT_MOUSEDOWN_DISMISS: `mousedown.dismiss.anky.modal`,
	EVENT_CLICK_DATA_API   : `click.anky.modal.data-api`,

	CLASS_NAME_SCROLLABLE: 'modal-shell-scrollable',
	CLASS_NAME_OPEN      : 'anky-modal-open',
	CLASS_NAME_SHOW      : 'anky-modal-show',
	CLASS_SCROLL_LOCK    : 'anky-scroll-lock-modal',

	SELECTOR_DIALOG      : '.anky-modal-shell',
	SELECTOR_BODY        : 'body',
	SELECTOR_MODAL       : '#search-modal-wrap',
	SELECTOR_MODAL_BODY  : '.modal-body',
	SELECTOR_DATA_TOGGLE : '[data-toggle="modal"]',
	SELECTOR_DATA_DISMISS: '[data-close="modal"]',
	SELECTOR_SEARCH_INPUT: '.anky-search-input',
	SELECTOR_TARGETS     : 'input,button,select,textarea',
	TRANSITION_END       : 'transitionend',
	Default              : {
		keyboard: true,
		focus   : true,
		show    : true
	},
	config               : '',
	target               : '',
	thisElement          : '',
	thisIsShown          : false,
	thisIsTransitioning  : false,

	run: function() {
		$( document ).
		on( window.anky.modals.EVENT_CLICK_DATA_API, window.anky.modals.SELECTOR_DATA_TOGGLE, function( event ) {
			const selector = window.anky.helper.getSelectorFromElement( this );

			if ( selector ) {
				window.anky.modals.target = selector;
			}

			window.anky.modals.config = $( window.anky.modals.target ).
			data( window.anky.modals.DATA_KEY ) ?
					'toggle' : {
						...$( window.anky.modals.target ).
						data(),
						...$( this ).
						data()
					};

			if ( 'A' === this.tagName || 'AREA' === this.tagName ) {
				event.preventDefault();
			}

			const $target = $( window.anky.modals.target ).
			one( window.anky.modals.EVENT_SHOW, function( showEvent ) {
				if ( showEvent.isDefaultPrevented() ) {
					// Only register focus restorer if modal will actually get shown
					return;
				}

				$target.one( window.anky.modals.EVENT_HIDDEN, function() {
					if ( $( this ).
					is( ':visible' ) ) {
						// return focus to trigger element
						focus();
					}
				} );
			} );

			window.anky.modals.thisElement = window.anky.modals.target;
			window.anky.modals.toggle( window.anky.modals.thisElement );
		} );
		$( document ).
		on( 'click', function( e ) {
			if ( !$( e.target ).
			closest( window.anky.modals.SELECTOR_DIALOG ).length && !$( e.target ).
			closest( window.anky.modals.SELECTOR_DATA_TOGGLE ).length ) {
				window.anky.modals.hide( event, $( window.anky.modals.target ).
				find( window.anky.modals.SELECTOR_DIALOG ) );
			}
		} );
	},

	// Init.
	toggle: function( relatedTarget ) {
		let dialog = $( relatedTarget ).
		find( window.anky.modals.SELECTOR_DIALOG );

		return window.anky.modals.thisIsShown ? window.anky.modals.hide( dialog ) : window.anky.modals.show( relatedTarget, dialog );
	},

	// Show Modal.
	show: function( relatedTarget ) {
		if ( window.anky.modals.thisIsShown || window.anky.modals.thisIsTransitioning ) {
			return;
		}

		window.anky.modals.thisIsTransitioning = true;

		const showEvent = $.Event( window.anky.modals.EVENT_SHOW, {
			relatedTarget
		} );

		$( window.anky.modals.thisElement ).
		trigger( showEvent );

		if ( window.anky.modals.thisIsShown || showEvent.isDefaultPrevented() ) {
			return;
		}

		window.anky.modals.thisIsShown = true;

		$( document.htmlElement ).
		addClass( window.anky.modals.CLASS_NAME_OPEN );

		window.anky.modals.setEscapeEvent();

		$( window.anky.modals.thisElement ).
		on(
				window.anky.modals.EVENT_CLICK_DISMISS,
				window.anky.modals.SELECTOR_DATA_DISMISS,
				event => window.anky.modals.hide( event )
		);

		window.anky.modals.showElement( relatedTarget );

		$( window.anky.modals.SELECTOR_BODY ).
		addClass( window.anky.modals.CLASS_SCROLL_LOCK );
	},

	// Hide Modal.
	hide: function( dialogArg ) {
		if ( !window.anky.modals.thisIsShown || window.anky.modals.thisIsTransitioning ) {
			return;
		}
		const hideEvent = $.Event( window.anky.modals.EVENT_HIDE );

		$( window.anky.modals.thisElement ).
		trigger( hideEvent );

		if ( !window.anky.modals.thisIsShown || hideEvent.isDefaultPrevented() ) {
			return;
		}

		window.anky.modals.thisIsShown         = false;
		window.anky.modals.thisIsTransitioning = true;

		window.anky.modals.setEscapeEvent();

		$( document ).
		off( window.anky.modals.EVENT_FOCUSIN );

		$( window.anky.modals.thisElement ).
		removeClass( window.anky.modals.CLASS_NAME_SHOW );

		$( window.anky.modals.thisElement ).
		off( window.anky.modals.EVENT_CLICK_DISMISS );
		$( dialogArg ).
		off( window.anky.modals.EVENT_MOUSEDOWN_DISMISS );

		$( window.anky.modals.thisElement ).
		one( window.anky.modals.TRANSITION_END, event => window.anky.modals.hideModal( event ) );
	},

	dispose: function( dialog ) {
		[window, window.anky.modals.thisElement, dialog].forEach( htmlElement => $( htmlElement ).
		off( window.anky.modals.EVENT_KEY ) );

		/**
		 * `document` has 2 events `EVENT_FOCUSIN` and `EVENT_CLICK_DATA_API`
		 * Do not move `document` in `htmlElements` array
		 * It will remove `EVENT_CLICK_DATA_API` event that should remain
		 */
		$( document ).
		off( window.anky.modals.EVENT_FOCUSIN );

		$.removeData( window.anky.modals.thisElement, window.anky.modals.DATA_KEY );

		window.anky.modals.thisElement         = null;
		dialog                                     = null;
		window.anky.modals.thisIsShown         = null;
		window.anky.modals.thisIsTransitioning = null;
	},

	hideModal: function() {
		$( window.anky.modals.thisElement ).
		css( 'display', 'none' );
		$( window.anky.modals.thisElement ).
		attr( 'aria-hidden', true );
		$( window.anky.modals.thisElement ).
		attr( 'tabindex', '-1' );
		$( window.anky.modals.thisElement ).
		removeAttr( 'aria-modal' );
		$( window.anky.modals.thisElement ).
		removeAttr( 'role' );
		window.anky.modals.thisIsTransitioning = false;

		window.anky.helper.getFirstFocusableElem( $( window.anky.modals.thisElement ) ).
					 focus();

		$( document.htmlElement ).
		removeClass( window.anky.modals.CLASS_NAME_OPEN );

		$( window.anky.modals.thisElement ).
		trigger( window.anky.modals.EVENT_HIDDEN );

		$( window.anky.modals.SELECTOR_BODY ).
		removeClass( window.anky.modals.CLASS_SCROLL_LOCK );
	},

	setEscapeEvent: function() {
		if ( window.anky.modals.thisIsShown ) {
			$( document ).
			on( window.anky.modals.EVENT_KEYDOWN_DISMISS, event => {
						if ( event.which === window.anky.ESCAPE_KEYCODE ) {
							event.preventDefault();
							window.anky.modals.hide();
						}
					}
			);
		} else if ( !window.anky.modals.thisIsShown ) {
			$( window.anky.modals.thisElement ).
			off( window.anky.modals.EVENT_KEYDOWN_DISMISS );
		}
	},

	showElement: function( relatedTarget ) {
		let thisDialog = $( relatedTarget ).
		find( window.anky.modals.SELECTOR_DIALOG );

		const modalBody = thisDialog ? thisDialog.find( window.anky.modals.SELECTOR_MODAL_BODY ) : null;

		$( window.anky.modals.thisElement ).
		css( 'display', 'block' );
		$( window.anky.modals.thisElement ).
		removeAttr( 'aria-hidden' );
		$( window.anky.modals.thisElement ).
		removeAttr( 'tabindex' );
		$( window.anky.modals.thisElement ).
		attr( 'aria-modal', true );
		$( window.anky.modals.thisElement ).
		attr( 'role', 'dialog' );

		if ( $( thisDialog ).
				 hasClass( window.anky.modals.CLASS_NAME_SCROLLABLE ) && modalBody ) {
			modalBody.scrollTop = 0;
		} else {
			$( window.anky.modals.thisElement ).scrollTop = 0;
		}

		setTimeout( function() {
			$( window.anky.modals.thisElement ).
			addClass( window.anky.modals.CLASS_NAME_SHOW );
		}, 0 );

		$( document ).
		on( window.anky.modals.EVENT_KEYDOWN_DISMISS, event => {
			window.anky.helper.enforceFocus( event, window.anky.modals.SELECTOR_MODAL, window.anky.modals.SELECTOR_TARGETS );
		} );

		const shownEvent = $.Event( window.anky.modals.EVENT_SHOWN, {
			relatedTarget
		} );

		$( thisDialog ).
		one( window.anky.modals.TRANSITION_END, function() {
			window.anky.helper.getFirstFocusableElem( $( window.anky.modals.thisElement ) ).
						 focus();

			$( window.anky.modals.thisElement ).
			find( window.anky.modals.SELECTOR_SEARCH_INPUT ).
			focus();
			window.anky.modals.thisIsTransitioning = false;

			$( window.anky.modals.thisElement ).
			trigger( shownEvent );
		} );
	}
};

/**
 * File navigation.js.
 * Handles toggling the navigation menu for small screens and enables TAB key
 * navigation support for dropdown menus.
 *
 *
 * @package Anky
 */
/*globals $*/

window.anky.navigation = {
	/* SELECTORS */
	SELECTOR_MENU                         : '#primary-menu',
	SELECTOR_SUBMENU                      : '.anky-menu-item-has-submenu',
	SELECTOR_BODY                         : 'body',
	SELECTOR_MENU_OPEN                    : '.open',
	SELECTOR_MENU_LINK                    : '.anky-menu-item-link',
	SELECTOR_MENU_LINK_CLASS              : 'anky-menu-item-link',
	SELECTOR_DROPDOWN_BTN                 : '.anky-dropdown-btn',
	SELECTOR_MENU_ITEM                    : '.anky-menu-item',
	SELECTOR_MENU_ITEM_OPENED             : '.anky-menu-item.open',
	SELECTOR_SUBMENU_CHILD_MENU           : '.anky-submenu-list',
	SELECTOR_SUBMENU_CHILD_MENU_SIDE_CLASS: 'anky-lside',
	SELECTOR_PARENT_DROPDOWN_CLASS        : 'parent-opened',
	SELECTOR_PARENT_DROPDOWN              : '.parent-opened',
	SELECTOR_BURGER_BTN                   : '.anky-js-menu-toggle',
	SELECTOR_SUBMENU_LINK                 : '.anky-menu-item-has-submenu > .anky-menu-item-link',
	SELECTOR_MENU_WRAPPER                 : '.anky-menu-wrapper',
	SELECTOR_TARGETS                      : 'input,button,select,textarea,a',
	SELECTOR_HEADER                       : '#masthead',
	SELECTOR_UPPER_HEADER                 : '.anky-upper-header-bar',
	SELECTOR_INNER_HEADER                 : '.anky-header-inner-wrapper',

	/* Classes */
	CLASS_MENU_OPEN      : 'open',
	CLASS_ACTIVE_BURGER  : 'active',
	CLASS_CLOSE_BTN_CLASS: 'anky-toggler-close',
	CLASS_SCROLL_LOCK    : 'anky-scroll-lock',
	CLASS_BODY_MENU_OPEN : 'anky-submenu-opened',
	CLASS_NAV_HIDDEN     : 'anky-nav-hidden',
	CLASS_FIXED_HEADER   : 'anky-fixed-header',

	TIMEOUT_TIME        : 1000,
	SLIDE_TOGGLE_TIME   : 300,
	SLIDE_DELAY_TIME    : 400,
	_isShown            : false,
	_isSubLevelShown    : false,
	_elementHasSubLevels: false,
	_menuBurgerBtnActive: true,
	_headerTop          : 0,

	run: function() {
		$( window.anky.navigation.SELECTOR_MENU ).
		on( 'click mouseenter', window.anky.navigation.SELECTOR_DROPDOWN_BTN, window.anky.navigation.submenuSwitchState );

		// Close navigation dropdown on `ESC` keypress or document on click
		$( document ).
		keydown( function( e ) {
			if ( e.which === window.anky.ESCAPE_KEYCODE ) {
				window.anky.navigation.closeAll();
			}
		} ).
		click( function( e ) {
			if ( !$( window.anky.navigation.SELECTOR_MENU ).
			is( e.target ) && $( window.anky.navigation.SELECTOR_MENU ).
					 has( e.target ).length === 0 ) {
				window.anky.navigation.closeAll();
			}
		} );

		// Menu hide to burger in customizer
		$( window.parent.document.body ).
		find( '[name="header-layout-type"]' ).
		on( 'change', function() {
			setTimeout( function() {
				let menu      = $( window.anky.navigation.SELECTOR_MENU ),
						menuItems = menu.children(),
						flag      = true;

				if ( window.matchMedia( '(min-width: 1087px)' ).matches && flag ) {
					let menuItemsWidth = 0,
							menuWrap       = $( menu ).
							parent()[0],
							menuWrapWidth  = $( menuWrap ).
							outerWidth();
					for ( let i = 0; i < menuItems.length; i ++ ) {
						menuItemsWidth = menuItemsWidth + $( menuItems[i] ).
						outerWidth();
					}

					if ( menuItemsWidth > menuWrapWidth ) {
						$( window.anky.navigation.SELECTOR_HEADER ).
						addClass( window.anky.navigation.CLASS_NAV_HIDDEN );
					}
				}
				$( '.anky-navigation-wrapper' ).
				removeClass( 'hidden' );
				$( window.anky.navigation.SELECTOR_MENU ).
				on( 'click mouseenter', window.anky.navigation.SELECTOR_DROPDOWN_BTN, window.anky.navigation.submenuSwitchState );
			}, 1500 );

			window.anky.navigation.dropDownClassesToggle( 'close' );
		} );
	},

	closeAll: function() {
		let menus = $( window.anky.navigation.SELECTOR_MENU ).
		find( '.open' );
		if ( menus.length ) {
			[...menus].forEach( elem => (
					$( elem ).
					removeClass( window.anky.navigation.CLASS_MENU_OPEN )
			) );
		}
		$( window.anky.navigation.SELECTOR_BODY ).
		removeClass( window.anky.navigation.CLASS_BODY_MENU_OPEN );
		window.anky.navigation._isShown = false;
	},

	/* Toggles Burger and Menu if there is no command */
	toggleBurger: function( command ) {
		const DATA_KEY              = 'anky.menu';
		const EVENT_KEY             = `.${ DATA_KEY }`;
		const EVENT_FOCUSIN         = `focusin${ EVENT_KEY }`;
		const EVENT_KEYDOWN_DISMISS = `keydown.dismiss${ EVENT_KEY }`;

		if ( command === 'open' ) {
			$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
			slideDown( window.anky.navigation.SLIDE_TOGGLE_TIME ).
			addClass( window.anky.navigation.CLASS_ACTIVE_BURGER );

			window.anky.navigation.dropDownClassesToggle( 'open' );

			$( window.anky.navigation.SELECTOR_BURGER_BTN ).
			attr( 'aria-expanded', true );

			$( document ).
			on( EVENT_KEYDOWN_DISMISS, function( event ) {
				window.anky.helper.enforceFocus( event, window.anky.navigation.SELECTOR_MENU_WRAPPER, window.anky.navigation.SELECTOR_TARGETS );
			} );

		} else if ( command === 'close' ) {
			if ( $( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
			hasClass( window.anky.navigation.CLASS_ACTIVE_BURGER ) ) {
				$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
				removeClass( 'anky-animate-in' );

				window.anky.navigation.dropDownClassesToggle( 'close' );
				setTimeout( function() {
					$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
					slideUp( window.anky.navigation.SLIDE_TOGGLE_TIME, function() {
						$( this ).
						removeClass( window.anky.navigation.CLASS_ACTIVE_BURGER );
					} );
				}, window.anky.navigation.SLIDE_DELAY_TIME );
			}

			$( window.anky.navigation.SELECTOR_BURGER_BTN ).
			attr( 'aria-expanded', true );
			$( document ).
			off( EVENT_FOCUSIN );
			$( window.anky.navigation.SELECTOR_BODY ).
			removeClass( window.anky.navigation.CLASS_BODY_MENU_OPEN );
		} else {
			if ( $( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
			hasClass( window.anky.navigation.CLASS_ACTIVE_BURGER ) ) {
				$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
				addClass( 'anky-animate-out' ).
				removeClass( 'anky-animate-in' );
				window.anky.navigation.dropDownClassesToggle( 'close' );

				setTimeout( function() {
					$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
					slideUp( window.anky.navigation.SLIDE_TOGGLE_TIME, function() {
						$( this ).
						removeClass( 'anky-animate-out' ).
						removeClass( window.anky.navigation.CLASS_ACTIVE_BURGER );
					} );
				}, window.anky.navigation.SLIDE_DELAY_TIME );
			} else {
				if ( !$( window.anky.navigation.SELECTOR_HEADER ).
				hasClass( window.anky.navigation.CLASS_FIXED_HEADER ) ) {
					$( 'html, body' ).
					animate( {
										 scrollTop: $( window.anky.navigation.SELECTOR_HEADER ).
										 offset().top
									 }, 200, function() {
						$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
						slideDown( window.anky.navigation.SLIDE_TOGGLE_TIME, function() {
							$( this ).
							addClass( 'anky-animate-in' ).
							addClass( window.anky.navigation.CLASS_ACTIVE_BURGER );
							window.anky.navigation.dropDownClassesToggle( 'open' );
						} );
					} );
				} else {
					$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
					slideDown( window.anky.navigation.SLIDE_TOGGLE_TIME, function() {
						$( this ).
						addClass( 'anky-animate-in' ).
						addClass( window.anky.navigation.CLASS_ACTIVE_BURGER );
						window.anky.navigation.dropDownClassesToggle( 'open' );
					} );
				}
			}

			$( document ).
			on( window.anky.navigation.EVENT_KEYDOWN_DISMISS, function( event ) {
				window.anky.helper.enforceFocus( event, window.anky.navigation.SELECTOR_MENU_WRAPPER, window.anky.navigation.SELECTOR_TARGETS );
			} );

			$( window.anky.navigation.SELECTOR_BURGER_BTN ).
			attr( 'aria-expanded', (
					!!$( window.anky.navigation.SELECTOR_BURGER_BTN ).
					attr( 'aria-expanded' )
			) );
		}
	},

	submenuSwitchState: function( e ) {
		e.stopPropagation();
		let data = window.anky.navigation.prepareState( e );

		if ( e.type === 'mouseenter' && screen.width > window.anky.navigation.MOBILE_SCREEN_BREAKPOINT ) {
			window.anky.navigation.openSubmenu( data );
		} else if ( e.type === 'click' ) {
			if ( window.anky.navigation._isShown && false === window.anky.navigation.isChildList( data.menuItem ) ) {
				window.anky.navigation.closeSubmenu( data );
			} else {
				window.anky.navigation.openSubmenu( data );
			}
		}
	},

	// checks if it item parent is opened
	isChildList: function( item ) {
		return item.parents( window.anky.navigation.SELECTOR_SUBMENU ).
								hasClass( window.anky.navigation.CLASS_MENU_OPEN ) && false === item.hasClass( window.anky.navigation.CLASS_MENU_OPEN );
	},

	/* opens submenu */
	openSubmenu: function( data ) {
		let dataMenuItem = data.menuItem;
		dataMenuItem.add( $( `> ${ window.anky.navigation.SELECTOR_MENU_LINK } + ${ window.anky.navigation.SELECTOR_DROPDOWN_BTN }` ) ).
								 addClass( window.anky.navigation.CLASS_MENU_OPEN );

		if ( dataMenuItem.find( window.anky.navigation.SELECTOR_SUBMENU_CHILD_MENU ).length > 1 ) {
			dataMenuItem.add( $( `> ${ window.anky.navigation.SELECTOR_MENU_LINK } + ${ window.anky.navigation.SELECTOR_DROPDOWN_BTN }` ) ).
									 addClass( window.anky.navigation.SELECTOR_PARENT_DROPDOWN_CLASS );
		}

		data.menuLink.add( dataMenuItem.find( window.anky.navigation.SELECTOR_MENU_LINK ) ).
				 attr( 'aria-expanded', 'true' );

		window.anky.navigation._isShown = true;

		let el       = dataMenuItem.find( window.anky.navigation.SELECTOR_SUBMENU_CHILD_MENU );
		let elRight  = el.offset().left + $( el ).
		width();
		let winWidth = window.innerWidth;

		if ( elRight > winWidth ) {
			$( el ).
			addClass( window.anky.navigation.SELECTOR_SUBMENU_CHILD_MENU_SIDE_CLASS );
		}
		window.anky.navigation.submenuOpened( 'add' );
	},

	/* Closes submenu */
	closeSubmenu: function( data ) {
		let dataMenuItem = data.menuItem;
		dataMenuItem.add( dataMenuItem.find( window.anky.navigation.SELECTOR_MENU_ITEM_OPENED ) ).
								 removeClass( window.anky.navigation.CLASS_MENU_OPEN );

		dataMenuItem.find( window.anky.navigation.SELECTOR_MENU_LINK ).
								 attr( 'aria-expanded', 'false' );

		dataMenuItem.find( window.anky.navigation.SELECTOR_SUBMENU_CHILD_MENU ).
								 removeClass( window.anky.navigation.SELECTOR_SUBMENU_CHILD_MENU_SIDE_CLASS );

		if ( dataMenuItem.parent().
											parent().
											hasClass( 'parent-opened' ) ) {
			window.anky.navigation._isShown = true;
		} else {
			window.anky.navigation._isShown = false;
		}

		if ( data.openedSiblings.length ) {
			data.openedSiblings.removeClass( window.anky.navigation.CLASS_MENU_OPEN );
			window.anky.navigation.openSubmenu( data );
		}
		window.anky.navigation.submenuOpened( 'remove' );
	},

	/* Prepares state */
	prepareState: function( e ) {
		let menuLink,
				menuButton,
				menuItem;

		if ( $( e.currentTarget ).
		hasClass( window.anky.navigation.SELECTOR_MENU_LINK_CLASS ) ) {
			menuLink   = $( e.currentTarget );
			menuButton = menuLink.prev();
			menuItem   = menuLink.parent();
		} else {
			menuButton = $( e.currentTarget );
			menuLink   = menuButton.prev();
			menuItem   = menuLink.parent();
		}

		return {
			menuButton     : menuButton,
			menuLink       : menuLink,
			menuItem       : menuItem,
			openedSiblings : menuItem.siblings( window.anky.navigation.SELECTOR_MENU_OPEN ),
			submenuTopLevel: menuItem.parent( window.anky.navigation.SELECTOR_SUBMENU )
		};
	},

	/* Checking submenu statement */
	submenuOpened: function( event ) {
		if ( !$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
		hasClass( window.anky.navigation.CLASS_ACTIVE_BURGER ) && 'add' === event ) {
			$( window.anky.navigation.SELECTOR_BODY ).
			addClass( window.anky.navigation.CLASS_BODY_MENU_OPEN );
		} else if ( !$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
		hasClass( window.anky.navigation.CLASS_ACTIVE_BURGER ) && 'remove' === event && !$( window.anky.navigation.SELECTOR_SUBMENU_CHILD_MENU ).
		is( ':visible' ) ) {
			$( window.anky.navigation.SELECTOR_BODY ).
			removeClass( window.anky.navigation.CLASS_BODY_MENU_OPEN );
		}
	},

	/* Sets events according to screen size */
	setDynamicEvents: function() {
		const SELECTOR_PARENT_DROPDOWN = '.parent-opened';
		const SELECTOR_SUBMENU         = '.anky-menu-item-has-submenu';
		const SELECTOR_MENU_LINK       = '.anky-menu-item-link';
		const SELECTOR_SUBMENU_LINK    = `${ SELECTOR_SUBMENU } > ${ SELECTOR_MENU_LINK }`;

		if ( screen.width > window.anky.navigation.MOBILE_SCREEN_BREAKPOINT ) {
			$( document ).
			on( 'mouseenter', SELECTOR_SUBMENU_LINK, function( e ) {
				e.stopPropagation();
				if ( $( e.currentTarget ).
						 parent( 'li' ).
						 parent()[0] === $( window.anky.navigation.SELECTOR_MENU )[0] ) {
					window.anky.navigation.closeAll();
				}
				window.anky.navigation.openSubmenu( window.anky.navigation.prepareState( e ) );
			} ).
			on( 'mouseleave', window.anky.navigation.SELECTOR_MENU_OPEN, function( e ) {
				if ( $( e.currentTarget ).
				parents( SELECTOR_PARENT_DROPDOWN ).length ) {
					let target         = e.currentTarget;
					let TIMEOUT_HOLDER = setTimeout( function() {
						$( target ).
						removeClass( window.anky.navigation.CLASS_MENU_OPEN );
						window.anky.navigation._isShown = false;
					}, 500 );

					$( e.currentTarget ).
					on( 'mouseenter', function() {
						clearInterval( TIMEOUT_HOLDER );
					} );
				} else {
					let TIMEOUT_HOLDER = setTimeout( function() {
						if ( $( e.currentTarget ).
						hasClass( window.anky.navigation.SELECTOR_MENU_ITEM ) ) {
							$( e.currentTarget ).
							removeClass( window.anky.navigation.CLASS_MENU_OPEN );
						}
						window.anky.navigation._isShown = false;
						window.anky.navigation.submenuOpened( 'remove' );
					}, window.anky.navigation.TIMEOUT_TIME );

					$( e.currentTarget ).
					on( 'mouseenter', function() {
						clearInterval( TIMEOUT_HOLDER );
					} );
				}
			} );
		}

		if ( true === window.anky.navigation._menuBurgerBtnActive ) {
			$( document ).
			keydown( function( e ) {
				if ( e.which === window.anky.ESCAPE_KEYCODE ) {
					window.anky.navigation.toggleBurger( 'close' );
				}
			} ).
			on( 'click', window.anky.navigation.SELECTOR_BURGER_BTN, function( e ) {
				e.preventDefault();
				window.anky.navigation.toggleBurger();
			} );
			$( document ).
			on( 'focusout', window.anky.navigation.SELECTOR_BURGER_BTN, function() {
				if ( $( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
				hasClass( 'active' ) ) {
					$( document ).
					click( function( e ) {
						if ( !$( e.target ).
						closest( window.anky.navigation.SELECTOR_INNER_HEADER ).length && !$( e.target ).
						closest( window.anky.navigation.SELECTOR_BURGER_BTN ).length ) {
							window.anky.navigation.toggleBurger( 'close' );
							window.anky.navigation.submenuOpened( 'remove' );
						}
					} );
				}
			} );
			window.anky.navigation._menuBurgerBtnActive = false;
		}
	},

	/* Hide navigation */
	menuHide: function() {
		let menu      = $( window.anky.navigation.SELECTOR_MENU ),
				menuItems = menu.children(),
				flag      = true;

		if ( window.matchMedia( '(min-width: 1087px)' ).matches && flag ) {
			let menuItemsWidth = 0,
					menuWrapWidth  = $( menu ).
					parents( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
					outerWidth();
			for ( let i = 0; i < menuItems.length; i ++ ) {
				menuItemsWidth = menuItemsWidth + $( menuItems[i] ).
				outerWidth();
			}

			if ( menuItemsWidth > menuWrapWidth ) {
				$( window.anky.navigation.SELECTOR_HEADER ).
				addClass( window.anky.navigation.CLASS_NAV_HIDDEN );
			} else {
				$( window.anky.navigation.SELECTOR_HEADER ).
				removeClass( 'CLASS_NAV_HIDDEN' );
			}

			if ( !$( window.anky.navigation.SELECTOR_HEADER ).
			hasClass( window.anky.navigation.CLASS_NAV_HIDDEN ) ) {

				if ( $( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
				hasClass( window.anky.navigation.CLASS_ACTIVE_BURGER ) ) {
					$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
					removeClass( 'anky-animate-in' ).
					removeClass( window.anky.navigation.CLASS_ACTIVE_BURGER ).
					css( 'display', '' );
					window.anky.navigation.dropDownClassesToggle( 'close' );
				}

				$( window.anky.navigation.SELECTOR_BURGER_BTN ).
				attr( 'aria-expanded', true );
			}

			flag = false;
		} else {
			$( window.anky.navigation.SELECTOR_MENU_WRAPPER ).
			css( 'display', '' );
		}

		$( '.anky-navigation-wrapper' ).
		removeClass( 'hidden' );
	},

	// Fix header position on scrolling
	headerFixOnScroll: function() {
		window.anky.navigation._headerTop = $( window.anky.navigation.SELECTOR_HEADER ).
		offset().top;
		let headerHeight                      = $( window.anky.navigation.SELECTOR_INNER_HEADER ).
		outerHeight();

		// set height to header bar wrapper
		$( window.anky.navigation.SELECTOR_HEADER ).
		height( headerHeight );

		//Fix header bar on scrolling
		$( window ).
		on( 'scroll', function() {
			let scrollTop = $( window ).
			scrollTop();

			if ( scrollTop >= window.anky.navigation._headerTop ) {
				$( window.anky.navigation.SELECTOR_HEADER ).
				addClass( 'anky-fixed-header' );
			} else {
				$( window.anky.navigation.SELECTOR_HEADER ).
				removeClass( 'anky-fixed-header' );
			}
		} ).
		trigger( 'scroll' );
	},

	dropDownClassesToggle: function( ev ) {
		let $body              = $( window.anky.navigation.SELECTOR_BODY ),
				$selectorBurgerBtn = $( window.anky.navigation.SELECTOR_BURGER_BTN ),
				$header            = $( window.anky.navigation.SELECTOR_HEADER ),
				classScrollLock    = window.anky.navigation.CLASS_SCROLL_LOCK,
				classCloseBtn      = window.anky.navigation.CLASS_CLOSE_BTN_CLASS,
				classOpen          = 'dropdown-opened',
				documentWidth      = document.documentElement.clientWidth,
				cred               = Math.abs( window.innerWidth - documentWidth );

		if ( ev === 'close' ) {
			$header.removeClass( classOpen );
			$selectorBurgerBtn.removeClass( classCloseBtn );
			$body.removeClass( classScrollLock );

			$body.css(
					{
						'padding-right': '',
						'overflow'     : ''
					}
			);

			$( window.anky.navigation.SELECTOR_INNER_HEADER ).
			css( 'overflow-y', '' );
		} else if ( ev === 'open' ) {
			$header.addClass( classOpen );
			$selectorBurgerBtn.addClass( classCloseBtn );
			$body.addClass( classScrollLock );

			$body.css(
					{
						'padding-right': cred,
						'overflow'     : 'hidden'
					}
			);

			$( window.anky.navigation.SELECTOR_INNER_HEADER ).
			css( 'overflow-y', 'scroll' );
		}
	}

};

/**
 * File select2-init.js.
 *
 * @package Anky
 */
/*globals anky, $*/

anky.select2 = {

	run: function() {
		/**
		 * ------------------------------------------------------------------------
		 * Constants
		 * ------------------------------------------------------------------------
		 */

		const CLASS_ARCHIVE_DROPDOWN = 'select';

		// Select2 init
		window.anky.select2.initSelect2( $( CLASS_ARCHIVE_DROPDOWN ) );

		$( '.widgets-area, .anky-menu-wrapper' ).
		on( 'DOMSubtreeModified', function() {
			setTimeout( function() {
				window.anky.select2.initSelect2( $( CLASS_ARCHIVE_DROPDOWN ) );
			}, 0 );
		} );

		// Select2 dropdowns custom scroll init
		$( document ).
		on( 'select2:open', 'select', function() {
			let $dropdown = $( 'body' ).
			children( '.select2-container--open' ).
			last();

			setTimeout( function() {
				window.anky.helper.getScrollForElement( $dropdown, 352 );
			}, 0 );
		} );
	},

	// Select2 initialization
	initSelect2: function() {
		let elem = $( document ).
		find( 'select' );

		$( elem ).
		each( function( i, obj ) {
			if ( !$( obj ).
			hasClass( 'select2-hidden-accessible' ) ) {
				$( obj ).
				select2(
						{
							theme           : 'classic',
							dropdownCssClass: 'anky-select2-dropdown-inner',
							width           : 'auto'
						}
				);
			}
		} );
	}

};

/**
 * File slider.js.
 *
 * @package Anky
 */
/*globals anky, $, Swiper*/

anky.slider = {

	run: function() {

		// Constants
		// Add to array objects with slider options
		const SLIDER_SELECTORS = [
			{
				selector       : '.post-template-default:not(.single-format-gallery) .anky-content-container .gallery',
				additionalClass: 'anky-gallery-container',
				items          : '1',
				nav            : true,
				dots           : true,
				margin         : 0
			},
			{
				selector       : 'aside.widget_media_gallery .gallery',
				additionalClass: 'anky-aside-gallery-container',
				items          : '1',
				nav            : true,
				dots           : true,
				margin         : 0
			},
			{
				selector       : '.anky-related-posts-wrap',
				additionalClass: 'anky-related-posts-container',
				items          : '1',
				nav            : true,
				dots           : false,
				margin         : 32
			},
			{
				selector       : '.tag-tiled .gallery',
				additionalClass: 'anky-gallery-container',
				items          : '1',
				nav            : true,
				dots           : true,
				margin         : 0
			}
		];

		setTimeout( window.anky.postWidth, 0 );

		// initializing each one
		$( SLIDER_SELECTORS ).
		each( window.anky.slider.sliderInit );
	},

	sliderInit: function( target ) {
		// Swiper slider initializing function
		target = target.length ? target : this;

		let $additionalClass        = target.additionalClass,
				margin                  = target.margin ? target.margin : 0,
				items                   = target.items,
				arrows                  = target.nav,
				bullets                 = target.dots,
				swiperContainerSelector = $( target.selector ).
				wrap( '<div class="swiper-container ' + $additionalClass + '" style="' + $( target.selector ).
				attr( 'style' ) + '"></div>' ).
				removeAttr( 'style' ).
				parent(),
				$swiperWrapper          = $( target.selector ).
				addClass( 'swiper-wrapper' ),
				$itemsSelector          = $( target.selector ).
				children().
				addClass( 'slider-item' ),
				$swiperSelector         = $( swiperContainerSelector )[0];

		// Adding HTML for slider navigation n bullets
		if ( false !== bullets ) {
			$( $( target.selector )[0] ).
			after( '<div class="swiper-pagination"></div>' );
		}

		if ( arrows ) {
			$( $( target.selector )[0] ).
			after( '<div class="slider-nav"><div class="swiper-button-prev"></div><div class="swiper-button-next"></div></div>' );
		}

		// Disabling bullets
		if ( 1 === $( $itemsSelector ).length || false === bullets ) {
			$( $swiperWrapper ).
			parent().
			find( '.swiper-pagination' ).
			addClass( 'anky-swiper-pagination-disabled' );
		}

		// slider needs setTimeout to calculate width on post pages
		setTimeout( function() {
			new Swiper( $swiperSelector, {
				slidesPerView: items,
				wrapperClass : 'swiper-wrapper',
				slideClass   : 'slider-item',
				navigation   : arrows ? {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev'
				} : false,
				pagination   : bullets ? {
					el  : '.swiper-pagination',
					type: 'bullets'
				} : false,
				spaceBetween : margin
			} );
		}, 0 );
	}

};

/**
 * File language-switcher.js.
 * Handles toggling the language-switcher.js
 *
 * @package Anky
 */
/*globals $*/

window.anky.languageSwitcher = {
	listWrapSelector   : '.anky-language-switcher-list-wrapper',
	listSelector       : '.anky-language-switcher-list',
	listCurrentSelector: '.anky-language-switcher-current',
	listOpenedClass    : 'opened',

	run: function() {
		if ( !window.anky.languageSwitcher.listSelector.length ) {
			return false;
		}

		$( window.anky.languageSwitcher.listCurrentSelector ).
		on( 'click', function() {
			$( this ).
			toggleClass( window.anky.languageSwitcher.listOpenedClass ).
			siblings( window.anky.languageSwitcher.listWrapSelector ).
			slideToggle();

			setTimeout( function() {
				window.anky.helper.getScrollForElement( window.anky.languageSwitcher.listWrapSelector, 352 );
			}, 0 );

			$( document ).
			click( function( e ) {
				if ( !$( e.target ).
				closest( window.anky.languageSwitcher.listWrapSelector ).length && !$( e.target ).
				closest( window.anky.languageSwitcher.listCurrentSelector ).length ) {
					$( window.anky.languageSwitcher.listCurrentSelector ).
					removeClass( window.anky.languageSwitcher.listOpenedClass ).
					siblings( window.anky.languageSwitcher.listWrapSelector ).
					slideUp();
				}
			} );
		} );
	}
};

/**
 * File set-post-width.js.
 *
 * Adjust Align Position
 *
 * @package Anky
 */
/*globals $*/

window.anky.postWidth = function() {
	/**
	 * Calls setPostWidth() function with different parameters
	 *
	 * Function checks if there is page-sidebar.
	 * If it is not it calls setWidthAndPosition() for elements that should have full width and should be aligned.
	 *
	 */
	const $body = $( 'body' );

	if ( !$body.
	hasClass( 'anky-has-sidebar' ) ) {
		setPostWidth( '.alignfull', '#page' );
		setPostWidth( '.alignwide' );
		setPostWidth( '.anky-gallery-container' );
		setPostWidth( '.wp-block-quote.is-style-large' );
		setPostWidth( '.wp-block-pullquote' );
		setPostWidth( '.wp-block-separator.is-style-wide' );

		/**
		 * Sets full width of the parent for the element and aligns element`s left corner to parent`s left corner
		 *
		 * There are elements inside content-container but should have full width of the main container/body.
		 * Usually they have a class .alignwide and .alignfull.
		 *
		 *
		 * @param { DOM element }   selector           Element that should have full width and be aligned.
		 * @param { DOM element }   parentSelector     passed element should have the width of this selector.
		 *
		 */
		function setPostWidth( selector, parentSelector ) {

			$( selector ).
			each( function() {

				let $this       = $( this ),
						parent      = parentSelector ? parentSelector : '.anky-container',
						parentWidth = $( this ).
						closest( parent ).
						width();

				$this.
				css( 'left', '0' );

				const parentLeftCoordinate   = $( parent ).
				offset().left;
				const selectorLeftCoordinate = $this.
				offset().left;
				const parentPaddingLeft      = parseInt(
						$( parent ).
						css( 'padding-left' ).
						replace( 'px', '' )
				);

				if ( window.matchMedia( `(min-width: ${ window.anky.MOBILE_BREAK_POINT }px)` ).matches ) {
					$this.
					css(
							{
								position: 'relative',
								width   : parentWidth,
								left    : parentLeftCoordinate - selectorLeftCoordinate + parentPaddingLeft
							}
					);
				} else {
					$this.
					css(
							{
								position: 'relative',
								width   : '',
								left    : ''
							}
					);
				}
			} );
		};
	}

	const thumbnails = $( 'article.anky-content-container .post-thumbnail' );
	thumbnails.each( function() {
		let $this     = $( this ),
				imgWidth  = $this.children( 'img' ).
													width(),
				imgHeight = $this.children( 'img' ).
													height();

		if ( imgWidth > imgHeight ) {
			if ( $body.
					 hasClass( 'single-post' ) || $body.
					 hasClass( 'page' ) ) {
				if ( !$body.
				hasClass( 'anky-has-sidebar' ) && !$this.
				parent().
				hasClass( 'anky-related-post' ) ) {
					setPostWidth( $this );
				}
			} else {
				$this.
				addClass( 'anky-horizontal-thumbnail' );
			}
		} else if ( imgWidth < imgHeight ) {
			$this.
			addClass( 'anky-vertical-thumbnail' );
		}
	} );

	$( '.entry-content table' ).
	wrap( '<div class="anky-table-wrap"></div>' );
};

})( jQuery );
