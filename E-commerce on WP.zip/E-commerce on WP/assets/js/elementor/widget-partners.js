/**
 * Partners widget marque
 * Partners widget marque template 2 custom
 *
 * @package Anky/Elementor
 */
(
		function( $ ) {
			'use strict';
			let partnersMarque = function() {
				let $partnersWrapper = $( '.anky-partners-section-2 .anky-swiper-partners-wrapper' );
				if ( !$partnersWrapper.length ) {
					return;
				}

				let $winWidth = $( window ).
				width();
				$partnersWrapper.
				each( function() {
					let $partnersWrap        = $( this ),
							$widgetWrap          = $partnersWrap.closest( '.elementor-widget-anky_partners' ).
																									 data( 'id' ),
							$partnersParent      = $partnersWrap.parent(),
							$partnersParentClass = $partnersParent.attr( 'class' ),
							$partnersClone       = $partnersWrap.clone().
																									 appendTo( $partnersParent ),
							partnersParentLeft   = $partnersParent.offset().left,
							$partnersParentWidth = $partnersWrap.width(),
							transformWidth       = (
																				 $partnersParentWidth
																		 ) + partnersParentLeft,
							animationName        = `marqueeAnimation${ $partnersWrap.parents( 'section' ).
																																			 data( 'id' ) }`;

					if ( $partnersParentWidth > $winWidth ) {
						let animationDuration = $partnersWrap.children().length * 2.5;
						$partnersParent.css( 'transform', `translateX(-${ partnersParentLeft }px)` );

						$( 'head' ).
						append( `<style>[data-id="${ $widgetWrap }"] .${ $partnersParentClass }{ animation: ${ animationDuration }s linear 0s infinite normal none running ${ animationName } } @keyframes ${ animationName } {100% {transform: translateX( -${ transformWidth }px )}}</style>` );
					}
				} );
			};

			$( window ).
			on( 'elementor/frontend/init', function() {
				if ( window.elementorFrontend ) {
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_partners.default', partnersMarque );
				}
			} );
		}
)( jQuery );