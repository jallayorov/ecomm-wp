/**
 * Portfolio isotope
 *
 * @package Anky/Elementor
 */
(
		function( $ ) {
			'use strict';
			let filterWorker = function() {
				setTimeout( function() {
					$( '.anky-portfolio-section' ).
					each( function() {
						let $this        = $( this ),
								iso          = $this.find( '.anky-portfolio-section-body' ),
								skinNumber   = $this.data( 'skin' ),
								itemSelector = '.anky-portfolio-section-item',
								togglerBtn   = $this.find( '.anky-portfolio-section-list button' );

						// template 1 style masonry
						if ( 1 === skinNumber ) {
							iso.
							isotope( {
												 itemSelector: itemSelector,
												 masonry     : {
													 gutter: 32
												 }
											 } );

							//  template 4 and template 5 have not gutters
						} else if ( 4 === skinNumber || 5 === skinNumber ) {
							$this.closest( '.elementor-container' ).
										addClass( 'anky-portfolio-section-full' );

							iso.
							isotope( {
												 itemSelector: itemSelector,
												 masonry     : {
													 gutter: 16
												 }
											 } );
						}

						// other templates have gutters
						else {
							iso.
							isotope( {
												 itemSelector: itemSelector,
												 layoutMode  : 'fitRows',
												 fitRows     : {
													 gutter: 32
												 }
											 } );
						}

						window.anky.helper.filterInitCheck(iso);

						$( togglerBtn ).
						click( function( e ) {
							e.stopImmediatePropagation();

							let filterValue = '*' === $( this ).
							data( 'filter' )
									? 'anky-portfolio-section-item' : $( this ).
									data( 'filter' );

							iso.isotope( {filter: `.${ filterValue }`} );

							$this.find( '.anky-portfolio-section-list button.active' ).
										removeClass( 'active' );

							$( this ).
							addClass( 'active' );
						} );

						// horizontal scroll for anky-portfolio-section-list
						let listParent = $( $this.find( '.anky-portfolio-section-list' ) ),
								isDown     = false,
								startX,
								scrollLeft;

						listParent.mousedown( function( e ) {
							isDown = true;
							listParent.addClass( 'active' );
							startX     = e.pageX - listParent.offset().left;
							scrollLeft = listParent.scrollLeft();
						} );

						listParent.mouseleave( function() {
							isDown = false;
							listParent.removeClass( 'active' );
						} );

						listParent.mouseup( function() {
							isDown = false;
							listParent.removeClass( 'active' );
						} );

						listParent.mousemove( function( e ) {
							if ( !isDown ) {
								return;
							}
							e.preventDefault();
							const x    = + (
									e.pageX - listParent.offset().left
							);
							const walk = x - startX;
							listParent.scrollLeft( scrollLeft - walk );
						} );
					} );
				}, 1000 );
			};

			$( window ).
			on( 'elementor/frontend/init', function() {
				if ( window.elementorFrontend ) {
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_portfolio.default', filterWorker );
				}
			} );
		}
)( jQuery );