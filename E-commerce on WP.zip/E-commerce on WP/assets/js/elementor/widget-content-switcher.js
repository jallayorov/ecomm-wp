/**
 * Content switcher
 * Pricing widget content switcher or tabs
 *
 * @package Anky/Elementor
 */
(
		function( $ ) {
			'use strict';
			let contentToggleHandler = function() {
				let $button = $( '.anky-content-switcher-switch-button' );

				$button.on( 'click', function() {
					let btnAttrEq         = $( this ).
							data( 'heading-eq' ),
							$parent           = $( this ).
							parents( '.anky-content-switcher-container' ),
							$tab              = $( $parent ).
							find( `[data-tab-eq="${ btnAttrEq }"]` ),
							buttonActiveClass = 'anky-content-switcher-heading-active',
							tabActiveClass    = 'anky-content-switcher-tab-active';

					if ( !$( this ).
					hasClass( buttonActiveClass ) ) {
						$( this ).
						addClass( buttonActiveClass ).
						siblings().
						removeClass( buttonActiveClass );
						$( $tab ).
						addClass( tabActiveClass ).
						siblings().
						removeClass( tabActiveClass );
					}
				} );

			};

			$( window ).
			on( 'elementor/frontend/init', function() {
				if ( window.elementorFrontend ) {
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_content_switcher.default', contentToggleHandler );
				}
			} );
		}
)( jQuery );