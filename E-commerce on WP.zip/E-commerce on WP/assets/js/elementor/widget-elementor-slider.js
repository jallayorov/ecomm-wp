/**
 * Swiper slider initialization
 * We can use it for all types of templates
 *
 * @package Anky/Elementor
 */
(
		function( $ ) {
			'use strict';
			let elementorSlider = function() {
				// Elementor widget Slider
				let ankySliders = $( '.anky-slider-parent[data-anky-slider]' );

				if ( !ankySliders.length ) {
					return;
				}

				$( ankySliders ).
				each( createSlider );

				// get json from attribute and parce it
				function createSlider() {
					let $this      = $( this ),
							sliderData = JSON.parse( $( this ).
																			 attr( 'data-anky-slider' ) );
					if ( !sliderData.length ) {
						return;
					}

					//Add class to elementor section wrapper
					if ( $this.parent().
										 hasClass( 'anky-testimonials-skin_3' ) ) {
						$this.closest( 'section' ).
									addClass( 'anky-testimonials-skin_3-wrapper' );
					} else {
						$this.closest( 'section' ).
									removeClass( 'anky-testimonials-skin_3-wrapper' );
					}

					// check delay of autoplay
					if ( sliderData[1].autoplay && null === sliderData[1].autoplay.delay ) {
						delete sliderData[1].autoplay;
					}

					// set spaceBetween slides from hidden-block (width)
					let ankyElementorSlider = '';
					sliderData[1].autoHeight    = false;
					sliderData[1].lazyLoading = true;
					sliderData[1].watchSlidesVisibility = 1;


					// init Slider
					setTimeout( () => {
						ankyElementorSlider = new Swiper( `${ sliderData[0] }`, sliderData[1] );

						ankyElementorSlider.on( 'slideChange', function() {
							$this.find( '.swiper-pagination-bullet' ).
										removeClass( 'swiper-pagination-bullet-active' );
							$this.find( '.swiper-pagination-bullet:eq(' + ankyElementorSlider.activeIndex + ')' ).
										addClass( 'swiper-pagination-bullet-active' );
						} );

					}, 16 );

					// Class toggler
					function classListToggler( selector, addClass, removeClass ) {
						let el = $( `${ selector }` );

						el.removeClass( removeClass );
						el.addClass( addClass );
					}

					// Elementor widget Slider additional options for text
					if ( 'outside' === sliderData[2].slideTextOptions ) {
						classListToggler( `${ sliderData[0] } .swiper-slide p`, 'outside', 'inside' );
						classListToggler( `${ sliderData[0] }`, 'y-visible', 'overflow-hidden' );
					} else if ( 'inside' === sliderData[2].slideTextOptions ) {
						classListToggler( `${ sliderData[0] } .swiper-slide p`, 'inside', 'outside' );
						classListToggler( `${ sliderData[0] }`, 'overflow-hidden', 'y-visible' );
					}

					// Elementor widget Slider additional options for Pagination location
					if ( 'bottom' === sliderData[2].paginationLocation ) {
						classListToggler( `${ sliderData[0] } .anky-swiper-pagination`, 'position-bottom', 'position-top' );
					} else if ( 'top' === sliderData[2].paginationLocation ) {
						classListToggler( `${ sliderData[0] } .anky-swiper-pagination`, 'position-top', 'position-bottom' );
					}

					// Elementor widget Slider additional options (arrow hide in mobile)
					if ( sliderData[2].hideArrows ) {
						const rightArrow = $( `${ sliderData[0] } .swiper-button-next` );
						const leftArrow  = $( `${ sliderData[0] } .swiper-button-prev` );

						rightArrow.addClass( 'hide-arrows' );
						leftArrow.addClass( 'hide-arrows' );
					}

					// Elementor widget Slider additional options (animation toggler)
					setTimeout( () => {
						if ( sliderData[2].isAnimation ) {
							const slidesLength      = ankyElementorSlider.slides.length - 2;
							const createProgressBar = () => {
								const div = document.createElement( 'div' );
								div.classList.add( 'progressBarContainer' );
								const progressBlock = `<div><span class="progressBar"><div class="inProgress" style="--anky-slider-transition: ${ sliderData[1].autoplay.delay }ms"></div></span></div>`;

								for ( let i = 0; i < slidesLength; i ++ ) {
									div.innerHTML += progressBlock;
								}

								ankyElementorSlider.el.after( div );
							};

							createProgressBar();

							const progressBars = document.querySelectorAll( '.progressBarContainer span.progressBar .inProgress' );

							ankyElementorSlider.on( 'activeIndexChange', () => {
								setInterval( () => {
									progressBars[ankyElementorSlider.realIndex].style.transition = '';
									progressBars[ankyElementorSlider.realIndex].style.width      = '100%';
								}, 30 );

								if ( 0 === ankyElementorSlider.realIndex ) {
									progressBars.forEach( progressBar => {
										progressBar.style.width      = 0;
										progressBar.style.transition = 'none';
									} );
								} else if ( ankyElementorSlider.realIndex > 0 ) {
									progressBars[0].style.width      = '100%';
									progressBars[0].style.transition = 'none';
								}
							} );

							if ( 0 === ankyElementorSlider.realIndex ) {
								setTimeout( () => {
									progressBars[0].style.width = '0';
								}, 20 );

								setTimeout( () => {
									progressBars[0].style.width = '100%';
								}, 30 );
							}
						}
					}, 20 );
				}
			};

			$( window ).
			on( 'elementor/frontend/init', function() {
				if ( window.elementorFrontend ) {
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_posts.default', elementorSlider );
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_slider.default', elementorSlider );
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_testimonials.default', elementorSlider );
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_team.default', elementorSlider );
				}
			} );
		}
)( jQuery );