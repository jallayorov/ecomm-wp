/**
 * Widget FAQ
 * Elementor FAQ widget scripts
 *
 * @package Anky/Elementor
 */
/* global elementorFrontend*/
(
		function( $ ) {
			'use strict';
			let docCurPos = 0;
			// Accordion for FAQ widget
			let accordion = function() {
				let $title = $( '.anky-faq-accordion-item-title' );

				$title.
				off().
				on(
						'click', function() {

							let $this     = $( this ),
									openClass = 'open';

							$this.
							next().
							stop().
							slideToggle().
							parent( '.anky-faq-accordion-item' ).
							toggleClass( openClass ).
							siblings().
							removeClass( openClass ).
							find( '.anky-faq-accordion-content' ).
							stop().
							slideUp();
						}
				);
			};

			// FAQ template 2 form toggler
			let faq2FormSwitcher = function() {
				if ( !$( '.anky-faq-accordion-section-template2' ).length ) {
					return;
				}
				const $formSwitchBtn = $( '.anky-js-switch' ),
							$faqWrapper    = $formSwitchBtn.parents( '.anky-faq-accordion-section-template2' ),
							formOpenClass  = 'anky-faq-form-opened';

				$formSwitchBtn.
				on( 'click', function() {
					$faqWrapper.toggleClass( formOpenClass );
				} );
			};

			//FAQ template 5 aside list fixation
			let stickyScrollSpy = function() {
				let $ankySticky = $( '.anky-sticky-scrollspy' ),
						$links          = $ankySticky.find( 'a' );

				if ( !$ankySticky.length ) {
					return;
				}
				let stickyHeight = $ankySticky.
						height(),
						stickyParent = $ankySticky.parent(),
						isDesktop    = $( window ).
													 width() > window.anky.MOBILE_BREAK_POINT,
						$navbar      = $( '.anky-site-header' ).
													 height() || 40;

				$ankySticky.css( 'top', $navbar + 'px' );

				if ( !isDesktop ) {
					stickyParent.css( 'height', stickyHeight );
				}

				$( '.anky-sticky-scrollspy a[href^="#"]' ).
				on( 'click', function( e ) {
					e.preventDefault();

					let anchor       = $( this ).
							attr( 'href' ),
							anchorTop    = $( anchor ).
							offset().top,
							scrollHeight = isDesktop ?
									anchorTop - $navbar :
									anchorTop - $navbar - (
																stickyHeight * 2
														);

					$( 'html, body' ).
					stop().
					animate( {
										 scrollTop: scrollHeight
									 }, 250 );

					if ( $links.length ) {
						$links.
						removeClass( 'active' );
					}
					$( this ).
					addClass( 'active' );
				} );

				$( document ).
				on( 'scroll', function() {
					onScroll( $navbar, $ankySticky, $links );
				} );
			};

			let onScroll = function( navbar, $sticky, $links ) {
				if ( !$sticky.length ) {
					return;
				}
				let $widgetParent           = $sticky.parents( '.elementor-widget-container' ),
						stickyParent            = $( '.anky-sticky-scrollspy-parent' ),
						stickyFixedClass        = 'anky-sticky-fixed',
						stickyFixedBotClass     = 'anky-sticky-fixed-bottom',
						stickyListTop           = $sticky.offset().top,
						stickyBotPosition       = stickyListTop + $sticky.height(),
						stickyParentBotPosition = $widgetParent.offset().top + $widgetParent.height(),
						docScrollTop            = $( document ).
						scrollTop(),
						scrollTop               = docScrollTop + navbar,
						stickyTop               = $widgetParent.offset().top,
						docScroll               = docScrollTop > docCurPos,
						sectionHeaderHeight     = $( 'anky-faq-section-title' ).
						height();

				docCurPos = $( document ).
				scrollTop();

				if ( stickyBotPosition > stickyParentBotPosition && docScroll ) {
					stickyParent.addClass( stickyFixedBotClass );
					$sticky.css( 'top', '' );
				} else if ( !docScroll && scrollTop <= stickyListTop ) {
					stickyParent.removeClass( stickyFixedBotClass );
					$sticky.css( 'top', navbar );
				}

				// Add/remove class 'fixed' to category list when its in answers area
				scrollTop >= stickyTop ?
						stickyParent.addClass( stickyFixedClass ) :
						stickyParent.removeClass( stickyFixedClass );

				(
						scrollTop <= stickyParentBotPosition
				) && (
						scrollTop >= stickyTop
				) ?
						stickyParent.addClass( stickyFixedClass ) :
						stickyParent.removeClass( stickyFixedClass );

				$links.each( function() {
					let $currentLink        = $( this ),
							ScrollTopFromHeader = $( $currentLink.attr( 'href' ) ).
																		offset().top - sectionHeaderHeight;
					if ( scrollTop >= ScrollTopFromHeader ) {
						$links.removeClass( 'active' );
						$currentLink.addClass( 'active' );
					}
				} );
			};

			$( window ).
			on( 'elementor/frontend/init', function() {
				if ( window.elementorFrontend ) {
					elementorFrontend.hooks.addAction(
							'frontend/element_ready/anky_faq.default', function() {
								accordion();
								stickyScrollSpy();
								faq2FormSwitcher();
							} );
				}
			} );

			$( window ).
			on( 'resize', stickyScrollSpy );
		}
)( jQuery );