/**
 * Lottie Initialization
 * Elementor FAQ widget scripts
 *
 * @package Anky/Elementor
 */
/*globals elementorFrontend, lottie*/
(
		function( $ ) {
			'use strict';
			const AnkyLottieHandler = function( $scope, $ ) {

				const $lottieIcons = $scope.find( '.anky-lottie-animation' );

				if ( !$lottieIcons.length ) {
					return;
				}

				$lottieIcons.each( function( index, item ) {
					let $item    = $( item ),
							instance = new window.ankyLottieAnimations( $item );

					instance.init();
				} );
			};

			$( window ).
			on( 'elementor/frontend/init', function() {

				elementorFrontend.hooks.addAction(
						'frontend/element_ready/widget',
						AnkyLottieHandler
				);

			} );

			window.ankyLottieAnimations = function( $elem ) {

				let self    = this,
						$lottie = null;

				if ( $elem.hasClass( 'anky-lottie-animation' ) ) {
					$lottie = $elem;
				} else {
					$lottie = $elem.find( '.anky-lottie-animation' );
				}

				self.init = function() {

					//Check if widget has been initialized before
					if ( $lottie.data( 'initialized' ) ) {
						return;
					}

					//Mark widget as initialized
					$lottie.data( 'initialized', true );

					const loop     = $lottie.data( 'lottie-loop' ),
								reverse  = $lottie.data( 'lottie-reverse' ),
								trigger  = $lottie.data( 'lottie-hover' ),
								speed    = $lottie.data( 'lottie-speed' ),
								scroll   = $lottie.data( 'lottie-scroll' ),
								viewPort = $lottie.data( 'lottie-viewport' ),
								renderer = $lottie.data( 'lottie-render' ),
								animItem = lottie.loadAnimation(
										{
											container: $lottie[0],
											renderer : renderer || 'svg',
											loop     : !!loop,
											path     : $lottie.data( 'lottie-url' ),
											autoplay : true
										}
								);

					if ( reverse ) {
						animItem.setDirection( - 1 );
					}

					if ( speed && 1 !== speed ) {
						animItem.setSpeed( speed );
					}

					animItem.addEventListener( 'DOMLoaded', function() {

						if ( scroll || viewPort ) {

							let scrollSpeed = $lottie.data( 'scroll-speed' ),
									scrollStart = $lottie.data( 'scroll-start' ),
									scrollEnd   = $lottie.data( 'scroll-end' );

							animItem.pause();

							const animateSettings = {
								elType : 'SECTION',
								animate: {
									speed: viewPort ? 'viewport' : scrollSpeed,
									range: {
										start: scrollStart,
										end  : scrollEnd
									}
								},
								effects: ['animate']
							};

							const animateInstance = new window.ankyEffects( $lottie[0], animateSettings, animItem );

							animateInstance.init();

						}

						if ( trigger ) {
							animItem.pause();
							$elem.hover( function() {
								animItem.play();
							}, function() {
								animItem.pause();
							} );
						}

					} );

				};

			};
			window.ankyEffects          = function( element, settings, lottieInstance ) {

				let self            = this,
						$el             = $( element ),
						scrolls         = $el.data( 'scrolls' ),
						elementSettings = settings,
						elType          = elementSettings.elType;

				self.elementRules = {};

				self.init = function() {

					if ( scrolls || 'SECTION' === elType ) {

						if ( !elementSettings.effects.length ) {
							return;
						}

						self.setDefaults();

						elementorFrontend.elements.$window.on( 'scroll load', self.initScroll );
					} else {
						elementorFrontend.elements.$window.off( 'scroll load', self.initScroll );
						return;
					}

				};

				self.setDefaults = function() {

					elementSettings.defaults      = {};
					elementSettings.defaults.axis = 'y';

				};

				self.getPercents = function() {

					const dimensions = self.getDimensions();

					let elementTopWindowPoint = dimensions.elementTop - pageYOffset,
							elementEntrancePoint  = elementTopWindowPoint - innerHeight;

					// passed range percents
					return 100 / dimensions.range * (
								 elementEntrancePoint * - 1
					);

				};

				self.initScroll = function() {

					self.initScrollEffects();

				};

				self.initScrollEffects = function() {

					let percents = self.getPercents();

					const elemSettings = $el.closest( '.elementor-element' ).
																	 data( 'settings' );

					if ( elemSettings && 'fixed' === elemSettings._position ) {

						percents = self.getLottieViewportHeightPercentage();

					}

					if ( elementSettings.effects.includes( 'animate' ) ) {
						self.animate( percents, elementSettings.animate );
					}

					if ( elementSettings.effects.includes( 'translateY' ) ) {
						self.transform( 'translateY', percents, elementSettings.vscroll );
					}

				};

				self.getLottieViewportHeightPercentage = function() {

					const offsetObj         = elementSettings.animate.range;
					const offsetStart       = offsetObj.start || 0,
								offsetEnd         = offsetObj.end || 0,
								initialPageHeight = window.innerHeight || document.documentElement.scrollHeight - document.documentElement.clientHeight,
								heightOffset      = initialPageHeight * offsetStart / 100,
								pageRange         = initialPageHeight + heightOffset + initialPageHeight * offsetEnd / 100,
								scrollPos         = document.documentElement.scrollTop + document.body.scrollTop + heightOffset;

					return scrollPos / pageRange * 100;

				};

				self.getDimensions = function() {

					const elementOffset = $el.offset();

					const dimensions = {
						elementHeight: $el.outerHeight(),
						elementWidth : $el.outerWidth(),
						elementTop   : elementOffset.top,
						elementLeft  : elementOffset.left
					};

					dimensions.range = dimensions.elementHeight + innerHeight;

					return dimensions;

				};

				self.getStep = function( percents, options ) {
					return - (
							percents - 50
					) * options.speed;

				};

				self.animate = function( percents, data ) {

					var stopFrame = lottieInstance.totalFrames;

					if ( data.range ) {

						if ( data.range.start > percents ) {
							percents = data.range.start;
						}

						if ( data.range.end < percents ) {
							percents = data.range.end;
						}

					}

					const currentFrame = (
																	 percents / 100
															 ) * (
																	 stopFrame
															 );

					//Check if element is visible
					if ( data.speed === 'viewport' ) {
						if ( data.range.start !== percents && data.range.end !== percents ) {
							lottieInstance.play();
						} else {
							lottieInstance.pause();
						}
					} else {
						lottieInstance.goToAndStop( currentFrame, true );
					}

				};

				self.transform = function( action, percents, data ) {

					if ( 'down' === data.direction ) {
						percents = 100 - percents;
					}

					if ( data.range ) {

						if ( data.range.start > percents ) {
							percents = data.range.start;
						}

						if ( data.range.end < percents ) {
							percents = data.range.end;
						}

					}

					elementSettings.defaults.unit = 'px';

					self.updateElement( 'transform', action, self.getStep( percents, data ) + elementSettings.defaults.unit );

				};

				self.updateElement = function( propName, key, value ) {

					if ( !self.elementRules[propName] ) {
						self.elementRules[propName] = {};
					}

					if ( !self.elementRules[propName][key] ) {
						self.elementRules[propName][key] = true;

						self.updateElementRule( propName );
					}

					const cssVarKey = '--' + key;

					element.style.setProperty( cssVarKey, value );

				};

				self.updateElementRule = function( rule ) {

					let cssValue = '';

					$.each( self.elementRules[rule], function( variableKey ) {
						cssValue += variableKey + '(var(--' + variableKey + '))';
					} );

					$el.css( rule, cssValue );

				};

			};
		}
)( jQuery );