/**
 * Scripts within admin pages.
 * @package Anky/Admin
 */
/* global wp, jQuery, Anky */
(
		function( $, api, externals ) {
			'use strict';
			const ankyAdmin = {

				/*
				 * Start.
				 */
				init: function() {
					const $body = $( 'body' );
					$body.
					on( 'click', '.anky-plugins-installer-link', ankyAdmin.ajaxPluginInstall );
					ankyAdmin.toggleAccordion();

					$body.
					on( 'click', '.js-anky-import', ankyAdmin.startImport );

					$( '.js-anky-websites-search' ).
					on( 'keyup', ankyAdmin.search );

					$( '.js-anky-nav-link' ).
					on( 'click', ankyAdmin.demoNavigation );

					ankyAdmin.reloadOnImportDone();

					ankyAdmin.tipTip();
				},

				/*
				 * Init jQuery TiTip Helper.
				 */
				tipTip: function() {
					let tipTip = $( '.info-tip' );

					// Bail early.
					if ( !tipTip.length ) {
						return;
					}

					tipTip.
					tipTip(
							{
								attribute      : 'data-help-tip',
								defaultPosition: 'top'
							}
					);
				},

				/*
				 * Handles ajax request for plugin installation and activation.
				 */
				ajaxPluginInstall: function( evt ) {
					evt.preventDefault();
					const $btn = $( this ) || $( '.anky-plugins-installer-link' );
					// Bail early.
					if ( !$btn.length ) {return;}

					const ajaxCallbackHandler = function( response ) {

						if ( typeof response === 'object' && typeof response.message !== 'undefined' ) {

							$btn.after( `<p><i>${ response.message }</i></p>` );
							if ( 1 === response.skip ) {
								$btn.removeClass( 'process-now updating-message' );
								$btn.html( $btn.data( 'name' ) );
								setTimeout(
										function() {
											window.location.replace( $btn.data( 'location' ) );
										},
										3000
								);
							} else if ( typeof response.url !== 'undefined' ) {
								$.post( response.url, response, ajaxCallbackHandler ).
									fail( ajaxCallbackHandler );
							} else {
								$btn.removeClass( 'process-now updating-message' ).
										 addClass( 'error' ).
										 html( $btn.data( 'name' ) );
								$btn.addClass( 'error' );
							}

						} else {
							$btn.removeClass( 'process-now updating-message' );
							$btn.html( $btn.data( 'name' ) );
							if ( 'error' === response.statusText && 0 === response.readyState ) {
								$btn.addClass( 'error' );
							} else {
								$btn.next( 'p' ).
										 slideUp(
												 '800',
												 function() {
													 $( this ).
													 remove();
													 setTimeout(
															 function() {
																 let $error = new DOMParser().
																		 parseFromString( response, 'text/html' ).
																		 querySelector( '.error' ),
																		 $notes = $( '.anky-notes' );

																 if ( $( $error ).length ) {
																	 if ( !$notes.data( 'error' ) ) {
																		 $notes.prepend( $error ).
																						data( 'error', 'true' );
																		 $notes.find( '.error' ).
																						hide().
																						slideDown();
																	 }
																 } else {
																	 window.location.replace( $btn.data( 'location' ) );
																 }
															 },
															 800
													 );
												 }
										 );
							}
						}

					};

					if ( !$btn.hasClass( 'process-now' ) ) {

						const data = $btn.data( 'ajax' ),
									url  = $btn.attr( 'href' );
						$btn.html( $btn.data( 'processing' ) ).
								 addClass( 'process-now updating-message' );

						//Request plugin activation
						$.post( url, data, ajaxCallbackHandler ).
							error( ajaxCallbackHandler );
					}
				},

				/*
				 * Activate accordion.
				 */
				toggleAccordion: function() {
					let $title = $( '.anky-support-accordion-item-title' );

					// Bail early.
					if ( !$title.length ) {return;}

					$title.off();
					$title.on( 'click', function() {

						let $this     = $( this ),
								openClass = 'open';

						$this.next().
									stop().
									slideToggle().
									parent( '.anky-support-accordion-item' ).
									toggleClass( openClass ).
									siblings().
									removeClass( openClass ).
									find( '.anky-support-accordion-content' ).
									stop().
									slideUp();
					} );
				},

				/**
				 * Grid Layout search functionality.
				 */
				search: function() {
					let $container = $( '.js-anky-websites__list-container' ),
							value      = $( this ).
							val();
					if ( 0 < value.length ) {
						// Hide all items.
						$container.
						find( '.js-anky-websites__item' ).
						hide();

						// Show just the ones that have a match on the import name.
						$container.
						find( '.js-anky-websites__item[data-name*="' + value.toLowerCase() + '"]' ).
						show();
					} else {
						$container.
						find( '.js-anky-websites__item' ).
						show();
					}
				},

				/**
				 * Demo content animation functionality.
				 */
				animate: function( category ) {
					// Cache selector to all items
					const $items            = $( '.js-anky-websites__list-container' ).
								find( '.js-anky-websites__item' ),
								fadeoutClass      = 'anky-is-fadeout',
								fadeinClass       = 'anky-is-fadein',
								animationDuration = 200,
								dfd               = jQuery.Deferred();

					// Hide all items.
					const fadeOut = function() {
						const dfd = jQuery.Deferred();

						$items.addClass( fadeoutClass );

						setTimeout( function() {
							$items.removeClass( fadeoutClass ).
										 hide();

							dfd.resolve();
						}, animationDuration );

						return dfd.promise();
					};

					const fadeIn = function( category, dfd ) {
						let filter = category ? `[data-categories*="${ category }"]` : 'div';

						if ( 'all' === category ) {
							filter = 'div';
						}

						$items.filter( filter ).
									 show().
									 addClass( fadeinClass );

						setTimeout( function() {
							$items.removeClass( fadeinClass );

							dfd.resolve();
						}, animationDuration );
					};

					const promise = fadeOut();
					promise.done( function() {
						fadeIn( category, dfd );
					} );

					return dfd;
				},

				/**
				 * Demo content categories navigation functionality.
				 */
				demoNavigation: function( event ) {
					event.preventDefault();

					// Remove 'active' class from the previous nav list items.
					$( this ).
					parent().
					siblings().
					removeClass( 'active' );

					// Add the 'active' class to this nav list item.
					$( this ).
					parent().
					addClass( 'active' );

					const category = this.hash.slice( 1 );

					// show/hide the right items, based on category selected
					const $container = $( '.js-anky-websites__list-container' );
					$container.css( 'min-width', $container.outerHeight() );

					const promise = ankyAdmin.animate( category );

					promise.done( function() {
						$container.removeAttr( 'style' );
					} );
				},

				/**
				 * Run the main import with a selected predefined demo or with manual files (selected = false).
				 */
				startImport: function() {
					// Prepare data for the AJAX call
					let data = new FormData();
					data.append( 'action', 'ocdi_import_demo_data' );
					data.append( 'security', Anky.ajaxNonce );
					data.append(
							'selected',
							$( this ).
							attr( 'data-import' )
					);

					// AJAX call to import everything (content, widgets, before/after setup)
					ankyAdmin.ajaxCall( data );
				},

				/**
				 * The main AJAX call, which executes the import process.
				 *
				 * @param data The data to be passed to the AJAX call.
				 */
				ajaxCall: function( data ) {
					const switchBlocks = function() {
						$( '.js-anky-ajax-loader' ).
						hide();
						$( '.js-anky-importing' ).
						hide();
						$( '.js-anky-imported' ).
						show();
					};

					$.
					ajax( {
									method     : 'POST',
									url        : Anky.ajaxUrl,
									data       : data,
									contentType: false,
									processData: false,
									beforeSend : function() {
										$( '.js-anky-ajax-loader' ).
										show();
										$( '.js-anky-importing' ).
										show();
										$( '.js-anky-imported' ).
										hide();
										$( '.js-anky-ajax-response' ).
										empty();
										tb_show( '', '/?TB_inline&inlineId=anky_import_modal&width=700&height=500' );
									}
								} ).
					done( function( response ) {
						if ( 'undefined' !== typeof response.status && 'newAJAX' === response.status ) {
							ankyAdmin.ajaxCall( data );
						} else if ( 'undefined' !== typeof response.status && 'customizerAJAX' === response.status ) {
							// Fix for data.set and data.delete, which they are not supported in some browsers.
							let newData = new FormData();
							newData.append( 'action', 'ocdi_import_customizer_data' );
							newData.append( 'security', Anky.ajaxNonce );
							$( '.js-anky-ajax-loader' ).
							hide();
							ankyAdmin.ajaxCall( newData );
						} else if ( 'undefined' !== typeof response.status && 'afterAllImportAJAX' === response.status ) {
							// Fix for data.set and data.delete, which they are not supported in some browsers.
							let newData = new FormData();
							newData.append( 'action', 'ocdi_after_import_data' );
							newData.append( 'security', Anky.ajaxNonce );
							$( '.js-anky-ajax-loader' ).
							hide();
							ankyAdmin.ajaxCall( newData );
						} else if ( 'undefined' !== typeof response.message ) {
							$( '.js-anky-ajax-response' ).
							append( response.message );

							if ( 'undefined' !== typeof response.title ) {
								$( '.js-anky-ajax-response-title' ).
								html( response.title );
							}

							if ( 'undefined' !== typeof response.subtitle ) {
								$( '.js-anky-ajax-response-subtitle' ).
								html( response.subtitle );
							}
							switchBlocks();

							// Trigger custom event, when OCDI import is complete.
							$( document ).
							trigger( 'ankyImportComplete' );
						} else {
							$( '.js-anky-ajax-response' ).
							append( `${ Anky.errorSvg }<p>${ response }</p>` );
							$( '.js-anky-ajax-response-title' ).
							html( Anky.importFailed );
							$( '.js-anky-ajax-response-subtitle' ).
							html( `<p>${ Anky.importFailedSubtitle }</p>` );
							switchBlocks();
						}
					} ).
					fail( function( error ) {
						$( '.js-anky-ajax-response' ).
						append( `${ Anky.errorSvg }<p>${ Anky.errorTitle }: ${ error.statusText } (${ error.status })</p>` );
						$( '.js-anky-ajax-response-title' ).
						html( Anky.importFailed );
						$( '.js-anky-ajax-response-subtitle' ).
						html( `<p>${ Anky.importFailedSubtitle }</p>` );
						switchBlocks();
					} );
				},

				/**
				 * Reload page after import is done and modal is closed.
				 */
				reloadOnImportDone: function() {
					const $document = $( document );
					$document.
					on( 'ankyImportComplete', function() {
						$document.
						on( 'tb_unload', function() {
							window.location.reload();
						} );
					} );
				}
			};

			$( document ).
			ready( ankyAdmin.init );
		}
		( jQuery )
);
