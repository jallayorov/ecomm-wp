<?php
/**
 * The sidebar containing the footer widget area.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Anky
 * @author  Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$sidebars = anky_get_sidebars( 'anky-footer-sidebar' );

if ( empty( $sidebars ) ) {
	return;
}
?>
<div class="anky-row">
	<?php foreach ( $sidebars as $sidebar ) : ?>
		<div class="anky-col-2">
			<?php anky_get_widget( $sidebar['id'] ); ?>
		</div>
	<?php endforeach; ?>
</div>
