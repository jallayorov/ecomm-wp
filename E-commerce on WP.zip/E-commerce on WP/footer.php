<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link        https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package     Anky
 * @author      Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<footer id="colophon" class="site-footer">
	<?php anky_footer_inner_before(); ?>
	<div class="anky-container">
		<?php anky_footer_inner(); ?>
	</div>
	<?php anky_footer_inner_after(); ?>
</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
