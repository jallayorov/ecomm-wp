<?php
/**
 * Search form template.
 *
 * Template consist of 2 search forms, Modal and Widget. To trigger modal one must pass
 * parameter `modal` to get_search_form().
 *
 * @package Anky
 * @author  Anky (Andrew Black)
 *
 * @var $args array array containing search form arguments.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

// Build a string containing an aria-label to use for the search form and input.
$form_args           = array(
	'role'         => 'search',
	'method'       => 'get',
	'action'       => esc_url( home_url( '/' ) ),
	'autocomplete' => 'off',
);
$search_input_args   = array(
	'type'        => 'text',
	'value'       => get_search_query(),
	'name'        => 's',
	'id'          => anky_unique_id( 's-' ),
	'class'       => 'anky-search-input',
	'placeholder' => esc_attr__( 'Search', 'anky' ),
);

if ( $args['aria_label'] ) {
	$form_args['aria-label'] = $args['aria_label'];
}

// Modal search form.
if ( isset( $args['modal'] ) ) :
	$form_args['class'] = array( 'searchform', 'anky-searchform-modal' );
	$form_args['id'] = 'searchform-modal';
	?>

	<div class="anky-modal anky-search-modal" id="search-modal-wrap" aria-hidden="true" tabindex="-1">
		<div class="anky-modal-shell anky-modal-shell-scrollable">
			<div class="anky-search-modal-content anky-modal-content">
				<div class="anky-container">
					<div class="anky-modal-header">
						<div class="anky-modal-header-column">
							<?php anky_search_header_top(); ?>
						</div>
						<div class="anky-modal-header-column">
							<?php anky_search_header_bottom(); ?>
						</div>
					</div>
					<div class="anky-modal-body">
						<form <?php anky_the_atts( $form_args ); ?>>
							<div class="anky-input-group anky-mb-1">
								<label class="anky-search-label anky-mb-1" for="<?php echo esc_attr( anky_get_prop( $search_input_args, 'id' ) ); ?>">
									<?php esc_html_e( 'Search for anything', 'anky' ); ?>
								</label>
								<input <?php anky_the_atts( $search_input_args ); ?>/>
							</div>
							<div class="anky-input-group anky-mb-1">
								<button type="submit" class="anky-search-submit" id="search-modal-submit" aria-label="<?php echo esc_attr_x( 'Search', 'submit button', 'anky' ); ?>">
									<span class="anky-icon-magnifying-glass" aria-hidden="true"></span>
								</button>
							</div>
						</form>
					</div><!--.anky-modal-body-->
				</div><!--.anky-container-->
			</div><!--.anky-search-modal-content-->
		</div><!--.anky-modal-shell-->
	</div><!--.anky-modal-->

<?php
else :
	$form_args['id'] = anky_unique_id( 'searchform-' );

	$form_args['class']               = array( 'searchform', 'anky-searchform' );
	$search_input_args['placeholder'] = esc_attr__( 'Search...', 'anky' );
	?>
	<div class="anky-search-form-wrapper">
		<form <?php anky_the_atts( $form_args ); ?>>
			<div class="anky-input-group anky-mb-1">
				<label class="anky-search-label anky-mb-1 screen-reader-text" for="<?php echo esc_attr( anky_get_prop( $search_input_args, 'id' ) ); ?>">
					<?php esc_html_e( 'Search', 'anky' ); ?>
				</label>
				<input <?php anky_the_atts( $search_input_args ); ?>/>
				<button type="submit"
					class="anky-search-submit"
					id="<?php echo esc_attr( anky_unique_id( 'search-submit-' ) ); ?>"
					aria-label="<?php echo esc_attr_x( 'Search', 'submit button', 'anky' ); ?>">
					<span class="anky-icon-magnifying-glass" aria-hidden="true"></span>
				</button>
			</div>
		</form>
	</div>
<?php endif; ?>
