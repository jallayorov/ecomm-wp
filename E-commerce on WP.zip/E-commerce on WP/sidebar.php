<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Anky
 * @author  Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

if ( ! anky_get_sidebar( 'anky-main-sidebar' ) ) {
	return;
}

echo '<aside ';
anky_the_atts(
	array(
		'id'         => 'secondary',
		'class'      => 'widget-area',
		'role'       => 'complementary',
		'aria-label' => esc_attr__( 'Main sidebar', 'anky' ),
	)
);
echo '>';
anky_get_widget( 'anky-main-sidebar' );
echo '</aside><!-- #secondary -->';
