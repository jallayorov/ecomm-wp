<?php
/**
 * Anky theme configuration base for Customizer.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Config;

use Anky\Includes\Anky;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Sanitizes Initial setup
 */
class Anky_Customizer_Config {

	/**
	 * Theme controller Instance.
	 *
	 * @var Anky $theme
	 * @access protected
	 */
	protected $theme;

	/**
	 * Constructor.
	 *
	 * @param Anky $theme Theme controller Instance.
	 */
	public function __construct( Anky $theme ) {
		$this->theme = $theme;

		add_filter( 'anky_customizer_config', array( $this, 'add_config' ), 30, 2 );
	}

	/**
	 * Base method for adding customizer configurations.
	 *
	 * @param array $config customizer configurations.
	 *
	 * @return array updated Customizer config.
	 */
	public function add_config( $config ) {
		return $config;
	}

}

