<?php
/**
 * Customizer Configurations: Panels.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Panels Config.
 */
class Anky_Customizer_Panels_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'panel-globals' => array(
				'item_type'   => 'panel',
				'title'       => __( 'Global Settings', 'anky' ),
				'description' => __(
					'The Global settings are the default settings for all of your reviews, and they determine how they look and behave. Customize them on according sections below',
					'anky'
				),
				'type'        => 'options',
				'priority'    => 1,
			),
			'panel-header'  => array(
				'item_type'   => 'panel',
				'title'       => __( 'Site Header', 'anky' ),
				'description' => __(
					'One of the most crucial parts of your website is the header. It`s the first thing people see when they arrive at your website, and you already know how important first impressions are. Use this section to edit the logo, site title, icon and layout type',
					'anky'
				),
				'type'        => 'options',
				'priority'    => 2,
			),
		);

		return array_merge( $config, $_config );
	}

}
