<?php
/**
 * Customizer Configurations: Footer Widgets section.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Sections\Footer;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Footer Widgets section config.
 */
class Anky_Customizer_Footer_Widgets_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'section-footer-widgets' => array(
				'item_type'          => 'section',
				'title'              => __( 'Site Footer', 'anky' ),
				'description'        => __( 'Customize widgets layout and edit text blocks on Footer section.', 'anky' ),
				'priority'           => 4,
				'type'               => 'options',
				'description_hidden' => true,
				'fields'             => array(
					/**
					 * Layout type.
					 */
					'footer-widgets-layout-type' => array(
						'label'             => __( 'Widgets layout', 'anky' ),
						'type'              => 'anky-radio-image',
						'default'           => $this->theme->options->get( 'footer-widgets-layout-type' ),
						'transport'         => 'postMessage',
						'priority'          => 1,
						'selective_refresh' => array(
							'selector'            => '.anky-footer-widgets-area',
							'container_inclusive' => false,
							'render_callback'     => function () {
								$this->theme->widgets->prepare_widgets_areas();
								$this->theme->footer->build_footer_widgets();
							},
						),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_radio' ),
						'choices'           => array(
							'disabled' => array(
								'label' => __( 'Disabled', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'layout_disabled',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'layout-1' => array(
								'label' => __( '3 widget columns area', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'footer_widgets_layout_1',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
						),
					),

					/**
					 * Copyright.
					 */
					'footer-copyrights'          => array(
						'label'    => __( 'Copyright & Custom content', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 2,
					),
					'footer-copyright-text'      => array(
						'label'             => __( 'Copyright text', 'anky' ),
						'priority'          => 3,
						'type'              => 'text',
						'default'           => $this->theme->options->get( 'footer-copyright-text' ),
						'transport'         => 'postMessage',
						'selective_refresh' => array(
							'selector'            => '.anky-site-info-container',
							'container_inclusive' => false,
							'render_callback'     => function () {
								$this->theme->footer->site_info();
							},
						),
						'sanitize_callback' => 'wp_kses_post',
					),
					'footer-right-block-content' => array(
						'label'             => __( 'Footer custom content text block', 'anky' ),
						'priority'          => 4,
						'type'              => 'anky-tinymce',
						'default'           => $this->theme->options->get( 'footer-right-block-content' ),
						'transport'         => 'postMessage',
						'selective_refresh' => array(
							'selector'            => '.anky-credentials-container',
							'container_inclusive' => false,
							'render_callback'     => function () {
								$this->theme->footer->author_credentials();
							},
						),
						'sanitize_callback' => 'wp_kses_post',
						'input_attrs'       => array(
							'toolbar1'     => 'bold italic bullist numlist alignleft aligncenter alignright link',
							'mediaButtons' => true,
						),
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}
}
