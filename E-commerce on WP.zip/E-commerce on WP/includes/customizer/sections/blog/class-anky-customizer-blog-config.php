<?php
/**
 * Customizer Configurations: Blog section.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Sections\Blog;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Builder\Blog\Anky_Related_Posts_Builder;
use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Blog section config.
 */
class Anky_Customizer_Blog_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'section-main-blog' => array(
				'item_type'          => 'section',
				'title'              => __( 'Site Blog', 'anky' ),
				'description'        => __( 'Edit the current settings of blog the way you want visitors to see it.', 'anky' ),
				'type'               => 'options',
				'priority'           => 3,
				'description_hidden' => true,
				'fields'             => array(

					/**
					 * Sidebar.
					 */
					'main-blog-sidebar-divider'  => array(
						'label'    => __( 'Main Sidebar', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 1,
					),
					'main-blog-sidebar'          => array(
						'label'             => __( 'Enable Blog Sidebar', 'anky' ),
						'priority'          => 2,
						'type'              => 'anky-switcher',
						'default'           => $this->theme->options->get( 'main-blog-sidebar' ),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_checkbox' ),
					),
					'main-blog-sidebar-position' => array(
						'label'             => __( 'Choose sidebar position', 'anky' ),
						'priority'          => 3,
						'type'              => 'select',
						'default'           => $this->theme->options->get( 'main-blog-sidebar-position' ),
						'active_callback'   => function () {
							return $this->theme->options->get( 'main-blog-sidebar' );
						},
						'choices'           => array(
							'left'  => __( 'Left', 'anky' ),
							'right' => __( 'Right', 'anky' ),
						),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_select' ),
					),

					/**
					 * Excerpt style.
					 */
					'blog-excerpt-style-divider' => array(
						'label'    => __( 'Excerpt', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 4,
					),
					'blog-excerpt-style'         => array(
						'label'             => __( 'Style', 'anky' ),
						'type'              => 'select',
						'default'           => $this->theme->options->get( 'blog-excerpt-style' ),
						'priority'          => 5,
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_select' ),
						'choices'           => array(
							'disabled'      => __( 'Disabled', 'anky' ),
							'default'       => __( 'Default WordPress excerpt', 'anky' ),
							'custom_unlink' => __( "Custom without 'Read More' link", 'anky' ),
							'custom_link'   => __( "Custom with 'Read More' link", 'anky' ),
						),
					),
					'blog-excerpt-length'        => array(
						'label'             => __( 'Length', 'anky' ),
						'type'              => 'anky-radio-image',
						'default'           => $this->theme->options->get( 'blog-excerpt-length' ),
						'priority'          => 6,
						'transport'         => 'postMessage',
						'active_callback'   => function () {
							return ! in_array( $this->theme->options->get( 'blog-excerpt-style' ), array( 'disabled', 'default' ), true );
						},
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_radio' ),
						'choices'           => array(
							2 => array(
								'label' => __( '2 Columns', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'blog_excerpt_2_lines',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							3 => array(
								'label' => __( '3 Columns', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'blog_excerpt_3_lines',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
						),
					),
					/**
					 * Related posts.
					 */
					// Sidebar.
					'blog-related-posts-divider' => array(
						'label'    => __( 'Related posts', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 6,
					),
					'blog-related-posts'         => array(
						'label'             => __( 'Enable Related posts', 'anky' ),
						'priority'          => 7,
						'type'              => 'anky-switcher',
						'transport'         => 'postMessage',
						'selective_refresh' => array(
							'selector'            => '.anky-related-posts-customizer-wrap',
							'container_inclusive' => false,
							'render_callback'     => function () {
								Anky_Related_Posts_Builder::get_instance()->render();
							},
						),
						'default'           => $this->theme->options->get( 'blog-related-posts' ),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_checkbox' ),
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}
}
