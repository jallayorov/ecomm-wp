<?php
/**
 * Customizer Configurations: Language switcher section.
 * Consist of config for Language switcher options located in `Menus` panel.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Sections\Menu;

use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Language switcher section.
 */
class Anky_Customizer_Menu_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'language-switcher' => array(
				'item_type'          => 'section',
				'title'              => __( 'Language Switcher', 'anky' ),
				'panel'              => 'nav_menus',
				'description'        => '<i>' .
										sprintf(
										/* translators: 1 - link to Polylang plugin, 2 Link to WPML plugin*/
											__(
												'This function allows you to change the language of the site. If you want to enable the feature, you first need to install either a <a href="%1$s" target="_blank" rel="nofollow noindex">WPML</a> or <a href="%2$s" target="_blank" rel="nofollow noindex">Polylang</a> plugin.',
												'anky'
											),
											'//wordpress.org/plugins/polylang/',
											'//wpml.org/'
										) .
										'</i>',
				'description_hidden' => false,
				'fields'             => array(
					'custom-switcher' => array(
						'label'             => __( 'Enable custom switcher?', 'anky' ),
						'priority'          => 1,
						'type'              => 'anky-switcher',
						'default'           => $this->theme->options->get( 'custom-switcher' ),
						'transport'         => 'postMessage',
						'selective_refresh' => array(
							'selector'            => '.anky-language-switcher-preview-container',
							'container_inclusive' => false,
							'render_callback'     => function () {
								$this->theme->header->build_custom_language_switcher();
							},
						),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_checkbox' ),
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}

}
