<?php
/**
 * Customizer Configurations: Header Layout section.
 * Consist of config for Main Header and Header Upper Bar layout options.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Sections\Header;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Header Layout section config.
 */
class Anky_Customizer_Header_Layout_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'section-header-layout' => array(
				'item_type'          => 'section',
				'title'              => __( 'Header Layout', 'anky' ),
				'panel'              => 'panel-header',
				'description'        => __( 'Choose one of available Header layouts', 'anky' ),
				'priority'           => 3,
				'description_hidden' => true,
				'fields'             => array(

					/**
					 * Upper bar Layout type.
					 */
					'header-upper-bar-layout-divider' => array(
						'label'    => __( 'Header Upper Bar Layout', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 1,
					),
					'header-upper-bar-layout-type'    => array(
						'label'             => __( 'Header Bar Layout', 'anky' ),
						'type'              => 'anky-radio-image',
						'default'           => $this->theme->options->get( 'header-upper-bar-layout-type' ),
						'transport'         => 'postMessage',
						'priority'          => 2,
						'selective_refresh' => array(
							'selector'            => '.anky-upper-header-bar-wrap',
							'container_inclusive' => true,
							'render_callback'     => function () {
								$this->theme->header->build_upper_header();
							},
						),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_radio' ),
						'choices'           => array(
							'disabled' => array(
								'label' => __( 'Disabled', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'layout_disabled',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'layout-1' => array(
								'label' => __( 'Address, phone and social networks on right side.', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_upper_bar_layout_1',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'layout-2' => array(
								'label' => __( 'Address and phone with icons on the left and social networks on the right side.', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_upper_bar_layout_2',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'layout-3' => array(
								'label' => __( 'Social networks on the left and address, phone and email on the right side.', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_upper_bar_layout_3',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'layout-4' => array(
								'label' => __( 'Address and phone on the left and additional mini menu on the right side.', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_upper_bar_layout_4',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
						),
					),

					/**
					 * Layout type.
					 */
					'header-layout-divider'           => array(
						'label'    => __( 'Main Header', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 3,
					),
					'header-layout-type'              => array(
						'label'             => __( 'Header Layout type', 'anky' ),
						'type'              => 'anky-radio-image',
						'default'           => $this->theme->options->get( 'header-layout-type' ),
						'transport'         => 'postMessage',
						'priority'          => 4,
						'selective_refresh' => array(
							'selector'            => '#masthead',
							'container_inclusive' => true,
							'render_callback'     => function () {
								$this->theme->header->build( $this->theme->options->get( 'header-layout-type' ) );
							},
						),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_radio' ),
						'choices'           => array(
							'header-layout-1' => array(
								'label' => __( 'Logo left', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_layout_1',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'header-layout-2' => array(
								'label' => __( 'Logo in the middle of menu', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_layout_2',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'header-layout-3' => array(
								'label' => __( 'Logo above menu', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_layout_3',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'header-layout-4' => array(
								'label' => __( 'Menu hidden, Logo right', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_layout_4',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'header-layout-5' => array(
								'label' => __( 'Menu hidden, Logo centered', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'header_layout_5',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
						),
					),

					/**
					 * Custom widgets.
					 */
					'header-widgets-divider'          => array(
						'label'    => __( 'Custom Widgets', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 5,
					),
					'header-widget-search'            => array(
						'label'             => __( 'Enable search widget?', 'anky' ),
						'priority'          => 6,
						'type'              => 'anky-switcher',
						'default'           => $this->theme->options->get( 'header-widget-search' ),
						'transport'         => 'postMessage',
						'selective_refresh' => array(
							'selector'            => '.anky-widget-search',
							'container_inclusive' => false,
							'render_callback'     => function () {
								echo $this->theme->widgets->get_search_widget(); //phpcs:ignore WordPress.Security.EscapeOutput
							},
						),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_checkbox' ),
					),
					'header-widget-tel'               => array(
						'label'             => __( 'Enable Call Us widget?', 'anky' ),
						'priority'          => 7,
						'type'              => 'anky-switcher',
						'default'           => $this->theme->options->get( 'header-widget-tel' ),
						'transport'         => 'postMessage',
						'selective_refresh' => array(
							'selector'            => '.anky-widget-tel',
							'container_inclusive' => false,
							'render_callback'     => function () {
								echo $this->theme->widgets->get_phone_widget(); //phpcs:ignore WordPress.Security.EscapeOutput
							},
						),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_checkbox' ),
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}

}
