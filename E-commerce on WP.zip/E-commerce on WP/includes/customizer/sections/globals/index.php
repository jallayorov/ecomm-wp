<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Customizer
 */

/* Silence is golden, and we agree. */
