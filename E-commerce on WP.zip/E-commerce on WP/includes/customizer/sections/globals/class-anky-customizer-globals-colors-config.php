<?php
/**
 * Customizer Configurations: Global Colors section config
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Sections\Globals;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Global Colors section config.
 */
class Anky_Customizer_Globals_Colors_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'colors' => array(
				'item_type'          => 'section',
				'title'              => __( 'Colors', 'anky' ),
				'description'        => __( 'Theme colors setup', 'anky' ),
				'panel'              => 'panel-globals',
				'priority'           => 2,
				'description_hidden' => true,
				'fields'             => array(
					'globals-color-scheme' => array(
						'label'             => __( 'Theme color scheme', 'anky' ),
						'type'              => 'anky-radio-image',
						'default'           => $this->theme->options->get( 'globals-color-scheme' ),
						'transport'         => 'postMessage',
						'description'       => __( 'Select between available color schemes. More color settings will be available in future updates.', 'anky' ),
						'priority'          => 1,
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_radio' ),
						'choices'           => array(
							'light' => array(
								'label' => __( 'Light', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'light_schema',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
							'dark'  => array(
								'label' => __( 'Dark', 'anky' ),
								'path'  => Anky_UI_Controller::get_svg(
									array(
										'icon'   => 'dark_schema',
										'width'  => 73,
										'height' => 49,
									)
								),
							),
						),
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}
}
