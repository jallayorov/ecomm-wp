<?php
/**
 * Customizer Configurations: Global Optimization section config
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Sections\Globals;

use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Global Optimization section config.
 */
class Anky_Customizer_Globals_Optimization_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'colors' => array(
				'item_type'          => 'section',
				'title'              => __( 'Assets', 'anky' ),
				'description'        => __( 'Theme assets settings', 'anky' ),
				'panel'              => 'panel-globals',
				'priority'           => 4,
				'description_hidden' => true,
				'fields'             => array(
					'globals-assets-loading-mode' => array(
						'label'             => __( 'Theme assets loading mode', 'anky' ),
						'type'              => 'select',
						'default'           => $this->theme->options->get( 'globals-assets-loading-mode' ),
						'transport'         => 'postMessage',
						'description'       => __(
							'Defines the way theme assets will be loaded. By default the CDN method is set, which allow to speed up loading time. If any errors occur, switch to Local loading',
							'anky'
						),
						'priority'          => 1,
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_select' ),
						'choices'           => array(
							'cdn'   => __( 'CDN', 'anky' ),
							'local' => __( 'Local ', 'anky' ),
						),
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}
}
