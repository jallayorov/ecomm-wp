<?php
/**
 * Customizer Configurations: Global Contacts section config.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Sections\Globals;

use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Global Contacts section config.
 */
class Anky_Customizer_Globals_Contacts_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'section-globals-contact' => array(
				'item_type'          => 'section',
				'title'              => __( 'Contacts', 'anky' ),
				'panel'              => 'panel-globals',
				'description'        => __( 'Main theme contact information. Here you can manage all your contact information.', 'anky' ),
				'priority'           => 3,
				'description_hidden' => true,
				'fields'             => array(
					/**
					 * Main contact data.
					 */
					'globals-contact-main-data-divider'       => array(
						'label'    => __( 'Main contact information', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 1,
					),
					'globals-contact-tel-number'              => array(
						'label'             => __( 'Phone number', 'anky' ),
						'description'       => __(
							'Do not leave this field empty. Do not use digits in this field. Allowed characters: You can only use digits, spaces, `+`, `-`, `()` characters.',
							'anky'
						),
						'type'              => 'text',
						'priority'          => 2,
						'default'           => $this->theme->options->get( 'globals-contact-tel-number' ),
						'transport'         => 'postMessage',
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => array( 'Anky\Includes\Customizer\Anky_Validator', 'validate_phone_number' ),
						'input_attrs'       => array(
							'placeholder' => __( 'Enter phone number here', 'anky' ),
						),
					),
					'globals-contact-email'                   => array(
						'label'             => __( 'Email', 'anky' ),
						'description'       => __( 'Do not leave this field empty.', 'anky' ),
						'type'              => 'text',
						'priority'          => 3,
						'default'           => $this->theme->options->get( 'globals-contact-email' ),
						'transport'         => 'postMessage',
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => array( 'Anky\Includes\Customizer\Anky_Validator', 'validate_email' ),
						'input_attrs'       => array(
							'placeholder' => __( 'Enter email here', 'anky' ),
						),
					),

					/**
					 * Address.
					 */
					'globals-contact-address-divider'         => array(
						'label'    => __( 'Address information', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 4,
					),
					'globals-contact-address'                 => array(
						'label'             => __( 'Address', 'anky' ),
						'description'       => __( 'Do not leave this field empty.', 'anky' ),
						'type'              => 'text',
						'priority'          => 5,
						'default'           => $this->theme->options->get( 'globals-contact-address' ),
						'transport'         => 'postMessage',
						'validate_callback' => array( 'Anky\Includes\Customizer\Anky_Validator', 'is_empty' ),
						'sanitize_callback' => 'sanitize_text_field',
						'input_attrs'       => array(
							'placeholder' => __( 'Enter address here', 'anky' ),
						),
					),
					'globals-contact-address-map-embed'       => array(
						'label'             => __( 'Google map embed link', 'anky' ),
						'description'       => __( 'Copy and paste an embed link from Google Maps without altering it. Do not put any other content in this field.', 'anky' ),
						'type'              => 'text',
						'priority'          => 6,
						'default'           => $this->theme->options->get( 'globals-contact-address-map-embed' ),
						'transport'         => 'postMessage',
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_google_map_embed' ),
						'validate_callback' => array( 'Anky\Includes\Customizer\Anky_Validator', 'validate_google_map_embed' ),
						'input_attrs'       => array(
							'placeholder' => __( 'Paste embed here', 'anky' ),
						),
					),

					/**
					 * Social networks.
					 */
					'globals-contact-social-networks-divider' => array(
						'label'    => __( 'Social networks', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 7,
					),
					'globals-contact-social-networks'         => array(
						'label'             => __( 'Social networks links', 'anky' ),
						'priority'          => 8,
						'type'              => 'anky-repeater',
						'description'       => __( 'Enter any social links. The supported social network link will be replaced with corresponding icon.', 'anky' ),
						'default'           => $this->theme->options->get( 'globals-contact-social-networks' ),
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}
}
