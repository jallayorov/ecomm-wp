<?php
/**
 * Customizer Configurations: Global Typography section config.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 * @see        Anky_Control_Google_Font_Select for avalable input options.
 */

namespace Anky\Includes\Customizer\Sections\Globals;

use Anky\Includes\Customizer\Config\Anky_Customizer_Config;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Configurations: Global Typography section config.
 */
class Anky_Customizer_Globals_Typography_Config extends Anky_Customizer_Config {

	/**
	 * Register Panels and Sections for Customizer.
	 *
	 * @param array $config Customizer Configurations.
	 *
	 * @return array Customizer Configurations with updated configurations.
	 */
	public function add_config( $config ) {
		$_config = array(
			'section-globals-typography' => array(
				'item_type'          => 'section',
				'title'              => __( 'Typography', 'anky' ),
				'description'        => __( 'Typography settings for theme', 'anky' ),
				'panel'              => 'panel-globals',
				'priority'           => 1,
				'description_hidden' => true,
				'fields'             => array(
					/**
					 * Font loading.
					 */
					'globals-fonts-loading-divider'  => array(
						'label'    => __( 'Fonts loading', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 1,
					),
					'globals-fonts-loading'          => array(
						'type'              => 'select',
						'label'             => __( 'Fonts loading method', 'anky' ),
						'description'       => __( 'Method of loading google fonts. Standard - fonts will be loaded as usual. Preload - preload and apply css after loading is done.', 'anky' ) . '<br>' .
											   __( 'If preload method is not working correctly, please use standard one.', 'anky' ),
						'section'           => 'section-globals-typography',
						'priority'          => 2,
						'transport'         => 'postMessage',
						'choices'           => array(
							'standard' => __( 'Standard', 'anky' ),
							'preload'  => __( 'Preload', 'anky' ),
						),
						'default'           => $this->theme->options->get( 'globals-fonts-loading' ),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_select' ),
					),

					/**
					 * Main.
					 */
					'globals-body-fonts-divider'     => array(
						'label'    => __( 'Main Body Font', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 3,
					),
					'globals-body-font-family'       => array(
						'type'              => 'anky-google-font',
						'label'             => __( 'Theme Main Font family', 'anky' ),
						'description'       => __( 'Main theme font that will be used for most of text.', 'anky' ) . ' ' . __( 'Fonts provided by Google Fonts and sorted alphabetically', 'anky' ),
						'section'           => 'section-globals-typography',
						'priority'          => 4,
						'default'           => $this->theme->options->get( 'globals-body-font-family' ),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_google_font' ),
					),

					/**
					 * Page Heading.
					 */
					'globals-headings-fonts-divider' => array(
						'label'    => __( 'Page Heading Font', 'anky' ),
						'type'     => 'anky-divider',
						'priority' => 5,
					),
					'globals-headings-font-family'   => array(
						'type'              => 'anky-google-font',
						'label'             => __( 'Page Heading Font family', 'anky' ),
						'description'       => __( 'Font that will be used for specific headings (mainly page heading).', 'anky' ) . ' ' .
											   __( 'Fonts provided by Google Fonts and sorted alphabetically', 'anky' ),
						'section'           => 'section-globals-typography',
						'priority'          => 6,
						'default'           => $this->theme->options->get( 'globals-headings-font-family' ),
						'sanitize_callback' => array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_google_font' ),
					),
				),
			),
		);

		return array_merge( $config, $_config );
	}

}
