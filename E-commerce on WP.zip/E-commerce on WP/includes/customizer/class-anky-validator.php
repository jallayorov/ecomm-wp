<?php
/**
 * Anky theme Customizer Validator Controller.
 *
 * @package    Customizer
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer;

use WP_Error;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Validator Controller class.
 */
class Anky_Validator {

	/**
	 * Validation callback stub.
	 *
	 * @param WP_Error $validity WordPress Error class.
	 * @param string   $value    Current input value.
	 *
	 * @return WP_Error
	 */
	public static function validate_callback( $validity, $value ) {
		return $validity;
	}

	/**
	 * Validate phone field for any forbidden characters.
	 *
	 * @param WP_Error $validity WordPress Error class.
	 * @param string   $value    Current input value.
	 *
	 * @return WP_Error
	 */
	public static function validate_phone_number( $validity, $value ) {
		self::is_empty( $validity, $value );

		if ( preg_match( '/[^0-9\+\s\(\)-]/', $value ) ) {
			$validity->add( 'wrong_phone_pattern', __( 'Field contains forbidden characters.', 'anky' ) );
		}

		return $validity;
	}

	/**
	 * Validate Email field for any forbidden characters.
	 *
	 * @param WP_Error $validity WordPress Error class.
	 * @param string   $value    Current input value.
	 *
	 * @return WP_Error
	 */
	public static function validate_email( $validity, $value ) {
		self::is_empty( $validity, $value );

		if ( ! filter_var( $value, FILTER_VALIDATE_EMAIL ) ) {
			$validity->add( 'wrong_email', __( 'Please enter a valid email address.', 'anky' ) );
		}

		return $validity;
	}

	/**
	 * Validate google map embed link.
	 *
	 * Add error message if passed value doesn't contain iframe and the value is not from google maps.
	 * Skip validation if passed value is empty string.  Not required to be filled.
	 *
	 * @param WP_Error $validity WordPress Error class.
	 * @param string   $value    Current input value.
	 *
	 * @return WP_Error
	 */
	public static function validate_google_map_embed( $validity, $value ) {
		if ( strlen( $value ) <= 1 ) {
			return $validity;
		}
		if ( false === anky_get_iframe_src( $value ) && false === strpos( $value, '//www.google.com/maps/embed' ) ) {
			$validity->add( 'wrong_embed', __( 'Please provide a correct embed link from Google Maps.', 'anky' ) );
		}

		return $validity;
	}

	/**
	 * Check if field is empty.
	 *
	 * @param WP_Error $validity WordPress Error class.
	 * @param string   $value    Current input value.
	 *
	 * @return WP_Error
	 */
	public static function is_empty( $validity, $value ) {
		if ( empty( $value ) ) {
			$validity->add( 'empty_field', __( 'Field must not be empty.', 'anky' ) );
		}

		return $validity;
	}

}

