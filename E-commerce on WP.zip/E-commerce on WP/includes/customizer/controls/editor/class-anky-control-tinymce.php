<?php
/**
 * Customizer Control: TinyMCE Control.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Controls\Editor;

use WP_Customize_Control;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 *  Customizer Control: TinyMCE Control.
 */
class Anky_Control_TinyMCE extends WP_Customize_Control {
	/**
	 * Control's Type.
	 *
	 * @since 3.4.0
	 * @var string
	 */
	public $type = 'anky-tinymce';

	/**
	 * Enqueue control related scripts/styles.
	 *
	 * @since 3.4.0
	 */
	public function enqueue() {
		wp_enqueue_style(
			'anky-custom-controls',
			ANKY_THEME_URI . 'assets/css/customizer' . ( ANKY_DEV_MODE ? '.css' : '.min.css' ),
			array(),
			ANKY_THEME_VERSION,
			'all'
		);
		wp_enqueue_editor();
	}

	/**
	 * Refresh the parameters passed to the JavaScript via JSON.
	 *
	 * @since 3.4.0
	 */
	public function to_json() {
		parent::to_json();
		$this->json['ankyTinymceToolbar1'] = isset( $this->input_attrs['toolbar1'] ) ? esc_attr( $this->input_attrs['toolbar1'] ) : 'bold italic bullist numlist alignleft aligncenter alignright link';
		$this->json['ankyTinymceToolbar2'] = isset( $this->input_attrs['toolbar2'] ) ? esc_attr( $this->input_attrs['toolbar2'] ) : '';
		$this->json['ankyMediaButtons']    = isset( $this->input_attrs['mediaButtons'] ) && ( true === $this->input_attrs['mediaButtons'] );
	}

	/**
	 * Render the control in the customizer
	 */
	public function render_content() {
		?>
		<div class="anky-tinymce-control">
			<label for="<?php echo esc_attr( $this->id ); ?>" class="customize-control-title"><?php echo esc_html( $this->label ); ?></label>
			<?php if ( ! empty( $this->description ) ) : ?>
				<p class="customize-control-description"><i><?php echo esc_html( $this->description ); ?></i></p>
			<?php endif; ?>
			<textarea id="<?php echo esc_attr( $this->id ); ?>" class="customize-control-tinymce-editor" <?php $this->link(); ?>><?php echo esc_html( $this->value() ); ?></textarea>
		</div>
		<?php
	}

}
