<?php
/**
 * Customizer Control: divider.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Controls\Divider;

use WP_Customize_Control;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Text control for separating control blocks.
 */
class Anky_Control_Divider extends WP_Customize_Control {

	/**
	 * The control type.
	 *
	 * @access public
	 * @var string
	 */
	public $type = 'anky-divider';

	/**
	 * Enqueue control related scripts/styles.
	 */
	public function enqueue() {
		wp_enqueue_style(
			'anky-custom-controls',
			ANKY_THEME_URI . 'assets/css/customizer' . ( ANKY_DEV_MODE ? '.css' : '.min.css' ),
			array(),
			ANKY_THEME_VERSION,
			'all'
		);
	}

	/**
	 * Render the control's content.
	 *
	 * @see WP_Customize_Control::render_content()
	 */
	protected function render_content() {
		echo '<div class="anky-control-heading-wrapper wp-ui-highlight">' . esc_html( $this->label ) . '</div>';
	}
}
