<?php
/**
 * Customizer Control: Google Font Select.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Controls\Fonts;

use WP_Customize_Control;
use WP_Customize_Manager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Google Font Select Custom Control.
 */
class Anky_Control_Google_Font_Select extends WP_Customize_Control {

	/**
	 * The type of control being rendered.
	 *
	 * @var string $type
	 */
	public $type = 'anky-google-font';

	/**
	 * The list of Google Fonts.
	 *
	 * @var bool $font_list
	 */
	private $font_list;

	/**
	 * The saved font values decoded from json.
	 *
	 * @var array $font_values
	 */
	private $font_values;

	/**
	 * The index of the saved font within the list of Google fonts
	 *
	 * @var int $font_list_index
	 */
	private $font_list_index;

	/**
	 * The number of fonts to display from the json file. Either positive integer or 'all'. Default = 'all'
	 *
	 * @var string|int $font_count
	 */
	private $font_count = 'all';

	/**
	 * The font list sort order. Either 'alpha' or 'popular'. Default = 'alpha'
	 *
	 * @var string $order_by
	 */
	private $order_by = 'alpha';

	/**
	 * Get our list of fonts from the json file
	 *
	 * @param WP_Customize_Manager $manager Customizer bootstrap instance.
	 * @param string               $id      Control ID.
	 * @param array                $args    All settings tied to the control. If undefined, `$id` will.
	 *
	 * @see WP_Customize_Control::__construct for settings details.
	 */
	public function __construct( $manager, $id, $args = array() ) {
		parent::__construct( $manager, $id, $args );

		// Get the font sort order.
		if ( isset( $this->input_attrs['order_by'] ) && 'popular' === strtolower( $this->input_attrs['order_by'] ) ) {
			$this->order_by = 'popular';
		}

		// Get the list of Google fonts.
		if ( isset( $this->input_attrs['font_count'] ) ) {
			if ( 'all' !== strtolower( $this->input_attrs['font_count'] ) ) {
				$this->font_count = ( abs( (int) $this->input_attrs['font_count'] ) > 0 ? abs( (int) $this->input_attrs['font_count'] ) : 'all' );
			}
		}
		$this->font_list = $this->get_fonts( $this->font_count );

		// Decode the default json font value.
		$this->font_values = json_decode( $this->value() );

		// Find the index of our default font within our list of Google fonts.
		$this->font_list_index = $this->get_font_index( $this->font_list, $this->font_values->family );
	}

	/**
	 * Return the list of Google Fonts from our json file.
	 *
	 * @param int $count How many fonts to obtain. Default is limited to 30 fonts.
	 *
	 * @return array|string
	 */
	public function get_fonts( $count = 30 ) {
		// Google Fonts json generated from https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=YOUR-API-KEY.
		$font_file = ANKY_THEME_DIR . 'includes/customizer/controls/fonts/google-fonts-alpha.php';
		if ( 'popular' === $this->order_by ) {
			$font_file = ANKY_THEME_DIR . 'includes/customizer/controls/fonts/google-fonts-popular.php';
		}

		$content = include $font_file;

		if ( 'all' === $count ) {
			return $content;
		} else {
			return array_slice( $content, 0, $count );
		}
	}

	/**
	 * Find the index of the saved font in our multidimensional array of Google Fonts
	 *
	 * @param array $haystack The array to search in.
	 * @param mixed $needle   The searched value.
	 *
	 * @return false|int|string
	 */
	public function get_font_index( $haystack, $needle ) {
		// Bail early.
		if ( ! is_array( $haystack ) ) {
			return false;
		}

		foreach ( $haystack as $key => $value ) {
			if ( $value->family === $needle ) {
				return $key;
			}
		}

		return false;
	}

	/**
	 * Enqueue control related scripts/styles.
	 */
	public function enqueue() {
		$loading_method = anky_get_option( 'globals-assets-loading-mode', 'cdn' );
		$assets         = array(
			'local' => array(
				'select2_js'  => anky_get_asset( '/js/select2.min.js' ),
				'select2_css' => anky_get_asset( '/css/vendors/select2.min.css' ),
			),
			'cdn'   => array(
				'select2_js'  => '//cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js',
				'select2_css' => '//cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/css/select2.min.css',
			),
		);
		wp_enqueue_script( 'select2', $assets[ $loading_method ]['select2_js'], array( 'jquery' ), '4.1.0-rc.0', true );
		wp_enqueue_style( 'select2', $assets[ $loading_method ]['select2_css'], array(), '4.1.0-rc.0', 'all' );

		wp_enqueue_style(
			'anky-custom-controls',
			anky_get_asset( 'css/customizer' . ( ANKY_DEV_MODE ? '.css' : '.min.css' ) ),
			array( 'select2' ),
			ANKY_THEME_VERSION,
			'all'
		);
	}

	/**
	 * Export our List of Google Fonts to JavaScript
	 */
	public function to_json() {
		parent::to_json();
		$this->json['ankyGoogleFonts'] = $this->font_list;
	}

	/**
	 * Render the control in the customizer
	 */
	public function render_content() {
		// Bail early.
		if ( empty( $this->font_list ) ) {
			return;
		}

		$font_counter    = 0;
		$is_font_in_list = false;
		$font_list_str   = '';
		$option_tmpl     = '<option value="%1$s" %2$s>%3$s</option>';
		$input_props     = array(
			'main'     => array(
				'type'  => 'hidden',
				'name'  => $this->id,
				'value' => $this->value(),
				'class' => 'customize-control-google-font-selection',
			),
			'category' => array(
				'type'  => 'hidden',
				'value' => $this->font_values->category,
				'class' => 'anky-fonts-category',
			),
		);
		?>
		<div class="anky-google-fonts-select-control">
			<input <?php anky_the_atts( $input_props['main'] ); ?> <?php $this->link(); ?> />
			<input <?php anky_the_atts( $input_props['category'] ); ?>>

			<?php
			// ======================================================
			// Font Families
			// ======================================================
			?>
			<div class="anky-google-fonts">
				<label for="<?php echo esc_attr( $this->id ); ?>">
					<?php if ( ! empty( $this->label ) ) : ?>
						<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $this->description ) ) : ?>
						<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
					<?php endif; ?>
				</label>
				<select class="anky-google-fonts-list" data-control-id="<?php echo esc_attr( $this->id ); ?>" id="<?php echo esc_attr( $this->id ); ?>">
					<?php
					foreach ( $this->font_list as $value ) {
						$font_counter ++;

						$font_list_str .= sprintf( $option_tmpl, $value->family, selected( $this->font_values->family, $value->family, false ), $value->family );

						if ( $this->font_values->family === $value->family ) {
							$is_font_in_list = true;
						}

						if ( is_int( $this->font_count ) && $font_counter === $this->font_count ) {
							break;
						}
					}

					// If the default or saved font value isn't in the list of displayed fonts, add it to the top of the list as the default font.
					if ( ! $is_font_in_list && $this->font_list_index ) {
						$font_list_str = sprintf(
							$option_tmpl,
							$this->font_list[ $this->font_list_index ]->family,
							selected(
								$this->font_values->family,
								$this->font_list[ $this->font_list_index ]->family,
								false
							),
							$this->font_list[ $this->font_list_index ]->family . ' - ' . esc_html__( 'Default', 'anky' )
						);
					}

					// Display list of font options.
					echo wp_kses(
						$font_list_str,
						array(
							'option' => array(
								'value'    => true,
								'selected' => true,
							),
						)
					);
					?>
				</select>
			</div>

			<?php
			// ======================================================
			// Font Weight for Regular
			// ======================================================
			?>
			<div class="anky-weight-style">
				<label for="<?php echo esc_attr( $this->id . '-regular-weight' ); ?>" class="customize-control-description">
					<?php
					/* translators: 1 tag for making text bolder, 2 closing tag.*/
					printf( esc_html__( 'Select weight & style for %1$sRegular%2$s text', 'anky' ), '<b>', '</b>' );
					?>
				</label>
				<select class="anky-font-regular-weight-style" id="<?php echo esc_attr( $this->id . '-regular-weight' ); ?>">
					<?php
					foreach ( $this->font_list[ $this->font_list_index ]->variants as $value ) {
						printf( $option_tmpl, $value, selected( $this->font_values->regularWeight, $value, false ), $value ); // phpcs:ignore WordPress.Security.EscapeOutput
					}
					?>
				</select>
			</div>

			<?php
			// ======================================================
			// Font Weight for Italic
			// ======================================================
			?>
			<div class="anky-weight-style">
				<label for="<?php echo esc_attr( $this->id . '-italic-weight' ); ?>" class="customize-control-description">
					<?php
					/* translators: 1 tag for making text bolder, 2 closing tag.*/
					printf( esc_html__( 'Select weight & style for %1$sItalic%2$s text', 'anky' ), '<b>', '</b>' );
					?>
				</label>
				<select class="anky-fonts-italic-weight-style" <?php disabled( in_array( 'italic', $this->font_list[ $this->font_list_index ]->variants, true ), false ); ?>
					id="<?php echo esc_attr( $this->id . '-italic-weight' ); ?>">
					<?php
					$option_count = 0;
					foreach ( $this->font_list[ $this->font_list_index ]->variants as $value ) {
						// Only add options that are italic.
						if ( strpos( $value, 'italic' ) !== false ) {
							printf( $option_tmpl, $value, selected( $this->font_values->italicWeight, $value, false ), $value ); // phpcs:ignore WordPress.Security.EscapeOutput
							$option_count ++;
						}
					}
					if ( 0 === $option_count ) {
						echo '<option value="" selected disabled> ' . esc_html__( 'Not Available for this font', 'anky' ) . '</option>';
					}
					?>
				</select>
			</div>

			<?php
			// ======================================================
			// Font Weight for Bold
			// ======================================================
			?>
			<div class="anky-weight-style">
				<label for="<?php echo esc_attr( $this->id . '-bold-weight' ); ?>" class="customize-control-description">
					<?php
					/* translators: 1 tag for making text bolder, 2 closing tag.*/
					printf( esc_html__( 'Select weight & style for %1$sBold%2$s text', 'anky' ), '<b>', '</b>' );
					?>
				</label>
				<select class="anky-fonts-bold-weight-style" id="<?php echo esc_attr( $this->id . '-bold-weight' ); ?>">
					<?php
					$option_count = 0;
					foreach ( $this->font_list[ $this->font_list_index ]->variants as $value ) {
						// Only add options that are NOT italic.
						if ( strpos( $value, 'italic' ) === false ) {
							printf( $option_tmpl, $value, selected( $this->font_values->boldWeight, $value, false ), $value ); // phpcs:ignore WordPress.Security.EscapeOutput
							$option_count ++;
						}
					}

					// This should never evaluate as there'll always be at least a 'regular' weight.
					if ( 0 === $option_count ) {
						echo '<option value="" selected disabled> ' . esc_html__( 'Not Available for this font', 'anky' ) . '</option>';
					}
					?>
				</select>
			</div>
		</div>
		<?php
	}

}
