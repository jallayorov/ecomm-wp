<?php
/**
 * Google fonts array parsed from Google Fonts json and sorted by popularity.
 *
 * @package    Anky
 * @subpackage Customizer
 * @sinse      1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

return array(
	(object) array(
		'family'   => 'Roboto',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '700',
				9  => '700italic',
				10 => '900',
				11 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Open Sans',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
				8 => '800',
				9 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Noto Sans JP',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'japanese',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Lato',
		'variants' =>
			array(
				0 => '100',
				1 => '100italic',
				2 => '300',
				3 => '300italic',
				4 => 'regular',
				5 => 'italic',
				6 => '700',
				7 => '700italic',
				8 => '900',
				9 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Montserrat',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Roboto Condensed',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Source Sans Pro',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '600',
				7  => '600italic',
				8  => '700',
				9  => '700italic',
				10 => '900',
				11 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Oswald',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Roboto Mono',
		'variants' =>
			array(
				0 => '100',
				1 => '100italic',
				2 => '300',
				3 => '300italic',
				4 => 'regular',
				5 => 'italic',
				6 => '500',
				7 => '500italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Raleway',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Poppins',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Noto Sans',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'devanagari',
				3 => 'greek',
				4 => 'greek-ext',
				5 => 'latin',
				6 => 'latin-ext',
				7 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Roboto Slab',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Merriweather',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
				6 => '900',
				7 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'PT Sans',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Ubuntu',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Playfair Display',
		'variants' =>
			array(
				0  => 'regular',
				1  => '500',
				2  => '600',
				3  => '700',
				4  => '800',
				5  => '900',
				6  => 'italic',
				7  => '500italic',
				8  => '600italic',
				9  => '700italic',
				10 => '800italic',
				11 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mukta',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Muli',
		'variants' =>
			array(
				0  => '200',
				1  => '300',
				2  => 'regular',
				3  => '500',
				4  => '600',
				5  => '700',
				6  => '800',
				7  => '900',
				8  => '200italic',
				9  => '300italic',
				10 => 'italic',
				11 => '500italic',
				12 => '600italic',
				13 => '700italic',
				14 => '800italic',
				15 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Open Sans Condensed',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'PT Serif',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Lora',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => 'italic',
				5 => '500italic',
				6 => '600italic',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Nunito',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '600',
				7  => '600italic',
				8  => '700',
				9  => '700italic',
				10 => '800',
				11 => '800italic',
				12 => '900',
				13 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Noto Sans KR',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Fira Sans',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Work Sans',
		'variants' =>
			array(
				0  => '100',
				1  => '200',
				2  => '300',
				3  => 'regular',
				4  => '500',
				5  => '600',
				6  => '700',
				7  => '800',
				8  => '900',
				9  => '100italic',
				10 => '200italic',
				11 => '300italic',
				12 => 'italic',
				13 => '500italic',
				14 => '600italic',
				15 => '700italic',
				16 => '800italic',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Titillium Web',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '600',
				7  => '600italic',
				8  => '700',
				9  => '700italic',
				10 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rubik',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
				6 => '700',
				7 => '700italic',
				8 => '900',
				9 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'hebrew',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Noto Serif',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Noto Sans TC',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'chinese-traditional',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Quicksand',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Nanum Gothic',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '800',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Nunito Sans',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '600',
				7  => '600italic',
				8  => '700',
				9  => '700italic',
				10 => '800',
				11 => '800italic',
				12 => '900',
				13 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Hind Siliguri',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'bengali',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'PT Sans Narrow',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Anton',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Heebo',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Inconsolata',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
				7 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Arimo',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'hebrew',
				5 => 'latin',
				6 => 'latin-ext',
				7 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Dosis',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Oxygen',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Barlow',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Karla',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Slabo 27px',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cabin',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Crimson Text',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '600',
				3 => '600italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Libre Baskerville',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Josefin Sans',
		'variants' =>
			array(
				0  => '100',
				1  => '200',
				2  => '300',
				3  => 'regular',
				4  => '500',
				5  => '600',
				6  => '700',
				7  => '100italic',
				8  => '200italic',
				9  => '300italic',
				10 => 'italic',
				11 => '500italic',
				12 => '600italic',
				13 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bitter',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Libre Franklin',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Yanone Kaffeesatz',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Source Code Pro',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
				12 => '900',
				13 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'latin',
				4 => 'latin-ext',
				5 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Hind',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Teko',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Dancing Script',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Fjalla One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Abel',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Lobster',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Indie Flower',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Pacifico',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Varela Round',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Merriweather Sans',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
				6 => '800',
				7 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Exo 2',
		'variants' =>
			array(
				0  => '100',
				1  => '200',
				2  => '300',
				3  => 'regular',
				4  => '500',
				5  => '600',
				6  => '700',
				7  => '800',
				8  => '900',
				9  => '100italic',
				10 => '200italic',
				11 => '300italic',
				12 => 'italic',
				13 => '500italic',
				14 => '600italic',
				15 => '700italic',
				16 => '800italic',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Source Serif Pro',
		'variants' =>
			array(
				0 => 'regular',
				1 => '600',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Arvo',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Overpass',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
				12 => '800',
				13 => '800italic',
				14 => '900',
				15 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Kanit',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Shadows Into Light',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'IBM Plex Sans',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'latin',
				4 => 'latin-ext',
				5 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cairo',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '600',
				4 => '700',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Comfortaa',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'latin',
				4 => 'latin-ext',
				5 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Amiri',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Noto Sans SC',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Barlow Condensed',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Hind Madurai',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Prompt',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Questrial',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Abril Fatface',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Asap',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Acme',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'EB Garamond',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
				5 => 'italic',
				6 => '500italic',
				7 => '600italic',
				8 => '700italic',
				9 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Bree Serif',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Amatic SC',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'hebrew',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Catamaran',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Archivo Narrow',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Martel',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '600',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Zilla Slab',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
				6 => '600',
				7 => '600italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Exo',
		'variants' =>
			array(
				0  => '100',
				1  => '200',
				2  => '300',
				3  => 'regular',
				4  => '500',
				5  => '600',
				6  => '700',
				7  => '800',
				8  => '900',
				9  => '100italic',
				10 => '200italic',
				11 => '300italic',
				12 => 'italic',
				13 => '500italic',
				14 => '600italic',
				15 => '700italic',
				16 => '800italic',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Play',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'latin',
				4 => 'latin-ext',
				5 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Domine',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Maven Pro',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cormorant Garamond',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
				6 => '600',
				7 => '600italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Fira Sans Condensed',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Righteous',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'PT Sans Caption',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rajdhani',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Signika',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Permanent Marker',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'IBM Plex Serif',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Fredoka One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Caveat',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Patua One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Crete Round',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Assistant',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '600',
				4 => '700',
				5 => '800',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Ubuntu Condensed',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Nanum Myeongjo',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '800',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Patrick Hand',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Vollkorn',
		'variants' =>
			array(
				0  => 'regular',
				1  => '500',
				2  => '600',
				3  => '700',
				4  => '800',
				5  => '900',
				6  => 'italic',
				7  => '500italic',
				8  => '600italic',
				9  => '700italic',
				10 => '800italic',
				11 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'latin',
				4 => 'latin-ext',
				5 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'ABeeZee',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Tajawal',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Frank Ruhl Libre',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '700',
				4 => '900',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Noticia Text',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Rokkitt',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Alegreya Sans',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '700',
				9  => '700italic',
				10 => '800',
				11 => '800italic',
				12 => '900',
				13 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Francois One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Satisfy',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Cinzel',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Alegreya',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '700',
				5 => '700italic',
				6 => '800',
				7 => '800italic',
				8 => '900',
				9 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Courgette',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Barlow Semi Condensed',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cuprum',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Alfa Slab One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kalam',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Kaushan Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Monda',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Tinos',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'hebrew',
				5 => 'latin',
				6 => 'latin-ext',
				7 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cardo',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'greek',
				1 => 'greek-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Noto Serif JP',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'japanese',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Passion One',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lobster Two',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Pathway Gothic One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Great Vibes',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Bebas Neue',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Archivo',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Istok Web',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Archivo Black',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Fira Sans Extra Condensed',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'News Cycle',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'DM Sans',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Volkhov',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Gloria Hallelujah',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Sacramento',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Quattrocento Sans',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cantarell',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Taviraj',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Didact Gothic',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Concert One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Old Standard TT',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Parisienne',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Baloo 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Yantramanav',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Ropa Sans',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Squada One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Hind Vadodara',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Sarabun',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Orbitron',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'M PLUS 1p',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'hebrew',
				5 => 'japanese',
				6 => 'latin',
				7 => 'latin-ext',
				8 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Montserrat Alternates',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Playfair Display SC',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
				4 => '900',
				5 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Prata',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cookie',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Changa',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Lalezar',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Inter',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Luckiest Guy',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Poiret One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Chivo',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
				6 => '900',
				7 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Josefin Slab',
		'variants' =>
			array(
				0 => '100',
				1 => '100italic',
				2 => '300',
				3 => '300italic',
				4 => 'regular',
				5 => 'italic',
				6 => '600',
				7 => '600italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Bad Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Hind Guntur',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'BenchNine',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Quattrocento',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Neuton',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'PT Mono',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Special Elite',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Russo One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Advent Pro',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
			),
		'subsets'  =>
			array(
				0 => 'greek',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Ultra',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Sawarabi Mincho',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'japanese',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Handlee',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Economica',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Philosopher',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bangers',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Vidaloka',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Sanchez',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Asap Condensed',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Ruda',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Gentium Basic',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Khand',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Marck Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Basic',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Gudea',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Press Start 2P',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'latin',
				4 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'M PLUS Rounded 1c',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'hebrew',
				5 => 'japanese',
				6 => 'latin',
				7 => 'latin-ext',
				8 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Karma',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Pragati Narrow',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Arapey',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Markazi Text',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Alice',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Unica One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Architects Daughter',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Hammersmith One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Sigmar One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Cabin Condensed',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Jaldi',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Mitr',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Spectral',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
				12 => '800',
				13 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Yellowtail',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Neucha',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Monoton',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'El Messiri',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'cyrillic',
				2 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Paytone One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Adamina',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Viga',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Coda',
		'variants' =>
			array(
				0 => 'regular',
				1 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Cormorant',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
				6 => '600',
				7 => '600italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Nanum Gothic Coding',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Audiowide',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Tangerine',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Pontano Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Homemade Apple',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Actor',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Merienda',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Amaranth',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Gothic A1',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Enriqueta',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Overpass Mono',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Gochi Hand',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Carter One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Pangolin',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'DM Serif Text',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Space Mono',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Rock Salt',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Sarala',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Playball',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Saira',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Oleo Script',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Aclonica',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Gentium Book Basic',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Electrolize',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rambla',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Alef',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Julius Sans One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Staatliches',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Fauna One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Lusitana',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Allura',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Fugaz One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Spartan',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Tenor Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Shadows Into Light Two',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Ramabhadra',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Baloo Chettan 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'malayalam',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Yrsa',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Varela',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Sawarabi Gothic',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'japanese',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bowlby One SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Damion',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Chewy',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Cantata One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Nanum Pen Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Covered By Your Grace',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Yeseva One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Mr Dafoe',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Kreon',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Abhaya Libre',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'sinhala',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Signika Negative',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Alex Brush',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Sorts Mill Goudy',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Unna',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Lilita One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'PT Serif Caption',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Marmelad',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Armata',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Antic',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Spinnaker',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Encode Sans',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Ubuntu Mono',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Lateef',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Jura',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Sintony',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Average',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Quantico',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'DM Serif Display',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Scada',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Marcellus',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Boogaloo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Khula',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Black Han Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'IBM Plex Mono',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Pridi',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Pinyon Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Reem Kufi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Nothing You Could Do',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Allerta',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Palanquin',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Kelly Slab',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Arsenal',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Glegoo',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Noto Serif SC',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cousine',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'hebrew',
				5 => 'latin',
				6 => 'latin-ext',
				7 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Padauk',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'myanmar',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Michroma',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Krub',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Black Ops One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Miriam Libre',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Encode Sans Condensed',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Saira Semi Condensed',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Antic Slab',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Alegreya Sans SC',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '700',
				9  => '700italic',
				10 => '800',
				11 => '800italic',
				12 => '900',
				13 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Caveat Brush',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Chakra Petch',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
				6 => '600',
				7 => '600italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Forum',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Capriola',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'VT323',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Annie Use Your Telescope',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Allan',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Rancho',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Anonymous Pro',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'greek',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Fredericka the Great',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Martel Sans',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '600',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bevan',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Share',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kameron',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cabin Sketch',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Judson',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Slabo 13px',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Overlock',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
				4 => '900',
				5 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Biryani',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '600',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rubik Mono One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rufina',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Share Tech Mono',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Gelasio',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Sriracha',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Lemonada',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Days One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Saira Extra Condensed',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Mali',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Candal',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Fira Mono',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Scheherazade',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Arbutus Slab',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Do Hyeon',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Halant',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cinzel Decorative',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Hanuman',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Bai Jamjuree',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Arima Madurai',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '700',
				6 => '800',
				7 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Saira Condensed',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bungee',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Shrikhand',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Itim',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Reenie Beanie',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Mukta Malar',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Berkshire Swash',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Niconne',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Suez One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Knewave',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Just Another Hand',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Gruppo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Noto Sans HK',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'chinese-hongkong',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Aldrich',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Italianno',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Leckerli One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'ZCOOL XiaoWei',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Caudex',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'greek',
				1 => 'greek-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Noto Serif TC',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'chinese-traditional',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Allerta Stencil',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Kosugi Maru',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'japanese',
				2 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Syncopate',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Londrina Solid',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Red Hat Display',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '700',
				5 => '700italic',
				6 => '900',
				7 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Eczar',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mada',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Marcellus SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Coustard',
		'variants' =>
			array(
				0 => 'regular',
				1 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Six Caps',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Raleway Dots',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Aleo',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mrs Saint Delafield',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Bentham',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Coming Soon',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Mallanna',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Magra',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Molengo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Trirong',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Racing Sans One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nobile',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bungee Inline',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kadwa',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Yesteryear',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Norican',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Sunflower',
		'variants' =>
			array(
				0 => '300',
				1 => '500',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Contrail One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Average Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Telex',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Krona One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Copse',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Pattaya',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'thai',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Grand Hotel',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Coda Caption',
		'variants' =>
			array(
				0 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'IBM Plex Sans Condensed',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Buenard',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Aladin',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Cutive Mono',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Oranienbaum',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Lexend Deca',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cormorant Infant',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
				6 => '600',
				7 => '600italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Alegreya SC',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '700',
				5 => '700italic',
				6 => '800',
				7 => '800italic',
				8 => '900',
				9 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
				6 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'IM Fell Double Pica',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Bubblegum Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Arizonia',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Suranna',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Graduate',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Chonburi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Duru Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Maitree',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Nanum Brush Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Rochester',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Lustria',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Jockey One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Amethysta',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Sofia',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Faustina',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => 'italic',
				5 => '500italic',
				6 => '600italic',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Changa One',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Noto Serif KR',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Almarai',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '700',
				3 => '800',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Homenaje',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Secular One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Carme',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rozha One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cedarville Cursive',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Titan One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Public Sans',
		'variants' =>
			array(
				0  => '100',
				1  => '200',
				2  => '300',
				3  => 'regular',
				4  => '500',
				5  => '600',
				6  => '700',
				7  => '800',
				8  => '900',
				9  => '100italic',
				10 => '200italic',
				11 => '300italic',
				12 => 'italic',
				13 => '500italic',
				14 => '600italic',
				15 => '700italic',
				16 => '800italic',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Petit Formal Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Delius',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Cambay',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Ovo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Marvel',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Mukta Vaani',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Schoolbell',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Lemon',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Laila',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Ceviche One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Merienda One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Love Ya Like A Sister',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Voltaire',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Carrois Gothic',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rye',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Belgrano',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Herr Von Muellerhoff',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Rasa',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Chelsea Market',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nixie One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Amiko',
		'variants' =>
			array(
				0 => 'regular',
				1 => '600',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'GFS Didot',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'greek',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Freckle Face',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sansita',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
				4 => '800',
				5 => '800italic',
				6 => '900',
				7 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Palanquin Dark',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Rosario',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
				5 => '300italic',
				6 => 'italic',
				7 => '500italic',
				8 => '600italic',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Calligraffitti',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Kristi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Belleza',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Metrophobic',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Radley',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cutive',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Gurajada',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Stardos Stencil',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Mr De Haviland',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Gilda Display',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Averia Serif Libre',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Federo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Athiti',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'McLaren',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Corben',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Oxygen Mono',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Pompiere',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Goudy Bookletter 1911',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Emilys Candy',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Unkempt',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Poly',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Vast Shadow',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Seaweed Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lekton',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bowlby One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sniglet',
		'variants' =>
			array(
				0 => 'regular',
				1 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Mate',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Anaheim',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Literata',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => 'italic',
				5 => '500italic',
				6 => '600italic',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'greek',
				2 => 'greek-ext',
				3 => 'latin',
				4 => 'latin-ext',
				5 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Inder',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'UnifrakturMaguntia',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Convergence',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Quando',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Antic Didone',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Sedgwick Ave',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Andada',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Fanwood Text',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Harmattan',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Fresca',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Montez',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Alike',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Gabriela',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Amita',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Megrim',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Frijole',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Red Hat Text',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Sue Ellen Francisco',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Trocchi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'IM Fell English',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'K2D',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cambo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Baumans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Esteban',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Jua',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Gravitas One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Fondamento',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Niramit',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Libre Caslon Text',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Walter Turncoat',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Kurale',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'devanagari',
				3 => 'latin',
				4 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mirza',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Gugi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Holtwood One SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Doppio One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'IM Fell DW Pica',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Wallpoet',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Rammetto One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Rouge Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Oleo Script Swash Caps',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'La Belle Aurore',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Battambang',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Share Tech',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Mountains of Christmas',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'NTR',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Give You Glory',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Shojumaru',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sen',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cormorant SC',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Crafty Girls',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Proza Libre',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
				8 => '800',
				9 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Livvic',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '900',
				15 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Alata',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Patrick Hand SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Bungee Shade',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Expletus Sans',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '500',
				3 => '500italic',
				4 => '600',
				5 => '600italic',
				6 => '700',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Limelight',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Strait',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Qwigley',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Happy Monkey',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Clicker Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Balthazar',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Podkova',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Brawler',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Spirax',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Fjord One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mouse Memoirs',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Spectral SC',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
				12 => '800',
				13 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Rakkas',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Faster One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Aref Ruqaa',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Alike Angular',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Bellefair',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Voces',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Cantora One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Mako',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Skranji',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Timmana',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Dawning of a New Day',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Cormorant Upright',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Montserrat Subrayada',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Andika',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Short Stack',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Zeyada',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Averia Sans Libre',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Oregano',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Aguafina Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Shanti',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Wendy One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Galada',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'bengali',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Iceland',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Geo',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Kosugi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'japanese',
				2 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Charm',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'BioRhyme',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Numans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Mandali',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Waiting for the Sunrise',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Sail',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'IM Fell French Canon SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Ruluko',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Jost',
		'variants' =>
			array(
				0  => '100',
				1  => '200',
				2  => '300',
				3  => 'regular',
				4  => '500',
				5  => '600',
				6  => '700',
				7  => '800',
				8  => '900',
				9  => '100italic',
				10 => '200italic',
				11 => '300italic',
				12 => 'italic',
				13 => '500italic',
				14 => '600italic',
				15 => '700italic',
				16 => '800italic',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Tauri',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Meddon',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Spicy Rice',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Euphoria Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Katibeh',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Puritan',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Imprima',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Tienne',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Loved by the King',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Vesper Libre',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '700',
				3 => '900',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'B612 Mono',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Finger Paint',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Delius Swash Caps',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Fontdiner Swanky',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nova Square',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ledger',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Meera Inimai',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'tamil',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bilbo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'David Libre',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'hebrew',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Pavanam',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Life Savers',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
				2 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Artifika',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Sonsie One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'The Girl Next Door',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Encode Sans Expanded',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Over the Rainbow',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Dokdo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Petrona',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Manrope',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'greek',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Denk One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Manjari',
		'variants' =>
			array(
				0 => '100',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'malayalam',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Baloo Bhaina 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'oriya',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Cherry Swash',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sarpanch',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
				5 => '900',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Gafata',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Carrois Gothic SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Srisakdi',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Princess Sofia',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Atma',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'bengali',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Rationale',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Darker Grotesque',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Dekko',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Eater',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ma Shan Zheng',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Codystar',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Port Lligat Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Libre Barcode 39',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ranchers',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Salsa',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Metamorphous',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Headland One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Encode Sans Semi Expanded',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Creepster',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Encode Sans Semi Condensed',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Bilbo Swash Caps',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Farro',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Vibur',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Orienta',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Sirin Stencil',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Manuale',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => 'italic',
				5 => '500italic',
				6 => '600italic',
				7 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Zilla Slab Highlight',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Crimson Pro',
		'variants' =>
			array(
				0  => '200',
				1  => '300',
				2  => 'regular',
				3  => '500',
				4  => '600',
				5  => '700',
				6  => '800',
				7  => '900',
				8  => '200italic',
				9  => '300italic',
				10 => 'italic',
				11 => '500italic',
				12 => '600italic',
				13 => '700italic',
				14 => '800italic',
				15 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Vollkorn SC',
		'variants' =>
			array(
				0 => 'regular',
				1 => '600',
				2 => '700',
				3 => '900',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Kotta One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Trade Winds',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lily Script One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Wire One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Englebert',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Prosto One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Fascinate Inline',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Yatra One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Vampiro One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nova Mono',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'greek',
				1 => 'latin',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Saira Stencil One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'ZCOOL QingKe HuangYou',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nosifer',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ruslan Display',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Slackey',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ribeye Marrow',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Grenze',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Just Me Again Down Here',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Sree Krushnadevaraya',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Alatsi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Cherry Cream Soda',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ewert',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bubbler One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Medula One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Almendra',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Chau Philomene One',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Jacques Francois Shadow',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Trochut',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Dynalight',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Amarante',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Elsie',
		'variants' =>
			array(
				0 => 'regular',
				1 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ibarra Real Nova',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '600',
				3 => '600italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Flamenco',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Mukta Mahee',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'gurmukhi',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Farsan',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Germania One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Scope One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Italiana',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Kranky',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Arya',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Macondo Swash Caps',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sumana',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Averia Gruesa Libre',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ribeye',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Gaegu',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'B612',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Asul',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Comic Neue',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Averia Libre',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Unlock',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Baskervville',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Port Lligat Slab',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Peralta',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'IM Fell English SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Ranga',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Inknut Antiqua',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
				5 => '800',
				6 => '900',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Be Vietnam',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
				12 => '800',
				13 => '800italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Caladea',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Hepta Slab',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '500',
				5 => '600',
				6 => '700',
				7 => '800',
				8 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mate SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Baloo Tamma 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'kannada',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sura',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Gamja Flower',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Ramaraja',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Sarina',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Coiny',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'League Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Engagement',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Modak',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Crushed',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Thasadith',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Habibi',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Blinker',
		'variants' =>
			array(
				0 => '100',
				1 => '200',
				2 => '300',
				3 => 'regular',
				4 => '600',
				5 => '700',
				6 => '800',
				7 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Kumar One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Rosarivo',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Snippet',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Tillana',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Balsamiq Sans',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kite One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Stoke',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Paprika',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Chathura',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Barriecito',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Chicle',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Milonga',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Gupter',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Fira Code',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'greek',
				3 => 'greek-ext',
				4 => 'latin',
				5 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Fenix',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Poller One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Stint Ultra Expanded',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Quintessential',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'IM Fell French Canon',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Henny Penny',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Simonetta',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '900',
				3 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'UnifrakturCook',
		'variants' =>
			array(
				0 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nova Round',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Monsieur La Doulaise',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Dorsa',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Koulen',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Stint Ultra Condensed',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sedgwick Ave Display',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Mystery Quest',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Overlock SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Akronim',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Mogra',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Big Shoulders Text',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
				7 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Chango',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Prociono',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Stalemate',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Marko One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Diplomata SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Girassol',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Miniver',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Pirata One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lovers Quarrel',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Delius Unicase',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Yeon Sung',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Maiden Orange',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Hanalei Fill',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sancreek',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kavoon',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Text Me One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Lakki Reddy',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Khmer',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Eagle Lake',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Calistoga',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Condiment',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Big Shoulders Display',
		'variants' =>
			array(
				0 => '100',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
				7 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Notable',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Donegal One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Tulpen One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Margarine',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Mina',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'bengali',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Londrina Outline',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Barrio',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Angkor',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Julee',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Buda',
		'variants' =>
			array(
				0 => '300',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Montaga',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Kodchasan',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Swanky and Moo Moo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Flavors',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bayon',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'IM Fell Great Primer',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Nokora',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Uncial Antiqua',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Cagliostro',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Vibes',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'New Rocker',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Oxanium',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '600',
				5 => '700',
				6 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Junge',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Rum Raisin',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Diplomata',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Asar',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mansalva',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Hi Melody',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Offside',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bigshot One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Jomolhari',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'tibetan',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Charmonman',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Libre Barcode 39 Extended Text',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Moul',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Cormorant Unicase',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '600',
				4 => '700',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Stylish',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Nova Flat',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Della Respira',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'DM Mono',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '500',
				5 => '500italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Baloo Thambi 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'KoHo',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Autour One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Redressed',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Underdog',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Rhodium Libre',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Griffy',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Glass Antiqua',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Song Myung',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Mrs Sheppards',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Content',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Galdeano',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Baloo Paaji 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'gurmukhi',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Chela One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Trykker',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Revalia',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bellota Text',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Wellfleet',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Smythe',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Chilanka',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'malayalam',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'IM Fell DW Pica SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Linden Hill',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Ruthie',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Major Mono Display',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'Baloo Da 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'bengali',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Inika',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Arbutus',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bokor',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nova Slim',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Joti One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Jim Nightshade',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Elsie Swash Caps',
		'variants' =>
			array(
				0 => 'regular',
				1 => '900',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Croissant One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Modern Antiqua',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kantumruy',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Kulim Park',
		'variants' =>
			array(
				0 => '200',
				1 => '200italic',
				2 => '300',
				3 => '300italic',
				4 => 'regular',
				5 => 'italic',
				6 => '600',
				7 => '600italic',
				8 => '700',
				9 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Risque',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Poor Story',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Smokum',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Libre Barcode 128',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Oldenburg',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Jomhuria',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'arabic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Fahkwang',
		'variants' =>
			array(
				0  => '200',
				1  => '200italic',
				2  => '300',
				3  => '300italic',
				4  => 'regular',
				5  => 'italic',
				6  => '500',
				7  => '500italic',
				8  => '600',
				9  => '600italic',
				10 => '700',
				11 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'thai',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Lexend Exa',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Monofett',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Federant',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Purple Purse',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Odor Mean Chey',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'MedievalSharp',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Metal Mania',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Keania One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Irish Grover',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Caesar Dressing',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Iceberg',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Meie Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Felipa',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Devonshire',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Libre Barcode 39 Extended',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Dangrek',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bahiana',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Gotu',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Sahitya',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'devanagari',
				1 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Nova Cut',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Londrina Shadow',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Original Surfer',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Peddana',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Cute Font',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Jacques Francois',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Kirang Haerang',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Asset',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Gorditas',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Libre Caslon Display',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Ravi Prakash',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Goblin One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lancelot',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Tomorrow',
		'variants' =>
			array(
				0  => '100',
				1  => '100italic',
				2  => '200',
				3  => '200italic',
				4  => '300',
				5  => '300italic',
				6  => 'regular',
				7  => 'italic',
				8  => '500',
				9  => '500italic',
				10 => '600',
				11 => '600italic',
				12 => '700',
				13 => '700italic',
				14 => '800',
				15 => '800italic',
				16 => '900',
				17 => '900italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Siemreap',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Plaster',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Emblema One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bungee Outline',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Atomic Age',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Almendra SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Galindo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Butcherman',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Libre Barcode 39 Text',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Courier Prime',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'monospace',
	),
	(object) array(
		'family'   => 'East Sea Dokdo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Piedra',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Odibee Sans',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'IM Fell Great Primer SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Snowburst One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'IM Fell Double Pica SC',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Freehand',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Ruge Boogie',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Black And White Picture',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
				1 => 'latin',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Dr Sugiyama',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Almendra Display',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Inria Serif',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Romanesco',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Kavivanar',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'tamil',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Kumar One Outline',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sunshiney',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'GFS Neohellenic',
		'variants' =>
			array(
				0 => 'regular',
				1 => 'italic',
				2 => '700',
				3 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'greek',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Fascinate',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Miss Fajardose',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Jolly Lodger',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Astloch',
		'variants' =>
			array(
				0 => 'regular',
				1 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Taprom',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Supermercado One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lacquer',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Molle',
		'variants' =>
			array(
				0 => 'italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Beth Ellen',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Macondo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sofadi One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Seymour One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Preahvihear',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bellota',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Fruktur',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Liu Jian Mao Cao',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Libre Barcode 128 Text',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Tenali Ramakrishna',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Metal',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bonbon',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Butterfly Kids',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'ZCOOL KuaiLe',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sevillana',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Hanalei',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Gidugu',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Erica One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Combo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Miltonian',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Mr Bedfort',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Miltonian Tattoo',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nova Script',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Geostar Fill',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bigelow Rules',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Baloo Bhai 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'gujarati',
				1 => 'latin',
				2 => 'latin-ext',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Nova Oval',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Stalinist One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'latin',
				2 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bungee Hairline',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Aubrey',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Sulphur Point',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Gayathri',
		'variants' =>
			array(
				0 => '100',
				1 => 'regular',
				2 => '700',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'malayalam',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Solway',
		'variants' =>
			array(
				0 => '300',
				1 => 'regular',
				2 => '500',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Suwannaphum',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Londrina Sketch',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kdam Thmor',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Single Day',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'korean',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Passero One',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Dhurjati',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Zhi Mang Xing',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'Inria Sans',
		'variants' =>
			array(
				0 => '300',
				1 => '300italic',
				2 => 'regular',
				3 => 'italic',
				4 => '700',
				5 => '700italic',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Lexend Giga',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Moulpali',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Geostar',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Kenia',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Suravaram',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'telugu',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Chenla',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Long Cang',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'chinese-simplified',
				1 => 'latin',
			),
		'category' => 'handwriting',
	),
	(object) array(
		'family'   => 'BioRhyme Expanded',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Fasthand',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'khmer',
			),
		'category' => 'serif',
	),
	(object) array(
		'family'   => 'Warnes',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lexend Tera',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Turret Road',
		'variants' =>
			array(
				0 => '200',
				1 => '300',
				2 => 'regular',
				3 => '500',
				4 => '700',
				5 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Viaoda Libre',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'cyrillic',
				1 => 'cyrillic-ext',
				2 => 'latin',
				3 => 'latin-ext',
				4 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lexend Mega',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Lexend Zetta',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
	(object) array(
		'family'   => 'Baloo Tammudu 2',
		'variants' =>
			array(
				0 => 'regular',
				1 => '500',
				2 => '600',
				3 => '700',
				4 => '800',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'telugu',
				3 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Bahianita',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'display',
	),
	(object) array(
		'family'   => 'Lexend Peta',
		'variants' =>
			array(
				0 => 'regular',
			),
		'subsets'  =>
			array(
				0 => 'latin',
				1 => 'latin-ext',
				2 => 'vietnamese',
			),
		'category' => 'sans-serif',
	),
);
