<?php
/**
 * Customizer Control: Switch toggle.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Controls\Switcher;

use WP_Customize_Control;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Toggle Switch Custom Control
 */
class Anky_Control_Switcher extends WP_Customize_Control {

	/**
	 * The highlight color.
	 *
	 * @access public
	 * @var string
	 */
	public static $theme_color = '';

	/**
	 * Control's Type.
	 *
	 * @var string
	 */
	public $type = 'anky-switcher';

	/**
	 * Function to add custom CSS for Admin.
	 */
	public static function add_toggler_css() {
		?>
		<style>
			.toggle-switch-inner::before {
				background-color : <?php echo esc_html(self::$theme_color); ?> !important;
			}
		</style>
		<?php
	}

	/**
	 * Get the Highlight SVG options set from the Admin Color Scheme.
	 */
	public static function set_theme_color() {
		global $_wp_admin_css_colors;

		$current_color = get_user_option( 'admin_color' );

		if ( empty( $current_color ) || ! isset( $_wp_admin_css_colors[ $current_color ] ) ) {
			$current_color = 'fresh';
		}

		self::$theme_color = $_wp_admin_css_colors[ $current_color ]->colors[1];
	}

	/**
	 * Enqueue control related scripts/styles.
	 */
	public function enqueue() {
		if ( '' === self::$theme_color ) {
			self::set_theme_color();
			// Print radio image customizer css.
			add_action( 'customize_controls_print_styles', array( $this, 'add_toggler_css' ) );
		}
	}

	/**
	 * Render the control in the customizer
	 */
	public function render_content() {
		$input_atts = array(
			'type'  => 'checkbox',
			'id'    => $this->id,
			'name'  => $this->id,
			'class' => 'toggle-switch-checkbox',
			'value' => $this->value(),
		);
		?>
		<div class="toggle-switch-control">
			<div class="toggle-switch">
				<input <?php anky_the_atts( $input_atts ); ?> <?php $this->link(); ?> <?php checked( $this->value() ); ?>>
				<label class="toggle-switch-label" for="<?php echo esc_attr( $this->id ); ?>">
					<span class="toggle-switch-inner"></span>
					<span class="toggle-switch-switch"></span>
				</label>
			</div>
			<?php if ( ! empty( $this->label ) ) : ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php endif; ?>
			<?php if ( ! empty( $this->description ) ) : ?>
				<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}

}
