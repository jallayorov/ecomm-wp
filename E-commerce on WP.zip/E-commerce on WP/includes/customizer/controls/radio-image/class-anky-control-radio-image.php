<?php
/**
 * Customizer Control: radio-image.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Controls\Radio_Image;

use Anky\Includes\Builder\Anky_UI_Controller;
use WP_Customize_Control;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Radio Image control (modified radio).
 */
class Anky_Control_Radio_Image extends WP_Customize_Control {

	/**
	 * The highlight color.
	 *
	 * @access public
	 * @var string
	 */
	public static $theme_color = '';

	/**
	 * The control type.
	 *
	 * @access public
	 * @var string
	 */
	public $type = 'anky-radio-image';

	/**
	 * Function to add custom CSS for Admin.
	 */
	public static function add_radio_img_svg_css() {
		?>
		<style type="text/css">
			.anky-radio-image-control-wrap svg * {
				fill   : <?php echo esc_html(self::$theme_color); ?> !important;
				stroke : <?php echo esc_html(self::$theme_color); ?> !important;
			}

			.anky-radio-image-control-wrap input[type="radio"]:checked + label svg {
				box-shadow : <?php echo '0 0 5px 5px ' . esc_html(self::hex2rgba( self::$theme_color, 0.5 ) ); ?>;
			}
		</style>
		<?php
	}

	/**
	 * Get the Highlight SVG options set from the Admin Color Scheme.
	 */
	public static function set_theme_color() {
		global $_wp_admin_css_colors;

		$current_color = get_user_option( 'admin_color' );

		if ( empty( $current_color ) || ! isset( $_wp_admin_css_colors[ $current_color ] ) ) {
			$current_color = 'fresh';
		}

		self::$theme_color = $_wp_admin_css_colors[ $current_color ]->colors[2];
	}

	/**
	 * Convert het to rgba format.
	 *
	 * @param string $color   Required. Color is hef format.
	 * @param bool   $opacity Optional. Add opacity layer.
	 *
	 * @return string Color in rgb or rga format
	 */
	private static function hex2rgba( $color, $opacity = false ) {
		$default = 'rgb(0,0,0)';

		// Return default if no color provided.
		if ( empty( $color ) ) {
			return $default;
		}

		// Sanitize $color if "#" is provided.
		if ( '#' === $color[0] ) {
			$color = substr( $color, 1 );
		}

		// Check if color has 6 or 3 characters and get values.
		if ( 6 === strlen( $color ) ) {
			$hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
		} elseif ( 3 === strlen( $color ) ) {
			$hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
		} else {
			return $default;
		}

		// Convert hex to rgb.
		$rgb = array_map( 'hexdec', $hex );

		// Check if opacity is set(rgba or rgb).
		if ( $opacity ) {
			if ( abs( $opacity ) > 1 ) {
				$opacity = 1.0;
			}
			$output = 'rgba(' . implode( ',', $rgb ) . ',' . $opacity . ')';
		} else {
			$output = 'rgb(' . implode( ',', $rgb ) . ')';
		}

		return $output;
	}

	/**
	 * Enqueue control related scripts/styles.
	 */
	public function enqueue() {
		if ( '' === self::$theme_color ) {
			self::set_theme_color();
			// Print radio image customizer css.
			add_action( 'customize_controls_print_styles', array( $this, 'add_radio_img_svg_css' ) );
		}
	}

	/**
	 * Render the control's content.
	 *
	 * @see WP_Customize_Control::render_content()
	 */
	protected function render_content() {
		// Bail early.
		if ( empty( $this->choices ) ) {
			return;
		}

		$description_id = "$this->id-description";
		?>
		<?php if ( ! empty( $this->label ) ) : ?>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php endif; ?>
		<?php if ( ! empty( $this->description ) ) : ?>
			<span id="<?php echo esc_attr( $description_id ); ?>" class="anky-description customize-control-description">
				<?php echo wp_kses_post( $this->description ); ?>
			</span>
		<?php endif; ?>

		<div id="<?php echo esc_attr( "$this->id-wrapper" ); ?>" class="anky-radio-image-control-wrap">
			<?php
			foreach ( $this->choices as $value => $label_data ) :
				$input_atts = array(
					'id'    => "$this->id-$value",
					'type'  => 'radio',
					'value' => $value,
					'name'  => $this->id,
					'class' => 'screen-reader-text',
				);
				if ( ! empty( $this->description ) ) {
					$input_atts['aria-describedby'] = $description_id;
				}
				$label_atts = array(
					'for'        => $input_atts['id'],
					'title'      => $label_data['label'],
					'aria-label' => $label_data['label'],
				);
				?>

				<input <?php anky_the_atts( $input_atts ); ?> <?php $this->link(); ?> <?php checked( $this->value(), $value ); ?>/>
				<label <?php anky_the_atts( $label_atts ); ?>>
					<?php echo wp_kses( $label_data['path'], Anky_UI_Controller::allowed_svg_html() ); ?>
				</label>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
