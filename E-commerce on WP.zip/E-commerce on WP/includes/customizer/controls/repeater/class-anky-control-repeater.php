<?php
/**
 * Customizer Control: Repeater.
 *
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer\Controls\Repeater;

use WP_Customize_Control;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Text repeater control that can be also sorted.
 */
class Anky_Control_Repeater extends WP_Customize_Control {

	/**
	 * Control's Type.
	 *
	 * @var string
	 * @access public
	 */

	public $type = 'anky-repeater';

	/**
	 * Render the control's content.
	 */
	public function render_content() {
		?>
		<div class="anky-sortable-repeater-control">
			<?php if ( ! empty( $this->label ) ) { ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php } ?>
			<?php if ( ! empty( $this->description ) ) { ?>
				<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php } ?>
			<input type="hidden"
				id="<?php echo esc_attr( $this->id ); ?>"
				name="<?php echo esc_attr( $this->id ); ?>"
				value="<?php echo esc_attr( $this->value() ); ?>"
				class="anky-customize-control-sortable-repeater" <?php $this->link(); ?> />
			<div class="anky-sortable-repeater sortable">
				<div class="anky-repeater-row">
					<input type="text" value="" class="anky-repeater-input" placeholder="https://"/>
					<span class="wp-ui-text-highlight dashicons dashicons-sort"></span>
					<button class="button anky-customize-control-sortable-repeater-delete wp-ui-highlight" type="button">
						<span class="dashicons dashicons-no-alt"></span>
					</button>
				</div>
			</div>
			<button class="button anky-customize-control-sortable-repeater-add wp-ui-highlight" type="button"><?php esc_html_e( 'Add', 'anky' ); ?></button>
		</div>
		<?php
	}

}
