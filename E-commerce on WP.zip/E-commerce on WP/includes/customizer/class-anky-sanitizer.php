<?php
/**
 * Anky theme Sanitizer Controller.
 *
 * @package    Customizer
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer;

// Exit if accessed directly.
use WP_Customize_Setting;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Sanitizer Controller class.
 */
class Anky_Sanitizer {

	/**
	 * Sanitization callback stub.
	 *
	 * @param mixed $value Data to be sanitized.
	 *
	 * @return mixed
	 */
	public static function sanitize_callback( $value ) {
		return $value;
	}

	/**
	 * Sanitizes checkbox input.
	 *
	 * @param string $input Input state.
	 *
	 * @return bool
	 */
	public static function sanitize_checkbox( $input ) {
		return true === $input;
	}

	/**
	 * Sanitize Textarea by removing irrelevant tags.
	 *
	 * @param string $input textarea value.
	 *
	 * @return string
	 * @see wp_kses_post
	 */
	public static function sanitize_textarea( $input ) {
		return wp_kses_post( $input );
	}

	/**
	 * Sanitizes numbers by transform into integer.
	 *
	 * @param string $input input value.
	 *
	 * @return int
	 */
	public static function sanitize_number( $input ) {
		return intval( $input );
	}

	/**
	 * Sanitizes phone number for using inside links.
	 *
	 * @param string $input input value.
	 *
	 * @return string|array|null
	 */
	public static function sanitize_phone_number( $input ) {
		return preg_replace( '/[^\d+]/', '', $input );
	}

	/**
	 * Sanitize radio buttons for current theme. Check whether the radio corresponds the current setting.
	 *
	 * @param string               $input   input value.
	 * @param WP_Customize_Setting $setting WordPress Customize Setting classes.
	 *
	 * @return mixed|string
	 */
	public static function sanitize_radio( $input, $setting ) {
		// Ensure input is a slug.
		$input              = sanitize_key( $input );
		$setting_id_cleared = preg_replace( '/(anky-options\[)(.*)(\])/Uis', '$2', $setting->id );
		// Get a list of choices from the control associated with the setting.
		$choices = $setting->manager->get_control( $setting_id_cleared )->choices;

		// If the input is a valid key, return it; otherwise, return the default.
		return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
	}

	/**
	 * Google Font sanitization
	 *
	 * @param string $input JSON string to be sanitized.
	 *
	 * @return string
	 */
	public static function sanitize_google_font( $input ) {
		$val = json_decode( $input, true );
		if ( is_array( $val ) ) {
			foreach ( $val as $key => $value ) {
				$val[ $key ] = sanitize_text_field( $value );
			}
			$input = wp_json_encode( $val );
		} else {
			$input = wp_json_encode( sanitize_text_field( $val ) );
		}

		return $input;
	}

	/**
	 * Alpha Color (Hex, RGB & RGBa) sanitization
	 *
	 * @param string               $input   Input to be sanitized.
	 * @param WP_Customize_Setting $setting WordPress Customize Setting classes.
	 *
	 * @return string Sanitized input
	 */
	public static function color_sanitization( $input, $setting ) {
		if ( empty( $input ) || is_array( $input ) ) {
			return $setting->default;
		}

		// If string doesn't start with 'rgb' then sanitize as hex color.
		if ( false === strpos( $input, 'rgb' ) ) {
			$input = sanitize_hex_color( $input );
		} else {
			// Sanitize as RGB color.
			if ( false === strpos( $input, 'rgba' ) ) {
				$input = str_replace( ' ', '', $input );
				sscanf( $input, 'rgb(%d,%d,%d)', $red, $green, $blue );
				$input = 'rgb(' . anky_in_range( $red, 0, 255 ) . ',' . anky_in_range( $green, 0, 255 ) . ',' . anky_in_range( $blue, 0, 255 ) . ')';
			} else { // Sanitize as RGBa color.
				$input = str_replace( ' ', '', $input );
				sscanf( $input, 'rgba(%d,%d,%d,%f)', $red, $green, $blue, $alpha );
				$input = 'rgba(' . anky_in_range( $red, 0, 255 ) . ',' . anky_in_range( $green, 0, 255 ) . ',' . anky_in_range( $blue, 0, 255 ) . ',' . anky_in_range( $alpha, 0, 1 ) . ')';
			}
		}

		return $input;
	}

	/**
	 * Sanitize Select for current theme. Check whether the option corresponds the current setting.
	 *
	 * @param string               $input   input value.
	 * @param WP_Customize_Setting $setting WordPress Customize Setting classes.
	 *
	 * @return string
	 */
	public static function sanitize_select( $input, $setting ) {
		$input = sanitize_key( $input );

		// list of possible select options.
		$setting_id_cleared = preg_replace( '/(anky-options\[)(.*)(\])/Uis', '$2', $setting->id );
		$choices            = $setting->manager->get_control( $setting_id_cleared )->choices;

		return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
	}

	/**
	 * Sanitize Google map embed link.
	 *
	 * @param string               $input   input value.
	 * @param WP_Customize_Setting $setting WordPress Customize Setting classes.
	 *
	 * @return string
	 */
	public static function sanitize_google_map_embed( $input, $setting ) {
		$input = sanitize_key( $input );
		if ( strlen( $input ) <= 1 ) {
			return $setting->default;
		}
		$src = anky_get_iframe_src( $input );
		$src = ( empty( $src ) ) ? strpos( $input, '//www.google.com/maps/embed' ) : $src;

		return empty( $src ) ? $setting->default : sanitize_text_field( $src );
	}

}

