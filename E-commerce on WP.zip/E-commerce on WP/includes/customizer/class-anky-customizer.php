<?php
/**
 * Main Customizer initialization class.
 *
 * @link       http://codex.wordpress.org/Theme_Customization_API
 * @package    Anky
 * @subpackage Customizer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Customizer;

use Anky\Includes\Anky;
use Anky\Includes\Customizer\Config\Anky_Customizer_Panels_Config;
use Anky\Includes\Customizer\Controls\Divider\Anky_Control_Divider;
use Anky\Includes\Customizer\Controls\Editor\Anky_Control_TinyMCE;
use Anky\Includes\Customizer\Controls\Fonts\Anky_Control_Google_Font_Select;
use Anky\Includes\Customizer\Controls\Radio_Image\Anky_Control_Radio_Image;
use Anky\Includes\Customizer\Controls\Repeater\Anky_Control_Repeater;
use Anky\Includes\Customizer\Controls\Switcher\Anky_Control_Switcher;
use Anky\Includes\Customizer\Sections\Blog\Anky_Customizer_Blog_Config;
use Anky\Includes\Customizer\Sections\Footer\Anky_Customizer_Footer_Widgets_Config;
use Anky\Includes\Customizer\Sections\Globals\Anky_Customizer_Globals_Colors_Config;
use Anky\Includes\Customizer\Sections\Globals\Anky_Customizer_Globals_Contacts_Config;
use Anky\Includes\Customizer\Sections\Globals\Anky_Customizer_Globals_Optimization_Config;
use Anky\Includes\Customizer\Sections\Globals\Anky_Customizer_Globals_Typography_Config;
use Anky\Includes\Customizer\Sections\Header\Anky_Customizer_Header_Layout_Config;
use Anky\Includes\Customizer\Sections\Menu\Anky_Customizer_Menu_Config;
use WP_Customize_Manager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Customizer Loader controller.
 */
class Anky_Customizer {

	/**
	 * Configurations Array.
	 *
	 * @acces private
	 * @var array
	 */
	private $config;

	/**
	 * Theme controller Instance.
	 *
	 * @var Anky $theme
	 * @access private
	 */
	private $theme;

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Constructor.
	 *
	 * @param Anky $theme Theme controller Instance.
	 */
	public function __construct( Anky $theme ) {
		$this->theme = $theme;

		// Starting the customizer.
		add_action( 'customize_preview_init', array( $this, 'init' ) );

		// Register our custom settings and controls.
		if ( is_admin() || is_customize_preview() ) {
			add_action( 'customize_register', array( $this, 'setup_config' ), 2 );
		}

		add_action( 'customize_register', array( $this, 'rewrite_customizer_defaults' ) );
		add_action( 'customize_register', array( $this, 'register_customizer' ) );
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'customize_control_js' ) );
	}

	/**
	 * Customizer Preview Initialization.
	 */
	public function init() {
		// Update options first.
		$this->theme->options->update();

		/**
		 * Enqueue Google Fonts for preview.
		 */
		wp_enqueue_style( 'anky-theme-font', $this->theme->fonts->prepare_fonts_url(), array(), ANKY_THEME_VERSION, 'all' );

		wp_enqueue_script(
			'anky-customizer',
			anky_get_asset( 'js/customizer-preview' . ( ANKY_DEV_MODE ? '.js' : '.min.js' ) ),
			array( 'customize-preview', 'jquery' ),
			ANKY_THEME_VERSION,
			true
		);
	}

	/**
	 * Setting up the configuration.
	 */
	public function setup_config() {
		new Anky_Customizer_Panels_Config( $this->theme );
		new Anky_Customizer_Globals_Typography_Config( $this->theme );
		new Anky_Customizer_Globals_Colors_Config( $this->theme );
		new Anky_Customizer_Globals_Contacts_Config( $this->theme );
		new Anky_Customizer_Header_Layout_Config( $this->theme );
		new Anky_Customizer_Blog_Config( $this->theme );
		new Anky_Customizer_Footer_Widgets_Config( $this->theme );
		new Anky_Customizer_Menu_Config( $this->theme );
		new Anky_Customizer_Globals_Optimization_Config( $this->theme );

		$this->config = apply_filters( 'anky_customizer_config', array() );
	}

	/**
	 * Rearrange the customizer sections that are set out of the box.
	 *
	 * @param \WP_Customize_Manager $wp_customize Customize Manager class.
	 */
	public function rewrite_customizer_defaults( WP_Customize_Manager $wp_customize ) {
		$wp_customize->remove_control( 'header_textcolor' );
		$wp_customize->remove_control( 'background_color' );
		$wp_customize->remove_section( 'header_image' );

		$wp_customize->get_section( 'title_tagline' )->panel    = 'panel-header';
		$wp_customize->get_section( 'title_tagline' )->priority = 1;

		$wp_customize->get_section( 'background_image' )->panel    = 'panel-globals';
		$wp_customize->get_section( 'background_image' )->priority = 5;

		$wp_customize->get_section( 'colors' )->panel    = 'panel-globals';
		$wp_customize->get_section( 'colors' )->priority = 3;

		$wp_customize->get_setting( 'blogname' )->transport        = 'postMessage';
		$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.anky-site-title',
				'render_callback' => function () {
					bloginfo( 'name' );
				},
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => function () {
					bloginfo( 'description' );
				},
			)
		);

		$wp_customize->get_setting( 'custom_logo' )->selector    = '.anky-site-branding';
		$wp_customize->get_control( 'custom_logo' )->description = esc_html__(
			'In order to properly display the site logo, please, select an image not higher that 56px, as the image height will be restricted by 56px on desktop and 48px in tablet and mobile devices.',
			'anky'
		);
	}

	/**
	 * Registering Customizer Panels and Sections.
	 *
	 * @param \WP_Customize_Manager $wp_customize Customize Manager class.
	 */
	public function register_customizer( WP_Customize_Manager $wp_customize ) {
		if ( empty( $this->config ) ) {
			return;
		}
		foreach ( $this->config as $id => $part ) {
			switch ( $part['item_type'] ) {
				case 'panel':
					$wp_customize->add_panel( $id, $part );
					break;
				case 'section':
					$this->register_sections( $wp_customize, $id, $part );
					break;
			}
		}
	}

	/**
	 * Enqueue Scripts and Styles that are used inside controls.
	 */
	public function customize_control_js() {
		wp_enqueue_script(
			'anky-customizer-control',
			ANKY_THEME_URI . 'assets/js/customizer-controls' . ( ANKY_DEV_MODE ? '.js' : '.min.js' ),
			array( 'customize-controls', 'jquery', 'jquery-ui-core', 'select2' ),
			ANKY_THEME_VERSION,
			true
		);

		$localize_data = array(
			'fontUnavailable' => esc_html__( 'Not Available for this font', 'anky' ),
			'switcher'        => esc_html__( 'Theme language switcher', 'anky' ),
		);

		wp_localize_script( 'anky-customizer-control', 'externals', $localize_data );
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Assistive functions to register Sections and Controls.
	 *
	 * @param \WP_Customize_Manager $wp_customize Customize Manager class.
	 * @param string                $section_id   Required. ID of the section.
	 * @param array                 $section      Required. Array of section args. For details see  WP_Customize_Section::__construct().
	 */
	private function register_sections( WP_Customize_Manager $wp_customize, $section_id, $section ) {
		$wp_customize->add_section( $section_id, $section );

		if ( ! empty( $section['fields'] ) ) {
			foreach ( $section['fields'] as $field_id => $field_data ) {
				$this->register_control( $wp_customize, $field_id, $field_data, $section_id );
			}
		}
	}

	/**
	 * Assistive functions to register Settings and Controls.
	 *
	 * @param \WP_Customize_Manager $wp_customize Customize Manager class.
	 * @param string                $field_id     Required. ID of the field.
	 * @param array                 $field_data   Required. Array of field args. For details see  WP_Customize_Control::__construct().
	 * @param string                $section_id   Required. Section ID to attach control fields to.
	 */
	private function register_control( WP_Customize_Manager $wp_customize, $field_id, $field_data, $section_id ) {
		if ( empty( $field_id ) || ! isset( $field_data ) ) {
			return;
		}

		if ( $section_id ) {
			$field_data['section'] = $section_id;
		}

		$field_data['settings'] = "{$this->theme->options->get_prefix()}[$field_id]";

		// Set the settings.
		$wp_customize->add_setting(
			$field_data['settings'],
			array(
				'default'           => anky_get_prop( $field_data, 'default', '' ),
				'type'              => 'option',
				'transport'         => anky_get_prop( $field_data, 'transport', 'refresh' ),
				'sanitize_callback' => anky_get_prop( $field_data, 'sanitize_callback', array( 'Anky\Includes\Customizer\Anky_Sanitizer', 'sanitize_callback' ) ),
				'validate_callback' => anky_get_prop( $field_data, 'validate_callback', array( 'Anky\Includes\Customizer\Anky_Validator', 'validate_callback' ) ),
			)
		);

		// Selective refresh if it is required.
		if ( isset( $field_data['selective_refresh'] ) ) {
			$wp_customize->selective_refresh->add_partial(
				$field_data['settings'],
				array(
					'selector'            => anky_get_prop( $field_data['selective_refresh'], 'selector' ),
					'settings'            => $field_data['settings'],
					'render_callback'     => anky_get_prop( $field_data['selective_refresh'], 'render_callback' ),
					'container_inclusive' => anky_get_prop( $field_data['selective_refresh'], 'container_inclusive', false ),
				)
			);
		}

		/**
		 * Set the required control type.
		 */
		switch ( $field_data['type'] ) {
			// Control divider.
			case 'anky-divider':
				$wp_customize->add_control(
					new Anky_Control_Divider(
						$wp_customize,
						$field_id,
						$field_data
					)
				);
				break;

			// Switch toggler control.
			case 'anky-switcher':
				$wp_customize->add_control(
					new Anky_Control_Switcher(
						$wp_customize,
						$field_id,
						$field_data
					)
				);
				break;

			// Radio image control.
			case 'anky-radio-image':
				$wp_customize->add_control(
					new Anky_Control_Radio_Image(
						$wp_customize,
						$field_id,
						$field_data
					)
				);
				break;

			// Google fonts control.
			case 'anky-google-font':
				$wp_customize->add_control(
					new Anky_Control_Google_Font_Select(
						$wp_customize,
						$field_id,
						$field_data
					)
				);
				break;

			// Sortable repeater control.
			case 'anky-repeater':
				$wp_customize->add_control(
					new Anky_Control_Repeater(
						$wp_customize,
						$field_id,
						$field_data
					)
				);
				break;

			// TinyMCE control.
			case 'anky-tinymce':
				$wp_customize->add_control(
					new Anky_Control_TinyMCE(
						$wp_customize,
						$field_id,
						$field_data
					)
				);
				break;

			// Default control type.
			default:
				$wp_customize->add_control(
					$field_id,
					$field_data
				);
				break;
		}
	}

}
