<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Compatibility
 */

/* Silence is golden, and we agree. */
