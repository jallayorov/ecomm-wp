<?php
/**
 * Index file
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 */

/* Silence is golden, and we agree. */
