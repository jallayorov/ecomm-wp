<?php
/**
 * Theme Elementor extension class.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor;

use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Contacts;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Content_Switcher;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_FAQ;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Feature_Box;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Partners;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Portfolio;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Posts;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Pricing;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Slider;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Team;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_Testimonials;
use Anky\Includes\Compatibility\Elementor\Widgets\Anky_Elementor_Widget_WPCF7;
use Anky\Includes\Core\Anky_Assistent;
use Elementor\Plugin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Theme Elementor extension class.
 */
final class Anky_Elementor_Extension extends Anky_Assistent {

	/**
	 * Widgets category group.
	 *
	 * @var string
	 * @access public
	 */
	public static $widget_group = 'anky-category';

	/**
	 * Minimum Elementor Version
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 * @access private
	 */
	private static $minimum_elementor_version = '3.3.1';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	private static $minimum_php_version = '7.0';

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( $this->is_compatible() ) {
			$this->set_hooks();
		}
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Register Widget Category Group.
	 */
	public function set_widget_category() {
		Plugin::$instance->elements_manager->add_category(
			self::$widget_group,
			array(
				'title' => __( 'Anky Theme', 'anky' ),
				'icon'  => 'fonts',
			)
		);
	}

	/**
	 * Register theme specific widgets.
	 */
	public function register_widgets() {
		$widgets_manager = Plugin::instance()->widgets_manager;
		$widgets         = array(
			new Anky_Elementor_Widget_Contacts(),
			new Anky_Elementor_Widget_Posts(),
			new Anky_Elementor_Widget_Slider(),
			new Anky_Elementor_Widget_Feature_Box(),
			new Anky_Elementor_Widget_Testimonials(),
			new Anky_Elementor_Widget_FAQ(),
			new Anky_Elementor_Widget_Partners(),
			new Anky_Elementor_Widget_Team(),
			new Anky_Elementor_Widget_Portfolio(),
			new Anky_Elementor_Widget_Pricing(),
			new Anky_Elementor_Widget_Content_Switcher(),
		);

		if ( class_exists( 'WPCF7' ) ) {
			$widgets[] = new Anky_Elementor_Widget_WPCF7();
		}

		foreach ( $widgets as $widget ) {
			$widgets_manager->register_widget_type( $widget );
		}
	}

	/**
	 * Enqueue depending styles.
	 */
	public function register_styles() {
		wp_register_style(
			'anky-elementor-extension',
			anky_get_asset( 'css/elementor-compatibility' . ( ANKY_DEV_MODE ? '.css' : '.min.css' ) ),
			array(),
			ANKY_THEME_VERSION,
			'all'
		);
	}

	/**
	 * Enqueue depending styles.
	 */
	public function add_styles() {
		wp_enqueue_style( 'anky-elementor-extension' );
	}

	/**
	 * Enqueue depending scripts.
	 */
	public function register_scripts() {
		$loading_method = anky_get_option( 'globals-assets-loading-mode', 'cdn' );
		$suffix         = ANKY_DEV_MODE ? '.js' : '.min.js';

		$assets = array(
			'local' => array(
				'isotope' => anky_get_asset( 'js/isotope.min.js' ),
				'lottie'  => anky_get_asset( 'js/lottie.min.js' ),
			),
			'cdn'   => array(
				'isotope' => '//cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js',
				'lottie'  => '//cdnjs.cloudflare.com/ajax/libs/lottie-web/5.8.1/lottie.min.js',
			),
		);

		wp_register_script( 'isotope', $assets[ $loading_method ]['isotope'], array( 'jquery' ), '3.0.6', true );
		wp_register_script( 'anky-widget-faq', anky_get_asset( 'js/elementor/widget-faq' . $suffix ), array( 'jquery' ), ANKY_THEME_VERSION, true );
		wp_register_script( 'anky-widget-partners', anky_get_asset( 'js/elementor/widget-partners' . $suffix ), array( 'jquery' ), ANKY_THEME_VERSION, true );
		wp_register_script( 'anky-widget-slider', anky_get_asset( 'js/elementor/widget-elementor-slider' . $suffix ), array( 'jquery' ), ANKY_THEME_VERSION, true );
		wp_register_script( 'anky-widget-portfolio', anky_get_asset( 'js/elementor/widget-portfolio' . $suffix ), array( 'jquery', 'isotope' ), ANKY_THEME_VERSION, true );
		wp_register_script( 'anky-widget-content-switcher', anky_get_asset( 'js/elementor/widget-content-switcher' . $suffix ), array( 'jquery' ), ANKY_THEME_VERSION, true );
		wp_register_script( 'lottie', $assets[ $loading_method ]['lottie'], array(), '5.8.1', true );
		wp_register_script( 'anky-lottie-init', anky_get_asset( 'js/elementor/lottie-init' . $suffix ), array( 'lottie' ), ANKY_THEME_VERSION, true );
	}

	/**
	 * Adding custom scripts with various purposes.
	 */
	public function add_custom_scripts() {
		// Localize jQuery with required data for Section Add-ons.
		$loading_method = anky_get_option( 'globals-assets-loading-mode', 'cdn' );
		$assets         = array(
			'local' => array(
				'lottie' => anky_get_asset( 'js/lottie.min.js' ),
			),
			'cdn'   => array(
				'lottie' => '//cdnjs.cloudflare.com/ajax/libs/lottie-web/5.8.1/lottie.min.js',
			),
		);

		wp_localize_script(
			'elementor-frontend',
			'anky_elementor_extensions',
			array(
				'url'    => admin_url( 'admin-ajax.php' ),
				'lottie' => $assets[ $loading_method ]['lottie'],
			)
		);

		// Cache.
		wp_add_inline_script(
			'elementor-frontend',
			'window.scopes_array = {};
                window.backend = 0;
                jQuery( window ).on( "elementor/frontend/init", function() {
                    
                    elementorFrontend.hooks.addAction( "frontend/element_ready/section", function( $scope, $ ){
                        if ( "undefined" == typeof $scope ) {
                                return;
                        }
                        if ( $scope.hasClass( "anky-lottie-animation" ) ) {
                            var id = $scope.data("id");
                            window.scopes_array[ id ] = $scope;
                        }
                        if(elementorFrontend.isEditMode()){
                            
                            var url = anky_elementor_extensions.lottie;
                            jQuery.cachedAssets = function( url, options ) {
                                // Allow user to set any option except for dataType, cache, and url.
                                options = jQuery.extend( options || {}, {
                                    dataType: "script",
                                    cache: true,
                                    url: url
                                });
                                // Return the jqXHR object so we can chain callbacks.
                                return jQuery.ajax( options );
                            };
                            jQuery.cachedAssets( url );
                            window.backend = 1;
                        }
                    });
                });
                jQuery(document).ready(function(){
                    if ( jQuery.find( ".anky-lottie-animation" ).length < 1 ) {
                        return;
                    }
                    var url = anky_elementor_extensions.lottie;
                    
                    jQuery.cachedAssets = function( url, options ) {
                        // Allow user to set any option except for dataType, cache, and url.
                        options = jQuery.extend( options || {}, {
                            dataType: "script",
                            cache: true,
                            url: url
                        });
                        
                        // Return the jqXHR object so we can chain callbacks.
                        return jQuery.ajax( options );
                    };
                    jQuery.cachedAssets( url );
                });	'
		);
	}

	/**
	 * Admin notice.
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 */
	public function admin_notice_missing_main_plugin() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Theme name 2: Elementor plugin name */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'anky' ),
			'<strong>ANKY</strong>',
			'<strong>Elementor</strong>'
		);

		echo wp_kses_post( sprintf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message ) );
	}

	/**
	 * Admin notice.
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 */
	public function admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Theme name 2: Elementor plugin name 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'anky' ),
			'<strong>ANKY</strong>',
			'<strong>ELEMENTOR</strong>',
			self::$minimum_elementor_version
		);

		echo wp_kses_post( sprintf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message ) );
	}

	/**
	 * Admin notice.
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 */
	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'anky' ),
			'<strong>ANKY</strong>',
			'<strong>PHP</strong>',
			self::$minimum_php_version
		);

		echo wp_kses_post( sprintf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message ) );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Compatibility Checks.
	 *
	 * Checks if the installed version of Elementor meets the plugin's minimum requirement.
	 * Checks if the installed PHP version meets the plugin's minimum requirement.
	 *
	 * @return  bool
	 */
	protected function is_compatible() {
		// Check if Elementor installed and activated.
		if ( ! did_action( 'elementor/loaded' ) ) {
			$this->add_action( 'admin_notices', $this, 'admin_notice_missing_main_plugin' );

			return false;
		}

		// Check for required Elementor version.
		if ( ! version_compare( ELEMENTOR_VERSION, self::$minimum_elementor_version, '>=' ) ) {
			$this->add_action( 'admin_notices', $this, 'admin_notice_minimum_elementor_version' );

			return false;
		}

		// Check for required PHP version.
		if ( version_compare( PHP_VERSION, self::$minimum_php_version, '<' ) ) {
			$this->add_action( 'admin_notices', $this, 'admin_notice_minimum_php_version' );

			return false;
		}

		return true;
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Setup the hooks for this class.
	 */
	private function set_hooks() {
		$this->add_action( 'elementor/init', $this, 'set_widget_category' );
		$this->add_action( 'elementor/widgets/widgets_registered', $this, 'register_widgets' );

		$this->add_action( 'wp_enqueue_scripts', $this, 'add_custom_scripts' );

		$this->add_action( 'elementor/frontend/after_register_styles', $this, 'register_styles' );
		$this->add_action( 'elementor/frontend/after_register_scripts', $this, 'register_scripts' );

		$this->add_action( 'elementor/frontend/before_enqueue_styles', $this, 'add_styles' );
	}

}



