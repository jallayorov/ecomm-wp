<?php
/**
 * Anky Theme Elementor Widget for displaying Contact Form 7 forms via a shortcode.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying Contact Form 7 forms via a shortcode.
 */
class Anky_Elementor_Widget_WPCF7 extends Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_wpcf7';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Contact Form', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->start_controls_section(
			$this->name . '_section_content',
			array( 'label' => esc_html__( 'Settings', 'anky' ) )
		);

		$this->add_control(
			$this->name . '_form_id',
			array(
				'label'   => __( 'Contact Form 7', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => anky_get_contact_forms_list(),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'shortcode', 'id', $settings[ $this->name . '_form_id' ] );
		$shortcode = sprintf( '[contact-form-7 %s]', $this->get_render_attribute_string( 'shortcode' ) );

		if ( ! empty( $settings[ $this->name . '_form_id' ] ) ) {
			echo do_shortcode( $shortcode );
		} else {
			echo '<div class="anky-form-not-selected">' . esc_html__( 'Contact Form is not selected. Select one from settings.', 'anky' ) . '</div>';
		}
	}

}
