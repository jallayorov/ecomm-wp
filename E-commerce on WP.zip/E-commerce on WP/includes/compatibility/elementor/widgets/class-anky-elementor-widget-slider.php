<?php
/**
 * Anky Theme Elementor Widget for creating slides.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for creating slides.
 */
class Anky_Elementor_Widget_Slider extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_slider';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Slider', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-slides';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the element requires.
	 *
	 * @return array Element styles dependencies.
	 */
	public function get_style_depends() {
		return array( 'swiper' );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'anky-widget-slider' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->add_slider_content_settings();
		$this->add_slider_display_settings();
		$this->add_slider_navigation_settings();

		$this->add_slide_img_style_settings();
		$this->add_slide_text_style_settings();
		$this->add_slide_navigation_style_group();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$output_escaped = '';
		$have_scrollbar = 'none' !== $settings[ $this->name . '_navigation_scrollbar_type' ];

		// Slider arrows.
		$left_icon = '';
		if ( isset( $settings[ $this->name . '_navigation_left_arrow' ]['value'] ) ) {
			ob_start();
			Icons_Manager::render_icon(
				$settings[ $this->name . '_navigation_left_arrow' ],
				array(
					'class'       => 'anky-slider-icon',
					'aria-hidden' => 'true',
				),
				'span'
			);
			$left_icon = ob_get_clean();
		}
		$right_icon = '';
		if ( isset( $settings[ $this->name . '_navigation_right_arrow' ]['value'] ) ) {
			ob_start();
			Icons_Manager::render_icon(
				$settings[ $this->name . '_navigation_right_arrow' ],
				array(
					'class'       => 'anky-slider-icon',
					'aria-hidden' => 'true',
				),
				'span'
			);
			$right_icon = ob_get_clean();
		}

		// Set arrows style.
		if ( 'default' === $settings[ $this->name . '_navigation_arrow_type' ] ) {
			$arrow_opt = '<div class="swiper-button-next"></div><div class="swiper-button-prev"></div>';
		} elseif ( 'custom' === $settings[ $this->name . '_navigation_arrow_type' ] ) {
			$arrow_opt = sprintf(
				'<div class="swiper-button-next swiper-button-next-custom">%s</div><div class="swiper-button-prev swiper-button-prev-custom">%s</div>',
				$right_icon,
				$left_icon
			);
		} else {
			$arrow_opt = '';
		}

		$slider_data = array(
			'#anky_elementor_slider_widget_' . $this->get_id(),
			array(
				'slidesPerView' => $settings[ $this->name . '_slides_to_show' ],
				'autoHeight'    => (bool) $settings[ $this->name . '_auto_height' ],
				'spaceBetween'  => $settings[ $this->name . '_space_per_slide' ],
				'pagination'    => $have_scrollbar ? false : array(
					'el'   => '.anky-swiper-pagination',
					'type' => $settings[ $this->name . '_navigation_pagination_options' ],
				),
				'loop'          => (bool) $settings[ $this->name . '_loop' ],
				'autoplay'      => $settings[ $this->name . '_autoplay' ] ?
					array(
						'delay'                => $settings[ $this->name . '_autoplay_delay' ],
						'disableOnInteraction' => false,
					) : false,
				'navigation'    => array(
					'nextEl' => '.swiper-button-next',
					'prevEl' => '.swiper-button-prev',
				),
				'scrollbar'     => array(
					'el'            => '.swiper-scrollbar',
					'draggable'     => false,
					'snapOnRelease' => true,
				),
				'breakpoints'   => array(
					'320'  => array(
						'slidesPerView' => 1,
						'spaceBetween'  => 16,
					),
					'426'  => array(
						'slidesPerView' => 1,
						'spaceBetween'  => 32,
					),
					'1025' => array(
						'slidesPerView' => $settings[ $this->name . '_slides_to_show' ],
					),
				),
			),
			array(
				'hideArrows'         => (bool) $settings[ $this->name . '_navigation_hide_arrows_on_mobile' ],
				'isAnimation'        => (bool) $settings[ $this->name . '_animation' ],
				'slideTextOptions'   => $settings[ $this->name . '_title_layout' ],
				'paginationLocation' => $settings[ $this->name . '_navigation_pagination_location' ],
			),
		);

		$output_escaped .= sprintf(
			'<div id="anky_elementor_slider_widget_%s" class="anky-slider-parent" data-anky-slider="%s">',
			esc_attr( $this->get_id() ),
			esc_attr( wp_json_encode( $slider_data ) )
		);

		// Adding scrollbar to top position.
		if ( 'top' === $settings[ $this->name . '_navigation_scrollbar_location' ] && $have_scrollbar ) {
			$output_escaped .= '<div class="swiper-scrollbar swiper-scrollbar-top"></div>';
		}

		$output_escaped .= '<div class="swiper-wrapper">'; // Adding Starting wrapper.

		/**
		 * Adding Slide Wrap, image and title.
		 */
		foreach ( $settings[ $this->name . '_content' ] as $slider ) {
			$output_escaped .= '<div class="swiper-slide slide-img-property elementor-repeater-item-' . esc_attr( $slider['_id'] ) . '">';
			$output_escaped .= $this->get_media_image_string( $slider, $this->name . '_slide_image', $settings['smart_stretch'] ? 'smart-stretch' : '' );
			$output_escaped .= '<p class="slide-text">' . esc_html( $slider[ $this->name . '_slide_title' ] ) . '</p></div><!--.slide-img-property-->';
		}

		$output_escaped .= '</div><!--.swiper-wrapper-->';    // Adding closing div for slider wrapper.
		$output_escaped .= $arrow_opt;                        // Adding slider arrows.
		$output_escaped .= $settings[ $this->name . '_navigation_pagination_enable' ] ? '<div class="anky-swiper-pagination"></div>' : '';

		// Adding scrollbar to bottom position.
		if ( 'bottom' === $settings[ $this->name . '_navigation_scrollbar_location' ] && $have_scrollbar ) {
			$output_escaped .= '<div class="swiper-scrollbar swiper-scrollbar-bottom"></div>';
		}

		$output_escaped .= '</div><!--.swiper-container-->';          // Adding closing div for slider container.

		// Output is properly sanitized where it's required.
		echo $output_escaped;                                         // phpcs:ignore WordPress.Security.EscapeOutput
	}

	// ======================================================
	// PRIVATE - Content settings
	// ======================================================

	/**
	 * Add Slider Content Setting controls to Content section of the Widget.
	 */
	private function add_slider_content_settings() {
		$this->start_controls_section(
			$this->name . '_content_section',
			array(
				'label' => __( 'Content Setup', 'anky' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			$this->name . '_slide_title',
			array(
				'label' => __( 'Content', 'anky' ),
				'type'  => Controls_Manager::TEXTAREA,
				'rows'  => 5,
			)
		);
		$repeater->add_control(
			$this->name . '_slide_image',
			array(
				'label'   => __( 'Image', 'anky' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array( 'url' => Utils::get_placeholder_image_src() ),
			)
		);
		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_slide_image',
				'default'   => 'medium',
				'separator' => 'none',
			)
		);
		$repeater->add_responsive_control(
			$this->name . '_slide_text_position',
			array(
				'label'     => __( 'Text position', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 400,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .slide-text.inside'  => 'left: {{SIZE}}px',
					'{{WRAPPER}} {{CURRENT_ITEM}} .slide-text.outside' => 'padding-left: {{SIZE}}px',
				),
			)
		);

		$this->add_control(
			$this->name . '_content',
			array(
				'label'       => esc_html__( 'Manage slides', 'anky' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array( $this->name . '_slide_title' => __( 'Placeholder text', 'anky' ) ),
					array( $this->name . '_slide_title' => __( 'Some text may be placed here', 'anky' ) ),
				),
				'title_field' => '{{{ anky_slider_slide_title }}}',
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Slider Display Settings controls to Content section of the Widget.
	 */
	private function add_slider_display_settings() {
		$this->start_controls_section(
			$this->name . '_display_settings_section',
			array(
				'label' => __( 'Display Settings', 'anky' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_responsive_control(
			$this->name . '_slides_to_show',
			array(
				'label'       => __( 'Slides to Show', 'anky' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => __( 'Maximum capacity - 10 slides', 'anky' ),
				'min'         => 1,
				'max'         => 10,
				'step'        => 1,
				'default'     => 1,
			)
		);
		$this->add_responsive_control(
			$this->name . '_space_per_slide',
			array(
				'label'       => __( 'Slides spacing', 'anky' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 50,
				'step'        => 1,
				'default'     => 32,
				'description' => __( 'Distance in px, between slides', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_auto_height',
			array(
				'label'        => __( 'Auto height', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '1',
			)
		);
		$this->add_control(
			$this->name . '_loop',
			array(
				'label'        => __( 'Infinite slides', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'description'  => __( 'If turned On, the slider starts circle through slides from the beginning.', 'anky' ),
				'return_value' => '1',
				'default'      => '',
			)
		);
		$this->add_control(
			$this->name . '_autoplay',
			array(
				'label'        => __( 'Autoplay', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '',
			)
		);
		$this->add_control(
			$this->name . '_autoplay_delay',
			array(
				'label'       => __( 'Autoplay delay', 'anky' ),
				'description' => __( 'NOTE: value is set in milliseconds', 'anky' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 100,
				'max'         => 10000,
				'step'        => 100,
				'default'     => 3000,
				'condition'   => array(
					$this->name . '_autoplay' => '1',
				),
			)
		);
		$this->add_control(
			$this->name . '_animation',
			array(
				'label'        => __( 'Enable animation', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '',
				'condition'    => array(
					$this->name . '_loop'     => '1',
					$this->name . '_autoplay' => '1',
				),
			)
		);
		$this->add_control(
			$this->name . '_title_layout',
			array(
				'label'       => __( 'Slide text position', 'anky' ),
				'type'        => Controls_Manager::SELECT,
				'description' => __( 'Where to place slide descriptive text: Can be placed on the image or below it.', 'anky' ),
				'options'     => array(
					'inside'  => __( 'On image', 'anky' ),
					'outside' => __( 'Below image', 'anky' ),
				),
				'default'     => 'inside',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Slider Navigation Settings control Groups to Content section of the Widget.
	 * Navigation contains
	 * - Arrows setup
	 * - Pagination setup
	 * - Scrollbar setup
	 */
	private function add_slider_navigation_settings() {
		$this->start_controls_section(
			$this->name . '_navigation_settings_section',
			array(
				'label' => esc_html__( 'Navigation Settings', 'anky' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->start_controls_tabs( $this->name . '_navigation_settings_section_tabs' );

		$this->add_arrow_settings();
		$this->add_pagination_settings();
		$this->add_scrollbar_settings();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Add Slider Arrow Setting controls to Content section of the Widget.
	 */
	private function add_arrow_settings() {
		$this->start_controls_tab(
			$this->name . '_navigation_arrows_tab',
			array(
				'label' => __( 'Arrows', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_navigation_arrow_type',
			array(
				'label'   => __( 'Style', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'none'    => __( 'None', 'anky' ),
					'default' => __( 'Default', 'anky' ),
					'custom'  => __( 'Custom', 'anky' ),
				),
				'default' => 'none',
			)
		);
		$this->add_control(
			$this->name . '_navigation_left_arrow',
			array(
				'label'            => __( 'Left arrow', 'anky' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'skin'             => 'inline',
				'label_block'      => false,
				'condition'        => array( $this->name . '_navigation_arrow_type' => 'custom' ),
			)
		);
		$this->add_control(
			$this->name . '_navigation_right_arrow',
			array(
				'label'            => __( 'Right arrow', 'anky' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'skin'             => 'inline',
				'label_block'      => false,
				'condition'        => array( $this->name . '_navigation_arrow_type' => 'custom' ),
			)
		);
		$this->add_control(
			$this->name . '_navigation_arrows_size',
			array(
				'label'     => __( 'Size', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 1,
						'max' => 300,
					),
				),
				'default'   => array( 'size' => 100 ),
				'condition' => array( $this->name . '_navigation_arrow_type' => array( 'default' ) ),
				/**
				 * Default icon is set with background so to make it bigger we need to scale the item.
				 * To use a `scale` function and avoid `calc` we use this hack.
				 */
				'selectors' => array(
					'{{WRAPPER}}'                     => '--anky-elementor-extension-widget-slider-arrow-size: {{SIZE}}',
					'{{WRAPPER}} .swiper-button-prev' => 'transform: scale(var(--anky-elementor-extension-widget-slider-arrow-size)) scale(0.01);',
					'{{WRAPPER}} .swiper-button-next' => 'transform: scale(var(--anky-elementor-extension-widget-slider-arrow-size)) scale(0.01);',
				),
			)
		);
		$this->add_control(
			$this->name . '_navigation_custom_arrows_size',
			array(
				'label'       => __( 'Size', 'anky' ),
				'type'        => Controls_Manager::SLIDER,
				'description' => __( 'Custom icon library only', 'anky' ),
				'range'       => array(
					'px' => array(
						'min' => 20,
						'max' => 60,
					),
				),
				'default'     => array( 'size' => 30 ),
				'condition'   => array( $this->name . '_navigation_arrow_type' => array( 'custom' ) ),
				'selectors'   => array(
					'{{WRAPPER}} .swiper-button-prev span, {{WRAPPER}} .swiper-button-next span' => 'font-size: {{SIZE}}px;',
					'{{WRAPPER}} .swiper-button-prev svg, {{WRAPPER}} .swiper-button-next svg'   => 'width: {{SIZE}}px !important; height: {{SIZE}}px !important;',
				),
			)
		);
		$this->add_control(
			$this->name . '_navigation_hide_arrows_on_mobile',
			array(
				'label'        => __( 'Hide arrows for mobile version', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '',
			)
		);
		$this->end_controls_tab();
	}

	/**
	 * Add Slider Pagination Setting controls to Content section of the Widget.
	 */
	private function add_pagination_settings() {
		$this->start_controls_tab(
			$this->name . '_navigation_pagination_tab',
			array(
				'label' => __( 'Pagination', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_navigation_pagination_enable',
			array(
				'label'        => __( 'Enable', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '',
			)
		);
		$this->add_control(
			$this->name . '_navigation_pagination_options',
			array(
				'label'     => __( 'Type', 'anky' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'bullets'     => __( 'Bullets', 'anky' ),
					'fraction'    => __( 'Fraction', 'anky' ),
					'progressbar' => __( 'Progressbar', 'anky' ),
				),
				'default'   => 'bullets',
				'condition' => array( $this->name . '_navigation_pagination_enable' => '1' ),
			)
		);
		$this->add_control(
			$this->name . '_navigation_pagination_location',
			array(
				'label'     => __( 'Location', 'anky' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'top'    => __( 'Top', 'anky' ),
					'bottom' => __( 'Bottom', 'anky' ),
				),
				'default'   => 'bottom',
				'condition' => array( $this->name . '_navigation_pagination_enable' => '1' ),
			)
		);
		$this->end_controls_tab();
	}

	/**
	 * Add Slider Scrollbar Setting controls to Content section of the Widget.
	 */
	private function add_scrollbar_settings() {
		$this->start_controls_tab(
			$this->name . '_navigation_scrollbar_tab',
			array(
				'label' => __( 'Scrollbar', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_navigation_scrollbar_type',
			array(
				'label'   => __( 'Type', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'none'    => __( 'None', 'anky' ),
					'default' => __( 'Default', 'anky' ),
					'custom'  => __( 'Custom', 'anky' ),
				),
				'default' => 'none',
			)
		);
		$this->add_control(
			$this->name . '_navigation_scrollbar_location',
			array(
				'label'     => __( 'Location', 'anky' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'top'    => __( 'Top', 'anky' ),
					'bottom' => __( 'Bottom', 'anky' ),
				),
				'default'   => 'bottom',
				'condition' => array( $this->name . '_navigation_scrollbar_type' => array( 'custom', 'default' ) ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_navigation_scrollbar_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 800,
					),
					'%'  => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'    => array(
					'size'  => 600,
					'units' => $this->position_size_units[0],
				),
				'condition'  => array( $this->name . '_navigation_scrollbar_type' => array( 'custom' ) ),
				'selectors'  => array( '{{WRAPPER}} .swiper-scrollbar' => 'width: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_control(
			$this->name . '_navigation_scrollbar_height',
			array(
				'label'     => esc_html__( 'Height', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 2,
						'max' => 20,
					),
				),
				'default'   => array( 'size' => 4 ),
				'condition' => array( $this->name . '_navigation_scrollbar_type' => array( 'custom' ) ),
				'selectors' => array( '{{WRAPPER}} .swiper-scrollbar' => 'height: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_tab();
	}

	// ======================================================
	// PRIVATE - Style settings
	// ======================================================

	/**
	 * Add Image Setting controls to Style section of the Widget.
	 */
	private function add_slide_img_style_settings() {
		$this->start_controls_section(
			$this->name . '_slide_images_style_section',
			array(
				'label' => __( 'Image', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_image_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 500,
					),
					'%'  => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'    => array(
					'unit' => $this->position_size_units[0],
					'size' => 320,
				),
				'selectors'  => array( '{{WRAPPER}} .swiper-slide img' => 'height: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_image_border_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .swiper-slide img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			'smart_stretch',
			array(
				'label'        => __( 'Smart stretch', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '1',
				'description'  => __( 'Automatically stretch image if its` proportions are 16:9', 'anky' ),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Slider Text Setting controls to Style section of the Widget.
	 */
	private function add_slide_text_style_settings() {
		$this->start_controls_section(
			$this->name . '_slide_text_style_section',
			array(
				'label' => esc_html__( 'Text', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_content_related_style_controls_part( "{$this->name}_slide_text", '.slide-text', '' );
		$this->end_controls_section();
	}

	/**
	 * Add Slider Navigation Settings control Groups to Style section of the Widget.
	 * Navigation contains:
	 * - Arrows setup
	 * - Pagination setup
	 * - Scrollbar setup
	 */
	private function add_slide_navigation_style_group() {
		$this->start_controls_section(
			$this->name . '_slide_navigation_style_section',
			array(
				'label' => __( 'Slide Navigation', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->start_controls_tabs( $this->name . '_slide_navigation_style_section_tabs' );

		$this->add_arrow_style_settings();
		$this->add_pagination_style_settings();
		$this->add_scrollbar_style_settings();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Add Slider Arrow Styling Setting controls to Style section of the Widget.
	 */
	private function add_arrow_style_settings() {
		$this->start_controls_tab(
			$this->name . '_slide_navigation_arrows_tab',
			array(
				'label' => __( 'Arrows', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_arrows_heading_none',
			array(
				'label'     => __( 'Enable arrows option to adjust style options', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => array( $this->name . '_navigation_arrow_type' => 'none' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_arrows_vertical_position',
			array(
				'label'      => __( 'Vertical position', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => - 300,
						'max' => 300,
					),
					'%'  => array(
						'min' => - 100,
						'max' => 100,
					),
				),
				'default'    => array(
					'unit' => $this->position_size_units[1],
					'size' => 50,
				),
				'condition'  => array( $this->name . '_navigation_arrow_type!' => 'none' ),
				'selectors'  => array( '{{WRAPPER}} .swiper-button-prev, {{WRAPPER}} .swiper-button-next' => 'top: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_left_arrow_position',
			array(
				'label'     => __( 'Left Arrow Position', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 10,
						'max' => 500,
					),
				),
				'default'   => array(
					'size' => 10,
				),
				'condition' => array( $this->name . '_navigation_arrow_type!' => 'none' ),
				'selectors' => array( '{{WRAPPER}} .swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_right_arrow_position',
			array(
				'label'     => __( 'Right Arrow Position', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 10,
						'max' => 500,
					),
				),
				'default'   => array(
					'size' => 10,
				),
				'condition' => array( $this->name . '_navigation_arrow_type!' => 'none' ),
				'selectors' => array( '{{WRAPPER}} .swiper-button-next' => 'right: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_arrows_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'default'    => array(
					'unit' => $this->position_size_units[1],
					'size' => 50,
				),
				'condition'  => array( $this->name . '_navigation_arrow_type!' => 'none' ),
				'selectors'  => array(
					'{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-next svg' => 'border-radius: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .swiper-button-prev, {{WRAPPER}} .swiper-button-prev svg' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();
	}

	/**
	 * Add Slider Pagination Styling Setting controls to Style section of the Widget.
	 */
	private function add_pagination_style_settings() {
		$this->start_controls_tab(
			$this->name . '_slide_navigation_pagination_tab',
			array(
				'label'     => __( 'Pagination', 'anky' ),
				'condition' => array( $this->name . '_navigation_pagination_enable' => '1' ),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_pagination_heading_none',
			array(
				'label'     => __( 'Enable pagination option to adjust style options', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => array( $this->name . '_navigation_pagination_enable' => '' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_pagination_location_top',
			array(
				'label'      => __( 'Adjust Position', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => - 300,
						'max' => 300,
					),
					'%'  => array(
						'min' => - 100,
						'max' => 100,
					),
				),
				'selectors'  => array( '{{WRAPPER}} .anky-swiper-pagination' => 'top: {{SIZE}}{{UNIT}};' ),
				'condition'  => array(
					$this->name . '_navigation_pagination_enable'   => '1',
					$this->name . '_navigation_pagination_location' => 'top',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_pagination_location_bottom',
			array(
				'label'      => __( 'Adjust Position', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => - 300,
						'max' => 300,
					),
					'%'  => array(
						'min' => - 100,
						'max' => 100,
					),
				),
				'default'    => array(
					'size'  => - 48,
					'units' => $this->default_size_units[0],
				),
				'selectors'  => array( '{{WRAPPER}} .anky-swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}};' ),
				'condition'  => array(
					$this->name . '_navigation_pagination_enable'   => '1',
					$this->name . '_navigation_pagination_location' => 'bottom',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_pagination_progressbar_width',
			array(
				'label'      => __( 'Progressbar Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 1120,
					),
					'%'  => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'    => array(
					'unit' => $this->position_size_units[0],
					'size' => 600,
				),
				'selectors'  => array( '{{WRAPPER}} .anky-swiper-pagination' => 'width: {{SIZE}}{{UNIT}};' ),
				'condition'  => array(
					$this->name . '_navigation_pagination_enable'  => '1',
					$this->name . '_navigation_pagination_options' => 'progressbar',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_pagination_progressbar_height',
			array(
				'label'     => __( 'Progressbar Height', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 0,
						'max' => 15,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 5,
				),
				'selectors' => array( '{{WRAPPER}} .anky-swiper-pagination' => 'height: {{SIZE}}{{UNIT}};' ),
				'condition' => array(
					$this->name . '_navigation_pagination_enable'  => '1',
					$this->name . '_navigation_pagination_options' => 'progressbar',
				),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_pagination_progressbar_color',
			array(
				'label'     => __( 'Progressbar Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .swiper-pagination-progressbar' => 'background-color: {{VALUE}}' ),
				'condition' => array(
					$this->name . '_navigation_pagination_enable'  => '1',
					$this->name . '_navigation_pagination_options' => 'progressbar',
				),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_pagination_progressbar_active_color',
			array(
				'label'     => __( 'Progressbar active color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .swiper-pagination-progressbar-fill' => 'background-color: {{VALUE}}' ),
				'condition' => array(
					$this->name . '_navigation_pagination_enable'  => '1',
					$this->name . '_navigation_pagination_options' => 'progressbar',
				),
			)
		);

		/**
		 * Animated pagination.
		 */
		$this->add_control(
			$this->name . '_slide_navigation_animated_pagination_heading',
			array(
				'label'     => __( 'Animated pagination', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( $this->name . '_animation' => '1' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_animated_pagination_margin_top',
			array(
				'label'     => __( 'Margin top', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 10,
						'max' => 240,
					),
				),
				'condition' => array( $this->name . '_animation' => '1' ),
				'default'   => array( 'size' => 48 ),
				'selectors' => array( '{{WRAPPER}} .progressBarContainer' => 'margin: {{SIZE}}{{UNIT}} auto 0 auto;' ),
			)
		);
		$this->end_controls_tab();
	}

	/**
	 * Add Slider Scrollbar Styling Setting controls to Style section of the Widget.
	 */
	private function add_scrollbar_style_settings() {
		$this->start_controls_tab(
			$this->name . '_slide_navigation_scrollbar_tab',
			array(
				'label' => __( 'Scrollbar', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_scrollbar_heading_none',
			array(
				'label'     => __( 'Set scrollbar option to Custom to adjust style options', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => array( $this->name . '_navigation_scrollbar_type!' => 'custom' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_scrollbar_location_top',
			array(
				'label'     => __( 'Adjust position', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => - 60,
						'max' => 60,
					),
				),
				'default'   => array( 'size' => 5 ),
				'selectors' => array( '{{WRAPPER}} .swiper-scrollbar' => 'top: {{SIZE}}{{UNIT}};' ),
				'condition' => array(
					$this->name . '_navigation_scrollbar_type'     => 'custom',
					$this->name . '_navigation_scrollbar_location' => 'top',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slide_navigation_scrollbar_location_bottom',
			array(
				'label'     => __( 'Bottom', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => - 60,
						'max' => 60,
					),
				),
				'default'   => array( 'size' => 5 ),
				'selectors' => array( '{{WRAPPER}} .swiper-scrollbar' => 'bottom: {{SIZE}}{{UNIT}};' ),
				'condition' => array(
					$this->name . '_navigation_scrollbar_type'     => 'custom',
					$this->name . '_navigation_scrollbar_location' => 'bottom',
				),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_scrollbar_color',
			array(
				'label'     => __( 'Scrollbar color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .swiper-scrollbar' => 'background-color: {{VALUE}}' ),
				'condition' => array(
					$this->name . '_navigation_scrollbar_type' => 'custom',
				),
			)
		);
		$this->add_control(
			$this->name . '_slide_navigation_scrollbar_active_color',
			array(
				'label'     => __( 'Scrollbar active color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .swiper-scrollbar-drag' => 'background-color: {{VALUE}}' ),
				'condition' => array(
					$this->name . '_navigation_scrollbar_type' => 'custom',
				),
			)
		);
		$this->end_controls_tab();
	}

}
