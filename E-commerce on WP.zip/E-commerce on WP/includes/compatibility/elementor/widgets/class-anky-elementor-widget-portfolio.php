<?php
/**
 * Anky Theme Elementor Widget for displaying Portfolio section.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use WP_Query;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying Portfolio section.
 */
class Anky_Elementor_Widget_Portfolio extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_portfolio';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Portfolio', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-products-archive';
	}

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'isotope', 'anky-widget-portfolio' );
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		/**
		 * Content.
		 */
		$this->add_content_display_settings();
		$this->add_content_settings();
		/**
		 * Styles.
		 */
		$this->add_intro_title_style_controls();
		$this->add_filter_buttons_style_controls();
		$this->add_item_container_style_controls();
		$this->add_content_style_controls();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Bail if post type is disabled.
		if ( isset( $settings[ $this->name . '_no_post_type_value' ] ) ) {
			printf( '<h3>%s</h3>', esc_html__( 'No Portfolio posts found', 'anky' ) );
			printf( '<p>%s</p>', esc_html__( 'Please active Anky Extensions Plugin to set up required post type.', 'anky' ) );

			return;
		}

		$query = new WP_Query(
			array(
				'posts_per_page' => (int) $settings[ $this->name . '_posts_number' ],
				'post_type'      => 'portfolio',
				'order'          => $settings[ $this->name . '_posts_order' ],
			)
		);

		$terms_data = array();

		// Collecting the loop data.
		ob_start();
		while ( $query->have_posts() ) {
			$query->the_post();
			$terms = wp_get_post_terms( get_the_ID(), array( 'portfolio_category' ) );
			if ( ! empty( $terms ) ) {
				$terms_data[] = $terms;
			}

			$wrapper_classes = array();
			$term_links      = '<span class="anky-post-cat">';
			foreach ( $terms as $slug ) {
				$wrapper_classes[] = $slug->slug;

				$term_links .= sprintf( '<a href="%s" rel="category">%s</a>, ', esc_url( get_term_link( (int) $slug->term_id ) ), esc_html( $slug->name ) );
			}
			$term_links = rtrim( $term_links, ', ' ) . '</span>';

			anky_load_template(
				'template-parts/elementor/portfolio/portfolio',
				$settings[ $this->name . '_skin' ],
				array(
					'terms'           => $terms,
					'wrapper_classes' => $wrapper_classes,
					'term_links'      => $term_links,
					'placeholder_url' => $settings[ $this->name . '_empty_image_placeholder' ] ? Utils::get_placeholder_image_src() : '',
				)
			);
		}

		$content          = ob_get_clean();
		$content_before   = '';
		$content_after    = '</div><!--.anky-portfolio-section-body--></div><!--.anky-portfolio-section-->';
		$terms_data       = array_unique( anky_array_flatten( $terms_data ), SORT_REGULAR );
		$current_skin_num = $this->get_template_number( $settings[ $this->name . '_skin' ] );

		// for template 4 and template 5.
		if ( in_array( $settings[ $this->name . '_skin' ], array( 'template4', 'template5' ), true ) ) {
			$content_before .= '<div class="anky-portfolio-section anky-portfolio-section-' . $current_skin_num . '" data-skin="' . $current_skin_num . '">';
			$content_before .= '<div class="anky-portfolio-section-header"><div class="anky-container">';
			$content_before .= $this->get_filter_template( $terms_data, $settings );
			$content_before .= '</div><!--.anky-container--></div><!--.anky-portfolio-section-header--><div class="anky-portfolio-section-body">';
		} else { // for other templates.
			$content_before .= '<div class="anky-container"><div class="anky-portfolio-section anky-portfolio-section-' . $current_skin_num . '" data-skin="' . $current_skin_num . '">';
			$content_before .= '<div class="anky-portfolio-section-header">';
			$content_before .= $this->get_filter_template( $terms_data, $settings );
			$content_before .= '</div><!--.anky-portfolio-section-header--><div class="anky-portfolio-section-body">';
			$content_after  .= '</div><!--elementor-widget-container-->';
		}

		// Output is properly sanitized where it's required.
		echo $content_before; // phpcs:ignore WordPress.Security.EscapeOutput
		echo $content;        // phpcs:ignore WordPress.Security.EscapeOutput
		echo $content_after;  // phpcs:ignore WordPress.Security.EscapeOutput

		wp_reset_postdata();
	}

	// ======================================================
	// PRIVATE - Render parts and helpers
	// ======================================================

	/**
	 * Parsing string and retrieve the first number from string.
	 * In current situation it can locate the template number from option string.
	 *
	 * @param string $template Required. Template string option.
	 *
	 * @return string|null
	 */
	private function get_template_number( $template ) {
		preg_match( '!\d+!', $template, $match );

		return $match[0] ?? null;
	}

	/**
	 * Prepare the template filter for rendering.
	 *
	 * @param array $terms    Required. Terms data to prepare terms filter.
	 * @param array $settings Required. Current widget settings data.
	 *
	 * @return string
	 */
	private function get_filter_template( $terms, $settings ) {
		$return = '<h2 class="anky-portfolio-section-title">' . esc_html( $settings[ $this->name . '_intro_title' ] ) . '</h2>';

		if ( ! empty( $terms ) ) {
			$return .= '<ul class="anky-portfolio-section-list anky-list-unstyled">';
			$return .= '<li><button type="button" class="active anky-btn-clear" data-filter="*">' . esc_html( $settings[ $this->name . '_all_portfolio_link_text' ] ) . '</button></li>';
			foreach ( $terms as $term ) {
				$return .= sprintf( '<li><button type="button" class="anky-btn-clear" data-filter="%s">%s</button></li>', esc_attr( $term->slug ), esc_html( $term->name ) );
			}
			$return .= '</ul>';
		}

		return $return;
	}

	// ======================================================
	// PRIVATE - Content settings
	// ======================================================

	/**
	 * Add Display settings to Content tab.
	 */
	private function add_content_display_settings() {
		$this->start_controls_section(
			$this->name . '_content_section',
			array(
				'label' => __( 'Content Settings', 'anky' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		// Bailing if Post type is not found.
		if ( ! anky_post_type_exists( 'portfolio' ) ) {
			$this->add_control(
				$this->name . '_no_post_type',
				array(
					'label' => __( 'Required post type not found.', 'anky' ) . ' ' . __( 'Please active Anky Extensions Plugin to set up required post type.', 'anky' ),
					'type'  => Controls_Manager::HEADING,
				)
			);
			$this->add_control(
				$this->name . '_no_post_type_value',
				array(
					'type'    => Controls_Manager::HIDDEN,
					'default' => true,
				)
			);
			$this->end_controls_section();

			return;
		}

		$this->add_control(
			$this->name . '_posts_number',
			array(
				'label'   => __( 'Number Of Posts', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '3',
				'options' => array(
					- 1 => __( 'All', 'anky' ),
					1   => 1,
					2   => 2,
					3   => 3,
					4   => 4,
					5   => 5,
					6   => 6,
				),
			)
		);
		$this->add_control(
			$this->name . '_posts_order',
			array(
				'label'   => __( 'Order by', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'ASC'  => __( 'ASC', 'anky' ),
					'DESC' => __( 'DESC', 'anky' ),

				),
			)
		);
		$this->add_control(
			$this->name . '_skin',
			array(
				'label'   => __( 'Template View', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'template1',
				'options' => array(
					'template1' => __( 'Skin 1', 'anky' ),
					'template2' => __( 'Skin 2', 'anky' ),
					'template3' => __( 'Skin 3', 'anky' ),
					'template4' => __( 'Skin 4', 'anky' ),
					'template5' => __( 'Skin 5', 'anky' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_empty_image_placeholder',
			array(
				'label'        => __( 'Add placeholder', 'anky' ),
				'description'  => __( 'Add image placeholder for posts without thumbnail', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '1',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add text content for Title and Filter button to Content tab.
	 */
	private function add_content_settings() {
		$this->start_controls_section(
			$this->name . '_text_content_section',
			array(
				'label' => esc_html__( 'Content Settings', 'anky' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			$this->name . '_intro_title',
			array(
				'label'       => __( 'Intro title', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Portfolio', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_all_portfolio_link_text',
			array(
				'label'       => __( 'All data filter text', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'All projects', 'anky' ),
			)
		);

		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Style Settings
	// ======================================================

	/**
	 * Add Intro text Specific style controls.
	 */
	private function add_intro_title_style_controls() {
		$this->start_controls_section(
			$this->name . '_intro_title_style_settings',
			array(
				'label' => __( 'Intro Title', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_content_related_style_controls_part( "{$this->name}_intro_title_title", '.anky-portfolio-section-title', '#16161A', $this->default_heading_typography );

		$this->end_controls_section();
	}

	/**
	 * Add Filter Section specific style controls.
	 */
	private function add_filter_buttons_style_controls() {
		$this->start_controls_section(
			$this->name . '_filter_buttons_style_settings',
			array(
				'label' => __( 'Filter content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			$this->name . '_filter_buttons_colors_popover',
			array(
				'label' => __( 'Colors', 'anky' ),
				'type'  => Controls_Manager::POPOVER_TOGGLE,
			)
		);

		$this->start_popover();
		$this->add_control(
			$this->name . '_filter_buttons_title_color',
			array(
				'label'     => __( 'Primary Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7E7E83',
				'selectors' => array(
					'{{WRAPPER}} .anky-portfolio-section-list button' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_filter_active_buttons_title_color',
			array(
				'label'     => __( 'Alternate state color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-portfolio-section-list button.active,{{WRAPPER}} .anky-portfolio-section-list button:hover' => 'color: {{VALUE}};',
				),
			)
		);
		$this->end_popover();

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_filter_buttons_title_typography',
				'selector'       => '{{WRAPPER}} .anky-portfolio-section-list button',
				'fields_options' => $this->default_paragraph_typography,

			)
		);

		/**
		 * Decorative Border part.
		 */
		$this->add_control(
			$this->name . '_filter_buttons_after_heading',
			array(
				'label'     => __( 'Decorative elements', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( $this->name . '_skin' => array( 'template2', 'template3' ) ),
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => $this->name . '_filter_border',
				'condition' => array( $this->name . '_skin' => array( 'template2', 'template3' ) ),
				'selector'  => '{{WRAPPER}} .anky-portfolio-section-list',
			)
		);
		$this->add_control(
			$this->name . '_filter_buttons_after_color',
			array(
				'label'     => __( 'Active element highlight color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array( $this->name . '_skin' => array( 'template2', 'template3' ) ),
				'selectors' => array(
					'{{WRAPPER}} .anky-portfolio-section-list button:after' => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_filter_buttons_after_height',
			array(
				'label'     => __( 'Height', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'condition' => array( $this->name . '_skin' => array( 'template2', 'template3' ) ),
				'selectors' => array(
					'{{WRAPPER}} .anky-portfolio-section-list button:after' => 'height: {{SIZE}}px;',
				),
			)
		);
		$this->add_control(
			$this->name . '_filter_buttons_after_position',
			array(
				'label'     => __( 'Position', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'condition' => array( $this->name . '_skin' => array( 'template2', 'template3' ) ),
				'range'     => array(
					'px' => array(
						'min'  => - 100,
						'max'  => 100,
						'step' => 1,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-portfolio-section-list button:after' => 'bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			$this->name . '_filter_buttons_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-section-list button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_filter_buttons_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 24,
					'bottom'   => 0,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-section-list li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_filter_buttons_container_margin',
			array(
				'label'      => __( 'Container margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 60,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-section-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Post item container style controls.
	 */
	private function add_item_container_style_controls() {
		$this->start_controls_section(
			$this->name . '_item_container_style_settings',
			array(
				'label' => __( 'Post container', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			$this->name . '_item_container_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => '%',
					'size' => 50,
				),
				'selectors'  => array( '{{WRAPPER}} .anky-portfolio-section-item' => 'width: calc({{SIZE}}{{UNIT}} - var(--anky-grid-gutters));' ),
				'condition'  => array( $this->name . '_skin!' => array( 'template4', 'template5' ) ),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_item_container_border',
				'selector' => '{{WRAPPER}} .anky-portfolio-section-item',
			)
		);
		$this->add_responsive_control(
			$this->name . '_item_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-section-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_item_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 32,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-section-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Post Content style controls.
	 * method contains styles for:
	 * - Image
	 * - Title
	 * - Categories
	 */
	private function add_content_style_controls() {
		$this->start_controls_section(
			$this->name . '_content_style_settings',
			array(
				'label' => __( 'Post content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->start_controls_tabs( $this->name . '_content_style_tabs' );

		/**
		 * Post thumbnail.
		 */
		$this->start_controls_tab(
			$this->name . '_content_image_tab',
			array( 'label' => __( 'Image', 'anky' ) )
		);
		$this->add_responsive_control(
			$this->name . '_content_image_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .post-thumbnail img' => 'width: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_image_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .post-thumbnail img' => 'height: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_image_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => 24,
				),
				'selectors'  => array(
					'{{WRAPPER}} .post-thumbnail, {{WRAPPER}} .post-thumbnail img, {{WRAPPER}} .anky-portfolio-item-info' => 'border-radius: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_image_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 32,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .post-thumbnail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array( $this->name . '_skin!' => array( 'template3', 'template4' ) ),
			)
		);
		$this->end_controls_tab();

		/**
		 *Post title.
		 */
		$this->start_controls_tab(
			$this->name . '_content_title_tab',
			array( 'label' => __( 'Title', 'anky' ) )
		);
		$this->add_control(
			$this->name . '_content_title_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-portfolio-item-title, {{WRAPPER}} .anky-portfolio-item-title a' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_content_title_typography',
				'selector'       => '{{WRAPPER}} .anky-portfolio-item-title',
				'fields_options' => $this->default_small_heading_typography,
				'separator'      => 'after',
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_title_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_title_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 24,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		/**
		 * Post categories.
		 */
		$this->start_controls_tab(
			$this->name . '_content_categories_tabs',
			array(
				'label'     => __( 'Categories', 'anky' ),
				'condition' => array( $this->name . '_skin!' => array( 'template4', 'template5' ) ),
			)
		);
		$this->add_control(
			$this->name . '_content_categories_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-post-cat, {{WRAPPER}} .anky-post-cat a' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_content_categories_typography',
				'selector'       => '{{WRAPPER}} .anky-portfolio-item-cats a',
				'fields_options' => $this->default_paragraph_typography,
				'separator'      => 'after',
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_categories_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-item-cats' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_categories_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-item-cats' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'label'     => __( 'Content Background', 'anky' ),
				'name'      => $this->name . '_post_content_background',
				'types'     => array( 'classic', 'gradient' ),
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .anky-portfolio-item-info',
				'condition' => array( $this->name . '_skin' => array( 'template3', 'template4' ) ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_item_info_padding',
			array(
				'label'           => __( 'Padding', 'anky' ),
				'type'            => Controls_Manager::DIMENSIONS,
				'size_units'      => $this->default_size_units,
				'desktop_default' => array(
					'top'    => 40,
					'right'  => 40,
					'bottom' => 40,
					'left'   => 40,
					'unit'   => 'px',
				),
				'mobile_default'  => array(
					'top'    => 24,
					'right'  => 24,
					'bottom' => 24,
					'left'   => 24,
					'unit'   => 'px',
				),
				'selectors'       => array(
					'{{WRAPPER}} .anky-portfolio-item-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'       => array( $this->name . '_skin' => array( 'template3', 'template4' ) ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_item_info_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-portfolio-item-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array( $this->name . '_skin' => array( 'template3', 'template4' ) ),
			)
		);
		$this->end_controls_section();
	}

}
