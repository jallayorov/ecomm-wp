<?php
/**
 * Anky Theme Elementor Widget for displaying custom content or Elementor template in tabs.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Plugin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying custom content or Elementor template in tabs.
 */
class Anky_Elementor_Widget_Content_Switcher extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_content_switcher';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Content Switcher', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-tabs';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'anky-widget-content-switcher' );
	}

	/**
	 * Whether preview reload is required.
	 *
	 * Used to determine whether the preview reload is required or not.
	 *
	 * @return bool Whether preview reload is required.
	 */
	public function is_reload_preview_required() {
		return true;
	}

	/**
	 * Register Content Toggle controls.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		/**
		 * Content.
		 */
		$this->add_switcher_intro_title_controls();
		$this->add_switcher_label_content_controls();
		$this->add_switcher_content_block( 'first' );
		$this->add_switcher_content_block( 'second' );
		$this->add_switcher_animation_display_controls();

		/**
		 * Style tab.
		 */
		$this->add_switcher_container_style_control();
		$this->add_switcher_intro_style_control();
		$this->add_switcher_main_style_controls();
		$this->add_switcher_content_style_control();
	}

	/**
	 * Render Content Toggle widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( $this->name . '_first_content_text', 'advanced' );
		$this->add_render_attribute( $this->name . '_first_content_text', 'class', 'anky-content-switcher-tab-item-first-text' );

		$this->add_inline_editing_attributes( $this->name . '_second_content_text', 'advanced' );
		$this->add_render_attribute( $this->name . '_second_content_text', 'class', 'anky-content-switcher-tab-item-second-text' );

		$animation           = 'fade' === $settings[ $this->name . '_animation' ] ? 'fade-' . $settings[ $this->name . '_fade_dir' ] : 'opacity';
		$container_classes   = array( 'anky-content-switcher-container', 'anky-content-switcher-container-' . $this->get_id() );
		$container_classes[] = ( 'column' === $settings[ $this->name . '_heading_layout' ] ) ? 'anky-content-switcher-vertical' : 'anky-content-switcher-horizontal';
		?>

		<div class="<?php echo esc_attr( implode( ' ', $container_classes ) ); ?>">
			<div class="anky-content-switcher-header">
				<?php if ( '1' === $settings[ $this->name . '_intro_switcher' ] ) : ?>
					<div class="anky-content-switcher-intro">
						<?php
						$this->add_inline_editing_attributes( $this->name . '_intro_heading', 'none' );
						$this->add_render_attribute( $this->name . '_intro_heading', 'class', 'anky-content-switcher-intro-title' );

						$this->add_inline_editing_attributes( $this->name . '_intro_content' );
						$this->add_render_attribute( $this->name . '_intro_content', 'class', 'anky-content-switcher-content' );
						?>
						<h3 <?php $this->print_render_attribute_string( $this->name . '_intro_heading' ); ?>><?php echo esc_html( $settings[ $this->name . '_intro_heading' ] ); ?></h3>
						<p <?php $this->print_render_attribute_string( $this->name . '_intro_content' ); ?>><?php echo esc_html( $settings[ $this->name . '_intro_content' ] ); ?></p>

					</div>
				<?php endif; ?>

				<div class="anky-content-switcher-switch-group">
					<div class="anky-content-switcher-switch-group-wrapper">
						<button type="button" class="anky-content-switcher-switch-button anky-content-switcher-heading-one anky-content-switcher-heading-active" data-heading-eq="1">
							<?php echo esc_html( $settings[ $this->name . '_heading_one' ] ); ?>
						</button>
						<button type="button" class="anky-content-switcher-switch-button anky-content-switcher-heading-two" data-heading-eq="2">
							<?php echo esc_html( $settings[ $this->name . '_heading_two' ] ); ?>
						</button>
					</div>
				</div>
			</div>

			<div class="anky-content-switcher-body <?php echo esc_attr( $animation ); ?>">
				<ul class="anky-content-switcher-tab-content">
					<li class="anky-content-switcher-tab-item anky-content-switcher-tab-item-first anky-content-switcher-tab-active" data-tab-eq="1">
						<?php
						if ( 'elementor_templates' === $settings[ $this->name . '_first_content_tools' ] ) {
							printf(
								'<div class="anky-content-switcher-first-content-item-wrapper">%s</div>',
								$this->get_template_content( $settings[ $this->name . '_first_content_templates' ] )
							);
						} else {
							echo wp_kses_post(
								sprintf(
									'<div %s>%s</div>',
									$this->get_render_attribute_string( $this->name . '_first_content_text' ),
									$this->parse_text_editor( $settings[ $this->name . '_first_content_text' ] )
								)
							);
						}
						?>
					</li>
					<li class="anky-content-switcher-tab-item anky-content-switcher-tab-item-second" data-tab-eq="2">
						<?php
						if ( 'elementor_templates' === $settings[ $this->name . '_second_content_tools' ] ) {
							printf(
								'<div class="anky-content-switcher-second-content-item-wrapper">%s</div>',
								$this->get_template_content( $settings[ $this->name . '_second_content_templates' ] )
							);
						} else {
							echo wp_kses_post(
								sprintf(
									'<div %s>%s</div>',
									$this->get_render_attribute_string( $this->name . '_second_content_text' ),
									$this->parse_text_editor( $settings[ $this->name . '_second_content_text' ] )
								)
							);
						}
						?>
					</li>
				</ul>
			</div>
		</div>
		<?php
	}

	// ======================================================
	// PRIVATE - Content Tab
	// ======================================================

	/**
	 * Add content switcher intro content that sets before the toggling buttons.
	 */
	private function add_switcher_intro_title_controls() {
		$this->start_controls_section(
			$this->name . '_intro_section',
			array(
				'label' => __( 'Switcher Intro', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_intro_switcher',
			array(
				'label'        => __( 'Show intro section', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'anky' ),
				'label_off'    => __( 'Hide', 'anky' ),
				'return_value' => '1',
				'default'      => '1',
			)
		);
		$this->add_control(
			$this->name . '_intro_heading',
			array(
				'label'       => __( 'Intro Title', 'anky' ),
				'default'     => __( 'Unique item title is here.', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => array( 'active' => true ),
				'condition'   => array( $this->name . '_intro_switcher' => '1' ),
			)
		);
		$this->add_control(
			$this->name . '_intro_content',
			array(
				'label'     => __( 'Intro Content', 'anky' ),
				'default'   => 'Lorem ipsum dolor sit amet consectetur elit. Maxime nostrum vero est aliquid, omnis in, tempora, rerum optio? Tempora, consectetur ratione doloremque enim quisquam a sed.',
				'type'      => Controls_Manager::TEXTAREA,
				'dynamic'   => array( 'active' => true ),
				'condition' => array( $this->name . '_intro_switcher' => '1' ),
			)
		);
		$this->add_control(
			$this->name . '_intro_layout',
			array(
				'label'     => __( 'Display', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'row'    => array(
						'title' => __( 'Inline', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
					'column' => array(
						'title' => __( 'Block', 'anky' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'default'   => 'column',
				'selectors' => array(
					'{{WRAPPER}} .anky-content-switcher-intro' => 'flex-direction: {{VALUE}};',
				),
				'condition' => array( $this->name . '_intro_switcher' => '1' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add content switcher labels content.
	 * This is mainly button triggers descriptive text.
	 */
	private function add_switcher_label_content_controls() {
		$this->start_controls_section(
			$this->name . '_headings_section',
			array(
				'label' => __( 'Switcher Labels', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_heading_one',
			array(
				'label'       => __( 'First Label', 'anky' ),
				'label_block' => true,
				/* translators: %s section number*/
				'default'     => sprintf( __( 'Content section %s', 'anky' ), '#1' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
			)
		);

		$this->add_control(
			$this->name . '_heading_two',
			array(
				'label'       => __( 'Second Label', 'anky' ),
				'label_block' => true,
				/* translators: %s section number*/
				'default'     => sprintf( __( 'Content section %s', 'anky' ), '#2' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
			)
		);

		$this->add_control(
			$this->name . '_heading_layout',
			array(
				'label'     => __( 'Display', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'row'    => array(
						'title' => __( 'Inline', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
					'column' => array(
						'title' => __( 'Block', 'anky' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'default'   => 'row',
				'condition' => array( $this->name . '_intro_switcher' => '1' ),
			)
		);

		$this->add_responsive_control(
			$this->name . '_headings_alignment',
			array(
				'label'     => __( 'Alignment', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'center',
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'     => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'   => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-content-switcher-horizontal .anky-content-switcher-switch-group' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .anky-content-switcher-vertical .anky-content-switcher-switch-group'   => 'align-items: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add content setup section for particular list item switch.
	 *
	 * Due to repeating nature of items the only thing required is to pass a string slug.
	 * Slug should be considered letters and be more like meaningful word.
	 *
	 * @param string $slug Required. Identifier for current switch zone.
	 */
	private function add_switcher_content_block( $slug ) {
		$this->start_controls_section(
			"{$this->name}_{$slug}_content_section",
			array(
				/* translators: slug used to identify content section by specific name or number */
				'label' => sprintf( __( '%s Content section ', 'anky' ), ucfirst( $slug ) ),
			)
		);

		$this->add_control(
			"{$this->name}_{$slug}_content_tools",
			array(
				'label'   => __( 'Content to Show', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'text_editor'         => __( 'Text Editor', 'anky' ),
					'elementor_templates' => __( 'Elementor Template', 'anky' ),
				),
				'default' => 'text_editor',
			)
		);
		$this->add_control(
			"{$this->name}_{$slug}_content_text",
			array(
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => esc_html__( 'Your unique content can be inserted here', 'anky' ),
				'dynamic'     => array( 'active' => true ),
				'condition'   => array( "{$this->name}_{$slug}_content_tools" => 'text_editor' ),
				'label_block' => true,
			)
		);
		$this->add_responsive_control(
			"{$this->name}_{$slug}_content_alignment",
			array(
				'label'     => __( 'Alignment', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'center',
				'options'   => array(
					'left'    => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'fa fa-align-left',
					),
					'center'  => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'fa fa-align-center',
					),
					'right'   => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'fa fa-align-right',
					),
					'justify' => array(
						'title' => __( 'Justify', 'anky' ),
						'icon'  => 'fa fa-align-justify',
					),
				),
				'condition' => array( "{$this->name}_{$slug}_content_tools" => 'text_editor' ),
				'selectors' => array( "{{WRAPPER}} .anky-content-switcher-tab-item-$slug-text" => 'text-align: {{VALUE}};' ),
			)
		);
		$this->add_control(
			"{$this->name}_{$slug}_content_templates",
			array(
				'label'       => __( 'Elementor Template', 'anky' ),
				'description' => __( 'Elementor Template is a template which you can choose from Elementor library. Each template will be shown in content', 'anky' ),
				'type'        => Controls_Manager::SELECT2,
				'options'     => $this->get_elementor_page_list(),
				'label_block' => true,
				'condition'   => array( "{$this->name}_{$slug}_content_tools" => 'elementor_templates' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add switcher animation display options.
	 */
	private function add_switcher_animation_display_controls() {
		$this->start_controls_section(
			$this->name . '_content_display',
			array(
				'label' => __( 'Switcher Animation Options', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_animation',
			array(
				'label'   => __( 'Animation Type', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'opacity' => __( 'Fade', 'anky' ),
					'fade'    => __( 'Slide', 'anky' ),
				),
				'default' => 'opacity',
			)
		);
		$this->add_control(
			$this->name . '_fade_dir',
			array(
				'label'     => __( 'Direction', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'top'    => array(
						'title' => __( 'Top', 'anky' ),
						'icon'  => 'eicon-arrow-up',
					),
					'bottom' => array(
						'title' => __( 'Bottom', 'anky' ),
						'icon'  => 'eicon-arrow-down',
					),
					'left'   => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-arrow-left',
					),
					'right'  => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-arrow-right',
					),
				),
				'default'   => 'top',
				'condition' => array( $this->name . '_animation' => 'fade' ),
			)
		);

		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Style tab
	// ======================================================

	/**
	 * Add style controls that applies to the Switcher main container.
	 */
	private function add_switcher_container_style_control() {
		$this->start_controls_section(
			$this->name . '_container_style',
			array(
				'label' => __( 'Container', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => $this->name . '_container_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .anky-content-switcher-container',
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_container_border',
				'selector' => '{{WRAPPER}} .anky-content-switcher-container',
			)
		);
		$this->add_control(
			$this->name . '_container_border_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-container' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => $this->name . '_container_box_shadow',
				'selector' => '{{WRAPPER}} .anky-content-switcher-container',
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add style controls for Switcher intro section.
	 */
	private function add_switcher_intro_style_control() {
		$this->start_controls_section(
			$this->name . '_intro_style_section',
			array(
				'label'     => __( 'Intro section', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( $this->name . '_intro_switcher' => '1' ),
			)
		);

		$this->start_controls_tabs( $this->name . '_intro_style_tabs' );

		$this->start_controls_tab(
			$this->name . '_intro_content_title_style_tab',
			array(
				'label' => __( 'Title', 'anky' ),
			)
		);
		$this->add_text_style_controls_part( 'title', '.anky-content-switcher-intro-title' );
		$this->add_responsive_control(
			$this->name . '_intro_title_spacer_row',
			array(
				'label'      => __( 'Title Gap', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 24,
				),
				'condition'  => array( $this->name . '_intro_layout' => 'row' ),
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-intro-title' => 'margin-right: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_title_spacer_column',
			array(
				'label'      => __( 'Title Gap', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 24,
				),
				'condition'  => array( $this->name . '_intro_layout' => 'column' ),
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-intro-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_intro_content_text_style_tab',
			array(
				'label' => __( 'Content', 'anky' ),
			)
		);
		$this->add_text_style_controls_part( 'content', '.anky-content-switcher-content' );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			$this->name . '_intro_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-intro' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'default'    => array(
					'unit'     => $this->default_size_units[0],
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 42,
					'left'     => 0,
					'isLinked' => true,
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-intro' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add style controls that applies to the Switcher toggler section.
	 */
	private function add_switcher_main_style_controls() {
		$this->start_controls_section(
			$this->name . '_switcher_headings_container_style_section',
			array(
				'label' => __( 'Switcher', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( $this->name . '_switcher_headings_container_tabs' );

		$this->start_controls_tab(
			$this->name . '_switcher_wrapper_style_tab',
			array(
				'label' => __( 'Wrapper', 'anky' ),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_switcher_wrapper_border',
				'selector' => '{{WRAPPER}} .anky-content-switcher-switch-group-wrapper',
			)
		);
		$this->add_control(
			$this->name . '_switcher_wrapper_border_radius',
			array(
				'label'      => __( 'Switcher Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 16,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-switch-group-wrapper' => 'border-radius: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_switcher_wrapper_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit'   => $this->default_size_units[0],
					'top'    => 2,
					'right'  => 2,
					'bottom' => 2,
					'left'   => 2,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-switch-group-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'           => $this->name . '_switcher_wrapper_background_color',
				'types'          => array( 'classic', 'gradient' ),
				'fields_options' => array(
					'background' => array( 'default' => 'classic' ),
					'color'      => array( 'default' => '#F5F5F5' ),
				),
				'selector'       => '{{WRAPPER}} .anky-content-switcher-switch-group-wrapper',
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'label'    => __( 'Shadow', 'anky' ),
				'name'     => $this->name . '_switcher_wrapper_box_shadow',
				'selector' => '{{WRAPPER}} .anky-content-switcher-switch-group-wrapper',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_headings_style_tab',
			array(
				'label' => __( 'Switchers', 'anky' ),
			)
		);

		$this->add_responsive_control(
			$this->name . '_switcher_headings_spacing',
			array(
				'label'     => __( 'Spacing', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'units' => $this->default_size_units[0],
					'size'  => 0,
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-content-switcher-horizontal .anky-content-switcher-heading-one' => 'margin-right: {{SIZE}}px;',
					'{{WRAPPER}} .anky-content-switcher-vertical .anky-content-switcher-heading-one'   => 'margin-bottom: {{SIZE}}px;',
				),
			)
		);

		$this->add_switcher_label_style_controls( 'first', '.anky-content-switcher-heading-one' );
		$this->add_switcher_label_style_controls( 'second', '.anky-content-switcher-heading-two' );

		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_container_tab',
			array(
				'label' => __( 'Container', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_switcher_container_background_color',
			array(
				'label'     => __( 'Background', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .anky-content-switcher-switch-group' => 'background: {{VALUE}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_switcher_container_border',
				'selector' => '{{WRAPPER}} .anky-content-switcher-switch-group',
			)
		);
		$this->add_control(
			$this->name . '_switcher_container_border_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array( '{{WRAPPER}} .anky-content-switcher-switch-group' => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => $this->name . '_switcher_container_box_shadow',
				'selector' => '{{WRAPPER}} .anky-content-switcher-switch-group',
			)
		);
		$this->add_responsive_control(
			$this->name . '_switcher_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-switch-group' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_switcher_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array( '{{WRAPPER}} .anky-content-switcher-switch-group' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->end_controls_tab(); // _container_tab.

		$this->end_controls_tabs(); // _switcher_headings_container_tabs.

		$this->end_controls_section();
	}

	/**
	 * Add style controls that applies to the Switcher content section.
	 */
	private function add_switcher_content_style_control() {
		$this->start_controls_section(
			$this->name . '_content_style_section',
			array(
				'label' => __( 'Content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			$this->name . '_two_content_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'range'      => array(
					$this->default_size_units[0] => array(
						'min'  => 0,
						'step' => 1,
						'max'  => 1000,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-container .anky-content-switcher-tab-content > li' => 'min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs( $this->name . '_content_style_tabs' );

		$this->add_switcher_content_style_control_part( 'first', '.anky-content-switcher-tab-item-first', '.anky-content-switcher-tab-item-first-text' );
		$this->add_switcher_content_style_control_part( 'second', '.anky-content-switcher-tab-item-second', '.anky-content-switcher-tab-item-second-text' );

		$this->end_controls_tabs();

		$this->add_responsive_control(
			$this->name . '_contents_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-body' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_contents_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-content-switcher-tab-item-first, {{WRAPPER}} .anky-content-switcher-tab-item-second' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Control parts
	// ======================================================

	/**
	 * Add switcher inner content style controls for particular list item.
	 *
	 * Due to repeating nature of items the only thing required is to pass a string slug.
	 * Slug should be considered letters and be more like meaningful word.
	 *
	 * @param string $slug             Required. Identifier for current switch zone.
	 * @param string $selector         Required. Css selector for content wrap item.
	 * @param string $selector_content Required. Css selector for content part of List Item.
	 */
	private function add_switcher_content_style_control_part( $slug, $selector, $selector_content ) {
		$selector_wrap             = "{{WRAPPER}} $selector";
		$selector_text_content     = "{{WRAPPER}} $selector_content";
		$selector_text_content_all = "{{WRAPPER}} $selector_content *";

		$this->start_controls_tab(
			"{$this->name}_{$slug}_content_style_tab",
			array(
				/* translators: slug used to identify content section by specific name or number */
				'label' => sprintf( __( '%s Content', 'anky' ), ucfirst( $slug ) ),
			)
		);

		$this->add_control(
			"{$this->name}_{$slug}_content_color",
			array(
				'label'     => __( 'Text Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$selector_text_content     => 'color: {{VALUE}};',
					$selector_text_content_all => 'color: {{VALUE}};',
				),
				'condition' => array( "{$this->name}_{$slug}_content_tools" => 'text_editor' ),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => "{$this->name}_{$slug}_content_typography",
				'selector'  => $selector_text_content,
				'condition' => array( "{$this->name}_{$slug}_content_tools" => 'text_editor' ),
			)
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			array(
				'name'      => "{$this->name}_{$slug}_content_text_shadow",
				'selector'  => $selector_text_content,
				'condition' => array( "{$this->name}_{$slug}_content_tools" => 'text_editor' ),
			)
		);
		$this->add_control(
			"{$this->name}_{$slug}_content_background_color",
			array(
				'label'     => __( 'Background', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( $selector_wrap => 'background: {{VALUE}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => "{$this->name}_{$slug}_content_border",
				'selector' => $selector_wrap,
			)
		);
		$this->add_control(
			"{$this->name}_{$slug}_content_border_radius",
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array( $selector_wrap => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => "{$this->name}_{$slug}_content_box_shadow",
				'selector' => $selector_wrap,
			)
		);

		$this->end_controls_tab();
	}

	/**
	 * Add text specific style controls part.
	 *
	 * @param string $slug     Required. Identifier for current switch zone.
	 * @param string $selector Required. Css selector used to apply props to.
	 */
	private function add_text_style_controls_part( $slug, $selector ) {
		$selector_string = "{{WRAPPER}} $selector";

		$this->add_control(
			"{$this->name}_{$slug}_heading_color",
			array(
				'label'     => __( 'Text Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( $selector_string => 'color: {{VALUE}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => "{$this->name}_{$slug}_heading_typography",
				'selector' => $selector_string,
			)
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			array(
				'name'     => "{$this->name}_{$slug}_heading_text_shadow",
				'selector' => $selector_string,
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => "{$this->name}_{$slug}_background",
				'types'    => array( 'classic', 'gradient' ),
				'selector' => $selector_string,
			)
		);
		$this->add_control(
			"{$this->name}_{$slug}_heading_background_color_clip",
			array(
				'label'       => __( 'Background clip', 'anky' ),
				'type'        => Controls_Manager::SELECT,
				'description' => __( 'This feature sets whether an element`s background extends underneath its border box, padding box, or content box.', 'anky' ) .
								 __( 'NOTICE: This feature is experimental and may not work in some older browsers.', 'anky' ),
				'options'     => array(
					'border-box'  => __( 'Border', 'anky' ),
					'padding-box' => __( 'Padding', 'anky' ),
					'content-box' => __( 'Content', 'anky' ),
					'text'        => __( 'Text', 'anky' ),
					'unset'       => __( 'Disable', 'anky' ),
				),
				'default'     => 'unset',
				'selectors'   => array( $selector_string => '-webkit-background-clip: {{VALUE}}; background-clip: {{VALUE}};' ),
			)
		);
	}

	/**
	 * Add switcher label style controls for particular list item switch toggler.
	 *
	 * Due to repeating nature of items the only thing required is to pass a string slug.
	 * Slug should be considered letters and be more like meaningful word.
	 *
	 * @param string $slug     Required. Identifier for current switch zone.
	 * @param string $selector Required. Css selector used to apply props to.
	 */
	private function add_switcher_label_style_controls( $slug, $selector ) {
		$selector_string = "{{WRAPPER}} $selector";

		$this->add_control(
			"{$this->name}_{$slug}_heading_head",
			array(
				/* translators: slug used to identify content section by specific name or number */
				'label'     => sprintf( __( '%s Label', 'anky' ), ucfirst( $slug ) ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => "{$this->name}_{$slug}_heading_typography",
				'selector'       => $selector_string,
				'fields_options' => $this->default_paragraph_typography,
			)
		);

		$this->add_control(
			"{$this->name}_{$slug}_heading_active_colors_popover",
			array(
				'label' => __( 'Active Color State', 'anky' ),
				'type'  => Controls_Manager::POPOVER_TOGGLE,
			)
		);

		$this->start_popover();

		$this->add_control(
			"{$this->name}_popover_switch_{$slug}_active_colors",
			array(
				/* translators: slug used to identify content section by specific name or number */
				'label' => sprintf( __( '%s switcher active color state', 'anky' ), ucfirst( $slug ) ),
				'type'  => Controls_Manager::HEADING,
			)
		);
		$this->add_control(
			"{$this->name}_popover_switch_{$slug}_active_heading_color",
			array(
				'label'     => __( 'Text Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array( $selector_string . '.anky-content-switcher-heading-active' => 'color: {{VALUE}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'           => "{$this->name}_popover_switch_{$slug}_active_heading_background_color",
				'types'          => array( 'classic', 'gradient' ),
				'fields_options' => array(
					'background' => array( 'default' => 'classic' ),
					'color'      => array( 'default' => '#FFF' ),
				),
				'selector'       => $selector_string . '.anky-content-switcher-heading-active',
			)
		);

		$this->end_popover();

		$this->add_control(
			"{$this->name}_{$slug}_heading_default_colors_popover",
			array(
				'label' => __( 'Default Color State', 'anky' ),
				'type'  => Controls_Manager::POPOVER_TOGGLE,
			)
		);

		$this->start_popover();

		$this->add_control(
			"{$this->name}_popover_switch_{$slug}_default_colors",
			array(
				/* translators: slug used to identify content section by specific name or number */
				'label' => sprintf( __( '%s switcher default color state', 'anky' ), ucfirst( $slug ) ),
				'type'  => Controls_Manager::HEADING,
			)
		);
		$this->add_control(
			"{$this->name}_popover_switch_{$slug}_default_heading_color",
			array(
				'label'     => __( 'Text Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7E7E83',
				'selectors' => array( $selector_string => 'color: {{VALUE}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => "{$this->name}_popover_switch_{$slug}_default_heading_background_color",
				'types'    => array( 'classic', 'gradient' ),
				'selector' => $selector_string,
			)
		);

		$this->end_popover();

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => "{$this->name}_{$slug}_heading_box_shadow",
				'selector' => $selector_string,
			)
		);
		$this->add_control(
			"{$this->name}_{$slug}_heading_border_radius",
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 16,
				),
				'selectors'  => array( $selector_string => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_responsive_control(
			"{$this->name}_{$slug}_headings_padding",
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit'     => $this->default_size_units[0],
					'top'      => 16,
					'right'    => 24,
					'bottom'   => 16,
					'left'     => 24,
					'isLinked' => true,
				),
				'selectors'  => array(
					$selector_string => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
	}

	// ======================================================
	// PRIVATE - Assistance
	// ======================================================

	/**
	 * Get Elementor Page List
	 *
	 * Returns an array of Elementor templates
	 *
	 * @return array Elementor Templates
	 */
	private function get_elementor_page_list() {
		$page_list = get_posts(
			array(
				'post_type' => 'elementor_library',
				'showposts' => 999,
			)
		);

		// Bail early.
		if ( empty( $page_list ) && is_wp_error( $page_list ) ) {
			return array();
		}

		$options = array();

		foreach ( $page_list as $post ) {
			$options[ $post->post_title ] = $post->post_title;
		}

		update_option( 'temp_count', $options );

		return $options;
	}

	/**
	 * Get Elementor Template HTML Content
	 *
	 * @param string $title Template Title.
	 *
	 * @return string HTML Markup of the selected template.
	 */
	private function get_template_content( $title ) {
		$frontend = Plugin::$instance->frontend;

		return $frontend->get_builder_content_for_display( $this->get_id_by_title( $title ) );
	}

	/**
	 * Get ID By Title
	 *
	 * Get Elementor Template ID by title
	 *
	 * @param string $title template title.
	 *
	 * @return string $template_id template ID.
	 */
	private function get_id_by_title( $title ) {
		$template = get_page_by_title( $title, OBJECT, 'elementor_library' );

		return $template->ID ?? $title;
	}

}
