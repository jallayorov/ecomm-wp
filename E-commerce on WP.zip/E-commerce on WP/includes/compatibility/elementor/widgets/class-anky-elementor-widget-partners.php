<?php
/**
 * Anky Theme Elementor Widget for displaying Partners.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;
use Elementor\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying Partners.
 */
class Anky_Elementor_Widget_Partners extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_partners';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Partners', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-logo';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'anky-widget-partners' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->add_content_layout_settings();
		$this->add_content_settings();

		$this->add_content_style_settings();
		$this->add_additional_description_style_settings();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$content_before = '';
		$content_after  = '</div><!--.anky-row--></div><!--.anky-container--></div><!--. anky-partners-section-->';

		switch ( $settings[ $this->name . '_templates' ] ) {
			case 'template1':
				$content_before .= '<div class="anky-partners-section anky-partners-section-1"><div class="anky-container"><div class="anky-row">';
				break;
			case 'template2':
				$content_before .= '<div class="anky-partners-section anky-partners-section-2"><div class="anky-partners-section-slider"><div class="anky-partners-swiper-container"><div class="anky-swiper-partners-wrapper">';

				$content_after = '</div><!--.anky-swiper-partners-wrapper--></div><!--.anky-partners-swiper-container--></div><!--.anky-partners-section-slider--></div><!--.anky-partners-section-->';
				break;
			case 'template3':
				$content_before .= '<div class="anky-partners-section anky-partners-section-3"><div class="anky-container"><div class="anky-row">';
				break;
			case 'template4':
				$content_before .= '<div class="anky-partners-section anky-partners-section-4"><div class="anky-container"><div class="anky-row">';
				break;
			case 'template5':
				$this->add_inline_editing_attributes( $this->name . '_block_desc', 'advanced' );
				$this->add_render_attribute( $this->name . '_block_desc', 'class', 'anky-faq-description-section' );
				$content_before .= '<div class="anky-container"><div class="anky-row"><div class="anky-col-4">';
				$content_before .= '<div ' . $this->get_render_attribute_string( $this->name . '_block_desc' ) . '>' . wp_kses_post( $this->parse_text_editor( $settings[ $this->name . '_block_desc' ] ) ) . '</div>';
				$content_before .= '</div><div class="anky-col-2 anky-partners-section-5"><div class="anky-partners-section "><div class="anky-row">';

				$content_after = '</div><!--.anky-row--></div><!--.anky-partners-section-5--></div><!--.anky-partners-section--></div><!--.anky-row--></div><!--.anky-container-->';
				break;
		}

		// Output is properly sanitized where it's required.
		echo $content_before; // phpcs:ignore WordPress.Security.EscapeOutput

		foreach ( $settings[ $this->name . '_list' ] as $i => $partner ) {
			$partner_data = ( 'template1' === $settings[ $this->name . '_templates' ] ) ?
				array_merge( $this->prepare_render_loop_data( $partner, $i ), array( 'col' => $settings[ $this->name . '_columns_style' ] ) ) :
				$this->prepare_render_loop_data( $partner, $i );

			anky_load_template(
				'template-parts/elementor/partners/partners',
				$settings[ $this->name . '_templates' ],
				$partner_data
			);
		}

		// Output is properly sanitized where it's required.
		echo $content_after;  // phpcs:ignore WordPress.Security.EscapeOutput
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Add Content Layout settings fields to `Content` tab.
	 */
	private function add_content_layout_settings() {
		$this->start_controls_section(
			$this->name . '_content_layout',
			array(
				'label' => esc_html__( 'Layout', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_templates',
			array(
				'label'       => __( 'Template view', 'anky' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'template1',
				'options'     => array(
					'template1' => __( 'Skin 1', 'anky' ),
					'template2' => __( 'Skin 2', 'anky' ),
					'template3' => __( 'Skin 3', 'anky' ),
					'template4' => __( 'Skin 4', 'anky' ),
					'template5' => __( 'Skin 5', 'anky' ),
				),
				'description' => __( 'NOTE: If you choose Skin 2, please, add at least 4 partner items', 'anky' ),
			)
		);
		// Adding column size only to first skin.
		$this->add_control(
			$this->name . '_columns_style',
			array(
				'label'     => __( 'Column style', 'anky' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 1,
				'options'   => array(
					2 => __( 'Wide', 'anky' ),
					1 => __( 'Narrow', 'anky' ),
				),
				'condition' => array( $this->name . '_templates' => 'template1' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Content settings fields to `Content` tab.
	 */
	private function add_content_settings() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => __( 'Content', 'anky' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();
		$repeater->add_control(
			$this->name . '_partner_title',
			array(
				'label'   => __( 'Title', 'anky' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Partner Title', 'anky' ),
			)
		);
		$repeater->add_control(
			$this->name . '_partner_logo',
			array(
				'label'   => __( 'Logo', 'anky' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);
		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_partner_logo',
				'default'   => 'thumbnail',
				'separator' => 'none',
			)
		);
		$repeater->add_control(
			$this->name . '_partner_link',
			array(
				'label'         => __( 'URL', 'anky' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => 'https://www.example.com/',
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$this->add_control(
			$this->name . '_list',
			array(
				'label'       => __( 'Partners List', 'anky' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'partner_title' => 'IKEA',
					),
					array(
						'partner_title' => 'SPOTIFY',
					),
				),
				'title_field' => '{{{ anky_partners_partner_title }}}',
			)
		);
		$this->add_control(
			$this->name . '_block_desc',
			array(
				'label'     => __( 'Additional section text', 'anky' ),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => __( 'Place your data here', 'anky' ),
				'condition' => array(
					$this->name . '_templates' => array( 'template5' ),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Content Style settings fields to `Style` tab.
	 * Section will we available for `template2` and `template3` only.
	 */
	private function add_content_style_settings() {
		$this->start_controls_section(
			$this->name . '_section_style_partner_name',
			array(
				'label'     => __( 'Partner title', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_templates' => array( 'template2', 'template3' ),
				),
			)
		);

		$this->add_typography_control_style_part( "{$this->name}_name", '.anky-partners-item-title', '' );

		$this->end_controls_section();
	}

	/**
	 * Add Additional Content Style settings fields to `Style` tab.
	 * Section will we available for `template5` only.
	 */
	private function add_additional_description_style_settings() {
		$this->start_controls_section(
			$this->name . '_section_style_block_desc',
			array(
				'label'     => esc_html__( 'Partners description styles', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_templates' => array( 'template5' ),
				),
			)
		);
		$this->add_typography_control_style_part( "{$this->name}_block_desc", '.anky-faq-description-section *', '' );
		$this->end_controls_section();
	}

	/**
	 * Retrieve data for each render loop iteration.
	 *
	 * @param array $loop_item Required. Array of collected data.
	 * @param int   $index     Optional. Current iteration index.
	 *
	 * @return array Data that should be passed to template.
	 */
	private function prepare_render_loop_data( $loop_item, $index = 0 ) {
		$link_setting_key = $this->get_repeater_setting_key( $this->name . '_list_item_original_link', $this->name . '_list', $index );
		$this->add_link_attributes( $link_setting_key, $loop_item[ $this->name . '_partner_link' ], true );
		$this->add_render_attribute( $link_setting_key, 'class', 'anky-partners-section-item-link' );
		if ( ! in_array( 'href', array_keys( $this->get_render_attributes( $link_setting_key ) ), true ) ) {
			$this->add_render_attribute( $link_setting_key, 'href', '#' );
		}

		$loop_item_logo = empty( $loop_item[ $this->name . '_partner_logo' ]['url'] )
			? '<span class="anky-partners-item-title">' . $loop_item[ $this->name . '_partner_title' ] . '</span>'
			: $this->get_media_image_string( $loop_item, $this->name . '_partner_logo', 'anky-partners-section-img' );

		// Replace alt with proper naming.
		$loop_item_logo = preg_replace( '/alt="(.*)"/', 'alt="' . esc_attr( $loop_item[ $this->name . '_partner_title' ] ) . ' logo"', $loop_item_logo );

		return array(
			'title' => $loop_item[ $this->name . '_partner_title' ],
			'link'  => $this->get_render_attribute_string( $link_setting_key ),
			'logo'  => $loop_item_logo,
		);
	}

}
