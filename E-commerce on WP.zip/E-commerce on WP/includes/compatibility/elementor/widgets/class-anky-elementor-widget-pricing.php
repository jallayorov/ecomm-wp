<?php
/**
 * Anky Theme Elementor Widget for Price Block.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Modules\DynamicTags\Module;
use Elementor\Repeater;
use Elementor\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for Price Block.
 */
class Anky_Elementor_Widget_Pricing extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_pricing';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Pricing', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'lottie', 'anky-lottie-init' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		/**
		 * Content.
		 */
		$this->add_display_settings();
		$this->add_header_content_settings();
		$this->add_feature_list_settings();
		$this->add_link_settings();

		/**
		 * Styles
		 */
		$this->add_container_style_controls();
		$this->add_illustrations_style_settings();
		$this->add_content_style_controls();
		$this->add_price_style_controls();
		$this->add_delimiter_style_controls();
		$this->add_feature_list_style_settings();

		$this->add_link_style_settings();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( $this->name . '_title_text' );
		$this->add_render_attribute( $this->name . '_title_text', 'class', 'anky-plan-title' );

		$this->add_inline_editing_attributes( $this->name . '_price_value' );
		$this->add_render_attribute( $this->name . '_price_value', 'class', 'anky-plan-price' );

		$this->add_inline_editing_attributes( $this->name . '_price_duration' );
		$this->add_render_attribute( $this->name . '_price_duration', 'class', 'anky-pricing-duration' );

		$this->add_inline_editing_attributes( $this->name . '_feature_intro_text' );
		$this->add_render_attribute( $this->name . '_feature_intro_text', 'class', 'anky-pricing-features-intro-text' );

		if ( 'custom_url' === $settings[ $this->name . '_button_url_type' ] ) {
			$link_key = $this->name . '_button_link';

			$this->add_link_attributes( $link_key, $settings[ $link_key ] );
			if ( empty( $settings[ $link_key ]['url'] ) ) {
				$this->add_render_attribute( $link_key, 'href', '#' );
			}
		} else {
			$link_key = $this->name . '_button_link_existing_content';
			$this->add_render_attribute( $link_key, 'href', get_permalink( $settings[ $link_key ] ) );
		}
		$this->add_render_attribute( $link_key, 'class', array( 'anky-btn', 'anky-pricing-btn-link' ) );

		$link = sprintf(
			'<a %s>%s</a>',
			$this->get_render_attribute_string( $link_key ),
			$settings[ $this->name . '_button_text' ]
		);

		?>
		<div class="anky-pricing-block anky-pricing-block-<?php echo esc_attr( $settings[ $this->name . '_skin' ] ); ?>">
			<div class="anky-pricing-header">
				<?php
				if ( in_array( $settings[ $this->name . '_skin' ], array( 'skin-4', 'skin-5' ), true ) ) {
					echo '<div class="anky-pricing-text-wrap"><div class="anky-pricing-illustration">';
					if ( 'image' === $settings[ $this->name . '_illustration_type' ] ) {
						$this->render_media_image( $settings, $this->name . '_image', 'anky-pricing-illustration-img' );
					} elseif ( 'animation' === $settings[ $this->name . '_illustration_type' ] ) {
						$this->add_render_attribute(
							$this->name . '_lottie',
							array(
								'class'               => array(
									'anky-pricing-illustration-lottie',
									'anky-lottie-animation',
								),
								'data-lottie-url'     => $settings[ $this->name . '_lottie_url' ],
								'data-lottie-loop'    => $settings[ $this->name . '_lottie_loop' ],
								'data-lottie-reverse' => $settings[ $this->name . '_lottie_reverse' ],
							)
						);
						printf( '<div %s></div>', wp_kses_post( $this->get_render_attribute_string( $this->name . '_lottie' ) ) );
					}
					echo '</div><!--.anky-pricing-illustration--><div class="anky-pricing-info-wrap">';
				}

				echo wp_kses_post( '<h2 ' . $this->get_render_attribute_string( $this->name . '_title_text' ) . '>' . $settings[ $this->name . '_title_text' ] . '</h2>' );

				if ( in_array( $settings[ $this->name . '_skin' ], array( 'skin-3', 'skin-4', 'skin-5' ), true ) ) {
					$this->add_inline_editing_attributes( $this->name . '_description_text' );
					$this->add_render_attribute( $this->name . '_description_text', 'class', array( 'anky-plan-description', 'color-secondary' ) );

					printf(
						'<div %s>%s</div>',
						wp_kses_post( $this->get_render_attribute_string( $this->name . '_description_text' ) ),
						wp_kses_post( $this->parse_text_editor( $settings[ $this->name . '_description_text' ] ) )
					);
				}
				?>
				<div class="anky-pricing-value">
					<span class="anky-pricing-currency"><?php echo esc_html( $settings[ $this->name . '_price_currency' ] ); ?></span>
					<span <?php echo wp_kses_post( $this->get_render_attribute_string( $this->name . '_price_value' ) ); ?>><?php echo esc_html( $settings[ $this->name . '_price_value' ] ); ?></span>
					<span <?php echo wp_kses_post( $this->get_render_attribute_string( $this->name . '_price_duration' ) ); ?>><?php echo esc_html( $settings[ $this->name . '_price_duration' ] ); ?></span>
				</div>

				<?php
				if ( '1' === $settings[ $this->name . '_discount' ] ) :
					$this->add_inline_editing_attributes( $this->name . '_discount_price_value' );
					$this->add_render_attribute( $this->name . '_discount_price_value', 'class', 'anky-pricing-price' );

					$this->add_inline_editing_attributes( $this->name . '_discount_price_text' );
					$this->add_render_attribute( $this->name . '_discount_price_text', 'class', array( 'anky-pricing-discount-group-item', 'anky-pricing-discount-text', 'anky-ai-center' ) );
					?>
					<div class="anky-pricing-discount-group anky-d-flex anky-ai-center">
						<s class="anky-pricing-discount-group-item anky-pricing-discount-old-price anky-d-flex anky-ai-center">
							<span class="anky-pricing-currency"><?php echo esc_html( $settings[ $this->name . '_price_currency' ] ); ?></span>
							<span <?php echo wp_kses_post( $this->get_render_attribute_string( $this->name . '_discount_price_value' ) ); ?>><?php echo esc_html( $settings[ $this->name . '_discount_price_value' ] ); ?></span>
						</s>
						<p <?php echo wp_kses_post( $this->get_render_attribute_string( $this->name . '_discount_price_text' ) ); ?>><?php echo esc_html( $settings[ $this->name . '_discount_price_text' ] ); ?></p>
					</div>
				<?php
				endif;
				if ( in_array( $settings[ $this->name . '_skin' ], array( 'skin-4', 'skin-5' ), true ) ) {
					echo '</div><!--.anky-pricing-info-wrap--></div><!--.anky-pricing-text-wrap-->';
				}
				?>

				<?php echo ( 'skin-2' !== $settings[ $this->name . '_skin' ] ) ? wp_kses_post( $link ) : ''; ?>

			</div>
			<?php
			echo in_array( $settings[ $this->name . '_skin' ], array( 'skin-2', 'skin-3' ), true ) ? '<hr class="anky-pricing-delimiter">' : '';

			// Create a space between blocks.
			if ( 'skin-4' === $settings[ $this->name . '_skin' ] ) {
				echo '</div><div class="anky-pricing-block anky-pricing-block-' . esc_attr( $settings[ $this->name . '_skin' ] ) . ' anky-pricing-block-body">';
			}

			if ( 'skin-5' !== $settings[ $this->name . '_skin' ] ) :
				?>
				<div class="anky-pricing-body">
					<?php echo wp_kses_post( '<p ' . $this->get_render_attribute_string( $this->name . '_feature_intro_text' ) . '>' . $settings[ $this->name . '_feature_intro_text' ] . '</p>' ); ?>
					<ul class="anky-list-unstyled anky-features-list">
						<?php
						foreach ( $settings[ $this->name . '_feature_list' ] as $i => $item ) :
							echo '<li class="anky-features-list-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">';
							if ( 'icon' === $item[ $this->name . '_list_item_icon_type' ] ) :
								$icon_new = empty( $item[ $this->name . '_list_item_icon' ] ) && Icons_Manager::is_migration_allowed();
								$icon_migrated = isset( $item['__fa4_migrated'][ $this->name . '_list_item_icon_updated' ] );

								if ( $icon_new || $icon_migrated ) :
									Icons_Manager::render_icon(
										$item[ $this->name . '_list_item_icon_updated' ],
										array(
											'class'       => 'anky-features-list-item-icon',
											'aria-hidden' => 'true',
										),
										'span'
									);
								else :
									?>
									<span class="anky-features-list-item-icon <?php echo esc_attr( $item[ $this->name . '_list_item_icon' ] ); ?>" aria-hidden="true"></span>
								<?php
								endif; // is_new|migrated.

							elseif ( 'animation' === $item[ $this->name . '_list_item_icon_type' ] ) :
								$lottie_key = $this->name . '_list_item_lottie' . $i;
								$this->add_render_attribute(
									$lottie_key,
									array(
										'class'               => array( 'anky-features-list-item-icon', 'anky-lottie-animation' ),
										'data-lottie-url'     => $item[ $this->name . '_list_item_lottie_url' ],
										'data-lottie-loop'    => $item[ $this->name . '_list_item_lottie_loop' ],
										'data-lottie-reverse' => $item[ $this->name . '_list_item_lottie_reverse' ],
									)
								);
								?>
								<div <?php echo wp_kses_post( $this->get_render_attribute_string( $lottie_key ) ); ?>></div>
							<?php endif; ?>
							<span class="anky-features-list-item-text"><?php echo esc_html( $item[ $this->name . '_list_item_text' ] ); ?></span>
							<?php
							echo '</li>';
						endforeach;
						?>
					</ul>

					<?php echo ( 'skin-2' === $settings[ $this->name . '_skin' ] ) ? wp_kses_post( $link ) : ''; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ======================================================
	// PRIVATE - Content settings
	// ======================================================

	/**
	 * Add display settings for content tab.
	 */
	private function add_display_settings() {
		$this->start_controls_section(
			$this->name . '_general_settings',
			array(
				'label' => __( 'Display Settings', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_skin',
			array(
				'label'   => __( 'Skin', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'skin-1',
				'options' => array(
					'skin-1' => esc_html__( 'Skin 1', 'anky' ),
					'skin-2' => esc_html__( 'Skin 2', 'anky' ),
					'skin-3' => esc_html__( 'Skin 3', 'anky' ),
					'skin-4' => esc_html__( 'Skin 4', 'anky' ),
					'skin-5' => esc_html__( 'Skin 5', 'anky' ),
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Content settings for Content tab.
	 * Content contains settings for `Title`, `Description`, `Price`, `Illustration` parts.
	 */
	private function add_header_content_settings() {
		$this->start_controls_section(
			$this->name . '_header_section',
			array(
				'label' => __( 'Content', 'anky' ),
			)
		);

		$this->start_controls_tabs( $this->name . '_header_content_section_tabs' );

		// Title and description tab.
		$this->start_controls_tab(
			$this->name . '_header_content_title_tab',
			array(
				'label' => __( 'Title', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_title_text',
			array(
				'label'       => __( 'Text', 'anky' ),
				'default'     => __( 'Plan type', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
			)
		);
		$this->add_control(
			$this->name . '_description_text',
			array(
				'label'   => __( 'Description', 'anky' ),
				'type'    => Controls_Manager::WYSIWYG,
				'dynamic' => array( 'active' => true ),
				'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
			)
		);
		$this->end_controls_tab();

		// Price tab.
		$this->start_controls_tab(
			$this->name . '_header_content_price_tab',
			array(
				'label' => __( 'Price', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_discount',
			array(
				'label'        => __( 'Discount', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'return_value' => '1',
			)
		);
		$this->add_control(
			$this->name . '_discount_price_value',
			array(
				'label'       => __( 'Initial Price', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'description' => __( 'This price will be displayed crossed out', 'anky' ),
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
				'condition'   => array( $this->name . '_discount' => '1' ),
			)
		);
		$this->add_control(
			$this->name . '_discount_price_text',
			array(
				'label'       => __( 'Discount Text', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
				'condition'   => array( $this->name . '_discount' => '1' ),
			)
		);
		$this->add_control(
			$this->name . '_price_currency',
			array(
				'label'       => __( 'Currency', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'default'     => '$',
				'label_block' => true,
			)
		);
		$this->add_control(
			$this->name . '_price_value',
			array(
				'label'       => __( 'Price', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'default'     => '25',
				'label_block' => true,
			)
		);
		$this->add_control(
			$this->name . '_price_duration',
			array(
				'label'       => __( 'Duration', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'default'     => __( 'per month', 'anky' ),
				'label_block' => true,
			)
		);
		$this->end_controls_tab();

		// Illustration tab.
		$this->start_controls_tab(
			$this->name . '_header_content_image_tab',
			array(
				'label'     => __( 'Illustration', 'anky' ),
				'condition' => array(
					$this->name . '_skin' => array( 'skin-4', 'skin-5' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_illustration_type',
			array(
				'label'   => __( 'Illustration Type', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'animation' => __( 'Lottie Animation', 'anky' ),
					'image'     => __( 'Image', 'anky' ),
				),
				'default' => 'image',
			)
		);
		$this->add_control(
			$this->name . '_image',
			array(
				'label'     => __( 'Choose Image', 'anky' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array( 'url' => Utils::get_placeholder_image_src() ),
				'condition' => array( $this->name . '_illustration_type' => 'image' ),
			)
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_image',
				'default'   => 'thumbnail',
				'separator' => 'none',
			)
		);
		$this->add_control(
			$this->name . '_lottie_url',
			array(
				'label'       => __( 'Animation JSON URL', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'description' => sprintf(
				/* translators: 1: Opening link tag, 2: Closing link tag*/
					__( 'Paste JSON URL code from %1$s official website %2$s', 'anky' ),
					'<a href="https://lottiefiles.com/" target="_blank">',
					'</a>'
				),
				'label_block' => true,
				'condition'   => array( $this->name . '_illustration_type' => 'animation' ),
			)
		);
		$this->add_control(
			$this->name . '_lottie_loop',
			array(
				'label'        => __( 'Loop', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'default'      => 'true',
				'condition'    => array( $this->name . '_illustration_type' => 'animation' ),
			)
		);
		$this->add_control(
			$this->name . '_lottie_reverse',
			array(
				'label'        => __( 'Reverse', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'condition'    => array( $this->name . '_illustration_type' => 'animation' ),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Add feature list repeater controls.
	 */
	private function add_feature_list_settings() {
		$this->start_controls_section(
			$this->name . '_list_section',
			array(
				'label'     => __( 'Feature List', 'anky' ),
				'condition' => array(
					$this->name . '_skin!' => 'skin-5',
				),
			)
		);

		$this->add_control(
			$this->name . '_feature_intro_text',
			array(
				'label'       => __( 'Text', 'anky' ),
				'default'     => __( 'Plan includes:', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
			)
		);

		$repeater = new REPEATER();
		$repeater->add_control(
			$this->name . '_list_item_text',
			array(
				'label'       => __( 'Text', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Feature Title', 'anky' ),
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_icon_type',
			array(
				'label'   => __( 'Icon Type', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'icon'      => __( 'Icon', 'anky' ),
					'animation' => __( 'Lottie Animation', 'anky' ),
				),
				'default' => 'icon',
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_icon_updated',
			array(
				'label'            => __( 'Icon', 'anky' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => $this->name . '_list_item_icon',
				'default'          => array(
					'value'   => 'fas fa-check',
					'library' => 'fa-solid',
				),
				'condition'        => array( $this->name . '_list_item_icon_type' => 'icon' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_lottie_url',
			array(
				'label'       => __( 'Animation JSON URL', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'description' => sprintf(
				/* translators: 1: Opening link tag, 2: Closing link tag*/
					__( 'Paste JSON URL code from %1$s official website %2$s', 'anky' ),
					'<a href="https://lottiefiles.com/" target="_blank">',
					'</a>'
				),
				'label_block' => true,
				'condition'   => array( $this->name . '_list_item_icon_type' => 'animation' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_lottie_loop',
			array(
				'label'        => __( 'Loop', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'default'      => 'true',
				'condition'    => array( $this->name . '_list_item_icon_type' => 'animation' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_lottie_reverse',
			array(
				'label'        => __( 'Reverse', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'condition'    => array( $this->name . '_list_item_icon_type' => 'animation' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_icon_color',
			array(
				'label'     => __( 'Icon Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array( $this->name . '_list_item_icon_type' => 'icon' ),
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .anky-features-list-item-icon'    => 'color: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}}.anky-features-list-item svg path' => 'fill: {{VALUE}};',
				),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_text_color',
			array(
				'label'     => __( 'Text Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .anky-features-list-item-text' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_feature_list',
			array(
				'label'   => __( 'Price plan features', 'anky' ),
				'type'    => Controls_Manager::REPEATER,
				'default' => array(
					array(
						$this->name . '_list_item_icon_updated' => array(
							'value'   => 'fas fa-check',
							'library' => 'fa-solid',
						),
						$this->name . '_list_item_text'         => __( 'Access to all modules', 'anky' ),
					),
					array(
						$this->name . '_list_item_icon_updated' => array(
							'value'   => 'fas fa-check',
							'library' => 'fa-solid',
						),
						$this->name . '_list_item_text'         => __( 'Build first screen free', 'anky' ),
					),
					array(
						$this->name . '_list_item_icon_updated' => array(
							'value'   => 'fas fa-check',
							'library' => 'fa-solid',
						),
						$this->name . '_list_item_text'         => __( 'Free membership', 'anky' ),
					),
				),
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ elementor.helpers.renderIcon( this, anky_pricing_list_item_icon_updated, {}, "i", "panel" ) || \'<i class="{{ anky_pricing_list_item_icon }}" aria-hidden="true"></i>\' }}} {{{ anky_pricing_list_item_text }}}',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add link button settings.
	 */
	private function add_link_settings() {
		$this->start_controls_section(
			$this->name . '_button_section',
			array(
				'label' => __( 'Link', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_button_text',
			array(
				'label'       => __( 'Text', 'anky' ),
				'default'     => __( 'Get Started', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
			)
		);
		$this->add_control(
			$this->name . '_button_url_type',
			array(
				'label'       => __( 'Link Type', 'anky' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'custom_url'   => __( 'Custom URL', 'anky' ),
					'internal_url' => __( 'Existing Page', 'anky' ),
				),
				'default'     => 'custom_url',
				'label_block' => true,
			)
		);
		$this->add_control(
			$this->name . '_button_link',
			array(
				'label'       => __( 'Link', 'anky' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => array(
					'active'     => true,
					'categories' => array(
						Module::POST_META_CATEGORY,
						Module::URL_CATEGORY,
					),
				),
				'condition'   => array( $this->name . '_button_url_type' => 'custom_url' ),
				'label_block' => true,
			)
		);
		$this->add_control(
			$this->name . '_button_link_existing_content',
			array(
				'label'       => __( 'Existing Page', 'anky' ),
				'type'        => Controls_Manager::SELECT2,
				'options'     => $this->get_all_posts(),
				'multiple'    => false,
				'label_block' => true,
				'condition'   => array( $this->name . '_button_url_type' => 'internal_url' ),
			)
		);

		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Style
	// ======================================================

	/**
	 * Add Container Wrapper Specific style controls.
	 */
	private function add_container_style_controls() {
		$this->start_controls_section(
			$this->name . '_container_style_settings',
			array(
				'label' => __( 'Container', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 1120,
					),
					'%'  => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors'  => array( '{{WRAPPER}} .anky-pricing-block' => 'width: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_container_border',
				'selector' => '{{WRAPPER}} .anky-pricing-block',
			)
		);
		$this->add_control(
			$this->name . '_container_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-block' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => $this->name . '_container_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .anky-pricing-block',
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'label'    => __( 'Shadow', 'anky' ),
				'name'     => $this->name . '_container_container_shadow',
				'selector' => '{{WRAPPER}} .anky-pricing-block',
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'    => 40,
					'right'  => 40,
					'bottom' => 40,
					'left'   => 40,
					'unit'   => $this->default_size_units[0],
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-block' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 8,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-block' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Illustration style controls.
	 *
	 * Controls will be visible only on `Skin-4` and `Skin-5`.
	 */
	private function add_illustrations_style_settings() {
		$this->start_controls_section(
			$this->name . '_icon_style_settings',
			array(
				'label'     => __( 'Illustration', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_skin' => array( 'skin-4', 'skin-5' ),
				),
			)
		);

		$this->add_responsive_control(
			$this->name . '_illustration_size',
			array(
				'label'      => __( 'Size', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 250,
					),
					'%'  => array(
						'min' => 0,
						'max' => 200,
					),
					'em' => array(
						'min' => 0,
						'max' => 18,
					),
				),
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 200,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-illustration svg, {{WRAPPER}} .anky-pricing-illustration img' => 'width: {{SIZE}}{{UNIT}} !important; height: {{SIZE}}{{UNIT}} !important',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_illustration_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-illustration' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Content Specific style controls.
	 *
	 * Contain controls for Title and Description blocks.
	 */
	private function add_content_style_controls() {
		$this->start_controls_section(
			$this->name . '_content_style_settings',
			array(
				'label' => __( 'Content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( $this->name . '_content_style_tabs' );

		/**
		 * Title.
		 */
		$this->start_controls_tab(
			$this->name . '_content_style_title',
			array(
				'label' => __( 'Title', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_content_title_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-plan-title' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_content_title_typography',
				'selector'       => '{{WRAPPER}} .anky-plan-title',
				'fields_options' => $this->default_small_heading_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_title_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-plan-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_title_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 16,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-plan-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_tab();

		/**
		 * Content.
		 */
		$this->start_controls_tab(
			$this->name . '_content_style_content',
			array(
				'label'     => __( 'Content', 'anky' ),
				'condition' => array(
					$this->name . '_skin' => array( 'skin-3', 'skin-4', 'skin-5' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_content_content_text_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7E7E83',
				'selectors' => array(
					'{{WRAPPER}} .anky-plan-description' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_content_content_text_typography',
				'selector'       => '{{WRAPPER}} .anky-plan-description',
				'fields_options' => $this->default_paragraph_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_content_text_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-plan-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_content_text_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 24,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-plan-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Add Price Specific style controls.
	 *
	 * Contain controls For:
	 * - Price Currency
	 * - Main Price
	 * - Price Duration
	 * - Discount Price (If enabled)
	 * - Discount Text (If enabled)
	 */
	private function add_price_style_controls() {
		$this->start_controls_section(
			$this->name . '_price_style_settings',
			array(
				'label' => __( 'Price', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * PRICE.
		 */
		$this->start_controls_tabs( $this->name . '_price_style_tabs' );

		/**
		 * Currency.
		 */
		$this->start_controls_tab(
			$this->name . '_content_style_price',
			array(
				'label' => __( 'Currency', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_currency_text_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-currency' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_currency_text_typography',
				'selector'       => '{{WRAPPER}} .anky-pricing-currency',
				'fields_options' => $this->default_heading_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_currency_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-currency' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_currency_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-currency' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		/**
		 * Main Price
		 */
		$this->start_controls_tab(
			$this->name . '_price_heading',
			array(
				'label' => __( 'Main', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_main_price_text_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-plan-price' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_main_price_text_typography',
				'selector'       => '{{WRAPPER}} .anky-plan-price',
				'fields_options' => $this->default_heading_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_price_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-plan-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_price_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 12,
					'bottom'   => 0,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-plan-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		/**
		 * Duration.
		 */
		$this->start_controls_tab(
			$this->name . '_dur_heading',
			array(
				'label' => __( 'Duration', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_duration_text_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7E7E83',
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-duration' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_duration_text_typography',
				'selector'       => '{{WRAPPER}} .anky-pricing-duration',
				'fields_options' => $this->default_paragraph_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_duration_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-duration' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_duration_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-duration' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		/**
		 * DISCOUNT.
		 */
		$this->start_controls_tabs(
			$this->name . '_discount_price_style_tabs',
			array(
				'condition' => array( $this->name . '_discount' => '1' ),
				'separator' => 'before',
			)
		);

		/**
		 * Discount Price.
		 */
		$this->start_controls_tab(
			$this->name . '_discount_style_value',
			array(
				'label' => __( 'Discount value', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_old_price_value_text_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#AEAEB2',
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-discount-old-price .anky-pricing-price, {{WRAPPER}} .anky-pricing-discount-old-price .anky-pricing-currency' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_old_price_value_text_typography',
				'selector'       => '{{WRAPPER}} .anky-pricing-discount-old-price .anky-pricing-price, {{WRAPPER}} .anky-pricing-discount-old-price .anky-pricing-currency',
				'fields_options' => $this->default_paragraph_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_old_price_value_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-discount-old-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_old_price_value_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 12,
					'bottom'   => 0,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-discount-old-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		/**
		 * Discount Text.
		 */
		$this->start_controls_tab(
			$this->name . '_discount_style_text',
			array(
				'label' => __( 'Discount value', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_old_price_content_text_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#CD1638',
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-discount-text' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_old_price_content_text_typography',
				'selector'       => '{{WRAPPER}} .anky-pricing-discount-text',
				'fields_options' => $this->default_paragraph_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_old_text_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-discount-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_main_old_text_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-discount-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Add Delimiter Specific style controls.
	 *
	 * Controls are available for `Skin-2` and `Skin-3` only.
	 */
	private function add_delimiter_style_controls() {
		$this->start_controls_section(
			$this->name . '_feature_list_delimiter_style_settings',
			array(
				'label'     => __( 'Delimiter', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( $this->name . '_skin' => array( 'skin-2', 'skin-3' ) ),
			)
		);
		$this->add_control(
			$this->name . '_feature_list_delimiter_height',
			array(
				'label'     => __( 'Height', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 1,
						'max' => 10,
					),
				),
				'default'   => array(
					'units' => 'px',
					'size'  => 1,
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-delimiter' => 'height: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_feature_list_delimiter_spacing',
			array(
				'label'     => __( 'Spacing', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'unit' => 'px',
					'size' => 8,
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-delimiter' => 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_feature_list_delimiter_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-delimiter' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'           => $this->name . '_feature_list_delimiter_background',
				'types'          => array( 'classic', 'gradient' ),
				'fields_options' => array(
					'background' => array(
						'default' => 'classic',
					),
					'color'      => array(
						'default' => '#e0e0e0',
					),
				),
				'selector'       => '{{WRAPPER}} .anky-pricing-delimiter',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Feature List Items styler controls.
	 */
	private function add_feature_list_style_settings() {
		$this->start_controls_section(
			$this->name . '_feature_list_style_settings',
			array(
				'label'     => __( 'Features', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_skin!' => 'skin-5',
				),
			)
		);
		$this->start_controls_tabs( $this->name . '_feature_list_style_tabs' );

		$this->start_controls_tab(
			$this->name . '_features_intro_text_tab',
			array(
				'label' => __( 'Intro', 'anky' ),
			)
		);

		$this->add_typography_control_style_part( 'intro_text', '.anky-pricing-features-intro-text' );
		$this->add_responsive_control(
			$this->name . '_intro_text_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-features-intro-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_text_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-features-intro-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_features_text_tab',
			array(
				'label' => __( 'Text', 'anky' ),
			)
		);

		$this->add_typography_control_style_part( 'list_text', '.anky-features-list-item-text' );
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_features_icon_tab',
			array(
				'label' => __( 'Icon', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_list_icon_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#CD1638',
				'selectors' => array(
					'{{WRAPPER}} .anky-features-list-item-icon'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .anky-features-list-item svg path' => 'fill: {{VALUE}};',
				),
			)
		);
		$icon_margin_side = is_rtl() ? 'left' : 'right';
		$this->add_responsive_control(
			$this->name . '_feature_list_icon_spacing',
			array(
				'label'     => __( 'Spacing', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'size' => 10,
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-features-list-item svg, {{WRAPPER}} .anky-features-list-item-icon' => 'margin-' . $icon_margin_side . ': {{SIZE}}px',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_feature_list_icon_size',
			array(
				'label'     => __( 'Size', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'unit' => 'px',
					'size' => 16,
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-features-list-item-icon'                                                   => 'font-size: {{SIZE}}px',
					'{{WRAPPER}} .anky-features-list-item svg, {{WRAPPER}} .anky-features-list-item-icon svg' => 'min-width: {{SIZE}}px !important; height: {{SIZE}}px !important',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			$this->name . '_feature_list_item_common',
			array(
				'label'     => __( 'Other', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_feature_list_item_margin',
			array(
				'label'     => __( 'Items Vertical Spacing', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'unit' => 'px',
					'size' => 24,
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-features-list .anky-features-list-item:not(:last-child)' => 'margin-bottom: {{SIZE}}px;',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-body' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Button Link style controls.
	 */
	private function add_link_style_settings() {
		$this->start_controls_section(
			$this->name . '_button_style_settings',
			array(
				'label' => __( 'Link', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_button_typography',
				'selector'       => '{{WRAPPER}} .anky-pricing-btn-link',
				'fields_options' => $this->default_paragraph_typography,
				'separator'      => 'after',
			)
		);
		$this->add_responsive_control(
			$this->name . '_button_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => '%',
					'size' => 100,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-btn-link' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs( $this->name . '_button_style_tabs' );

		/**
		 * Normal state.
		 */
		$this->start_controls_tab(
			$this->name . '_button_style_normal',
			array(
				'label' => __( 'Normal', 'anky' ),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_button_border',
				'selector' => '{{WRAPPER}} .anky-pricing-btn-link',
			)
		);
		$this->add_control(
			$this->name . '_button_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 16,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-btn-link' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_button_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-btn-link' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'           => $this->name . '_button_background',
				'types'          => array( 'classic', 'gradient' ),
				'fields_options' => array(
					'background' => array(
						'default' => 'classic',
					),
					'color'      => array(
						'default' => '#F5F5F5',
					),
				),
				'selector'       => '{{WRAPPER}} .anky-pricing-btn-link',
			)
		);
		$this->end_controls_tab();

		/**
		 * Hover state.
		 */
		$this->start_controls_tab(
			$this->name . '_button_style_hover',
			array(
				'label' => __( 'Hover', 'anky' ),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_button_hover_border',
				'selector' => '{{WRAPPER}} .anky-pricing-btn-link:hover',
			)
		);
		$this->add_control(
			$this->name . '_button_hover_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-btn-link:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_button_hover_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#FFF',
				'selectors' => array(
					'{{WRAPPER}} .anky-pricing-btn-link:hover' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'           => $this->name . '_button_hover_background',
				'types'          => array( 'classic', 'gradient' ),
				'fields_options' => array(
					'background' => array(
						'default' => 'classic',
					),
					'color'      => array(
						'default' => '#16161A',
					),
				),
				'selector'       => '{{WRAPPER}} .anky-pricing-btn-link:hover',
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			$this->name . '_button_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'    => 16,
					'right'  => 32,
					'bottom' => 16,
					'left'   => 32,
					'unit'   => $this->default_size_units[0],
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-btn-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_button_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'    => 8,
					'right'  => 0,
					'bottom' => 40,
					'left'   => 0,
					'unit'   => $this->default_size_units[0],
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-pricing-btn-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Assistive
	// ======================================================

	/**
	 * Get All Posts
	 *
	 * @return array posts/pages query
	 */
	private function get_all_posts() {
		$all_posts = get_posts(
			array(
				'posts_per_page' => - 1,
				'post_type'      => array( 'page', 'post' ),
			)
		);
		$posts     = array();
		if ( ! empty( $all_posts ) && ! is_wp_error( $all_posts ) ) {
			foreach ( $all_posts as $post ) {
				$posts[ $post->ID ] = strlen( $post->post_title ) > 20 ? substr( $post->post_title, 0, 20 ) . '...' : $post->post_title;
			}
		}

		return $posts;
	}

}
