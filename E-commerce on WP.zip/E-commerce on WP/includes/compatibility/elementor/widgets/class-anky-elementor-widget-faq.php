<?php
/**
 * Anky Theme Elementor Widget for displaying FAQ block section.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying contacts.
 */
class Anky_Elementor_Widget_FAQ extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_faq';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'FAQ', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-accordion';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'anky-widget-faq' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		/**
		 * Content.
		 */
		$this->add_content_settings();
		$this->add_intro_section_content_settings();
		/**
		 * Style.
		 */
		$this->add_item_container_style_settings();
		$this->add_content_style_settings();
		$this->add_intro_section_style_settings();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$content_before   = '';
		$content_after    = '';
		$faq_list         = $settings[ $this->name . '_list' ];
		$has_contact_form = ! empty( $settings[ $this->name . '_form_id' ] );

		$content_before .= '<section class="anky-faq-accordion-section anky-faq-accordion-section-' . esc_attr( $settings[ $this->name . '_skin' ] ) . '">';
		switch ( $settings[ $this->name . '_skin' ] ) {
			case 'template1':
			case 'template3':
				$content_before .= '<div class="anky-container"><div class="anky-faq-accordion anky-faq-accordion-' . esc_attr( $settings[ $this->name . '_skin' ] ) . '">';
			$content_after      .= '</div><!--.anky-container--></div><!--.anky-faq-accordion-->';
			break;
			case 'template2':
				$content_before .= '<div class="anky-container"><div class="anky-row"><div class="anky-col-3">';
				$content_before .= '<h2 class="anky-faq-page-header">' . esc_html( $settings[ $this->name . '_intro_title' ] ) . '</h2>';
				$content_before .= '<p class="anky-faq-page-description color-secondary">' . esc_html( $settings[ $this->name . '_intro_text' ] ) . '</p>';
				$content_before .= ( $has_contact_form && ! empty( $settings[ $this->name . '_btn_label' ] ) ) ? '<button type="button" class="anky-btn anky-btn-outlined anky-js-switch anky-form-show-btn">' . esc_html( $settings[ $this->name . '_btn_label' ] ) . '</button>' : '';
				$content_before .= '</div><!--.anky-col-3--><div class="anky-col-3 anky-faq-items"><div class="anky-faq-accordion anky-faq-accordion-' . esc_attr( $settings[ $this->name . '_skin' ] ) . '">';

				$content_after .= '</div><!--.anky-faq-accordion -->';
				$content_after .= $has_contact_form ?
					do_shortcode(
						'<div class="anky-contact-form-wrapper anky-form-skin-1">[contact-form-7 id="' . $settings[ $this->name . '_form_id' ] .
						'"]<button type="button" class="anky-btn anky-btn-outlined anky-btn-full-w anky-js-switch">' . esc_html__( 'Cancel', 'anky' ) . '</button></div>'
					) : '';
				$content_after .= '</div><!--.anky-faq-items--></div><!--.anky-row--></div><!--.anky-container-->';

				break;
			case 'template4':
				$content_before .= '<div class="anky-container"><div class="anky-row">';
				$content_after  .= '</div><!--.anky-container--></div><!--.anky-faq-accordion-->';

				break;
			case 'template5':
				$content_before .= '<div class="anky-container"><div class="anky-row"><div class="anky-col-2 anky-sticky-scrollspy-parent"><div class="anky-sticky-scrollspy">';

				$faq_list   = array();
				$group_list = array();
				foreach ( $settings[ $this->name . '_list' ] as $item ) {
					$group_type                                = empty( $item[ $this->name . '_group_name' ] ) ? __( 'Untitled', 'anky' ) : $item[ $this->name . '_group_name' ];
					$faq_list[ sanitize_key( $group_type ) ][] = $item;
					$group_list[]                              = $group_type;
				}
				$content_before .= '<ul class="anky-list-unstyled">';
				foreach ( array_unique( $group_list ) as $list_item ) {
					$content_before .= sprintf( '<li><a href="#%s">%s</a></li>', sanitize_key( $this->name . '_group_' . $list_item ), esc_html( $list_item ) );
				}
				$content_before .= '</ul>';
				$content_before .= '</div><!--.anky-sticky-scrollspy--></div><!--.anky-sticky-scrollspy-parent--><div class="anky-col-4">';

				$content_after .= '</div><!--.anky-col-4--></div><!--.anky-row--></div><!--.anky-container-->';

				break;
		}
		$content_after .= '</section>';
		echo $content_before; // phpcs:ignore WordPress.Security.EscapeOutput

		foreach ( $faq_list as $key => $item ) {
			if ( 'string' === gettype( $key ) ) {
				$id = $this->name . '_group_' . $key;
				echo '<div class="anky-faq-section" id="' . sanitize_key( $id ) . '">';
				echo '<h5 class="anky-faq-section-title">' . esc_html( ucfirst( $key ) ) . '</h5>';
				echo '<div class="anky-faq-accordion anky-faq-accordion-' . esc_attr( $settings[ $this->name . '_skin' ] ) . '">';
				foreach ( $item as $group_item ) {
					anky_load_template(
						'template-parts/elementor/faq/faq',
						$settings[ $this->name . '_skin' ],
						array(
							'title'   => $group_item[ $this->name . '_title' ],
							'content' => $this->parse_text_editor( $group_item[ $this->name . '_content' ] ),
							'id'      => $group_item['_id'],
						)
					);
				}
				echo '</div><!--.anky-faq-accordion-type-5--></div><!--#' . sanitize_key( $id ) . '-->';
			} else {
				anky_load_template(
					'template-parts/elementor/faq/faq',
					$settings[ $this->name . '_skin' ],
					array(
						'title'   => $item[ $this->name . '_title' ],
						'content' => $this->parse_text_editor( $item[ $this->name . '_content' ] ),
						'id'      => $item['_id'],
					)
				);
			}
		}

		echo $content_after; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	// ======================================================
	// PRIVATE - Content settings
	// ======================================================

	/**
	 * Add Content settings fields to `Content` tab.
	 */
	private function add_content_settings() {
		$this->start_controls_section(
			$this->name . '_content_section',
			array( 'label' => __( 'Content', 'anky' ) )
		);

		$this->add_control(
			$this->name . '_skin',
			array(
				'label'   => __( 'Skin', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'template1',
				'options' => array(
					'template1' => __( 'Skin 1', 'anky' ),
					'template2' => __( 'Skin 2', 'anky' ),
					'template3' => __( 'Skin 3', 'anky' ),
					'template4' => __( 'Skin 4', 'anky' ),
					'template5' => __( 'Skin 5', 'anky' ),
				),
			)
		);

		$repeater = new Repeater();
		// Content.
		$repeater->add_control(
			$this->name . '_title',
			array(
				'label'     => __( 'FAQ Question', 'anky' ),
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => __( 'FAQ Question', 'anky' ),
				'separator' => 'after',
				'rows'      => 4,
			)
		);
		$repeater->add_control(
			$this->name . '_content',
			array(
				'label'   => __( 'FAQ Answer', 'anky' ),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => '<p>Some unique content here</p>',
			)
		);
		$repeater->add_control(
			$this->name . '_group_heading',
			array(
				'label'     => __( 'FAQ Group', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);
		// Group.
		$repeater->add_control(
			$this->name . '_group_heading_description',
			array(
				'label' => __( 'NOTE: Will work only in Skin 5', 'anky' ),
				'type'  => Controls_Manager::HEADING,
			)
		);
		$repeater->add_control(
			$this->name . '_group_name',
			array(
				'label'       => __( 'FAQ group name', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'description' => __( 'FAQ can be grouped by different titles. If the field will be empty the item goes to `Untitled` group', 'anky' ),
				'default'     => 'Untitled',
			)
		);

		$this->add_control(
			$this->name . '_list',
			array(
				'label'       => __( 'FAQ List Group', 'anky' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						$this->name . '_title'   => 'How do I switch to a different plan?',
						$this->name . '_content' => '<p>You can switch to a new plan at any time by going to the Billing page in your account. Select the plan you’d like to switch to and immediately start using new features.</p>',
					),
					array(
						$this->name . '_title'   => 'I’m bad at learning new software, will someone help me?',
						$this->name . '_content' => '<p>Absolutely! You can get actionable feedback and help with anky Experts. Schedule a one-on-one consultation with our experienced team members to make the most of your portfolio. anky Experts can help you build and optimize a new website or review and make recommendations for your current site - advising on curation, themes and design, SEO, gallery and custom page creation, setting up and selling with your online store, and much more.</p>',
					),
				),
				'title_field' => '{{{ anky_faq_title }}}',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Additional Intro Content settings fields to `Content` tab.
	 * Control section Will only be displayed on `Template2` view.
	 * It will allow to set title text, button label text and select contact form.
	 */
	private function add_intro_section_content_settings() {
		$this->start_controls_section(
			$this->name . '_intro_content_section',
			array(
				'label'     => __( 'Intro Content', 'anky' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => array( $this->name . '_skin' => array( 'template2' ) ),
			)
		);

		$this->add_control(
			$this->name . '_intro_title',
			array(
				'label'   => __( 'Title', 'anky' ),
				'type'    => Controls_Manager::TEXT,
				'default' => 'FAQ',
			)
		);
		$this->add_control(
			$this->name . '_intro_text',
			array(
				'label'   => __( 'Text', 'anky' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( 'All your frequently asked questions about anky — Wordpress Theme', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_btn_label',
			array(
				'label'       => __( 'FAQ button label', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Ask Your Question',
				'description' => __( 'NOTE: If the field will be left blank, the button will not be displayed', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_form_id',
			array(
				'label'       => __( 'Add Contact Form', 'anky' ),
				'type'        => Controls_Manager::SELECT,
				'description' => __( 'NOTE: If the field will be left blank, the button will not be displayed', 'anky' ),
				'options'     => anky_get_contact_forms_list(),
			)
		);

		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Style settings
	// ======================================================

	/**
	 * Add item container Style settings fields to `Style` tab.
	 */
	private function add_item_container_style_settings() {
		$this->start_controls_section(
			$this->name . '_container_style_section',
			array(
				'label' => esc_html__( 'Item container', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_container_border',
				'selector' => '{{WRAPPER}} .anky-faq-accordion-item',
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-accordion-item' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => $this->name . '_container_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .anky-faq-accordion-item',
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'    => 20,
					'right'  => 20,
					'bottom' => 20,
					'left'   => 20,
					'unit'   => $this->default_size_units[0],
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-accordion-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-accordion-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Content Style settings fields to `Style` tab.
	 */
	private function add_content_style_settings() {
		$this->start_controls_section(
			$this->name . '_content_style_section',
			array(
				'label' => esc_html__( 'Content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( $this->name . '_content_style_section_tab' );

		// Question.
		$this->start_controls_tab(
			$this->name . '_content_title_tab',
			array(
				'label' => __( 'Title', 'anky' ),
			)
		);

		$this->add_typography_control_style_part( "{$this->name}_content_title", '.anky-faq-question-title', '#16161A', $this->default_small_heading_typography );

		$this->add_responsive_control(
			$this->name . '_content_title_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-question-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_title_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-question-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		// Answer.
		$this->start_controls_tab(
			$this->name . '_content_text_tab',
			array(
				'label' => __( 'Content', 'anky' ),
			)
		);
		$this->add_typography_control_style_part( "{$this->name}_content_text", '.anky-faq-accordion-content *', '#7E7E83', $this->default_link_typography );

		$this->add_responsive_control(
			$this->name . '_content_text_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-accordion-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		// Link.
		$this->start_controls_tab(
			$this->name . '_content_link_tab',
			array(
				'label' => __( 'Link', 'anky' ),
			)
		);
		$this->add_control(
			"{$this->name}_content_link_color",
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#CD1638',
				'selectors' => array(
					'{{WRAPPER}} .anky-faq-accordion-content a'        => 'color: {{VALUE}};',
					'{{WRAPPER}} .anky-faq-accordion-content a:before' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => "{$this->name}_content_link_typography",
				'selector'       => '{{WRAPPER}} .anky-faq-accordion-content a',
				'fields_options' => $this->default_paragraph_typography,
			)
		);

		$this->add_responsive_control(
			$this->name . '_content_link_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-accordion-content a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		// Icon.
		$this->start_controls_tab(
			$this->name . '_icon_tab',
			array(
				'label'     => __( 'Icon', 'anky' ),
				'condition' => array( $this->name . '_skin' => 'template3' ),
			)
		);
		$this->add_control(
			$this->name . '_icon_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .anky-faq-question-icon' => 'color: {{VALUE}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_icon_size',
			array(
				'label'     => __( 'Size', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => array(
					'{{WRAPPER}} .anky-faq-question-icon' => 'font-size: {{SIZE}}px;',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_icon_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-faq-question-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Add Additional Intro Style settings fields to `Style` tab.
	 * Control section Will only be displayed on `Template2` view.
	 * It will allow to set styles for title text, button label text.
	 */
	private function add_intro_section_style_settings() {
		$this->start_controls_section(
			$this->name . 'section_style__header',
			array(
				'label'     => __( 'FAQ Intro Section', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_skin' => array( 'template2' ),
				),
			)
		);

		// Intro title.
		$this->add_control(
			$this->name . '_intro_title_heading',
			array(
				'label'     => __( 'Intro Title', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);
		$this->add_typography_control_style_part( "{$this->name}_intro_title", 'h2', '' );
		// Intro text.
		$this->add_control(
			$this->name . '_intro_content_title',
			array(
				'label'     => __( 'Intro Text', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);
		$this->add_typography_control_style_part( "{$this->name}_intro_content", '.anky-faq-page-description', '' );
		// Intro btn.
		$this->add_control(
			$this->name . '_intro_btn_heading',
			array(
				'label'     => __( 'FAQ intro button', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);
		$this->add_typography_control_style_part( "{$this->name}_intro_btn", '.anky-btn', '' );

		$this->end_controls_section();
	}

}
