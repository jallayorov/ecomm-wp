<?php
/**
 * Anky Theme Elementor Widget for displaying Team members section.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 *
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;
use Elementor\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying Team members section.
 */
class Anky_Elementor_Widget_Team extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_team';

	/**
	 * Amount of social networks control fields.
	 *
	 * @var int
	 * @aceces private
	 */
	private $social_networks_amount = 5;

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Team', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-my-account';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'anky-widget-slider' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->add_general_content_settings();
		$this->add_content_controls();

		$this->add_image_style_controls();
		$this->add_content_style_controls();
		$this->add_social_networks_style_controls();
		$this->add_slider_style_controls();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$slider_data = array(
			'#anky_elementor_team_' . $settings[ $this->name . '_skin' ],
			array(
				'loop'                  => false,
				'slidesPerView'         => 'auto',
				'spaceBetween'          => 32,
				'slidesPerGroup'        => 1,
				'watchOverflow'         => true,
				'watchSlidesVisibility' => true,
				'pagination'            => array(
					'el'   => '.swiper-scrollbar',
					'type' => 'progressbar',
				),
				'autoplay'              => $settings[ $this->name . '_carousel_play' ] ?
					array(
						'delay'                => $settings[ $this->name . '_carousel_autoplay_speed' ],
						'disableOnInteraction' => false,
					) : false,
				'navigation'            => array(
					'nextEl' => '.anky-team-slider-button-next',
					'prevEl' => '.anky-team-slider-button-prev',
				),
				'breakpoints'           => array(
					'320'  => array(
						'slidesPerView' => 1,
						'spaceBetween'  => 16,
					),
					'735'  => array(
						'slidesPerView' => 2,
						'spaceBetween'  => 32,
					),
					'1088' => array(
						'slidesPerView' => 3,
					),
				),
			),
			array(
				'hideArrows'  => false,
				'isAnimation' => false,
			),
		);

		$section_wrapper_class = array( 'anky-slider-parent', 'anky-team-section', "anky-team-section-{$settings[$this->name.'_skin']}" );
		if ( 'skin-1' === $settings[ $this->name . '_skin' ] ) :
			?>
			<div id="<?php echo esc_attr( 'anky_elementor_team_' . $settings[ $this->name . '_skin' ] ); ?>"
				class="<?php echo esc_attr( implode( ' ', $section_wrapper_class ) ); ?>"
				data-anky-slider="<?php echo esc_attr( wp_json_encode( $slider_data ) ); ?>">
				<div class="anky-slider-wrapper swiper-wrapper">
					<?php foreach ( $settings[ $this->name . '_members_list' ] as $i => $person ) : ?>
						<div class="swiper-slide anky-team-member-card">
							<?php $this->render_member_image( $person ); ?>
							<div class="anky-team-member-info">
								<?php
								$this->render_member_name( $person, $i );
								$this->render_member_title( $person, $i );
								$this->render_member_department( $person, $i );
								?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="anky-team-slider-nav">
					<div class="anky-team-slider-button-prev-wrapper">
						<button type="button" class="anky-team-slider-button-prev" aria-label="<?php esc_attr_e( 'Previous slide', 'anky' ); ?>">
							<span class="anky-icon-chevron-left" aria-hidden="true"></span>
						</button>
					</div>
					<div class="anky-progressbar swiper-scrollbar" aria-hidden="true"></div>
					<div class="anky-team-slider-button-next-wrapper">
						<button type="button" class="anky-team-slider-button-next" aria-label="<?php esc_attr_e( 'Next slide', 'anky' ); ?>">
							<span class="anky-icon-chevron-right" aria-hidden="true"></span>
						</button>
					</div>
				</div>
			</div>
		<?php else : ?>
			<div class="<?php echo esc_attr( implode( ' ', $section_wrapper_class ) ); ?>">
				<div class="anky-row">
					<?php foreach ( $settings[ $this->name . '_members_list' ] as $i => $person ) : ?>
						<div class="anky-col-2">
							<div class="anky-team-member-card">
								<?php $this->render_member_image( $person ); ?>
								<div class="anky-team-member-info">
									<?php
									$this->render_member_name( $person, $i );
									$this->render_member_title( $person, $i );
									$this->render_member_department( $person, $i );
									$this->render_social_links( $person, $i );
									?>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php
		endif;
	}

	// ======================================================
	// PRIVATE - Render parts
	// ======================================================

	/**
	 * Render part that renders the members image.
	 *
	 * @param array $person Current member data.
	 */
	private function render_member_image( $person = array() ) {
		// Bail early.
		if ( empty( $person[ $this->name . '_member_image' ]['url'] ) ) {
			return;
		}

		echo '<div class="anky-member-picture-wrapper">';
		$this->render_media_image( $person, $this->name . '_member_image', 'anky-member-image' );
		echo '</div>';
	}

	/**
	 * Render part that renders the members' Name.
	 *
	 * @param array   $person Current member data.
	 * @param integer $index  Current person iteration index.
	 */
	private function render_member_name( $person = array(), $index = 0 ) {
		if ( empty( $person ) || empty( $person[ $this->name . '_member_name' ] ) ) {
			return;
		}

		$name_setting_key = $this->get_repeater_setting_key( $this->name . '_member_name', $this->name . '_members_list', $index );
		$this->add_inline_editing_attributes( $name_setting_key, 'none' );
		$this->add_render_attribute( $name_setting_key, 'class', 'anky-team-member-name' );

		echo wp_kses_post( sprintf( '<h3 %s>%s</h3>', $this->get_render_attribute_string( $name_setting_key ), $person[ $this->name . '_member_name' ] ) );
	}

	/**
	 * Render part that renders the members' Title.
	 *
	 * @param array   $person Current member data.
	 * @param integer $index  Current person iteration index.
	 */
	private function render_member_title( $person = array(), $index = 0 ) {
		if ( empty( $person ) || empty( $person[ $this->name . '_member_title' ] ) ) {
			return;
		}

		$title_setting_key = $this->get_repeater_setting_key( $this->name . '_member_title', $this->name . '_members_list', $index );
		$this->add_inline_editing_attributes( $title_setting_key, 'none' );
		$this->add_render_attribute( $title_setting_key, array( 'class' => array( 'anky-team-member-title', 'anky-team-member-info-highlight' ) ) );

		echo wp_kses_post( sprintf( '<p %s>%s</p>', $this->get_render_attribute_string( $title_setting_key ), $person[ $this->name . '_member_title' ] ) );
	}

	/**
	 * Render part that renders the members` department info.
	 *
	 * @param array   $person Current member data.
	 * @param integer $index  Current person iteration index.
	 */
	private function render_member_department( $person = array(), $index = 0 ) {
		if ( empty( $person ) || empty( $person[ $this->name . '_member_department' ] ) ) {
			return;
		}

		$department_setting_key = $this->get_repeater_setting_key( $this->name . '_member_department', $this->name . '_members_list', $index );
		$this->add_inline_editing_attributes( $department_setting_key, 'none' );
		$this->add_render_attribute( $department_setting_key, array( 'class' => array( 'anky-team-member-department', 'anky-team-member-info-highlight' ) ) );

		echo wp_kses_post( sprintf( '<p %s>%s</p>', $this->get_render_attribute_string( $department_setting_key ), trim( $person[ $this->name . '_member_department' ] ) ) );
	}

	/**
	 * Render part that renders the members` Social networks info.
	 *
	 * @param array   $person Current member data.
	 * @param integer $index  Current person iteration index.
	 */
	private function render_social_links( $person = array(), $index = 0 ) {
		if ( empty( $person ) || '1' !== $person[ $this->name . '_member_social_enable' ] ) {
			return;
		}

		$i = 1;

		echo '<ul class="anky-team-member-social-networks anky-list-unstyled">';

		for ( ; $i <= $this->social_networks_amount; $i ++ ) :
			$current_person = $person["{$this->name}_member_social_network_$i"];

			if ( empty( $current_person ) ) {
				continue;
			}

			$social_setting_key = $this->get_repeater_setting_key( $this->name . "_member_social_network_$i", $this->name . '_members_list', $index );
			$this->add_link_attributes( $social_setting_key, $current_person );
			if ( ! in_array( 'href', array_keys( $this->get_render_attributes( $social_setting_key ) ), true ) ) {
				$this->add_render_attribute( $social_setting_key, 'href', '#' );
			}
			?>
			<li class="anky-team-member-social-networks-item">
				<a <?php $this->print_render_attribute_string( $social_setting_key ); ?>><?php Anky_UI_Controller::render_social_link_icon( $current_person['url'] ); ?></a>
			</li>
		<?php
		endfor;
		if ( ! empty( $person[ $this->name . '_member_mail' ] ) ) {
			$mail_setting_key = $this->get_repeater_setting_key( $this->name . '_member_mail', $this->name . '_members_list', $index );
			$this->add_inline_editing_attributes( $mail_setting_key, 'none' );
			$this->add_link_attributes( $mail_setting_key, $person[ $this->name . '_member_mail' ] );
			$this->add_render_attribute( $mail_setting_key, 'href', 'mailto:' . $person[ $this->name . '_member_mail' ]['url'], true );
			?>
			<li class="anky-team-member-social-networks-item anky-team-member-social-networks-item-email">
				<a <?php $this->print_render_attribute_string( $mail_setting_key ); ?>><?php echo esc_html( $person[ $this->name . '_member_mail' ]['url'] ); ?></a>
			</li>
			<?php
		}
		echo '</ul>';
	}

	// ======================================================
	// PRIVATE - Content Tab Controls
	// ======================================================

	/**
	 * Add main content display setting controls.
	 */
	private function add_general_content_settings() {
		$this->start_controls_section(
			$this->name . '_general_settings',
			array(
				'label' => __( 'Display Settings', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_skin',
			array(
				'label'   => __( 'Skin', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'skin-1',
				'options' => array(
					'skin-1' => esc_html__( 'Skin 1', 'anky' ),
					'skin-2' => esc_html__( 'Skin 2', 'anky' ),
					'skin-3' => esc_html__( 'Skin 3', 'anky' ),
					'skin-4' => esc_html__( 'Skin 4', 'anky' ),
					'skin-5' => esc_html__( 'Skin 5', 'anky' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_carousel_play',
			array(
				'label'     => __( 'Auto Play', 'anky' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => array(
					$this->name . '_skin' => 'skin-1',
				),
			)
		);
		$this->add_control(
			$this->name . '_carousel_autoplay_speed',
			array(
				'label'       => __( 'Autoplay Speed', 'anky' ),
				'description' => __( 'Autoplay Speed means at which time the next slide should come. Set a value in milliseconds (ms)', 'anky' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 5000,
				'condition'   => array(
					$this->name . '_skin'          => 'skin-1',
					$this->name . '_carousel_play' => 'yes',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_carousel_arrows_pos',
			array(
				'label'      => __( 'Arrows Position', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'range'      => array(
					'px' => array(
						'min' => - 100,
						'max' => 100,
					),
					'em' => array(
						'min' => - 10,
						'max' => 10,
					),
				),
				'condition'  => array(
					$this->name . '_skin' => 'skin-1',
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-team-slider-nav .anky-team-slider-button-prev-wrapper' => 'right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .anky-team-slider-nav .anky-team-slider-button-next-wrapper' => 'left: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add main content controls.
	 */
	private function add_content_controls() {
		$this->start_controls_section(
			$this->name . '_content_settings',
			array( 'label' => __( 'Content', 'anky' ) )
		);

		$repeater = new Repeater();

		$repeater->add_control(
			$this->name . '_member_image',
			array(
				'label'   => __( 'Image', 'anky' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => array( 'active' => true ),
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);
		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_member_image',
				'default'   => 'anky-team',
				'separator' => 'none',
			)
		);
		$repeater->add_control(
			$this->name . '_member_name',
			array(
				'label'       => __( 'Name', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'default'     => 'John Doe',
				'separator'   => 'before',
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_member_title',
			array(
				'label'       => __( 'Job Title', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'default'     => __( 'Manager', 'anky' ),
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_member_department',
			array(
				'label'       => __( 'Department', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'default'     => __( 'Management', 'anky' ),
				'label_block' => true,
			)
		);

		$repeater->add_control(
			$this->name . '_member_social_enable',
			array(
				'label'        => __( 'Enable Social Icons', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'description'  => __( 'NOTE: Social Icons do not appear on Skin 1', 'anky' ),
				'default'      => '1',
				'separator'    => 'before',
				'return_value' => '1',
			)
		);

		$i = 1;
		for ( ; $i <= $this->social_networks_amount; $i ++ ) {
			$repeater->add_control(
				$this->name . "_member_social_network_$i",
				array(
					/* translators: %s Number of social networks by order */
					'label'         => sprintf( __( 'Social Network #%s', 'anky' ), $i ),
					'type'          => Controls_Manager::URL,
					'dynamic'       => array( 'active' => true ),
					'show_external' => true,
					'label_block'   => true,
					'default'       => array(
						'url'         => '',
						'is_external' => true,
						'nofollow'    => true,
					),
					'condition'     => array( $this->name . '_member_social_enable' => '1' ),
				)
			);
		}

		$repeater->add_control(
			$this->name . '_member_mail',
			array(
				'label'         => __( 'Email Address', 'anky' ),
				'type'          => Controls_Manager::URL,
				'dynamic'       => array( 'active' => true ),
				'label_block'   => true,
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),
				'condition'     => array( $this->name . '_member_social_enable' => '1' ),
			)
		);

		$this->add_control(
			$this->name . '_members_list',
			array(
				'label'       => __( 'Team Members', 'anky' ),
				'type'        => Controls_Manager::REPEATER,
				'default'     => array(
					array(
						$this->name . '_member_name'             => 'Fred Myers',
						$this->name . '_member_title'            => 'Head of Partnerships',
						$this->name . '_member_social_network_1' => array( 'url' => 'facebook.com' ),
						$this->name . '_member_social_network_2' => array( 'url' => 'instagram.com' ),
					),
					array(
						$this->name . '_member_name'          => 'Linda White',
						$this->name . '_member_title'         => 'Customer Support Manager',
						$this->name . '_member_social_enable' => '',
					),
					array(
						$this->name . '_member_name'             => 'Margaret Moreno',
						$this->name . '_member_title'            => 'Chief Financial Officer',
						$this->name . '_member_social_network_1' => array( 'url' => 'telegram.me' ),
					),
				),
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{anky_team_member_name}}} - {{{anky_team_member_title}}}',
			)
		);

		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Style Tab Controls
	// ======================================================

	/**
	 * Add Image style and effects settings controls.
	 */
	private function add_image_style_controls() {
		$this->start_controls_section(
			$this->name . '_image_style',
			array(
				'label' => __( 'Image', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_responsive_control(
			$this->name . '_image_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 1200,
					),
					'%'  => array(
						'min' => 0,
						'max' => 200,
					),
				),
				'default'    => array(
					'unit' => '%',
					'size' => 100,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-member-image' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_image_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 1200,
					),
					'%'  => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-member-image' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_image_border_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'separator'  => 'after',
				'selectors'  => array(
					'{{WRAPPER}} .anky-member-image' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_image_vertical_position',
			array(
				'label'       => __( 'Vertical position', 'anky' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => $this->position_size_units,
				'description' => __( 'Set image vertical position', 'anky' ),
				'selectors'   => array(
					'{{WRAPPER}} .anky-member-image' => 'object-position: 50% {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_image_object_fit',
			array(
				'label'     => __( 'Object fit', 'anky' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'cover'      => __( 'Cover', 'anky' ),
					'contain'    => __( 'Contain', 'anky' ),
					'fill'       => __( 'Fill', 'anky' ),
					'auto'       => __( 'Auto', 'anky' ),
					'scale-down' => __( 'Scale down', 'anky' ),
					'inherit'    => __( 'Inherit', 'anky' ),
				),
				'default'   => 'cover',
				'selectors' => array(
					'{{WRAPPER}} .anky-member-image' => 'object-fit: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			array(
				'name'     => 'anky_css_filters',
				'selector' => '{{WRAPPER}} .anky-member-image',
			)
		);
		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			array(
				'name'     => 'anky_hover_css_filters',
				'label'    => __( 'Hover CSS Filters', 'anky' ),
				'selector' => '{{WRAPPER}} .anky-member-image:hover',
			)
		);
		$this->add_control(
			$this->name . '_blend_mode',
			array(
				'label'     => __( 'Blend Mode', 'anky' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					''            => __( 'Normal', 'anky' ),
					'multiply'    => __( 'Multiply', 'anky' ),
					'screen'      => __( 'Screen', 'anky' ),
					'overlay'     => __( 'Overlay', 'anky' ),
					'darken'      => __( 'Darken', 'anky' ),
					'lighten'     => __( 'Lighten', 'anky' ),
					'color-dodge' => __( 'Color Dodge', 'anky' ),
					'saturation'  => __( 'Saturation', 'anky' ),
					'color'       => __( 'Color', 'anky' ),
					'luminosity'  => __( 'Luminosity', 'anky' ),
				),
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .anky-member-image' => 'mix-blend-mode: {{VALUE}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_image_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'    => 0,
					'right'  => 0,
					'bottom' => 24,
					'left'   => 0,
					'unit'   => $this->default_size_units[0],
				),
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .anky-member-picture-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add content style controls in a tabbed manner.
	 *
	 * Block consists of `Name`, `Title` and `Department` controls.
	 */
	private function add_content_style_controls() {
		$this->start_controls_section(
			$this->name . '_content_style',
			array(
				'label' => __( 'Content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( $this->name . '_content_style_tabs' );

		$this->start_controls_tab(
			$this->name . '_content_name_style_tab',
			array(
				'label' => __( 'Name', 'anky' ),
			)
		);
		$this->add_content_related_style_controls_part( "{$this->name}_name", '.anky-team-member-name', '' );
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_content_title_style_tab',
			array(
				'label' => __( 'Title', 'anky' ),
			)
		);
		$this->add_content_related_style_controls_part( "{$this->name}_title", '.anky-team-member-title', '' );
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_content_department_style_tab',
			array(
				'label' => __( 'Department', 'anky' ),
			)
		);
		$this->add_content_related_style_controls_part( "{$this->name}_department", '.anky-team-member-department', '' );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Add Social Networks style controls.
	 */
	private function add_social_networks_style_controls() {
		$this->start_controls_section(
			$this->name . '_socials_style',
			array(
				'label' => __( 'Social', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( $this->name . '__socials_style_tabs' );

		$this->start_controls_tab(
			$this->name . '__social_icon_style_tab',
			array(
				'label' => __( 'Icons', 'anky' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_social_icons_size',
			array(
				'label'       => __( 'Size', 'anky' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => $this->default_size_units,
				'label_block' => true,
				'selectors'   => array(
					'{{WRAPPER}} .anky-team-member-social-networks-item a' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			$this->name . '_social_icons_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7E7E83',
				'selectors' => array(
					'{{WRAPPER}} .anky-team-member-social-networks-item a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			$this->name . '_social_icons_hover_color',
			array(
				'label'     => __( 'Hover Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#BF1534',
				'selectors' => array(
					'{{WRAPPER}} .anky-team-member-social-networks-item a:hover' => 'color: {{VALUE}}',
				),
			)
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '__social_email_style_tab',
			array(
				'label' => __( 'Email', 'anky' ),
			)
		);
		$this->add_typography_control_style_part( $this->name . '_social_email', '.anky-team-member-social-networks-item-email a', '#7E7E83' );

		$this->add_control(
			$this->name . '_social_email_hover_color',
			array(
				'label'     => __( 'Hover Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#BF1534',
				'selectors' => array(
					'{{WRAPPER}} .anky-team-member-social-networks-item-email a:hover' => 'color: {{VALUE}}',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			$this->name . '_social_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-team-member-social-networks-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			$this->name . '_social_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'    => 0,
					'right'  => 16,
					'bottom' => 0,
					'left'   => 0,
					'unit'   => $this->default_size_units[0],
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-team-member-social-networks-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add slider style settings controls.
	 */
	private function add_slider_style_controls() {
		$this->start_controls_section(
			$this->name . '_carousel_style',
			array(
				'label'     => __( 'Carousel', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_skin' => 'skin-1',
				),
			)
		);

		$this->start_controls_tabs( $this->name . '_slider_style_tabs' );

		$this->start_controls_tab(
			$this->name . '_slider_button_style_tab',
			array(
				'label' => __( 'Button', 'anky' ),
			)
		);

		$button_selector       = '{{WRAPPER}} .anky-team-slider-nav .anky-team-slider-button-prev, {{WRAPPER}} .anky-team-slider-nav .anky-team-slider-button-next';
		$button_hover_selector = '{{WRAPPER}} .anky-team-slider-nav .anky-team-slider-button-prev:hover, {{WRAPPER}} .anky-team-slider-nav .anky-team-slider-button-next:hover';

		$this->add_control(
			$this->name . '_slider_arrow_color_button',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#e0e0e0',
				'selectors' => array(
					$button_selector => 'border-color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrow_hover_color_button',
			array(
				'label'     => __( 'Hover Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$button_hover_selector => 'border-color: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slider_arrow_button_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => '48',
				),
				'selectors'  => array(
					$button_selector => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slider_arrow_button_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => '48',
				),
				'selectors'  => array(
					$button_selector => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrow_button_background',
			array(
				'label'     => __( 'Background Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$button_selector => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrow_button_background_hover_background',
			array(
				'label'     => __( 'Background Hover Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$button_hover_selector => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrow_button_background_border_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => '%',
					'size' => '50',
				),
				'selectors'  => array(
					$button_selector => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrow_button_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					$button_selector => 'padding: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_slider_icon_style_tab',
			array(
				'label' => __( 'Icon', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrow_icon_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161a',
				'selectors' => array(
					$button_selector => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrow_icon_hover_color',
			array(
				'label'     => __( 'Hover Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$button_hover_selector => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_slider_arrow_icon_size',
			array(
				'label'      => __( 'Size', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => '24',
				),
				'selectors'  => array(
					$button_selector => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}
}
