<?php
/**
 * Anky Theme Elementor Widget for displaying Posts.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use WP_Query;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying Posts.
 */
class Anky_Elementor_Widget_Posts extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_posts';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Posts', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'anky-widget-slider' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->main_content_settings();

		$this->post_item_container_style_controls();
		$this->post_author_settings_group();
		$this->post_heading_settings_group();
		$this->post_excerpt_settings_group();
		$this->post_category_settings_group();
		$this->post_date_settings_group();
		$this->post_thumbnail_settings_group();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		/**
		 * In other cases we would use the `get_posts()`, but here it just can duplicate
		 * the current post. Mainly if we are in a singular.
		 */
		$query = new WP_Query(
			array(
				'posts_per_page' => $settings[ $this->name . '_post_per_page' ],
				'order'          => $settings[ $this->name . '_order_by' ],
				'post_type'      => $settings[ $this->name . '_available_post_type' ],
				'exclude'        => array( get_the_ID() ),
			)
		);

		// Before loop.
		$loop_closing_html_escaped = '';
		switch ( $settings[ $this->name . '_skin' ] ) {
			case 'template1':
			case 'template4':
			case 'template5':
			case 'template6':
				echo '<div class="anky-posts-' . esc_attr( $settings[ $this->name . '_skin' ] ) . '-parent">';
				$loop_closing_html_escaped .= '</div><!--.swiper-container-t1-->';
				break;
			case 'template2':
			case 'template3':
				$slider_data = array(
					'#anky_elementor_posts_' . $settings[ $this->name . '_skin' ],
					array(
						'slidesPerView' => 2,
						'autoHeight'    => true,
						'spaceBetween'  => 32,
						'pagination'    => array(
							'el'   => '.anky-swiper-pagination',
							'type' => 'bullets',
						),
						'loop'          => false,
						'autoplay'      => false,
						'navigation'    => array(
							'nextEl' => '.swiper-button-next',
							'prevEl' => '.swiper-button-prev',
						),
						'scrollbar'     => array(
							'el'            => '.swiper-scrollbar',
							'draggable'     => false,
							'snapOnRelease' => true,
						),
						'breakpoints'   => array(
							'315'  => array(
								'slidesPerView' => 1,
								'spaceBetween'  => 16,
							),
							'576'  => array(
								'spaceBetween'  => 32,
								'slidesPerView' => 1,
							),
							'1025' => array(
								'slidesPerView' => 2,
							),
						),
					),
					array(
						'hideArrows'  => false,
						'isAnimation' => false,
					),
				);

				printf(
					'<div id="anky_elementor_posts_%1$s" class="anky-slider-parent anky-posts-%1$s-parent" data-anky-slider="%2$s"><div class="swiper-wrapper">',
					esc_attr( $settings[ $this->name . '_skin' ] ),
					esc_attr( wp_json_encode( $slider_data ) )
				);
				$loop_closing_html_escaped .= '</div><!--.swiper-wrapper-->';
				$loop_closing_html_escaped .= sprintf(
					'<div class="anky-posts-%1$s-arrow swiper-button-prev"></div><div class="anky-posts-%1$s-pagination anky-swiper-pagination"></div><div class="anky-posts-%1$s-arrow swiper-button-next"></div>',
					esc_attr( $settings[ $this->name . '_skin' ] )
				);
				$loop_closing_html_escaped .= '</div><!--.swiper-container-' . $settings[ $this->name . '_skin' ] . '-->';
				break;
			case 'template7':
				$slider_data = array(
					'#anky_elementor_posts_' . $settings[ $this->name . '_skin' ],
					array(
						'slidesPerView' => 1,
						'autoHeight'    => true,
						'spaceBetween'  => 32,
						'pagination'    => false,
						'loop'          => false,
						'autoplay'      => false,
						'navigation'    => array(
							'nextEl' => '.swiper-button-next',
							'prevEl' => '.swiper-button-prev',
						),
						'scrollbar'     => array(
							'el'            => '.swiper-scrollbar',
							'draggable'     => false,
							'snapOnRelease' => true,
						),
						'breakpoints'   => array(
							'315' => array(
								'slidesPerView' => 1,
								'spaceBetween'  => 16,
							),
							'576' => array(
								'spaceBetween' => 32,
							),
						),
					),
					array(
						'hideArrows'  => false,
						'isAnimation' => false,
					),
				);

				printf(
					'<div id="anky_elementor_posts_%1$s" class="anky-slider-parent anky-posts-%1$s-parent" data-anky-slider="%2$s"><div class="swiper-wrapper">',
					esc_attr( $settings[ $this->name . '_skin' ] ),
					esc_attr( wp_json_encode( $slider_data ) )
				);
				$loop_closing_html_escaped .= '</div><!--.swiper-wrapper-->';
				$loop_closing_html_escaped .= sprintf(
					'<div class="anky-posts-%1$s-arrow swiper-button-prev"></div><div class="anky-posts-%1$s-pagination anky-swiper-pagination"></div><div class="anky-posts-%1$s-arrow swiper-button-next"></div>',
					esc_attr( $settings[ $this->name . '_skin' ] )
				);
				$loop_closing_html_escaped .= '</div><!--.swiper-container-' . $settings[ $this->name . '_skin' ] . '-->';
				break;
		}

		// The loop.
		while ( $query->have_posts() ) {
			$query->the_post();
			anky_load_template(
				'template-parts/elementor/posts/post',
				$settings[ $this->name . '_skin' ],
				array( 'placeholder_url' => $settings[ $this->name . '_empty_image_placeholder' ] ? Utils::get_placeholder_image_src() : '' )
			);
		}
		wp_reset_postdata();

		// After the loop.
		echo $loop_closing_html_escaped; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	// ======================================================
	// PRIVATE - Content settings
	// ======================================================

	/**
	 * Add main settings in content tab.
	 */
	private function main_content_settings() {
		$this->start_controls_section(
			$this->name . '_content_settings_section',
			array(
				'label' => esc_html__( 'Content Setup', 'anky' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);
		$this->add_control(
			$this->name . '_available_post_type',
			array(
				'label'    => __( 'Post Type', 'anky' ),
				'type'     => Controls_Manager::SELECT2,
				'default'  => 'post',
				'multiple' => false,
				'options'  => get_post_types( array( 'public' => true ) ),
			)
		);
		$this->add_control(
			$this->name . '_post_per_page',
			array(
				'label'   => __( 'Number of Posts', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 3,
				'options' => array(
					- 1 => __( 'All', 'anky' ),
					1   => 1,
					2   => 2,
					3   => 3,
					4   => 4,
					5   => 5,
				),
			)
		);
		$this->add_control(
			$this->name . '_order_by',
			array(
				'label'   => __( 'Order by', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => array(
					'ASC'  => 'ASC',
					'DESC' => 'DESC',
				),
			)
		);
		$this->add_control(
			$this->name . '_skin',
			array(
				'label'   => esc_html__( 'Skin', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'template1',
				'options' => array(
					'template1' => esc_html__( 'Skin 1', 'anky' ),
					'template2' => esc_html__( 'Skin 2', 'anky' ),
					'template3' => esc_html__( 'Skin 3', 'anky' ),
					'template4' => esc_html__( 'Skin 4', 'anky' ),
					'template5' => esc_html__( 'Skin 5', 'anky' ),
					'template6' => esc_html__( 'Skin 6', 'anky' ),
					'template7' => esc_html__( 'Skin 7', 'anky' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_empty_image_placeholder',
			array(
				'label'        => __( 'Add placeholder', 'anky' ),
				'description'  => __( 'Add image placeholder for posts without thumbnail', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '1',
			)
		);
		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Style settings
	// ======================================================

	/**
	 * Add Post item container style setting.
	 */
	private function post_item_container_style_controls() {
		$this->start_controls_section(
			$this->name . '_container_style_settings',
			array(
				'label' => __( 'Item container', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			$this->name . '_container_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-posts-item' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .anky-posts-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-posts-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Post Author settings group in Styles tab.
	 */
	private function post_author_settings_group() {
		$this->start_controls_section(
			$this->name . '_post_author_style_section',
			array(
				'label'     => __( 'Post Author', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_skin' => array( 'template3', 'template5' ),
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_post_author_typography',
				'label'          => __( 'Typography', 'anky' ),
				'selector'       => '{{WRAPPER}} .anky-entry-author a',
				'fields_options' => $this->default_paragraph_typography,
			)
		);
		$this->add_popover_colors_controls( 'author', '.anky-entry-author .anky-meta-title a' );
		$this->end_controls_section();
	}

	/**
	 *  Add Post Heading settings group in Styles tab.
	 */
	private function post_heading_settings_group() {
		$this->start_controls_section(
			$this->name . '_post_title_style_section',
			array(
				'label' => esc_html__( 'Title', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_post_title_typography',
				'label'          => esc_html__( 'Typography', 'anky' ),
				'selector'       => '{{WRAPPER}} .entry-title',
				'fields_options' => $this->default_small_heading_typography,
			)
		);
		$this->add_popover_colors_controls( 'title', '.entry-title a' );
		$this->add_responsive_control(
			$this->name . '_post_title_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .entry-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Post Excerpt settings group in Styles tab.
	 * Settings for template 2.
	 */
	private function post_excerpt_settings_group() {
		$this->start_controls_section(
			$this->name . '_post_excerpt_style_section',
			array(
				'label'     => esc_html__( 'Excerpt', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					$this->name . '_skin' => array( 'template2', 'template4' ),
				),
			)
		);
		$this->add_typography_control_style_part( "{$this->name}_post_excerpt", '.entry-content p', '#7E7E83' );
		$this->add_responsive_control(
			$this->name . '_post_excerpt_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .entry-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 *  Add Post Category settings group in Styles tab.
	 */
	private function post_category_settings_group() {
		$this->start_controls_section(
			$this->name . '_post_category_style_section',
			array(
				'label' => __( 'Category', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_post_category_typography',
				'label'          => __( 'Typography', 'anky' ),
				'selector'       => '{{WRAPPER}} .anky-post-cat a',
				'fields_options' => $this->default_paragraph_typography,
			)
		);
		$this->add_control(
			$this->name . '_default_post_category_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-post-cat a, {{WRAPPER}} .anky-post-cat' => 'color: {{VALUE}}',
					'{{WRAPPER}} .anky-post-cat a::before'                         => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					$this->name . '_skin!' => 'template5',
				),
			)
		);
		$this->add_control(
			$this->name . '_highlighted_post_category_color',
			array(
				'label'       => __( 'Color', 'anky' ),
				'type'        => Controls_Manager::COLOR,
				'default'     => '#FFFFFF',
				'description' => __( 'Control is applied to first highlighted item', 'anky' ),
				'selectors'   => array(
					'{{WRAPPER}} .anky-posts-item:first-child .anky-post-cat a, {{WRAPPER}} .anky-post-cat' => 'color: {{VALUE}}',
					'{{WRAPPER}} .anky-posts-item:first-child .anky-post-cat a::before'                         => 'background-color: {{VALUE}}',
				),
				'condition'   => array(
					$this->name . '_skin' => 'template5',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_post_category_margin',
			array(
				'label'           => __( 'Margin', 'anky' ),
				'type'            => Controls_Manager::DIMENSIONS,
				'size_units'      => $this->default_size_units,
				'desktop_default' => array(
					'top'  => 24,
					'unit' => 'px',
				),
				'mobile_default'  => array(
					'top'  => 16,
					'unit' => 'px',
				),
				'selectors'       => array(
					'{{WRAPPER}} .anky-post-cat' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Post Publish date settings group in Styles tab.
	 */
	private function post_date_settings_group() {
		$this->start_controls_section(
			$this->name . '_post_date_style_section',
			array(
				'label' => esc_html__( 'Date', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_post_date_typography',
				'label'          => esc_html__( 'Typography', 'anky' ),
				'selector'       => '{{WRAPPER}} .posted-on a',
				'fields_options' => $this->default_paragraph_typography,
			)
		);
		$this->add_popover_colors_controls( 'date', '.posted-on a' );
		$this->add_responsive_control(
			$this->name . '_post_date_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .posted-on' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Post Thumbnails settings group in Styles tab.
	 */
	private function post_thumbnail_settings_group() {
		$this->start_controls_section(
			$this->name . '_post_thumbnail_style_section',
			array(
				'label' => __( 'Thumbnail', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_responsive_control(
			$this->name . '_post_thumbnail_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-posts-item .post-thumbnail img' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_post_thumbnail_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-posts-item .post-thumbnail img' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_post_thumbnail_border_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-posts-item .post-thumbnail, {{WRAPPER}} .anky-posts-item .post-thumbnail img, {{WRAPPER}} .anky-posts-item .post-thumbnail:after' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_post_thumbnail_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-posts-item .post-thumbnail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add controls for colors
	 *
	 * Due to repeating nature of items the only thing required is to pass a string slug.
	 * Slug should be considered letters and be more like meaningful word.
	 *
	 * @param string $slug            Required. Identifier for current switch zone.
	 * @param string $selector_string Required. Css selector used to apply props to.
	 */
	private function add_popover_colors_controls( $slug, $selector_string ) {
		$this->add_control(
			$this->name . "_post_{$slug}_colors",
			array(
				'label'     => __( 'Colors', 'anky' ),
				'type'      => Controls_Manager::POPOVER_TOGGLE,
				'condition' => array(
					$this->name . '_skin' => 'template5',
				),
			)
		);
		$this->start_popover();
		$this->add_control(
			$this->name . "_highlighted_post_{$slug}_color",
			array(
				'label'       => __( 'Highlighted item', 'anky' ),
				'type'        => Controls_Manager::COLOR,
				'default'     => '#FFFFFF',
				'description' => __( 'Control is applied to first highlighted item', 'anky' ),
				'selectors'   => array(
					"{{WRAPPER}} .anky-posts-item:first-child {$selector_string}"         => 'color: {{VALUE}}',
					"{{WRAPPER}} .anky-posts-item:first-child {$selector_string}::before" => 'background-color: {{VALUE}}',
				),
				'condition'   => array(
					$this->name . '_skin' => 'template5',
				),
			)
		);
		$this->add_control(
			$this->name . "_post_{$slug}_color",
			array(
				'label'       => __( 'Other items', 'anky' ),
				'type'        => Controls_Manager::COLOR,
				'default'     => '#16161A',
				'description' => __( 'Control is applied to other items', 'anky' ),
				'selectors'   => array(
					"{{WRAPPER}} {$selector_string}"         => 'color: {{VALUE}}',
					"{{WRAPPER}} {$selector_string}::before" => 'background-color: {{VALUE}}',
				),
				'condition'   => array(
					$this->name . '_skin' => 'template5',
				),
			)
		);
		$this->end_popover();
		$this->add_control(
			$this->name . "_default_post_{$slug}_color",
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					"{{WRAPPER}} {$selector_string}"         => 'color: {{VALUE}}',
					"{{WRAPPER}} {$selector_string}::before" => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					$this->name . '_skin!' => 'template5',
				),
			)
		);
	}

}
