<?php
/**
 * Anky Theme Elementor Widget for displaying contacts.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying contacts.
 */
class Anky_Elementor_Widget_Contacts extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_contacts';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Contacts', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-envelope';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->start_controls_section(
			$this->name . '_section_content',
			array(
				'label' => esc_html__( 'Settings', 'anky' ),
			)
		);

		$url = Utils::get_placeholder_image_src();
		if ( has_custom_logo() ) {
			$url = wp_get_attachment_image_src( get_theme_mod( 'custom_logo' ), 'full' )[0];
		}
		$this->add_control(
			$this->name . '_image',
			array(
				'label'   => esc_html__( 'Site Logo', 'anky' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => $url,
				),
			)
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_image',
				'default'   => 'thumbnail',
				'separator' => 'none',
			)
		);

		$this->add_control(
			$this->name . '_email_link',
			array(
				'label'         => esc_html__( 'Email', 'anky' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_attr__( 'Enter Email', 'anky' ),
				'dynamic'       => array( 'active' => true ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => true,
				),
			)
		);

		$this->add_control(
			$this->name . '_tel_num_link',
			array(
				'label'         => esc_html__( 'Phone number', 'anky' ),
				'type'          => Controls_Manager::URL,
				'dynamic'       => array( 'active' => true ),
				'placeholder'   => esc_attr__( 'Enter phone number', 'anky' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => true,
				),
			)
		);

		$this->add_control(
			$this->name . '_address_link',
			array(
				'label'         => esc_html__( 'Address', 'anky' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_attr__( 'Enter your address', 'anky' ),
				'show_external' => true,
				'dynamic'       => array( 'active' => true ),
				'description'   => esc_html__( 'You can copy the address from Google Maps. This will create a link to show the address on the map.', 'anky' ),
				'default'       => array(
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( $this->name . '_email_link' );
		$this->add_link_attributes( $this->name . '_email_link', $settings[ $this->name . '_email_link' ] );
		$this->add_render_attribute( $this->name . '_email_link', 'href', 'mailto:' . $settings[ $this->name . '_email_link' ]['url'], true );
		$this->add_render_attribute( $this->name . '_email_link', 'class', 'anky-contacts-email-link' );

		$this->add_inline_editing_attributes( $this->name . '_tel_num_link' );
		$this->add_link_attributes( $this->name . '_tel_num_link', $settings[ $this->name . '_tel_num_link' ] );
		$this->add_render_attribute( $this->name . '_tel_num_link', 'href', 'tel:' . $settings[ $this->name . '_tel_num_link' ]['url'], true );
		$this->add_render_attribute( $this->name . '_tel_num_link', 'class', 'anky-contacts-tel-num-link' );

		$this->add_inline_editing_attributes( $this->name . '_address_link' );
		$this->add_link_attributes( $this->name . '_address_link', $settings[ $this->name . '_address_link' ] );
		$this->add_render_attribute( $this->name . '_address_link', 'class', 'anky-contacts-address-link' );
		$this->add_render_attribute( $this->name . '_address_link', 'href', '//www.google.com/maps/place/' . $settings[ $this->name . '_address_link' ]['url'], true );
		?>
		<div class="anky-contacts-widget-block-parent">
			<div class="anky-contacts-widget-block">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php $this->render_media_image( $settings, $this->name . '_image', 'anky-contacts-logo-link' ); ?></a>
			</div>
			<div class="anky-contacts-widget-block">
				<a <?php $this->print_render_attribute_string( $this->name . '_email_link' ); ?>><?php echo esc_html( $settings[ $this->name . '_email_link' ]['url'] ); ?></a>
			</div>
			<div class="anky-contacts-widget-block">
				<a <?php $this->print_render_attribute_string( $this->name . '_tel_num_link' ); ?>><?php echo esc_html( $settings[ $this->name . '_tel_num_link' ]['url'] ); ?></a>
			</div>
			<div class="anky-contacts-widget-block">
				<a <?php $this->print_render_attribute_string( $this->name . '_address_link' ); ?>><?php echo esc_html( $settings[ $this->name . '_address_link' ]['url'] ); ?></a>
			</div>
		</div>
		<?php
	}

	/**
	 * Render element output in the editor.
	 *
	 * Used to generate the live preview, using a Backbone JavaScript template.
	 */
	protected function content_template() {
		?>
		<#
		var name = '<?php echo esc_html( $this->name ); ?>',
		emailKey = name + '_email_link',
		telKey = name + '_tel_num_link',
		logoKey = name + '_image',
		addressKey = name + '_address_link';

		view.addInlineEditingAttributes( logoKey, 'none' );
		view.addRenderAttribute( logoKey, { 'class': [ 'anky-contacts-logo-link' ] } );

		view.addInlineEditingAttributes( emailKey, 'none' );
		view.addRenderAttribute( emailKey, { 'class': [ 'anky-contacts-email-link' ] } );

		view.addInlineEditingAttributes( telKey, 'none' );
		view.addRenderAttribute( telKey, { 'class': [ 'anky-contacts-tel-num-link' ] } );

		view.addInlineEditingAttributes( 'address_link', 'none' );
		view.addRenderAttribute( 'address_link', { 'class': [ 'anky-contacts-address-link' ] } );
		#>
		<div class="anky-contacts-widget-block-parent">
			<div class="anky-contacts-widget-block">
				<img src="{{{ settings[logoKey].url }}}" {{{ view.getRenderAttributeString( logoKey ) }}}>
			</div>
			<div class="anky-contacts-widget-block">
				<a href=mailto:"{{{ settings[emailKey].url }}}" {{{ view.getRenderAttributeString( emailKey ) }}}>{{{ settings[emailKey].url }}}</a>
			</div>
			<div class="anky-contacts-widget-block">
				<a href=tel:"{{{ settings[telKey].url }}}" {{{ view.getRenderAttributeString( telKey ) }}}>{{{ settings[telKey].url }}}</a>
			</div>
			<div class="anky-contacts-widget-block">
				<a href=//www.google.com/maps/place/"{{{ settings[addressKey].url }}}" {{{ view.getRenderAttributeString( addressKey ) }}}> {{{ settings[addressKey].url }}}</a>
			</div>
		</div>
		<?php
	}

}
