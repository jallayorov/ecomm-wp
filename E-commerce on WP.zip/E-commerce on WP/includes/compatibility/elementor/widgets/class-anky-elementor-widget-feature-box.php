<?php
/**
 * Anky Theme Elementor Feature Box Widget.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Feature Box Widget.
 */
class Anky_Elementor_Widget_Feature_Box extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_feature_box';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return __( 'Feature box', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-featured-image';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the widget keywords.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'feature', 'features', 'box', 'feature-box', 'feature box' );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'lottie', 'anky-lottie-init' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 */
	protected function register_controls() {
		$this->add_box_layout_settings();
		$this->add_feature_list_settings();
		$this->add_media_content_settings();

		$this->add_container_style_controls();
		$this->add_feature_list_box_style_controls();
		$this->add_intro_content_style_controls();
		$this->add_feature_list_style_settings();
		$this->add_media_content_style_settings();
	}

	/**
	 * Register controls.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Bail early.
		if ( ! $settings[ $this->name . '_list' ] ) {
			return;
		}
		$this->add_inline_editing_attributes( $this->name . '_list_intro_title', 'none' );
		$this->add_render_attribute( $this->name . '_list_intro_title', 'class', array( 'anky-feature-box-intro-title' ) );

		$this->add_inline_editing_attributes( $this->name . '_list_intro_text', 'none' );
		$this->add_render_attribute( $this->name . '_list_intro_text', 'class', array( 'anky-feature-box-intro-text' ) );

		$container_classes = array(
			'anky-feature-box-section',
			"anky-feature-box-{$settings[$this->name.'_skin']}",
			"anky-feature-box-{$settings[$this->name.'_icon_position']}",
		);
		?>
		<div class="<?php echo esc_attr( implode( ' ', $container_classes ) ); ?>">

			<?php
			if ( in_array( $settings[ $this->name . '_skin' ], array( 'skin-3', 'skin-6' ), true ) ) {
				if ( ! empty( $settings[ $this->name . '_list_intro_title' ] ) ) {
					printf( '<h2 %s>%s</h2>', wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_title' ) ), esc_html( $settings[ $this->name . '_list_intro_title' ] ) );
				}
				printf( '<p %s>%s</p>', wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_text' ) ), esc_html( $settings[ $this->name . '_list_intro_text' ] ) );
			}

			if ( 'skin-5' === $settings[ $this->name . '_skin' ] ) {
				printf(
					'<h2 class="anky-feature-box-section-title"><span %1$s>%2$s</span> <span %3$s>%4$s</span></h2>',
					wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_title' ) ),
					esc_html( $settings[ $this->name . '_list_intro_title' ] ),
					wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_text' ) ),
					esc_html( $settings[ $this->name . '_list_intro_text' ] )
				);
			}
			?>

			<ul class="anky-feature-box-list anky-list-unstyled">
				<?php
				if ( 'skin-4' === $settings[ $this->name . '_skin' ] ) {
					echo '<li class="anky-feature-box-list-item anky-feature-box-list-item-title">';
					printf( '<h2 %s>%s</h2>', wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_title' ) ), esc_html( $settings[ $this->name . '_list_intro_title' ] ) );
					printf( '<p %s>%s</p>', wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_text' ) ), esc_html( $settings[ $this->name . '_list_intro_text' ] ) );
					echo '</li>';
				}
				if ( 'skin-6' === $settings[ $this->name . '_skin' ] ) {
					echo '<li class="anky-feature-box-list-item anky-feature-box-list-item-title">';
					printf(
						'<h2 class="anky-feature-box-section-title"><span %1$s>%2$s</span> <span %3$s>%4$s</span></h2>',
						wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_title' ) ),
						esc_html( $settings[ $this->name . '_list_intro_title' ] ),
						wp_kses_post( $this->get_render_attribute_string( $this->name . '_list_intro_text' ) ),
						esc_html( $settings[ $this->name . '_list_intro_text' ] )
					);
					echo '</li>';
				}
				?>
				<?php foreach ( $settings[ $this->name . '_list' ] as $i => $feature_item ) : ?>
					<li class="anky-feature-box-list-item elementor-repeater-item-<?php echo esc_attr( $feature_item['_id'] ); ?>">
						<?php
						// Icon saving.
						if ( 'skin-5' === $settings[ $this->name . '_skin' ] ) :
							$icon = '';
						else :
							ob_start();
							if ( 'icon' === $feature_item[ $this->name . '_list_item_icon_type' ] ) :
								// Icon.
								$icon_new      = empty( $feature_item[ $this->name . '_list_item_icon' ] ) && Icons_Manager::is_migration_allowed();
								$icon_migrated = isset( $feature_item['__fa4_migrated'][ $this->name . '_list_item_icon_updated' ] );

								if ( $icon_new || $icon_migrated ) {
									if ( 'svg' === $feature_item[ $this->name . '_list_item_icon_updated' ]['library'] ) {
										echo '<div class="anky-feature-box-list-icon">';
									}
									Icons_Manager::render_icon(
										$feature_item[ $this->name . '_list_item_icon_updated' ],
										array(
											'class'       => 'anky-feature-box-list-icon',
											'aria-hidden' => 'true',
										),
										'span'
									);
									if ( 'svg' === $feature_item[ $this->name . '_list_item_icon_updated' ]['library'] ) {
										echo '</div>';
									}
								} else {
									printf( '<span class="anky-feature-box-list-icon %s" aria-hidden="true"></span>', esc_attr( $feature_item[ $this->name . '_list_item_icon' ] ) );
								}// is_new|migrated.
							elseif ( 'animation' === $feature_item[ $this->name . '_list_item_icon_type' ] ) :
								// Animation.
								$lottie_key = $this->name . '_list_item_lottie' . $i;
								$this->add_render_attribute(
									$lottie_key,
									array(
										'class'               => array( 'anky-feature-box-list-icon', 'anky-lottie-animation' ),
										'data-lottie-url'     => $feature_item[ $this->name . '_list_item_lottie_url' ],
										'data-lottie-loop'    => $feature_item[ $this->name . '_list_item_lottie_loop' ],
										'data-lottie-reverse' => $feature_item[ $this->name . '_list_item_lottie_reverse' ],
									)
								);
								printf( '<div %s></div>', wp_kses_post( $this->get_render_attribute_string( $lottie_key ) ) );
							elseif ( 'image' === $feature_item[ $this->name . '_list_item_icon_type' ] ) :
								// Image.
								$this->render_media_image( $feature_item, $this->name . '_list_item_image', 'anky-feature-box-list-img' );
							// Number.
							elseif ( 'number' === $feature_item[ $this->name . '_list_item_icon_type' ] ) :
								printf( '<span class="anky-feature-box-list-icon anky-feature-box-list-icon-number" aria-hidden="true">%s</span>', esc_html( $i + 1 ) );
							endif;
							$icon = ob_get_clean();
						endif; //$this->name. _skin.
						if ( 'card_top' === $settings[ $this->name . '_icon_position' ] ) {
							echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput
						}
						?>

						<div class="anky-feature-box-text-wrap">
							<div class="anky-feature-box-title-content">
								<?php
								if ( 'title_in' === $settings[ $this->name . '_icon_position' ] ) {
									echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput
								}
								?>
								<?php $this->render_feature_title( $feature_item, $i ); ?>
							</div>
							<div class="anky-feature-box-content">
								<?php
								$content_setting_key = $this->get_repeater_setting_key( $this->name . '_list_item_text', $this->name . '_list', $i );
								$this->add_inline_editing_attributes( $content_setting_key );
								$this->add_render_attribute( $content_setting_key, 'class', 'anky-feature-box-content' );
								?>

								<p <?php $this->print_render_attribute_string( $content_setting_key ); ?>><?php echo esc_html( $feature_item[ $this->name . '_list_item_text' ] ); ?></p>

								<?php
								if ( 'content_out' === $settings[ $this->name . '_icon_position' ] ) {
									echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput
								}
								?>
							</div>
						</div>
						<?php
						if ( 'card_bottom' === $settings[ $this->name . '_icon_position' ] ) {
							echo '<div class="anky-feature-box-item-illustration">';
							echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput
							echo '</div>';
						}
						?>
					</li>
				<?php endforeach; ?>
			</ul>
			<?php
			if ( ! in_array( $settings[ $this->name . '_skin' ], array( 'skin-3', 'skin-4' ), true ) ) {
				echo '<div class="anky-feature-box-media">';
				if ( 'image' === $settings[ $this->name . '_media_type' ] ) {
					// Show placeholder only for editor mode.
					if ( empty( $settings[ $this->name . '_media_image' ]['id'] ) && Plugin::$instance->editor->is_edit_mode() ) {
						$settings[ $this->name . '_media_image' ]['url'] = Utils::get_placeholder_image_src();
						echo wp_kses_post(
							str_replace(
								'alt=""',
								'alt="" class="anky-feature-box-media-img"',
								Group_Control_Image_Size::get_attachment_image_html(
									$settings,
									$this->name . '_media_image',
									$this->name . '_media_image'
								)
							)
						);
					} elseif ( ! empty( $settings[ $this->name . '_media_image' ]['id'] ) ) {
						// Print only if there is an image.
						echo wp_kses_post(
							str_replace(
								'class="',
								'class="anky-feature-box-media-img ',
								Group_Control_Image_Size::get_attachment_image_html(
									$settings,
									$this->name . '_media_image',
									$this->name . '_media_image'
								)
							)
						);
					}
				} elseif ( 'animation' === $settings[ $this->name . '_media_type' ] ) {
					if ( ! empty( $settings[ $this->name . '_media_lottie_url' ] ) ) {
						$this->add_render_attribute(
							$this->name . '_media_lottie',
							array(
								'class'               => array(
									'anky-feature-box-media-lottie',
									'anky-lottie-animation',
								),
								'data-lottie-url'     => $settings[ $this->name . '_media_lottie_url' ],
								'data-lottie-loop'    => $settings[ $this->name . '_media_lottie_loop' ],
								'data-lottie-reverse' => $settings[ $this->name . '_media_lottie_reverse' ],
							)
						);
						printf( '<div %s></div>', wp_kses_post( $this->get_render_attribute_string( $this->name . '_media_lottie' ) ) );
					}
				}
				echo '</div>';
			}
			?>
		</div>
		<?php
	}

	// ======================================================
	// PRIVATE - Helper
	// ======================================================

	/**
	 * Render correct feature title.
	 * Renders the feature title as a simple text or with first highlighted word.
	 *
	 * @param array $item  Required. Current repeater item.
	 * @param int   $index Optional. Repeater item index.
	 */
	private function render_feature_title( $item, $index = 0 ) {
		$title_setting_key = $this->get_repeater_setting_key( $this->name . '_list_item_title', $this->name . '_list', $index );
		$this->add_inline_editing_attributes( $title_setting_key, 'none' );
		$this->add_render_attribute( $title_setting_key, 'class', 'anky-feature-box-title' );

		$title_html = '<h3 ' . $this->get_render_attribute_string( $title_setting_key ) . '>' . $item[ $this->name . '_list_item_title' ];

		if ( $item[ $this->name . '_list_item_highlight_title' ] ) {
			$words_arr  = explode( ' ', trim( $item[ $this->name . '_list_item_title' ] ) );
			$title_html = str_replace( $words_arr[0], '<span class="anky-feature-title-highlight">' . $words_arr[0] . '</span>', $title_html );
		}

		$title_html .= '</h3>';

		echo wp_kses_post( $title_html );
	}

	// ======================================================
	// PRIVATE - Content Settings
	// ======================================================

	/**
	 * Add Text settings fields to Content tab.
	 */
	private function add_box_layout_settings() {
		$this->start_controls_section(
			$this->name . '_general_settings',
			array(
				'label' => __( 'Display Settings', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_skin',
			array(
				'label'   => __( 'Skin', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'skin-1',
				'options' => array(
					'skin-1' => __( 'Skin 1', 'anky' ),
					'skin-2' => __( 'Skin 2', 'anky' ),
					'skin-3' => __( 'Skin 3', 'anky' ),
					'skin-4' => __( 'Skin 4', 'anky' ),
					'skin-5' => __( 'Skin 5', 'anky' ),
					'skin-6' => __( 'Skin 6', 'anky' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_icon_position',
			array(
				'label'   => __( 'Icon Position', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'card_top',
				'options' => array(
					'card_top'    => __( 'Card Top', 'anky' ),
					'title_in'    => __( 'Inside Title', 'anky' ),
					'content_out' => __( 'After content', 'anky' ),
					'card_bottom' => __( 'Card bottom', 'anky' ),
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Feature List settings repeater field to Content tab.
	 */
	private function add_feature_list_settings() {
		$this->start_controls_section(
			$this->name . '_list_section',
			array(
				'label' => __( 'Features Content', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_list_intro_title',
			array(
				'label'       => __( 'Intro title', 'anky' ),
				'default'     => __( 'Anky Agency', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
				'condition'   => array(
					$this->name . '_skin!' => array( 'skin-1', 'skin-2' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_list_intro_text',
			array(
				'label'       => __( 'Intro text', 'anky' ),
				'default'     => __( 'We provide a range of services delivering high-end products', 'anky' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
				'condition'   => array(
					$this->name . '_skin!' => array( 'skin-1', 'skin-2' ),
				),
			)
		);

		$repeater = new Repeater();

		/**
		 * Icon.
		 */
		$repeater->add_control(
			$this->name . '_list_item_icon_type',
			array(
				'label'   => __( 'Icon Type', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'icon'      => __( 'Icon', 'anky' ),
					'animation' => __( 'Lottie Animation', 'anky' ),
					'number'    => __( 'Count', 'anky' ),
					'image'     => __( 'Image', 'anky' ),
				),
				'default' => 'icon',
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_icon_updated',
			array(
				'label'            => __( 'Icon', 'anky' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => $this->name . '_list_item_icon',
				'default'          => array(
					'value'   => 'fas fa-pencil-alt',
					'library' => 'fa-solid',
				),
				'condition'        => array( $this->name . '_list_item_icon_type' => 'icon' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_image',
			array(
				'label'     => __( 'Choose Image', 'anky' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array( 'url' => Utils::get_placeholder_image_src() ),
				'condition' => array( $this->name . '_list_item_icon_type' => 'image' ),
			)
		);
		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_list_item_image',
				'default'   => 'thumbnail',
				'condition' => array( $this->name . '_list_item_icon_type' => 'image' ),
				'separator' => 'none',
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_lottie_url',
			array(
				'label'       => __( 'Animation JSON URL', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'description' => sprintf(
				/* translators: 1: Opening link tag, 2: Closing link tag*/
					__( 'Paste JSON URL code from %1$s official website %2$s', 'anky' ),
					'<a href="https://lottiefiles.com/" target="_blank">',
					'</a>'
				),
				'label_block' => true,
				'condition'   => array( $this->name . '_list_item_icon_type' => 'animation' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_lottie_loop',
			array(
				'label'        => __( 'Loop', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'default'      => 'true',
				'condition'    => array( $this->name . '_list_item_icon_type' => 'animation' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_lottie_reverse',
			array(
				'label'        => __( 'Reverse', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'condition'    => array( $this->name . '_list_item_icon_type' => 'animation' ),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_icon_color',
			array(
				'label'     => __( 'Icon Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array( $this->name . '_list_item_icon_type' => array( 'icon', 'number' ) ),
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .anky-feature-box-list-icon' => 'color: {{VALUE}};',
				),
			)
		);

		/**
		 * Title.
		 */
		$repeater->add_control(
			$this->name . '_list_item_title',
			array(
				'label'       => __( 'Title', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'default'     => __( 'Enter Something Unique', 'anky' ),
				'placeholder' => __( 'Enter desired title', 'anky' ),
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_highlight_title',
			array(
				'label'        => __( 'Highlight the first word?', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'description'  => __( 'Highlight the first word or words (must be combined by unbroken `-` symbol).', 'anky' ),
				'return_value' => '1',
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_title_color',
			array(
				'label'     => __( 'Title Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .anky-feature-box-title' => 'color: {{VALUE}};',
				),
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_title_highlight_color',
			array(
				'label'     => __( 'Title highlight color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array( $this->name . '_list_item_highlight_title' => '1' ),
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .anky-feature-title-highlight' => 'color: {{VALUE}};',
				),
			)
		);

		/**
		 * Content.
		 */
		$repeater->add_control(
			$this->name . '_list_item_text',
			array(
				'label'       => __( 'Text', 'anky' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => __( 'Our UX & UI experts produce a unique design specifically for a particular app', 'anky' ),
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_text_color',
			array(
				'label'     => __( 'Text Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} {{CURRENT_ITEM}} .anky-feature-box-content p' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			$this->name . '_list',
			array(
				'label'   => __( 'Features', 'anky' ),
				'type'    => Controls_Manager::REPEATER,
				'default' => array(
					array(
						$this->name . '_list_item_icon_updated' => array(
							'value'   => 'fas fa-pen-nib',
							'library' => 'fa-solid',
						),
						$this->name . '_list_item_title'        => __( 'Unique design', 'anky' ),
						$this->name . '_list_item_text'         => __( 'Our UX & UI experts produce a unique design specifically for a particular app', 'anky' ),
					),
					array(
						$this->name . '_list_item_icon_updated' => array(
							'value'   => 'fas fa-code',
							'library' => 'fa-solid',
						),
						$this->name . '_list_item_title'        => __( 'High-end development', 'anky' ),
						$this->name . '_list_item_text'         => __( 'The development team in the agency is eager to develop high-end products', 'anky' ),
					),
					array(
						$this->name . '_list_item_icon_updated' => array(
							'value'   => 'fas fa-rocket',
							'library' => 'fa-solid',
						),
						$this->name . '_list_item_title'        => __( 'High-performance apps', 'anky' ),
						$this->name . '_list_item_text'         => __( 'We are focused on developing apps with superior performance', 'anky' ),
					),
				),
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ elementor.helpers.renderIcon( this, anky_feature_box_list_item_icon_updated, { }, "i", "panel" ) || \'<span class="{{ anky_feature_box_list_item_icon }}" aria-hidden="true"></span>\' }}} {{{ anky_feature_box_list_item_title || anky_feature_box_list_item_text }}}',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Media illustration content to Content tab.
	 */
	private function add_media_content_settings() {
		$this->start_controls_section(
			$this->name . '_media_section',
			array(
				'label'     => __( 'Media Content', 'anky' ),
				'condition' => array(
					$this->name . '_skin!' => array( 'skin-3', 'skin-4' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_media_type',
			array(
				'label'   => __( 'Media Type', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'animation' => __( 'Lottie Animation', 'anky' ),
					'image'     => __( 'Image', 'anky' ),
				),
				'default' => 'image',
			)
		);
		$this->add_control(
			$this->name . '_media_image',
			array(
				'label'       => __( 'Choose Image', 'anky' ),
				'type'        => Controls_Manager::MEDIA,
				'description' => __( 'NOTE: By keeping this field empty, during editing, you will see an image placeholder that will not be shown after publishing', 'anky' ),
				'default'     => array( 'url' => Utils::get_placeholder_image_src() ),
				'condition'   => array( $this->name . '_media_type' => 'image' ),
			)
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_media_image',
				'default'   => 'medium',
				'condition' => array( $this->name . '_media_type' => 'image' ),
				'separator' => 'none',
			)
		);

		$this->add_control(
			$this->name . '_media_lottie_url',
			array(
				'label'       => __( 'Animation JSON URL', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'description' => sprintf(
				/* translators: 1: Opening link tag, 2: Closing link tag*/
					__( 'Paste JSON URL code from %1$s official website %2$s', 'anky' ),
					'<a href="https://lottiefiles.com/" target="_blank">',
					'</a>'
				),
				'label_block' => true,
				'condition'   => array( $this->name . '_media_type' => 'animation' ),
			)
		);
		$this->add_control(
			$this->name . '_media_lottie_loop',
			array(
				'label'        => __( 'Loop', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'default'      => 'true',
				'condition'    => array( $this->name . '_media_type' => 'animation' ),
			)
		);
		$this->add_control(
			$this->name . '_media_lottie_reverse',
			array(
				'label'        => __( 'Reverse', 'anky' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'true',
				'condition'    => array( $this->name . '_media_type' => 'animation' ),
			)
		);
		$this->end_controls_section();
	}

	// ======================================================
	// PRIVATE - Style Settings
	// ======================================================

	/**
	 * Add Container Wrapper Specific style controls.
	 */
	private function add_container_style_controls() {
		$this->start_controls_section(
			$this->name . '_container_style_settings',
			array(
				'label' => __( 'Container', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_container_border',
				'selector' => '{{WRAPPER}} .anky-feature-box-section',
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-section' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => $this->name . '_container_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .anky-feature-box-section',
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'label'    => __( 'Shadow', 'anky' ),
				'name'     => $this->name . '_container_container_shadow',
				'selector' => '{{WRAPPER}} .anky-feature-box-section',
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'    => 20,
					'right'  => 20,
					'bottom' => 20,
					'left'   => 20,
					'unit'   => $this->default_size_units[0],
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Features list wrapper Specific style controls.
	 */
	private function add_feature_list_box_style_controls() {
		$this->start_controls_section(
			$this->name . '_list_box_item_style_settings',
			array(
				'label' => __( 'Feature List', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->start_controls_tabs( $this->name . '_list_box_style_tabs' );

		$this->start_controls_tab(
			$this->name . '_list_box_wrapper',
			array(
				'label' => __( 'Container', 'anky' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_box_wrapper_wrap',
			array(
				'label'     => __( 'Wrap', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'no-wrap' => array(
						'title' => __( 'No Wrap', 'anky' ),
						'icon'  => 'eicon-editor-close',
					),
					'wrap'    => array(
						'title' => __( 'Wrap', 'anky' ),
						'icon'  => 'eicon-text-align-left',
					),
				),
				'default'   => 'no-wrap',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-list' => 'flex-wrap: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_list_box_wrapper_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start'    => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'        => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'      => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
					'space-between' => array(
						'title' => __( 'Space between', 'anky' ),
						'icon'  => 'eicon-h-align-stretch',
					),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-list' => 'justify-content: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_list_box_wrapper_vertical_horizontal',
			array(
				'label'     => __( 'Vertical Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Top', 'anky' ),
						'icon'  => 'eicon-v-align-top',
					),
					'center'     => array(
						'title' => __( 'Middle', 'anky' ),
						'icon'  => 'eicon-v-align-middle',
					),
					'flex-end'   => array(
						'title' => __( 'Bottom', 'anky' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-list' => 'align-items: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_box_item_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_box_item_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_list_item_wrapper',
			array(
				'label' => __( 'Item', 'anky' ),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_list_item_border',
				'selector' => '{{WRAPPER}} .anky-feature-box-list-item:not(.anky-feature-box-list-item-title)',
			)
		);
		$this->add_control(
			$this->name . '_list_item_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-item:not(.anky-feature-box-list-item-title)' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => $this->name . '_list_item_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .anky-feature-box-list-item:not(.anky-feature-box-list-item-title)',
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_item_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'separator'  => 'before',
				'default'    => array(
					'unit' => '%',
					'size' => 30,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-item' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_item_spacing',
			array(
				'label'      => __( 'Item spacing', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 32,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-skin-1 .anky-feature-box-list-item:not(:last-child), {{WRAPPER}} .anky-feature-box-skin-3 .anky-feature-box-list-item:not(:last-child), {{WRAPPER}} .anky-feature-box-skin-4 .anky-feature-box-list-item'                  => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .anky-feature-box-skin-2 .anky-feature-box-list-item:not(:last-child), {{WRAPPER}} .anky-feature-box-skin-5 .anky-feature-box-list-item:not(:last-child), {{WRAPPER}} .anky-feature-box-skin-6 .anky-feature-box-list-item:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_item_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-item:not(.anky-feature-box-list-item-title)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_item_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 64,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Add Features Intro content Specific style controls.
	 */
	private function add_intro_content_style_controls() {
		$this->start_controls_section(
			$this->name . '_intro_style_settings',
			array(
				'label'     => __( 'Intro content', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( $this->name . '_skin!' => array( 'skin-1', 'skin-2' ) ),
			)
		);
		$this->start_controls_tabs( $this->name . '_intro_style_tabs' );

		$this->start_controls_tab(
			$this->name . '_intro_title_tab',
			array( 'label' => __( 'Title', 'anky' ) )
		);
		$this->add_typography_control_style_part( "{$this->name}_intro_title", '.anky-feature-box-intro-title', '#16161A', $this->default_heading_typography );
		$this->add_responsive_control(
			$this->name . '_intro_title_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'start'  => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'end'    => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'separator' => 'before',
				'default'   => 'start',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-intro-title' => 'text-align: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_title_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-intro-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array( $this->name . '_skin!' => array( 'skin-5', 'skin-6' ) ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_title_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 24,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'condition'  => array( $this->name . '_skin!' => array( 'skin-5', 'skin-6' ) ),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-intro-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_intro_content_tabs',
			array( 'label' => __( 'Content', 'anky' ) )
		);
		$this->add_typography_control_style_part( "{$this->name}_intro_content", '.anky-feature-box-intro-text', '#7E7E83' );
		$this->add_responsive_control(
			$this->name . '_intro_text_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'separator' => 'before',
				'options'   => array(
					'start'  => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'end'    => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'start',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-intro-text' => 'text-align: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_content_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'condition'  => array( $this->name . '_skin!' => array( 'skin-5', 'skin-6' ) ),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-intro-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_content_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 24,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'condition'  => array( $this->name . '_skin!' => array( 'skin-5', 'skin-6' ) ),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-intro-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			$this->name . '_intro_content_common_heading',
			array(
				'label'     => __( 'Spacings', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => array( $this->name . '_skin' => array( 'skin-5', 'skin-6' ) ),
				'separator' => 'before',
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_content_common_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'condition'  => array( $this->name . '_skin' => array( 'skin-5', 'skin-6' ) ),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_intro_content_common_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 24,
					'left'     => 0,
					'unit'     => $this->default_size_units[0],
					'isLinked' => true,
				),
				'condition'  => array( $this->name . '_skin' => array( 'skin-5', 'skin-6' ) ),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Feature List Items styler controls.
	 */
	private function add_feature_list_style_settings() {
		$this->start_controls_section(
			$this->name . '_collection_list_style_settings',
			array(
				'label' => __( 'Features content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->start_controls_tabs( $this->name . '_collection_list_style_tabs' );

		/**
		 * Title.
		 */
		$this->start_controls_tab(
			$this->name . '_collection_list_title_tab',
			array(
				'label' => __( 'Title', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_collection_list_title_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-title' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_collection_list_title_highlight_color',
			array(
				'label'     => __( 'Title highlight color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7E7E83',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-title-highlight' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => $this->name . '_collection_list_title_typography',
				'selector'       => '{{WRAPPER}} .anky-feature-box-title, {{WRAPPER}} .anky-feature-title-highlight',
				'separator'      => 'after',
				'fields_options' => $this->default_small_heading_typography,
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_title_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'     => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'   => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-title-content' => 'justify-content: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_collection_list_title_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_collection_list_title_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		/**
		 * Content.
		 */
		$this->start_controls_tab(
			$this->name . '_collection_list_content_tab',
			array(
				'label' => __( 'Content', 'anky' ),
			)
		);
		$this->add_typography_control_style_part( "{$this->name}_collection_list_content", '.anky-feature-box-content p', '#7E7E83' );
		$this->add_responsive_control(
			$this->name . '_content_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'separator' => 'before',
				'options'   => array(
					'start'  => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'end'    => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'start',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-content p' => 'text-align: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_collection_list_content_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_collection_list_content_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		/**
		 * Icons.
		 */
		$this->start_controls_tab(
			$this->name . '_collection_list_icon_tab',
			array(
				'label'     => __( 'Icon', 'anky' ),
				'condition' => array( $this->name . '_skin!' => 'skin-5' ),
			)
		);
		$this->add_control(
			$this->name . '_collection_list_icon_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-list-icon'                                           => 'color: {{VALUE}};',
					'{{WRAPPER}}  .anky-feature-box-list-icon:not(.anky-lottie-animation) svg path' => 'fill: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => $this->name . '_collection_list_icon_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .anky-feature-box-list-icon',
			)
		);
		$this->add_responsive_control(
			$this->name . '_collection_list_icon_size',
			array(
				'label'      => __( 'Size', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'default'    => array(
					'unit' => $this->default_size_units[0],
					'size' => 18,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-icon'     => 'font-size: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .anky-feature-box-list-img'      => 'width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .anky-feature-box-list-icon svg' => 'width: {{SIZE}}{{UNIT}} !important; height: {{SIZE}}{{UNIT}} !important',
				),
			)
		);
		$this->add_control(
			$this->name . '_collection_list_icon_counter_note',
			array(
				'label'     => __( 'Counter', 'anky' ),
				'type'      => Controls_Manager::RAW_HTML,
				'separator' => 'before',
				'raw'       => '<p><i>' . __( 'NOTE: the following controls will apply only to counter icon element', 'anky' ) . '</i></p>',
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'label'          => __( 'Counter Typography', 'anky' ),
				'name'           => $this->name . '_collection_list_icon_counter_typography',
				'selector'       => '{{WRAPPER}} .anky-feature-box-list-icon-number',
				'fields_options' => $this->default_small_heading_typography,
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'label'    => __( 'Counter Background', 'anky' ),
				'name'     => $this->name . '_collection_list_icon_counter_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .anky-feature-box-list-icon-number',
			)
		);
		$this->add_responsive_control(
			$this->name . '_list_item_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'separator' => 'before',
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'     => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'   => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-list-item' => 'align-items: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => $this->name . '_collection_list_icon_border',
				'selector'       => '{{WRAPPER}} .anky-feature-box-list-icon',
				'fields_options' => array(
					'border' => array( 'default' => 'solid' ),
					'width'  => array(
						'default' => array(
							'top'    => 1,
							'right'  => 1,
							'bottom' => 1,
							'left'   => 1,
							'unit'   => 'px',
						),
					),
					'color'  => array( 'default' => '#E0E0E0' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_collection_list_icon_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => '%',
					'size' => 50,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-icon, {{WRAPPER}} .anky_feature-box-list-icon' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_collection_list_icon_padding',
			array(
				'label'       => __( 'Padding', 'anky' ),
				'type'        => Controls_Manager::DIMENSIONS,
				'description' => __( 'NOTE: Not applicable to images', 'anky' ),
				'size_units'  => $this->default_size_units,
				'default'     => array(
					'top'    => 18,
					'right'  => 18,
					'bottom' => 18,
					'left'   => 18,
					'unit'   => $this->default_size_units[0],
				),
				'selectors'   => array(
					'{{WRAPPER}} .anky-feature-box-list-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_collection_list_icon_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-list-icon, {{WRAPPER}} .anky-feature-box-list-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Add media_content style controls.
	 */
	private function add_media_content_style_settings() {
		$this->start_controls_section(
			$this->name . '_media_content_style_settings',
			array(
				'label'     => __( 'Media Content', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( $this->name . '_skin!' => array( 'skin-3', 'skin-4' ) ),
			)
		);

		$this->add_responsive_control(
			$this->name . '_media_content_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 1200,
					),
					'%'  => array(
						'min' => 0,
						'max' => 200,
					),
					'em' => array(
						'min' => 0,
						'max' => 18,
					),
				),
				'default'    => array(
					'size' => 400,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-media svg' => 'width: {{SIZE}}{{UNIT}} !important;',
					'{{WRAPPER}} .anky-feature-box-media img' => 'width: {{SIZE}}{{UNIT}} !important',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_media_content_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 1800,
					),
					'%'  => array(
						'min' => 0,
						'max' => 300,
					),
					'em' => array(
						'min' => 0,
						'max' => 24,
					),
				),
				'default'    => array(
					'size' => 100,
					'unit' => '%',
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-media svg' => 'height: {{SIZE}}{{UNIT}} !important',
					'{{WRAPPER}} .anky-feature-box-media img' => 'height: {{SIZE}}{{UNIT}} !important',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_media_content_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'     => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'   => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'center',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-media' => 'justify-content: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_media_content_object_fit',
			array(
				'label'     => __( 'Object fit', 'anky' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => array(
					'cover'      => __( 'Cover', 'anky' ),
					'contain'    => __( 'Contain', 'anky' ),
					'fill'       => __( 'Fill', 'anky' ),
					'auto'       => __( 'Auto', 'anky' ),
					'scale-down' => __( 'Scale down', 'anky' ),
					'inherit'    => __( 'Inherit', 'anky' ),
				),
				'default'   => 'auto',
				'selectors' => array(
					'{{WRAPPER}} .anky-feature-box-media img' => 'object-fit: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_media_content_border_radius',
			array(
				'label'      => __( 'Border radius', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->position_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-media img, {{WRAPPER}} .anky-feature-box-media svg' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_media_content_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-feature-box-media' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

}
