<?php
/**
 * Anky Theme Elementor Widget for displaying Testimonials.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 *
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Utils;


// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Elementor Widget for displaying Testimonials.
 */
class Anky_Elementor_Widget_Testimonials extends Anky_Elementor_Widget_Base {

	/**
	 * Name of the widget.
	 *
	 * @var string
	 * @aceces private
	 */
	private $name = 'anky_testimonials';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Get element name.
	 *
	 * Retrieve the element name.
	 *
	 * @return string The name.
	 */
	public function get_name() {
		return $this->name;
	}

	/**
	 * Get element title.
	 *
	 * Retrieve the element title.
	 *
	 * @return string Element title.
	 */
	public function get_title() {
		return esc_html__( 'Anky Testimonials', 'anky' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the widget categories.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( Anky_Elementor_Extension::$widget_group );
	}

	/**
	 * Get script dependencies.
	 *
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @return array Element scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'anky-widget-slider' );
	}

	// ======================================================
	// PROTECTED
	// ======================================================

	/**
	 * Register controls.
	 */
	protected function register_controls() {
		$this->add_box_layout_settings();
		$this->add_testimonials_list_settings();

		$this->add_testimonial_item_container_style_controls();
		$this->add_intro_content_style_controls();
		$this->add_testimonials_content_style_controls();
		$this->add_author_style_controls();
		$this->add_slider_style_controls();
	}

	/**
	 * Render element.
	 *
	 * Generates the final HTML on the frontend.
	 */
	protected function render() {
		$settings    = $this->get_settings_for_display();
		$is_slider   = in_array( $settings[ $this->name . '_skin' ], array( 'skin_2', 'skin_3', 'skin_5', 'skin_6' ), true );
		$skin_method = "render_{$settings[$this->name .'_skin']}";
		?>
		<div class="anky-testimonials-section anky-testimonials-<?php echo esc_attr( $settings[ $this->name . '_skin' ] ); ?>">

			<?php
			if ( ! in_array( $settings[ $this->name . '_skin' ], array( 'skin_1', 'skin_3' ), true ) ) {
				$this->add_inline_editing_attributes( $this->name . '_intro_title', 'none' );
				$this->add_render_attribute( $this->name . '_intro_title', 'class', 'anky-testimonials-section-title' );
				$this->add_inline_editing_attributes( $this->name . '_intro_text' );
				$this->add_render_attribute( $this->name . '_intro_text', 'class', 'anky-testimonials-section-subtitle' );

				// Avoid printing empty heading for frontend.
				if ( Plugin::$instance->editor->is_edit_mode() ) {
					echo wp_kses_post( '<h2 ' . $this->get_render_attribute_string( $this->name . '_intro_title' ) . '>' . $settings[ $this->name . '_intro_title' ] . '</h2>' );
				} elseif ( ! empty( $settings[ $this->name . '_intro_title' ] ) ) {
					echo wp_kses_post( '<h2 ' . $this->get_render_attribute_string( $this->name . '_intro_title' ) . '>' . $settings[ $this->name . '_intro_title' ] . '</h2>' );
				}
				?>
				<p <?php $this->print_render_attribute_string( $this->name . '_intro_text' ); ?>><?php echo esc_html( $settings[ $this->name . '_intro_text' ] ); ?></p>
				<?php
			}

			switch ( $settings[ $this->name . '_skin' ] ) {
				case 'skin_2':
					$slider_data = array(
						'#anky-testimonials-' . $this->get_id(),
						array(
							'spaceBetween' => 32,
							'autoplay'     => $settings[ $this->name . '_slider_autoplay' ] ?
								array( 'delay' => $settings[ $this->name . '_slider_autoplay_delay' ] )
								: false,
							'pagination'   => array(
								'el'   => '.anky-swiper-pagination',
								'type' => 'bullets',
							),
							'navigation'   => array(
								'nextEl' => '.swiper-button-next',
								'prevEl' => '.swiper-button-prev',
							),
							'scrollbar'    => array(
								'el'            => '.swiper-scrollbar',
								'draggable'     => false,
								'snapOnRelease' => true,
							),
							'breakpoints'  => array(
								'315'  => array(
									'width'        => 312,
									'spaceBetween' => 16,
								),
								'576'  => array(
									'width'        => 496,
									'spaceBetween' => 32,
								),
								'1025' => array(
									'width' => 928,
								),
							),
						),
						array(
							'hideArrows'  => false,
							'isAnimation' => false,
						),
					);
					break;
				case 'skin_3':
					$slider_data = array(
						'#anky-testimonials-' . $this->get_id(),
						array(
							'items'         => '1',
							'spaceBetween'  => 0,
							'slidesPerView' => 1,
							'autoplay'      => $settings[ $this->name . '_slider_autoplay' ] ?
								array( 'delay' => $settings[ $this->name . '_slider_autoplay_delay' ] )
								: false,
							'loop'          => false,
							'pagination'    => array(
								'el'   => '.anky-swiper-pagination',
								'type' => 'bullets',
							),
							'navigation'    => array(
								'nextEl' => '.swiper-button-next',
								'prevEl' => '.swiper-button-prev',
							),
							'scrollbar'     => array(
								'el'            => '.swiper-scrollbar',
								'draggable'     => false,
								'snapOnRelease' => true,
							),
						),
						array(
							'hideArrows'  => false,
							'isAnimation' => false,
						),
					);
					break;
				case 'skin_5':
					$slider_data = array(
						'#anky-testimonials-' . $this->get_id(),
						array(
							'items'         => 2,
							'spaceBetween'  => 32,
							'slidesPerView' => 2,
							'autoplay'      => $settings[ $this->name . '_slider_autoplay' ] ?
								array( 'delay' => $settings[ $this->name . '_slider_autoplay_delay' ] )
								: false,
							'pagination'    => array(
								'el'   => '.anky-swiper-pagination',
								'type' => 'progressbar',
							),
							'navigation'    => array(
								'nextEl' => '.swiper-button-next',
								'prevEl' => '.swiper-button-prev',
							),
							'scrollbar'     => array(
								'el'            => '.swiper-scrollbar',
								'draggable'     => false,
								'snapOnRelease' => true,
							),
							'breakpoints'   => array(
								'315'  => array(
									'slidesPerView' => 1,
								),
								'1025' => array(
									'slidesPerView' => 2,
								),
							),
						),
						array(
							'hideArrows'  => false,
							'isAnimation' => false,
						),
					);
					break;
				case 'skin_6':
					$slider_data = array(
						'#anky-testimonials-' . $this->get_id(),
						array(
							'items'         => 1,
							'spaceBetween'  => 32,
							'slidesPerView' => 1,
							'autoplay'      => $settings[ $this->name . '_slider_autoplay' ] ?
								array(
									'reverseDirection' => 'left' === $settings[ $this->name . '_slider_direction' ],
									'delay'            => $settings[ $this->name . '_slider_autoplay_delay' ],
								)
								: false,
							'invert'        => true,
							'pagination'    => false,
							'navigation'    => false,
							'scrollbar'     => false,
							'breakpoints'   => array(
								'315'  => array(
									'width' => 312,
								),
								'768'  => array(
									'width' => 496,
								),
								'1025' => array(
									'width' => 736,
								),
							),
						),
						array(
							'hideArrows'  => false,
							'isAnimation' => false,
						),
					);
					break;
				default:
					$slider_data = array();
			}

			if ( $is_slider ) {
				printf(
					'<div id="anky-testimonials-%s" class="anky-slider-parent" data-anky-slider="%s"><div class="swiper-wrapper">',
					esc_attr( $this->get_id() ),
					esc_attr( wp_json_encode( $slider_data ) )
				);
			}

			// Skin_1 is single item mode.
			if ( 'skin_1' === $settings[ $this->name . '_skin' ] ) :
				echo '<div class="anky-testimonial-item">';
				$this->$skin_method( $settings );
				echo '</div>';
			else :
				if ( 'skin_4' === $settings[ $this->name . '_skin' ] ) {
					echo '<div class="anky-testimonials-items-wrap">';
				}
				// Other skins support multiple items.
				foreach ( $settings[ $this->name . '_list' ] as $i => $item ) :
					$container_class   = $is_slider ? array( 'anky-testimonial-slide', 'swiper-slide' ) : array( 'anky-testimonial-item' );
					$container_class[] = 'elementor-repeater-item-' . $item['_id'];

					echo '<div class="' . esc_attr( implode( ' ', $container_class ) ) . '">';
					$this->$skin_method( $item, $i );
					echo '</div>';

				endforeach;

				if ( 'skin_4' === $settings[ $this->name . '_skin' ] ) {
					echo '</div>';
				}

			endif; // skin check.

			if ( $is_slider ) :
				echo '</div><!--.swiper-wrapper-->';
				if ( 'skin_6' !== $settings[ $this->name . '_skin' ] ) :
					?>
					<div class="anky-testimonials-nav">
						<div class="anky-testimonials-arrow swiper-button-prev"></div>
						<div class="anky-testimonials-pagination anky-swiper-pagination"></div>
						<div class="anky-testimonials-arrow swiper-button-next"></div>
					</div>
				<?php
				endif;
				echo '</div><!--.anky-slider-parent-->';

			endif;
			?>
		</div><!--.anky-testimonials-section-->
		<?php
	}

	// ======================================================
	// PRIVATE - Render parts
	// ======================================================

	/**
	 * Render skin template part 1.
	 * Template contains single item as designed.
	 *
	 * @param array $settings Required. Settings data.
	 */
	private function render_skin_1( $settings ) {
		$this->add_inline_editing_attributes( $this->name . '_single_item_content' );
		$this->add_render_attribute( $this->name . '_single_item_content', 'class', 'anky-testimonial-content' );

		$this->add_inline_editing_attributes( $this->name . '_single_item_author_name', 'none' );
		$this->add_render_attribute( $this->name . '_single_item_author_name', 'class', 'anky-author-name' );

		$this->add_inline_editing_attributes( $this->name . '_single_item_author_job', 'none' );
		$this->add_render_attribute( $this->name . '_single_item_author_job', 'class', 'anky-author-desc' );
		?>
		<div class="anky-testimonial-wrapper">
			<div <?php $this->print_render_attribute_string( $this->name . '_single_item_content' ); ?>>"<?php echo esc_html( $settings[ $this->name . '_single_item_content' ] ); ?>"</div>
			<div class="anky-testimonial-author-info">
				<?php $this->render_media_image( $settings, $this->name . '_single_item_author_image', 'anky-testimonial-author-logo anky-testimonial-author-logo-small' ); ?>
				<div class="anky-testimonial-author-info-text">
					<p <?php $this->print_render_attribute_string( $this->name . '_single_item_author_name' ); ?>><?php echo esc_html( $settings[ $this->name . '_single_item_author_name' ] ); ?></p>
					<p <?php $this->print_render_attribute_string( $this->name . '_single_item_author_job' ); ?>><?php echo esc_html( $settings[ $this->name . '_single_item_author_job' ] ); ?></p>
				</div>
			</div>
			<?php $this->render_media_image( $settings, $this->name . '_single_item_company_logo', 'anky-testimonial-author-company-logo' ); ?>
		</div>
		<?php
	}

	/**
	 * Render skin template part 2.
	 * Template contains multiple items to be as part of slider.
	 *
	 * @param array   $item  Required. Current item data.
	 * @param integer $index Current iteration index.
	 */
	private function render_skin_2( $item, $index = 0 ) {
		?>
		<div class="anky-testimonial-author-info">
			<?php $this->render_media_image( $item, $this->name . '_list_item_author_image', 'anky-testimonial-author-logo anky-testimonial-author-logo-small' ); ?>
			<div class="anky-testimonial-author-info-text">
				<p class="anky-author-name"><?php echo esc_html( $item[ $this->name . '_list_item_author_name' ] ); ?></p>
				<p class="anky-author-desc"><?php echo esc_html( $item[ $this->name . '_list_item_author_job' ] ); ?></p>
			</div>
		</div>
		<div class="anky-testimonial-content">"<?php echo esc_html( $item[ $this->name . '_list_item_content' ] ); ?>"</div>

		<div class="anky-testimonial-author-company-logo-wrapper">
			<?php $this->render_media_image( $item, $this->name . '_list_item_company_logo', 'anky-testimonial-author-company-logo' ); ?>
		</div>
		<?php
	}

	/**
	 * Render skin template part 3.
	 * Template contains multiple items to be as part of slider with big image overlay.
	 *
	 * @param array   $item  Required. Current item data.
	 * @param integer $index Current iteration index.
	 */
	private function render_skin_3( $item, $index = 0 ) {
		?>
		<div class="anky-testimonial-author-info">
			<div class="anky-testimonial-author-logo-wrap">
				<?php $this->render_media_image( $item, $this->name . '_list_item_author_image', 'anky-testimonial-author-logo anky-testimonial-author-logo-full' ); ?>
			</div>
			<div class="anky-testimonial-content-wrap">
				<div class="anky-testimonial-content">"<?php echo esc_html( $item[ $this->name . '_list_item_content' ] ); ?>"</div>
				<div class="anky-testimonial-author-info-text">
					<p class="anky-author-name"><?php echo esc_html( $item[ $this->name . '_list_item_author_name' ] ); ?></p>
					<p class="anky-author-desc"><?php echo esc_html( $item[ $this->name . '_list_item_author_job' ] ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render skin template part 4.
	 * Template contains multiple items with flex or masonry layout.
	 *
	 * @param array   $item  Required. Current item data.
	 * @param integer $index Current iteration index.
	 */
	private function render_skin_4( $item, $index = 0 ) {
		$content_setting_key = $this->get_repeater_setting_key( $this->name . '_list_item_content', $this->name . '_list', $index );
		$this->add_inline_editing_attributes( $content_setting_key );
		$this->add_render_attribute( $content_setting_key, 'class', 'anky-testimonial-content' );

		$author_setting_key = $this->get_repeater_setting_key( $this->name . '_list_item_author_name', $this->name . '_list', $index );
		$this->add_inline_editing_attributes( $author_setting_key );
		$this->add_render_attribute( $author_setting_key, 'class', 'anky-author-name' );

		$author_pos_setting_key = $this->get_repeater_setting_key( $this->name . '_list_item_author_job', $this->name . '_list', $index );
		$this->add_inline_editing_attributes( $author_pos_setting_key );
		$this->add_render_attribute( $author_pos_setting_key, 'class', 'anky-author-desc' );
		?>
		<div class="anky-testimonial-post-wrapper">
			<div class="anky-testimonial-author-company-logo-wrapper">
				<?php $this->render_media_image( $item, $this->name . '_list_item_company_logo', 'anky-testimonial-author-company-logo anky-testimonial-author-company-logo-small' ); ?>
			</div>
			<div <?php $this->print_render_attribute_string( $content_setting_key ); ?>>"<?php echo esc_html( $item[ $this->name . '_list_item_content' ] ); ?>"</div>
			<div class="anky-testimonial-author-info">
				<?php $this->render_media_image( $item, $this->name . '_list_item_author_image', 'anky-testimonial-author-logo' ); ?>
				<div class="anky-testimonial-author-info-text">
					<p <?php $this->print_render_attribute_string( $author_setting_key ); ?>><?php echo esc_html( $item[ $this->name . '_list_item_author_name' ] ); ?></p>
					<p <?php $this->print_render_attribute_string( $author_pos_setting_key ); ?>><?php echo esc_html( $item[ $this->name . '_list_item_author_job' ] ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render skin template part 5.
	 * Template contains multiple items with as part of slider with
	 * post origin link and separated content body.
	 *
	 * @param array   $item  Required. Current item data.
	 * @param integer $index Current iteration index.
	 */
	private function render_skin_5( $item, $index = 0 ) {
		?>
		<div class="anky-testimonial-author-info">
			<?php $this->render_media_image( $item, $this->name . '_list_item_author_image', 'anky-testimonial-author-logo anky-testimonial-author-logo-small' ); ?>
			<div class="anky-testimonial-author-info-text">
				<p class="anky-author-name"><?php echo esc_html( $item[ $this->name . '_list_item_author_name' ] ); ?></p>
				<p class="anky-author-desc"><?php echo esc_html( $item[ $this->name . '_list_item_author_job' ] ); ?></p>
			</div>
		</div>

		<div class="anky-testimonial-content-body">
			<div class="anky-testimonial-content">"<?php echo esc_html( $item[ $this->name . '_list_item_content' ] ); ?>"</div>
			<?php $this->render_original_post_link( $item, $index ); ?>
		</div>
		<?php
	}

	/**
	 * Render skin template part 6.
	 * Template contains multiple items with as part of slider with
	 * post origin link and separated content body and in double reversed direction.
	 *
	 * @param array   $item  Required. Current item data.
	 * @param integer $index Current iteration index.
	 */
	private function render_skin_6( $item, $index = 0 ) {
		?>
		<div class="anky-testimonial-author-info">
			<?php $this->render_media_image( $item, $this->name . '_list_item_author_image', 'anky-testimonial-author-logo anky-testimonial-author-logo-small' ); ?>
			<div class="anky-testimonial-author-info-text">
				<p class="anky-author-name"><?php echo esc_html( $item[ $this->name . '_list_item_author_name' ] ); ?></p>
				<p class="anky-author-desc"><?php echo esc_html( $item[ $this->name . '_list_item_author_job' ] ); ?></p>
			</div>
		</div>
		<div class="anky-testimonial-content-body">
			<div class="anky-testimonial-content">"<?php echo esc_html( $item[ $this->name . '_list_item_content' ] ); ?>"</div>
			<?php $this->render_original_post_link( $item, $index ); ?>
		</div>
		<?php
	}

	/**
	 * Render testimonial original post link.
	 *
	 * @param array   $item  Required. Current item data.
	 * @param integer $index Current iteration index.
	 */
	private function render_original_post_link( $item, $index = 0 ) {
		if ( empty( $item[ $this->name . '_list_item_original_link' ]['url'] ) ) {
			return;
		}
		$link_setting_key = $this->get_repeater_setting_key( $this->name . '_list_item_original_link', $this->name . '_list', $index );
		$this->add_link_attributes( $link_setting_key, $item[ $this->name . '_list_item_original_link' ], true );
		?>
		<div class="anky-testimonial-link">
			<a <?php $this->print_render_attribute_string( $link_setting_key ); ?>>
				<?php esc_html_e( 'See original post', 'anky' ); ?>
				<?php Anky_UI_Controller::render_social_link_icon( $item[ $this->name . '_list_item_original_link' ]['url'] ); ?>
			</a>
		</div>
		<?php
	}


	// ======================================================
	// PRIVATE - Content settings
	// ======================================================

	/**
	 * Add layout Display settings to Content tab.
	 */
	private function add_box_layout_settings() {
		$this->start_controls_section(
			$this->name . '_general_settings',
			array(
				'label' => __( 'Display Settings', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_skin',
			array(
				'label'   => __( 'Skin', 'anky' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'skin_1',
				'options' => array(
					'skin_1' => __( 'Skin 1', 'anky' ),
					'skin_2' => __( 'Skin 2', 'anky' ),
					'skin_3' => __( 'Skin 3', 'anky' ),
					'skin_4' => __( 'Skin 4', 'anky' ),
					'skin_5' => __( 'Skin 5', 'anky' ),
					'skin_6' => __( 'Skin 6', 'anky' ),
				),
			)
		);

		$this->add_control(
			$this->name . '_slider_autoplay',
			array(
				'label'     => __( 'Slider autoplay', 'anky' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => array( $this->name . '_skin!' => array( 'skin_1', 'skin_4' ) ),
			)
		);
		$this->add_control(
			$this->name . '_slider_autoplay_delay',
			array(
				'label'     => __( 'Slider autoplay delay (in ms)', 'anky' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 100,
				'max'       => 10000,
				'step'      => 100,
				'default'   => 3000,
				'condition' => array(
					$this->name . '_skin!'           => array( 'skin_1', 'skin_4' ),
					$this->name . '_slider_autoplay' => 'yes',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_direction',
			array(
				'label'       => __( 'Slider direction', 'anky' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'left'  => __( 'Left', 'anky' ),
					'right' => __( 'Right', 'anky' ),
				),
				'description' => __( 'NOTE: Change this property If you need the slider to rotate RTL direction.', 'anky' ),
				'default'     => 'right',
				'condition'   => array(
					$this->name . '_skin'            => 'skin_6',
					$this->name . '_slider_autoplay' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Testimonials List settings repeater field to Content tab.
	 */
	private function add_testimonials_list_settings() {
		$this->start_controls_section(
			$this->name . '_list_section',
			array(
				'label' => __( 'Testimonials Content', 'anky' ),
			)
		);

		$this->add_control(
			$this->name . '_intro_title',
			array(
				'label'       => __( 'Intro title', 'anky' ),
				'default'     => __( 'What our clients say', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
				'condition'   => array(
					$this->name . '_skin!' => array( 'skin_1', 'skin_3' ),
				),
			)
		);
		$this->add_control(
			$this->name . '_intro_text',
			array(
				'label'       => __( 'Intro text', 'anky' ),
				'default'     => 'More than 125 000 people trust Anky and let us know every day',
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
				'condition'   => array(
					$this->name . '_skin!' => array( 'skin_1', 'skin_3' ),
				),
			)
		);

		$repeater = new Repeater();

		/**
		 * Author.
		 */
		$repeater->add_control(
			$this->name . '_list_item_author_name',
			array(
				'label'       => __( 'Author name', 'anky' ),
				'default'     => 'John Doe',
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_author_job',
			array(
				'label'       => __( 'Author job title', 'anky' ),
				'default'     => __( 'Assistance manager', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_author_image',
			array(
				'label'   => __( 'Author avatar', 'anky' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array( 'url' => Utils::get_placeholder_image_src() ),
			)
		);
		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_list_item_author_image',
				'default'   => 'thumbnail',
				'separator' => 'none',
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_company_logo',
			array(
				'label'   => __( 'Author company logo', 'anky' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array( 'url' => Utils::get_placeholder_image_src() ),
			)
		);
		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_list_item_company_logo',
				'default'   => 'thumbnail',
				'separator' => 'none',
			)
		);
		/**
		 * Content.
		 */
		$repeater->add_control(
			$this->name . '_list_item_content',
			array(
				'label'       => __( 'Testimonial content', 'anky' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => 'It fits our needs perfectly. It`s really wonderful. Anky did exactly what you said it does.',
				'label_block' => true,
			)
		);
		$repeater->add_control(
			$this->name . '_list_item_original_link',
			array(
				'label'         => __( 'Link to original post', 'anky' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
				'dynamic'       => array( 'active' => true ),
				'label_block'   => true,
				'default'       => array(
					'url'         => 'facebook.com',
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$this->add_control(
			$this->name . '_list',
			array(
				'label'       => __( 'Testimonials', 'anky' ),
				'type'        => Controls_Manager::REPEATER,
				'default'     => array(
					array(
						$this->name . '_list_item_author_name' => 'Mariah Rubye',
						$this->name . '_list_item_author_job'  => 'Senior Frontend Developer, Visa',
						$this->name . '_list_item_content'     => 'Anky made our design process more fluid and gave us a single source of truth for design, product, and development.',
					),
					array(
						$this->name . '_list_item_author_name' => 'Sarah Lester',
						$this->name . '_list_item_author_job'  => 'Creative Director, The New Yorker',
						$this->name . '_list_item_content'     => 'Just what I was looking for. Anky has completely surpassed our expectations. Anky should be nominated for service of the year. Really good.',
					),
					array(
						$this->name . '_list_item_author_name' => 'Thomas Hall',
						$this->name . '_list_item_author_job'  => 'Brand Manager, Visa',
						$this->name . '_list_item_content'     => 'It fits our needs perfectly. It`s really wonderful. Anky did exactly what you said it does.',
					),
					array(
						$this->name . '_list_item_author_name' => 'Tanisha Joe',
						$this->name . '_list_item_author_job'  => 'Research and Development Manager, Webflow',
						$this->name . '_list_item_content'     => 'I don`t know what else to say. Anky is exactly what our business has been lacking. Anky has really helped our business. I didn`t even need training.',
					),
				),
				'condition'   => array(
					$this->name . '_skin!' => 'skin_1',
				),
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ anky_testimonials_list_item_author_job }}}',
			)
		);

		$this->add_single_testimonial_content();

		$this->end_controls_section();
	}

	/**
	 * Add Testimonial content settings to Content tab.
	 * Used to display single Testimonial on `Skin_1`.
	 */
	private function add_single_testimonial_content() {
		/**
		 * Author.
		 */
		$this->add_control(
			$this->name . '_single_item_author_name',
			array(
				'label'       => __( 'Author name', 'anky' ),
				'default'     => 'John Doe',
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'condition'   => array(
					$this->name . '_skin' => 'skin_1',
				),
				'label_block' => true,
			)
		);
		$this->add_control(
			$this->name . '_single_item_author_job',
			array(
				'label'       => __( 'Author job title', 'anky' ),
				'default'     => __( 'Assistance manager', 'anky' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => array( 'active' => true ),
				'condition'   => array(
					$this->name . '_skin' => 'skin_1',
				),
				'label_block' => true,
			)
		);

		/**
		 * Content.
		 */
		$this->add_control(
			$this->name . '_single_item_content',
			array(
				'label'       => __( 'Testimonial content', 'anky' ),
				'type'        => Controls_Manager::TEXTAREA,
				'condition'   => array(
					$this->name . '_skin' => 'skin_1',
				),
				'default'     => 'It fits our needs perfectly. It`s really wonderful. Anky did exactly what you said it does.',
				'label_block' => true,
			)
		);

		/**
		 * Media.
		 */
		$this->add_control(
			$this->name . '_single_item_author_image',
			array(
				'label'     => __( 'Author avatar', 'anky' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array( 'url' => Utils::get_placeholder_image_src() ),
				'condition' => array(
					$this->name . '_skin' => 'skin_1',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_single_item_author_image',
				'default'   => 'thumbnail',
				'separator' => 'none',
				'condition' => array(
					$this->name . '_skin' => 'skin_1',
				),
			)
		);
		$this->add_control(
			$this->name . '_single_item_company_logo',
			array(
				'label'     => __( 'Author company logo', 'anky' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => array(
					$this->name . '_skin' => 'skin_1',
				),
				'default'   => array( 'url' => Utils::get_placeholder_image_src() ),
			)
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			array(
				'name'      => $this->name . '_single_item_company_logo',
				'default'   => 'thumbnail',
				'separator' => 'none',
				'condition' => array(
					$this->name . '_skin' => 'skin_1',
				),
			)
		);
	}

	// ======================================================
	// PRIVATE - Style settings
	// ======================================================

	/**
	 * Add Testimonial section container style setting.
	 */
	private function add_testimonial_item_container_style_controls() {
		$this->start_controls_section(
			$this->name . '_container_style_settings',
			array(
				'label' => __( 'Testimonial container', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-item' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->height_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-item, {{WRAPPER}} .anky-testimonial-slide' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);
		/**
		 * Complicated selector for skin 1 to 4.
		 * We use it to redirect styles to another part as per design requirements.
		 * NOTE: Some selectors are left intact intentionally.
		 */
		$skin_specific_selector = '{{WRAPPER}} .anky-testimonials-skin_1 .anky-testimonial-item,' .
								  '{{WRAPPER}} .anky-testimonials-skin_2 .anky-testimonial-item,' .
								  '{{WRAPPER}} .anky-testimonials-skin_3 .anky-testimonial-item,' .
								  '{{WRAPPER}} .anky-testimonials-skin_4 .anky-testimonial-item,' .
								  '{{WRAPPER}} .anky-testimonials-skin_5 .anky-testimonial-content-body,' .
								  '{{WRAPPER}} .anky-testimonials-skin_6 .anky-testimonial-content-body';

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => $this->name . '_container_border',
				'selector' => $skin_specific_selector,
			)
		);
		$this->add_control(
			$this->name . '_container_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					$skin_specific_selector => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => $this->name . '_container_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => $skin_specific_selector,
			)
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'label'     => __( 'Shadow', 'anky' ),
				'name'      => $this->name . '_container_container_shadow',
				'selectors' => $skin_specific_selector,
			)
		);
		$this->add_control(
			$this->name . '_container_container_horizontal_alignment',
			array(
				'label'     => __( 'Horizontal Alignment', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'separator' => 'before',
				'options'   => array(
					'flex-start'    => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'        => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'      => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
					'space-between' => array(
						'title' => __( 'Stretch', 'anky' ),
						'icon'  => 'eicon-h-align-stretch',
					),
				),
				'default'   => 'space-between',
				'condition' => array( $this->name . '_skin' => 'skin_4' ),
				'selectors' => array( '{{WRAPPER}} .anky-testimonials-items-wrap' => 'justify-content: {{VALUE}};' ),
			)
		);
		$this->add_control(
			$this->name . '_container_container_vertical_alignment',
			array(
				'label'     => __( 'Vertical Alignment', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-v-align-top',
					),
					'center'     => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-v-align-middle',
					),
					'flex-end'   => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'default'   => 'flex-start',
				'condition' => array( $this->name . '_skin' => 'skin_4' ),
				'selectors' => array( '{{WRAPPER}} .anky-testimonials-items-wrap' => 'align-items: {{VALUE}};' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'separator'  => 'before',
				'default'    => array(
					'top'    => 40,
					'right'  => 40,
					'bottom' => 40,
					'left'   => 40,
					'unit'   => 'px',
				),
				'selectors'  => array(
					$skin_specific_selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_container_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Add Testimonial section Intro content Specific style controls.
	 */
	private function add_intro_content_style_controls() {
		$this->start_controls_section(
			$this->name . '_intro_style_settings',
			array(
				'label'     => __( 'Intro content', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( $this->name . '_skin!' => array( 'skin_1', 'skin_3' ) ),
			)
		);
		$this->start_controls_tabs( $this->name . '_intro_style_tabs' );

		$this->start_controls_tab(
			$this->name . '_intro_title_tab',
			array( 'label' => __( 'Title', 'anky' ) )
		);
		$this->add_content_related_style_controls_part( "{$this->name}_intro_title", '.anky-testimonials-section-title', '#16161A', $this->default_heading_typography );
		$this->end_controls_tab();

		$this->start_controls_tab(
			$this->name . '_intro_content_tabs',
			array( 'label' => __( 'Content', 'anky' ) )
		);
		$this->add_content_related_style_controls_part( "{$this->name}_intro_content", '.anky-testimonials-section-subtitle', '#7E7E83' );
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Add Testimonial Content Specific style controls.
	 */
	private function add_testimonials_content_style_controls() {
		$this->start_controls_section(
			$this->name . '_content_style_settings',
			array(
				'label' => __( 'Content', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_content_related_style_controls_part( "{$this->name}_content", '.anky-testimonial-content', '#16161A', $this->default_small_heading_typography );

		$this->add_control(
			$this->name . '_content_origin_link_heading',
			array(
				'label'     => __( 'Post origin link', 'anky' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( $this->name . '_skin' => array( 'skin_5', 'skin_6' ) ),
			)
		);

		$this->start_controls_tabs(
			$this->name . '_content_origin_link_style_tabs',
			array( 'condition' => array( $this->name . '_skin' => array( 'skin_5', 'skin_6' ) ) )
		);

		/**
		 * Original post link.
		 */
		$this->start_controls_tab(
			$this->name . '_content_origin_link_tag_link_tab',
			array( 'label' => __( 'Link', 'anky' ) )
		);
		$this->add_content_related_style_controls_part( "{$this->name}_content_origin_link", '.anky-testimonial-link a', '#16161A', $this->default_link_typography );
		$this->end_controls_tab();

		/**
		 * Icon.
		 */
		$this->start_controls_tab(
			$this->name . '_content_origin_link_icon_tab',
			array( 'label' => __( 'Icon', 'anky' ) )
		);
		$this->add_control(
			$this->name . '_content_origin_link_icon_color',
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16161A',
				'selectors' => array(
					'{{WRAPPER}} .anky-testimonial-link span' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_origin_link_icon_size',
			array(
				'label'     => __( 'Size', 'anky' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'unit' => '%',
					'size' => 18,
				),
				'selectors' => array(
					'{{WRAPPER}} .anky-testimonial-link span' => 'font-size: {{SIZE}}px',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_origin_link_icon_padding',
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-link span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_content_origin_link_icon_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-link span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Add Testimonial Author info Specific style controls.
	 */
	private function add_author_style_controls() {
		$this->start_controls_section(
			$this->name . '_author_style_settings',
			array(
				'label' => __( 'Author data', 'anky' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->start_controls_tabs( $this->name . '_author_style_tabs' );

		/**
		 * Author name.
		 */
		$this->start_controls_tab(
			$this->name . '_author_name_tab',
			array( 'label' => __( 'Name', 'anky' ) )
		);
		$this->add_content_related_style_controls_part( "{$this->name}_author_name", '.anky-author-name', '#16161A', $this->default_link_typography );
		$this->end_controls_tab();

		/**
		 * Author job position.
		 */
		$this->start_controls_tab(
			$this->name . '_author_position_tabs',
			array( 'label' => __( 'Job', 'anky' ) )
		);
		$this->add_content_related_style_controls_part( "{$this->name}_author_position", '.anky-author-desc', '#7E7E83' );
		$this->end_controls_tab();

		/**
		 * Author images and company logo.
		 */
		$this->start_controls_tab(
			$this->name . '_author_images_tabs',
			array(
				'label'     => __( 'Images', 'anky' ),
				'condition' => array( $this->name . '_skin!' => 'skin_3' ),
			)
		);
		/**
		 * Avatar.
		 */
		$this->add_control(
			$this->name . '_author_avatar_popover',
			array(
				'label' => __( 'Avatar', 'anky' ),
				'type'  => Controls_Manager::POPOVER_TOGGLE,
			)
		);
		$this->start_popover();
		$this->add_responsive_control(
			$this->name . '_author_avatar_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => 56,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-logo' => 'width: {{SIZE}}px',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_author_avatar_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => 56,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-logo' => 'height: {{SIZE}}px',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_author_avatar_radius',
			array(
				'label'      => __( 'Border Radius', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit' => '%',
					'size' => 50,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-logo' => 'border-radius: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_author_avatar_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'top'      => 0,
					'right'    => 16,
					'bottom'   => 40,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-logo' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_popover();
		/**
		 * Company logo.
		 */
		$this->add_control(
			$this->name . '_author_company_logo_popover',
			array(
				'label'     => __( 'Company logo', 'anky' ),
				'type'      => Controls_Manager::POPOVER_TOGGLE,
				'condition' => array( $this->name . '_skin' => array( 'skin_1', 'skin_2', 'skin_4' ) ),
			)
		);
		$this->start_popover();
		$this->add_control(
			$this->name . '_author_company_logo_width_auto',
			array(
				'label'       => __( 'Set auto width', 'anky' ),
				'type'        => Controls_Manager::SWITCHER,
				'condition'   => array( $this->name . '_skin' => array( 'skin_2', 'skin_4' ) ),
				'description' => __( 'Control allows to activate horizontal alignment', 'anky' ),
			)
		);
		$this->add_control(
			$this->name . '_author_company_logo_align_horizontal',
			array(
				'label'     => __( 'Horizontal Align', 'anky' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array(
						'title' => __( 'Left', 'anky' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center'     => array(
						'title' => __( 'Center', 'anky' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end'   => array(
						'title' => __( 'Right', 'anky' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .anky-testimonial-author-company-logo-wrapper' => 'justify-content: {{VALUE}};',
				),
				'condition' => array( $this->name . '_author_company_logo_width_auto' => 'yes' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_author_company_logo_width',
			array(
				'label'      => __( 'Width', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'default'    => array(
					'unit' => '%',
					'size' => 100,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-company-logo' => 'width: {{SIZE}}{{UNIT}}',
				),
				'condition'  => array( $this->name . '_author_company_logo_width_auto' => '' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_author_company_logo_height',
			array(
				'label'      => __( 'Height', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => 80,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-company-logo' => 'height: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			$this->name . '_author_company_logo_margin',
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-company-logo' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_popover();

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			$this->name . '_author_container_margin',
			array(
				'label'      => __( 'Container margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'separator'  => 'before',
				'default'    => array(
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 40,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonial-author-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add Testimonials slider controls style settings.
	 */
	private function add_slider_style_controls() {
		$this->start_controls_section(
			$this->name . '_slider_style_settings',
			array(
				'label'     => __( 'Slider navigation', 'anky' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( $this->name . '_skin' => array( 'skin_2', 'skin_3', 'skin_5' ) ),
			)
		);

		/**
		 * Arrows.
		 */
		$this->add_control(
			$this->name . '_slider_arrows_popover',
			array(
				'label' => __( 'Arrows', 'anky' ),
				'type'  => Controls_Manager::POPOVER_TOGGLE,
			)
		);
		$this->start_popover();
		$this->add_control(
			$this->name . '_slider_arrows_border_color',
			array(
				'label'     => __( 'Border color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .anky-testimonials-arrow' => 'border-color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_arrows_color',
			array(
				'label'     => __( 'Arrows color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .anky-testimonials-arrow' => 'color: {{VALUE}};',
				),
			)
		);
		$this->end_popover();

		/**
		 * Pagination.
		 */
		$this->add_control(
			$this->name . '_slider_pagination_popover',
			array(
				'label' => __( 'Pagination', 'anky' ),
				'type'  => Controls_Manager::POPOVER_TOGGLE,
			)
		);
		$this->start_popover();
		$this->add_control(
			$this->name . '_slider_pagination_main_color',
			array(
				'label'     => __( 'Main color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .anky-testimonials-pagination .swiper-pagination-bullet, {{WRAPPER}} .anky-testimonials-skin_3 .swiper-pagination-bullet.swiper-pagination-bullet-active ~ .swiper-pagination-bullet:not(.swiper-pagination-bullet-active)' => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			$this->name . '_slider_pagination_active_color',
			array(
				'label'     => __( 'Active color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .anky-testimonials-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active, {{WRAPPER}} .anky-testimonials-pagination .swiper-pagination-progressbar-fill,  {{WRAPPER}} .anky-testimonials-pagination .swiper-pagination-progressbar-fill, {{WRAPPER}} .anky-testimonials-skin_3 .anky-testimonials-pagination .swiper-pagination-bullet' => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->end_popover();
		$this->add_responsive_control(
			$this->name . '_navigation_container_margin',
			array(
				'label'      => __( 'Container margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonials-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array( $this->name . '_skin!' => 'skin_3' ),
			)
		);
		$this->add_responsive_control(
			$this->name . '_navigation_container_bottom_position',
			array(
				'label'      => __( 'Vertical position', 'anky' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => $this->position_size_units,
				'default'    => array(
					'unit' => 'px',
					'size' => 80,
				),
				'selectors'  => array(
					'{{WRAPPER}} .anky-testimonials-nav' => 'bottom: {{SIZE}}{{UNIT}}',
				),
				'condition'  => array( $this->name . '_skin' => 'skin_3' ),
			)
		);
		$this->end_controls_section();
	}

}
