<?php
/**
 * Anky Elementor Widget base class. Used as assistive class.
 *
 * @package    Anky/Compatibility
 * @subpackage Elementor
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Compatibility\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Elementor Widget base class. Used as assistive class.
 */
abstract class Anky_Elementor_Widget_Base extends Widget_Base {

	/**
	 * Default size units.
	 *
	 * @var array
	 * @access protected
	 */
	protected $default_size_units = array( 'px', 'em', '%' );

	/**
	 * Default positioning size units.
	 *
	 * @var array
	 * @access protected
	 */
	protected $position_size_units = array( 'px', '%' );

	/**
	 * Default height size units.
	 *
	 * @var array
	 * @access protected
	 */
	protected $height_size_units = array( 'px', '%', 'vh' );

	/**
	 * Default typography value for Heading.
	 *
	 * @var array
	 * @access protected
	 */
	protected $default_heading_typography = array(
		'typography'  => array( 'default' => 'yes' ),
		'font_family' => array(
			'default' => 'Inter',
		),
		'font_size'   => array(
			'default' => array(
				'units' => 'px',
				'size'  => 32,
			),
		),
		'font_weight' => array(
			'default' => 700,
		),
		'line_height' => array(
			'default' => array(
				'units' => 'px',
				'size'  => 40,
			),
		),
	);

	/**
	 * Default typography value for Small Heading.
	 *
	 * @var array
	 * @access protected
	 */
	protected $default_small_heading_typography = array(
		'typography'  => array( 'default' => 'yes' ),
		'font_family' => array(
			'default' => 'Inter',
		),
		'font_size'   => array(
			'default' => array(
				'units' => 'px',
				'size'  => 22,
			),
		),
		'font_weight' => array(
			'default' => 700,
		),
		'line_height' => array(
			'default' => array(
				'units' => 'px',
				'size'  => 28,
			),
		),

	);

	/**
	 * Default typography value for Paragraph.
	 *
	 * @var array
	 * @access protected
	 */
	protected $default_paragraph_typography = array(
		'typography'  => array( 'default' => 'yes' ),
		'font_family' => array(
			'default' => 'Inter',
		),
		'font_size'   => array(
			'default' => array(
				'units' => 'px',
				'size'  => 18,
			),
		),
		'font_weight' => array(
			'default' => 400,
		),
		'line_height' => array(
			'default' => array(
				'units' => 'px',
				'size'  => 28,
			),
		),

	);

	/**
	 * Default typography value for Links.
	 *
	 * @var array
	 * @access protected
	 */
	protected $default_link_typography = array(
		'typography'  => array( 'default' => 'yes' ),
		'font_family' => array(
			'default' => 'Inter',
		),
		'font_size'   => array(
			'default' => array(
				'units' => 'px',
				'size'  => 18,
			),
		),
		'font_weight' => array(
			'default' => 700,
		),
		'line_height' => array(
			'default' => array(
				'units' => 'px',
				'size'  => 24,
			),
		),
	);

	/**
	 * Retrieve media image part.
	 *
	 * @param array  $setting   Required. Current item data.
	 * @param string $image_key Required. Settings key for image size.
	 * @param string $class     Optional. Additional Css class.
	 *
	 * @return string
	 */
	protected function get_media_image_string( $setting, $image_key, $class = '' ) {
		if ( empty( $setting[ $image_key ]['id'] ) ) {
			$string = str_replace(
				'alt=""',
				'alt="" class="' . $class . '"',
				Group_Control_Image_Size::get_attachment_image_html(
					$setting,
					$image_key,
					$image_key
				)
			);
		} else {
			$string = str_replace(
				'class="',
				'class="' . $class . ' ',
				Group_Control_Image_Size::get_attachment_image_html(
					$setting,
					$image_key,
					$image_key
				)
			);
		}

		return $string;
	}

	/**
	 * Render media image part.
	 *
	 * @param array  $setting   Required. Current item data.
	 * @param string $image_key Required. Settings key for image size.
	 * @param string $class     Optional. Additional Css class.
	 */
	protected function render_media_image( $setting, $image_key, $class = '' ) {
		echo wp_kses_post( $this->get_media_image_string( $setting, $image_key, $class ) );
	}

	/**
	 * Add typography control part.
	 *
	 * @param string $slug          Required. Identifier of control.
	 * @param string $selector      Required. Css selector used to apply props to.
	 * @param string $default_color Optional. Color that applies by default.
	 * @param array  $default_typo  Optional. Typography that applies by default.
	 */
	protected function add_typography_control_style_part( $slug, $selector, $default_color = '#16161A', $default_typo = array() ) {
		$selector = "{{WRAPPER}} $selector";
		$this->add_control(
			"{$slug}_color",
			array(
				'label'     => __( 'Color', 'anky' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => $default_color,
				'selectors' => array(
					$selector => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'           => "{$slug}_typography",
				'selector'       => $selector,
				'fields_options' => empty( $default_typo ) ? $this->default_paragraph_typography : $default_typo,
			)
		);
	}

	/**
	 * Add text specific style controls part.
	 *
	 * @param string $slug          Required. Identifier for current switch zone.
	 * @param string $selector      Required. Css selector used to apply props to.
	 * @param string $default_color Optional. Color that applies by default.
	 * @param array  $default_typo  Optional. Typography that applies by default.
	 */
	protected function add_content_related_style_controls_part( $slug, $selector, $default_color = '#16161A', $default_typo = array() ) {
		$this->add_typography_control_style_part( $slug, $selector, $default_color, $default_typo );

		$selector = "{{WRAPPER}} $selector";

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			array(
				'name'     => "{$slug}_shadow",
				'selector' => $selector,
			)
		);
		$this->add_responsive_control(
			"{$slug}_padding",
			array(
				'label'      => __( 'Padding', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'separator'  => 'before',
				'selectors'  => array(
					$selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			"{$slug}_margin",
			array(
				'label'      => __( 'Margin', 'anky' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => $this->default_size_units,
				'default'    => array(
					'unit'     => $this->default_size_units[0],
					'top'      => '0',
					'right'    => '0',
					'left'     => '0',
					'bottom'   => '16',
					'isLinked' => 'false',
				),
				'selectors'  => array(
					$selector => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
	}

}
