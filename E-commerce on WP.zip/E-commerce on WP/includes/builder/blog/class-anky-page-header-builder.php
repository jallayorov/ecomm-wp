<?php
/**
 * Page Header Builder.
 *
 * @package    Anky/Builder
 * @subpackage Blog
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Blog;

use Anky\Includes\Interfaces\Interface_Page_Layout;
use Anky\Includes\Traits\Trait_Singleton as Singleton;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Page Header Builder.
 */
class Anky_Page_Header_Builder implements Interface_Page_Layout {
	use Singleton;

	/**
	 * Print Html with Related posts slider
	 */
	public function render() {
		$data = $this->prepare_data();

		echo '<' . tag_escape( anky_get_prop( $data, 'tag', 'div' ) ) . ' class="' . esc_attr( anky_get_prop( $data, 'tag_class', '' ) ) . '">';
		echo ! empty( $data['up_title'] ) ? '<div class="anky-page-header-image"></div>' : '';
		anky_page_header_inner();
		echo ! empty( $data['up_title'] ) ? '<p class="page-subtitle">' . wp_kses( $data['up_title'], $data['allowed_html'] ) . '</p>' : '';
		echo ! empty( $data['title'] ) ? '<h1 class="page-title">' . wp_kses( $data['title'], $data['allowed_html'] ) . '</h1>' : '';
		echo ! empty( $data['subtitle'] ) ? '<p class="page-subtitle">' . wp_kses( $data['subtitle'], $data['allowed_html'] ) . '</p>' : '';
		echo '</' . tag_escape( anky_get_prop( $data, 'tag', 'div' ) ) . '>';

		return false;
	}

	/**
	 * Prepare arguments for related posts and obtain them.
	 *
	 * @return array Array of post objects or post IDs.
	 */
	public function prepare_data() {
		global $wp_query;

		$data = array(
			'tag'          => 'header',
			'tag_class'    => 'anky-page-header',
			'is_search'    => is_search(),
			'image'        => false,
			'allowed_html' => array(
				'span' => array(
					'class' => array(),
				),
			),
		);

		if ( is_home() ) {
			$data['title']    = __( 'Blog', 'anky' );
			$data['subtitle'] = __( 'Our recent publications', 'anky' );
		} elseif ( $data['is_search'] ) {
			$data['title']    = get_search_query() . '<span class="page-title-info anky-text-muted"> ' . $wp_query->found_posts . '</span>';
			$data['up_title'] = __( 'Search Results for:', 'anky' );
		}

		return $data;
	}

}
