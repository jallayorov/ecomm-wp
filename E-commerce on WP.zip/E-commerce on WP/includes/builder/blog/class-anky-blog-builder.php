<?php
/**
 * Theme blog builder.
 *
 * @package    Anky/Builder
 * @subpackage Blog
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Blog;

use Anky\Includes\Traits\Trait_Singleton as Singleton;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Related Posts Builder.
 */
class Anky_Blog_Builder {
	use Singleton;

	/**
	 * Render the blog entry meta with categories and date.
	 */
	public function entry_meta() {
		// Bail if search template.
		if ( is_search() ) {
			return;
		}
		$this->post_cats( true );
		$this->posted_on();
	}

	/**
	 * Render the blog entry meta with author and comments info.
	 */
	public function post_meta() {
		$this->post_author( false );
		$this->post_comments_info();
	}

	/**
	 * Alters the Reply to text for comments section.
	 *
	 * @param array $args         Comment reply link arguments.
	 *                            for more information on accepted arguments.
	 *
	 * @return array Comment reply link arguments.
	 * @see get_comment_reply_link()
	 */
	public function comments_reply_text( $args ) {
		/* translators: %s: Author of the comment being replied to. */
		$args['reply_to_text'] = esc_html__( 'Post a Reply to "%s"', 'anky' );

		return $args;
	}

	/**
	 * Print Html for author information for single post template.
	 *
	 * @param bool $include_bio Optional. Add Author description. Defaults to false.
	 */
	public function post_author( $include_bio = true ) {
		$include_bio = '' === $include_bio || $include_bio; // Replace with true in case passed via hook.
		$id          = get_the_author_meta( 'ID' );
		$bio         = get_the_author_meta( 'description' );
		?>
		<div class="anky-author">
			<div class="anky-author-avatar">
				<?php echo get_avatar( $id, 48 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
			<div class="anky-author-details">
				<span class="anky-meta-subtitle"><?php echo esc_html_x( 'Written by', 'post author', 'anky' ); ?></span>
				<span class="anky-meta-title"><a href="<?php echo esc_url( get_author_posts_url( $id ) ); ?>"><?php echo esc_html( get_the_author_meta( 'display_name' ) ); ?></a></span>
				<?php if ( $include_bio && ! empty( $bio ) ) : ?>
					<p class="anky-author-bio"><?php echo esc_html( $bio ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Print Html with post tags.
	 *
	 * @param string $before_tags Optional. String to insert before tag text.
	 * @param string $after_tags  Optional. String to insert after tag text.
	 */
	public function post_tags( $before_tags = '', $after_tags = '' ) {
		$tags_list = get_the_tag_list( '', ' ' );

		if ( $tags_list ) {
			printf( '<div class="anky-post-tags">%1$s%2$s%3$s</div>', $before_tags, $tags_list, $after_tags ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Print Html delimiter.
	 */
	public function the_delimiter() {
		echo '<hr class="anky-delimiter">';
	}

	/**
	 * Render content on Blog, Front, Archive pages template.
	 */
	public function footer_blog_entry_meta() {
		// Bail early.
		if ( is_single() ) {
			return;
		}

		// Print Entry meta.
		echo '<div class="entry-meta">';
		$this->post_cats( true );
		$this->posted_on();
		echo '</div>';

		if ( ! is_singular() ) {
			anky_post_thumbnail();
		}
	}

	/**
	 * Render Comments template with wrapper.
	 */
	public function render_comments() {
		/**
		 * Output comments wrapper if it's a post, or if comments are open,
		 * or if there's a comment number – and check for password.
		 */
		if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<div class="comments-wrapper section-inner">';

			comments_template();

			echo '</div><!-- .comments-wrapper -->';
		}
	}

	/**
	 * Render Post navigation block.
	 */
	public function posts_navigation() {
		$navigation_template = '%1$s<span class="nav-meta">%2$s</span>%3$s<span class="screen-reader-text">%4$s</span><span class="post-title">%5$s</span>';

		the_post_navigation(
			array(
				'next_text' => sprintf(
					$navigation_template,
					'',
					esc_html_x( 'Next', 'text for next post', 'anky' ),
					'<span class="anky-icon-chevron-right" aria-hidden="true"></span>',
					esc_html__( 'Next Post', 'anky' ),
					'%title'
				),
				'prev_text' => sprintf(
					$navigation_template,
					'<span class="anky-icon-chevron-left" aria-hidden="true"></span>',
					_x( 'Previous', 'text for previous post', 'anky' ),
					'',
					esc_html__( 'Previous Post', 'anky' ),
					'%title'
				),
			)
		);
	}

	/**
	 * Print Html with post categories.
	 *
	 * @param bool   $insert_delimeter Optional. Set delimiter and the end or not. Defaults to false.
	 * @param string $before_cats      Optional. String to insert before category text.
	 * @param string $after_cats       Optional. String to insert after category text.
	 */
	public function post_cats( $insert_delimeter = false, $before_cats = '', $after_cats = '' ) {
		$categories_list = get_the_category_list( esc_html_x( ', ', 'list item separator', 'anky' ) );

		if ( $categories_list ) {
			printf(
				'<span class="anky-post-cat">%1$s%2$s%3$s</span>%4$s',
				$before_cats,
				$categories_list,
				$after_cats,
				$insert_delimeter ? '<span class="anky-meta-delimiter">/</span>' : ''
			); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	public function posted_on() {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

		// Alter template if post has been updated.
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		// Wrap the time string in a link, and preface it with 'Posted on'.
		$posted_on = sprintf(
		/* translators: %s: post date. */
			_x( '<span class="screen-reader-text">Posted on</span> %s', 'post date', 'anky' ),
			'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
		);

		echo '<span class="posted-on">' . $posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Print Html comments counter information.
	 *
	 * @return boolean
	 */
	public function post_comments_info() {
		if ( is_single() && post_password_required() || ( ! comments_open() ) ) {
			return false;
		}
		?>

		<div class="anky-post-comments">
			<span class="anky-meta-subtitle"><?php esc_html_e( 'Conversation', 'anky' ); ?></span>
			<span class="anky-meta-title">
				<?php
				comments_popup_link(
					sprintf(
						wp_kses(
						/* translators: %s: post title */
							__( 'Post a comment <span class="screen-reader-text">for %s</span>', 'anky' ),
							array(
								'span' => array(
									'class' => array(),
								),
							)
						),
						wp_kses_post( get_the_title() )
					)
				);
				?>
			</span>
		</div>

		<?php
		return false;
	}

	/**
	 * Retrieve protected post password form content.
	 *
	 * @return string HTML content for password form for password protected post.
	 * @see get_the_password_form
	 */
	public function alter_password_form() {
		global $post;
		$input_id = 'anky_pwbox-' . ( empty( $post->ID ) ? anky_unique_id() : $post->ID );
		$output   = '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" class="post-password-form" method="post">';

		$output .= '<p>' . __( 'This content is password protected. To view it please enter your password below:', 'anky' ) . '</p>';
		$output .= '<div class="anky-input-wrap">';
		$output .= '<label for="' . $input_id . '">' . __( 'Password', 'anky' ) . '</label>';
		$output .= '<span class="anky-password-field-wrapper">';
		$output .= '<input name="post_password" id="' . $input_id . '" type="password" size="20" placeholder="' . esc_attr__( 'Enter your password', 'anky' ) . '" />';
		$output .= '<button class="anky-btn-clear anky-btn-password-toggler anky-js-toggle-password" type="button"><span class="anky-icon-eye-slash" aria-hidden="true"></span></button>';
		$output .= '</span>';
		$output .= '<button type="submit" class="anky-form-submit-btn">' . esc_html__( 'Show content', 'anky' ) . '</button>';
		$output .= '</div>';
		$output .= '</form>';

		/**
		 * Filters the HTML output for the protected post password form.
		 *
		 * If modifying the password field, please note that the core database schema
		 * limits the password field to 20 characters regardless of the value of the
		 * size attribute in the form input.
		 *
		 * @param string $output The password form HTML output.
		 */
		return apply_filters( 'anky_altered_password_form', $output );
	}

	/**
	 * Entry meta for `Post` template.
	 */
	public function entry_meta_template() {
		if ( 'post' === get_post_type() && is_singular() ) :
			echo '<div class="entry-meta">';
			anky_blog_entry_meta();
			echo '</div>';
		elseif ( 'page' !== get_post_type() ) :
			anky_posted_by();
		endif;
	}

	/**
	 * Render corresponding entry title.
	 */
	public function entry_title() {
		if ( is_singular() ) {
			the_title( '<h1 class="entry-title">', '</h1>' );
		} else {
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		}
	}

	/**
	 * Render corresponding entry title with arrow up-right.
	 *
	 * @param bool $add_arrow Optional. Add arrow icon to title link or not.
	 */
	public function entry_custom_title( $add_arrow = false ) {
		if ( $add_arrow ) {
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '<i class="anky-icon-arrow-up-right"></i></a></h2>' );
		} else {
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		}
	}

	/**
	 * Entry meta for single post article.
	 */
	public function single_post_meta() {
		if ( 'post' === get_post_type() && is_singular() ) {
			echo '<div class="anky-post-meta">';
			anky_blog_post_meta();
			echo '</div>';
		}
	}

	/**
	 * Print edit post link for logged in users with edit capabilities.
	 */
	public function edit_link() {
		if ( is_singular() ) {
			return;
		}
		edit_post_link(
			sprintf(
				wp_kses(
				/* translators: %s: Name of current post. Only visible to screen readers */
					'<span class="anky-icon-pencil" aria-hidden="true"></span><span class="anky-edit-link-text">' . __( 'Edit <span class="screen-reader-text">%s</span>', 'anky' ) . '</span>',
					array(
						'span' => array(
							'class'       => array(),
							'aria-hidden' => array(),
						),
					)
				),
				wp_kses_post( get_the_title() )
			),
			'<span class="edit-link">',
			'</span>'
		);
	}

	/**
	 * Print Related Posts entry header content.
	 */
	public function related_posts_header() {
		anky_posted_by();
		the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
		echo '<div class="entry-meta">';
		anky_blog_related_post_meta();
		echo '</div>';
	}

	/**
	 * Print post pagination template.
	 */
	public function posts_pagination() {
		// Previous/next page navigation.
		the_posts_pagination(
			array(
				'prev_text'          => '<span class="anky-icon-chevron-left anky-mobile-icon" aria-hidden="true"></span><span class="anky-page-number-title">'
										. esc_html__( 'Previous page', 'anky' ) . '</span>',
				'next_text'          => '<span class="anky-icon-chevron-right anky-mobile-icon" aria-hidden="true"></span><span class="anky-page-number-title">'
										. esc_html__( 'Next page', 'anky' ) . '</span>',
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'anky' ) . ' </span>',
				'mid_size'           => 5,
				'screen_reader_text' => esc_html__( 'Posts navigation', 'anky' ),
				'aria_label'         => esc_html__( 'Posts navigation', 'anky' ),
				'class'              => 'anky-page-pagination',
			)
		);
	}

}
