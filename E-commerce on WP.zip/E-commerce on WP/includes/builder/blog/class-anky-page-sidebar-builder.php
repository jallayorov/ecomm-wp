<?php
/**
 * Page Header Builder.
 *
 * @package    Anky/Builder
 * @subpackage Blog
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Blog;

use Anky\Includes\Interfaces\Interface_Page_Layout;
use Anky\Includes\Traits\Trait_Singleton as Singleton;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Page Header Builder.
 */
class Anky_Page_Sidebar_Builder implements Interface_Page_Layout {
	use Singleton;

	/**
	 * Print Html with Related posts slider.
	 *
	 * @return bool
	 */
	public function render() {
		$data = $this->prepare_data();
		// Prevent render in case there is no sidebar or it is post type `Page`.
		if ( ! $data['sidebar'] || $data['is_page'] ) {
			return false;
		}
		?>
		<div class="<?php echo esc_attr( $data['wrapper_class'] ); ?>">
			<?php get_sidebar(); ?>
		</div> <!--.anky-col-->
		<?php
		return false;
	}

	/**
	 * Prepare arguments for related posts and obtain them.
	 *
	 * @return array Array of custom data..
	 */
	public function prepare_data() {
		return array(
			'wrapper_class' => 'anky-col-2 anky-tablet-col-4',
			'is_page'       => is_page(),
			'sidebar'       => anky_get_option( 'main-blog-sidebar' ),
		);
	}

}
