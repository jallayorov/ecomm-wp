<?php
/**
 * Related Posts Builder.
 *
 * @package    Anky/Builder
 * @subpackage Blog
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Blog;

use Anky\Includes\Interfaces\Interface_Page_Layout;
use Anky\Includes\Traits\Trait_Singleton as Singleton;
use WP_Post;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Related Posts Builder.
 */
class Anky_Related_Posts_Builder implements Interface_Page_Layout {
	use Singleton;

	/**
	 * Print Html with Related posts slider
	 */
	public function render() {
		$related_posts = $this->prepare_data();
		$is_customizer = is_customize_preview();

		if ( ! empty( $related_posts ) ) :
			echo $is_customizer ? '<div class="anky-related-posts-customizer-wrap">' : '';
			echo '<section class="anky-related-posts">';
			echo '<h2 class="anky-section-title">' . esc_html__( 'You might also like', 'anky' ) . '</h2>';
			echo '<div class="anky-related-posts-wrap">';
			foreach ( $related_posts as $post_object ) {
				$GLOBALS['post'] = $post_object; // phpcs:ignore WordPress.Globals.Override
				setup_postdata( $GLOBALS['post'] );

				get_template_part( 'template-parts/related', 'posts' );
			}
			echo '</div><!--.anky-related-posts-wrap-->';
			echo '</section><!--.anky-related-posts-->';
			echo $is_customizer ? '</div>' : '';
			wp_reset_postdata();
		endif;
	}

	/**
	 * Prepare arguments for related posts and obtain them.
	 *
	 * @return int[]|WP_Post[] Array of post objects or post IDs.
	 */
	public function prepare_data() {
		global $post;

		// Prevent gathering data if option is disabled.
		if ( ! anky_get_option( 'blog-related-posts' ) ) {
			return array();
		}

		// Find related tags IDs.
		$tags    = wp_get_post_tags( $post->ID );
		$tag_ids = array();
		foreach ( $tags as $individual_tag ) {
			$tag_ids[] = intval( $individual_tag->term_id );
		}

		// Find related categories IDs.
		$categories   = wp_get_post_categories( $post->ID );
		$category_ids = array();
		foreach ( $categories as $individual_category ) {
			$category_ids[] = intval( $individual_category );
		}

		return get_posts(
			array(
				'tag__in'             => $tag_ids,
				'category__in'        => $category_ids,
				'post__not_in'        => array( $post->ID ),
				'posts_per_page'      => 4,
				'ignore_sticky_posts' => 1,
			)
		);
	}
}
