<?php
/**
 * Footer Builder.
 *
 * @package    Anky/Builder
 * @subpackage Footer
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Footer;

use Anky\Includes\Core\Anky_Options;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Footer Builder class.
 */
class Anky_Footer_Builder {

	/**
	 * Theme Options Instance.
	 *
	 * @var Anky_Options $theme
	 * @access private
	 */
	private $options;

	/**
	 * String replacements templates.
	 *
	 * @var array
	 * @access private
	 */
	private $replacement_templates;

	/**
	 * Constructor.
	 *
	 * @param Anky_Options $options Theme options Instance.
	 */
	public function __construct( Anky_Options $options ) {
		$this->options               = $options;
		$this->replacement_templates = array(
			'from' => array( '[copyright]', '[current_year]', '[site_title]', '[theme_name]', '[theme_author]' ),
			'to'   => array( '&copy;', gmdate( 'Y' ), get_option( 'blogname' ), 'Anky', '<a href="//anky.com" rel="nofollow noopener" target="_blank">Anky</a>' ),
		);
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Render search form modal.
	 */
	public function render_search_modal() {
		get_search_form(
			array(
				'aria_label' => esc_attr__( 'Search form', 'anky' ),
				'modal'      => true,
			)
		);
	}

	/**
	 * Render header upper bar.
	 */
	public function build_footer_widgets() {
		// Render in case there is something present in the bar.
		if ( 'disabled' === $this->options->get( 'footer-widgets-layout-type' ) ) {
			return;
		}
		$opening_tag_atts = array(
			'id'         => 'footer_widgets',
			'class'      => array( 'anky-footer-widgets', 'widgets-area' ),
			'role'       => 'complementary',
			'aria-label' => '',
		);
		?>
		<div class="anky-footer-widgets-area">
			<div class="anky-container">
				<div <?php anky_the_atts( $opening_tag_atts ); ?>>
					<?php get_sidebar( 'footer' ); ?>
				</div><!-- #footer_widgets -->
			</div>
		</div>
		<?php
	}

	/**
	 * Build main footer content.
	 */
	public function build() {
		?>
		<div class="site-info">
			<?php $this->site_info(); ?>
			<?php $this->author_credentials(); ?>
		</div><!-- .site-info -->
		<?php
	}

	/**
	 * Build site info for footer content.
	 */
	public function site_info() {
		$content         = $this->options->get( 'footer-copyright-text' );
		$content         = str_replace( $this->replacement_templates['from'], $this->replacement_templates['to'], $content );
		$string_template = '<div class="anky-site-info">%s</div>';
		if ( is_customize_preview() ) {
			$string_template = '<div class="anky-site-info-container"><div class="anky-site-info">%s</div></div>';
		}
		echo wp_kses_post( sprintf( $string_template, $content ) );
	}

	/**
	 * Build Theme Author credentials.
	 */
	public function author_credentials() {
		$content         = $this->options->get( 'footer-right-block-content' );
		$content         = str_replace( $this->replacement_templates['from'], $this->replacement_templates['to'], $content );
		$string_template = '<div class="anky-credentials">%s</div>';
		if ( is_customize_preview() ) {
			$string_template = '<div class="anky-credentials-container"><div class="anky-credentials">%s</div></div>';
		}
		echo wp_kses_post( sprintf( $string_template, $content ) );
	}

}
