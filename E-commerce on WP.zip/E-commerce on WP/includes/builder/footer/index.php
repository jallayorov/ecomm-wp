<?php
/**
 * Index file
 *
 * @package    Anky/Builder
 * @subpackage Footer
 */

/* Silence is golden, and we agree. */
