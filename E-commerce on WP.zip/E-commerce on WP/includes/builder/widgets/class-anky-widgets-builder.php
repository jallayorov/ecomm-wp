<?php
/**
 * Widgets Builder.
 *
 * @package    Anky/Builder
 * @subpackage Widgets
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Widgets;

use Anky\Includes\Core\Anky_Options;
use Anky\Includes\Customizer\Anky_Sanitizer;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Widgets Builder class.
 */
class Anky_Widgets_Builder {

	/**
	 * Sidebars data.
	 *
	 * @var array $sidebars
	 * @access public
	 */
	public $sidebars = array();

	/**
	 * Theme Options Instance.
	 *
	 * @var Anky_Options $theme
	 * @access private
	 */
	private $options;

	/**
	 * Constructor.
	 *
	 * @param Anky_Options $options Theme options Instance.
	 */
	public function __construct( Anky_Options $options ) {
		$this->options = $options;
		$this->prepare_widgets_areas();
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Render search widget part for header.
	 *
	 * @return string
	 */
	public function get_search_widget() {
		$is_enabled = $this->options->get( 'header-widget-search' );
		// Prevent collecting generating data if widget must be hidden.
		if ( ! $is_enabled ) {
			return '';
		}

		// Search button.
		$button_args = array(
			'class'       => array( 'anky-clean-btn', 'anky-js-trigger-search-modal', 'anky-search-btn' ),
			'type'        => 'button',
			'aria-label'  => esc_attr__( 'Toggle search modal', 'anky' ),
			'data-toggle' => 'modal',
			'data-target' => '#search-modal-wrap',
		);

		return sprintf(
			'<div class="anky-widget anky-widget-search"><button %1$s>%2$s</button></div>',
			anky_build_atts( $button_args ),
			'<span class="anky-icon-magnifying-glass" aria-hidden="true"></span>'
		);
	}

	/**
	 * Render Phone widget part for header.
	 *
	 * @return string
	 */
	public function get_phone_widget() {
		$is_enabled = $this->options->get( 'header-widget-tel' );
		$tel_data   = $this->options->get( 'globals-contact-tel-number' );

		// Just to preview the data.
		if ( is_customize_preview() ) {
			$tel_data = empty( $tel_data ) ? '+1234567890' : $tel_data;
		}

		// Prevent collecting generating data if widget must be hidden or empty.
		if ( ! $is_enabled || empty( $tel_data ) ) {
			return '';
		}

		$tel_data = 'tel:' . Anky_Sanitizer::sanitize_phone_number( $tel_data );

		// Tel phone link.
		$link_args = array(
			'href'       => $tel_data,
			'class'      => 'anky-header-tel-link',
			'aria-label' => __( 'Contact us now', 'anky' ),
			'title'      => __( 'Contact us now', 'anky' ),
			'rel'        => 'nofollow',
		);

		return sprintf(
			'<div class="anky-widget anky-widget-tel"><a %s>%s</a></div>',
			anky_build_atts( $link_args ),
			'<span class="anky-icon-phone" aria-hidden="true"></span>'
		);
	}

	/**
	 * Prepare sidebar areas.
	 */
	public function prepare_widgets_areas() {
		// Reset previous values if there are any.
		$this->sidebars        = array();
		$_is_customize_preview = is_customize_preview();

		// Main sidebar.
		if ( $this->options->get( 'main-blog-sidebar' ) || $_is_customize_preview ) {
			$this->sidebars['anky-main-sidebar'] = array(
				'id'            => 'anky-main-sidebar',
				'name'          => esc_html__( 'Main sidebar', 'anky' ),
				'description'   => esc_html__( 'The main sidebar widget area', 'anky' ),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			);
		}

		// Footer widgets area.
		$footer_widgets_amount = ( 'layout-1' === $this->options->get( 'footer-widgets-layout-type' ) || $_is_customize_preview ) ? 3 : 0;

		// Footer widgets.
		for ( $i = 1; $i <= $footer_widgets_amount; $i ++ ) {
			$this->sidebars["anky-footer-sidebar-$i"] = array(
				'id'            => "anky-footer-sidebar-$i",
				/* translators: %s widget area number. */
				'name'          => sprintf( esc_html__( 'Footer Widget Area %s', 'anky' ), $i ),
				/* translators: %s widget area number. */
				'description'   => sprintf( esc_html__( 'Footer Widget Area displayed in column %s', 'anky' ), $i ),
				'before_widget' => '<div id="%1$s" class="anky-footer-widget widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			);
		}
	}

}
