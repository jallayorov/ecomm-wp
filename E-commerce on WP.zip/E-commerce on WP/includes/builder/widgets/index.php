<?php
/**
 * Index file
 *
 * @package    Anky/Builder
 * @subpackage Widgets
 */

/* Silence is golden, and we agree. */
