<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Builder
 */

/* Silence is golden, and we agree. */
