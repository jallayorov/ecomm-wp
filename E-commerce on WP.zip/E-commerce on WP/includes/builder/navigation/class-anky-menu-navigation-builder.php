<?php
/**
 * Menu navigation Builder
 *
 * @package       Anky/Builder
 * @subpackage    Navigation
 * @author        Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Navigation;

use Anky\Includes\Traits\Trait_Singleton as Singleton;


// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Main Navigation Builder class.
 */
class Anky_Menu_Navigation_Builder {
	use Singleton;

	/**
	 * Navigation id used for registration of primary menu location.
	 *
	 * @var string $primary_menu_id
	 * @access public
	 */
	public static $primary_menu_id = 'primary';

	/**
	 * Navigation id used for registration of secondary location.
	 *
	 * @var string $header_bar_id
	 * @access public
	 */
	public static $header_bar_id = 'upper-bar';

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Retrieve navigation menu or the link to admin page to setup it.
	 *
	 * @return string
	 */
	public function get_primary_menu() {
		if ( ! has_nav_menu( self::$primary_menu_id ) ) {
			return $this->get_empty_menu_link();
		}

		$menu_args = apply_filters(
			'anky_primary_menu_args',
			array(
				'menu'                 => self::$primary_menu_id,
				'container'            => 'nav',
				'container_class'      => 'anky-navigation-wrapper hidden',
				'container_id'         => '',
				'container_aria_label' => esc_attr__( 'Primary menu', 'anky' ),
				'menu_class'           => 'anky-menu anky-list-unstyled',
				'menu_id'              => self::$primary_menu_id . '-menu',
				'echo'                 => false,
				'fallback_cb'          => 'wp_page_menu',
				'before'               => '',
				'after'                => '',
				'link_before'          => '',
				'link_after'           => '',
				'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
				'item_spacing'         => 'preserve',
				'depth'                => 0,
				'walker'               => new Anky_Primary_Navigation_Walker(),
			)
		);

		$menu_args['theme_location'] = self::$primary_menu_id;

		return wp_nav_menu( $menu_args );
	}

	/**
	 * Retrieve Header Bar navigation menu or the link to admin page to setup it.
	 *
	 * @return string
	 */
	public function get_header_bar_menu() {
		if ( ! has_nav_menu( self::$header_bar_id ) ) {
			return $this->get_empty_menu_link();
		}

		$menu_args = apply_filters(
			'anky_secondary_menu_args',
			array(
				'menu'                 => self::$header_bar_id,
				'container'            => false,
				'container_class'      => '',
				'container_id'         => '',
				'container_aria_label' => esc_attr__( 'Header Bar Menu', 'anky' ),
				'menu_class'           => 'anky-header-bar-menu anky-list-unstyled',
				'menu_id'              => self::$header_bar_id . '-menu',
				'echo'                 => false,
				'fallback_cb'          => 'wp_page_menu',
				'before'               => '',
				'after'                => '',
				'link_before'          => '',
				'link_after'           => '',
				'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
				'item_spacing'         => 'preserve',
				'depth'                => 0,
				'walker'               => new Anky_Secondary_Navigation_Walker(),
			)
		);

		$menu_args['theme_location'] = self::$header_bar_id;

		return wp_nav_menu( $menu_args );
	}


	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Retrieve a link to setup or customize menu location.
	 * May return empty string if menu is set but is not attached to Location and user is has no permissions to edit menu.
	 *
	 * @return string
	 */
	private function get_empty_menu_link() {
		if ( is_customize_preview() ) {
			$tag  = 'button';
			$atts = array(
				'type'                 => 'button',
				'class'                => array( 'anky-widget-handler', 'anky-widget-handler-btn', 'anky-js-widget-focus' ),
				'data-customizer-link' => 'menu_locations',
				'onclick'              => 'ankyCustomizeLink(this)', // Required to trigger focus after partial is re-rendered.
			);
		} elseif ( current_user_can( 'edit_theme_options' ) ) {
			$tag  = 'a';
			$atts = array(
				'href'   => admin_url( 'nav-menus.php' ),
				'class'  => array( 'anky-widget-handler', 'anky-widget-handler-link' ),
				'target' => '_blank',
			);
		} else {
			// Show nothing if it is regular user.
			return '';
		}

		$template_str = sprintf( '<%1$s %2$s>%3$s</%1$s>', $tag, anky_build_atts( $atts ), esc_html__( 'Assign menu', 'anky' ) );

		return '<span class="anky-empty-menu-wrapper">' . $template_str . '</span>';
	}

}
