<?php
/**
 * Anky theme custom Nav Walker.
 *
 * @package    Anky/Builder
 * @subpackage Navigation
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Navigation;

use Anky\Includes\Builder\Anky_UI_Controller;
use stdClass;
use Walker_Nav_Menu;
use WP_Post;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky theme custom Nav Walker.
 */
class Anky_Primary_Navigation_Walker extends Walker_Nav_Menu {

	/**
	 * Whether the items_wrap contains schema microdata or not.
	 *
	 * @var boolean
	 */
	private $has_schema = true;

	/**
	 * Top level items of the menu.
	 *
	 * @var array
	 * @access private
	 */
	private $top_level_items;

	/**
	 * Menu center position.
	 *
	 * @var int
	 * @access private
	 */
	private $center_position_in_menu;

	/**
	 * Menu center position.
	 *
	 * @var string
	 * @access private
	 */
	private $header_layout;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->header_layout = anky_get_option( 'header-layout-type', 'header-layout-1' );

		if ( 'header-layout-2' === $this->header_layout ) {
			add_filter( 'wp_nav_menu_objects', array( $this, 'find_menu_center_position' ), 10, 2 );
		}

		if ( ! has_filter( 'wp_nav_menu_args', array( $this, 'add_schema_to_navigation' ) ) ) {
			add_filter( 'wp_nav_menu_args', array( $this, 'add_schema_to_navigation' ) );
		}
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Starts the list before the elements are added.
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 *
	 * @see   Walker_Nav_Menu::start_lvl()
	 *
	 * @since WP 3.0.0
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		// Choosing the spacing type.
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$t = '';
			$n = '';
		} else {
			$t = "\t";
			$n = "\n";
		}

		$indent = str_repeat( $t, $depth );

		// Default class to add to the file.
		$classes = array( 'anky-list-unstyled' );

		// Class to submenu.
		if ( $depth >= 0 ) {
			$classes[] = 'anky-submenu-list';
		}

		/**
		 * Filters the CSS class(es) applied to a menu list element.
		 *
		 * @param array    $classes The CSS classes that are applied to the menu `<ul>` element.
		 * @param stdClass $args    An object of `wp_nav_menu()` arguments.
		 * @param int      $depth   Depth of menu item. Used for padding.
		 *
		 * @since WP 4.8.0
		 */
		$class_names = join( ' ', apply_filters( 'nav_menu_submenu_css_class', $classes, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		/*
		 * The submenu container needs to have a labelledby
		 * attribute which points to it's trigger link.
		 *
		 * Form a string for the labelledby attribute from the the latest
		 * link with an id that was added to the $output.
		 */
		$labelledby = '';
		// Find all links with an id in the output.
		preg_match_all( '/(<a.*?id=\"|\')(.*?)\"|\'.*?>/im', $output, $matches );
		// With pointer at end of array check if we got an ID match.
		if ( end( $matches[2] ) ) {
			// Build a string to use as aria-labelledby.
			$labelledby = 'aria-labelledby="' . esc_attr( end( $matches[2] ) ) . '"';
		}
		$output .= "{$n}{$indent}<ul$class_names $labelledby>{$n}";
	}

	/**
	 * Starts the element output.
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param WP_Post  $item   Menu item data object.
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 * @param int      $id     Current item ID.
	 *
	 * @see   Walker::start_el()
	 *
	 * @since 3.0.0
	 * @since 4.4.0 The {@see 'nav_menu_item_args'} filter was added.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		// Form item spacing.
		$t      = ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) ? '' : "\t";
		$indent = ( $depth ) ? str_repeat( $t, $depth ) : '';

		if ( isset( $args->items_wrap ) ) {
			// Add schema before/after links.
			if ( false !== strpos( $args->items_wrap, 'itemscope' ) && false === $this->has_schema ) {
				$this->has_schema  = true;
				$args->link_before = '<span itemprop="name">' . $args->link_before;

				$args->link_after .= '</span>';
			}
		}

		// Generating CSS class.
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;

		/**
		 * Updating the CSS classes of a menu item in the WordPress Customizer preview results in all classes defined
		 *  in that particular input box to come in as one big class string.
		 *
		 * @param $class
		 *
		 * @return array|false|string[]
		 */
		$split_on_spaces = function ( $class ) {
			return preg_split( '/\s+/', $class );
		};
		$classes         = anky_array_flatten( array_map( $split_on_spaces, $classes ) );

		/**
		 * Filters the arguments for a single nav menu item.
		 *
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param WP_Post  $item  Menu item data object.
		 * @param int      $depth Depth of menu item. Used for padding.
		 *
		 * @since WP 4.4.0
		 */
		$args = apply_filters( 'nav_menu_item_args', $args, $item, $depth );

		// Add submenu or active classes where they are needed.
		if ( $this->has_children ) {
			$classes[] = 'anky-menu-item-has-submenu';
		}
		if ( in_array( 'current-menu-item', $classes, true ) || in_array( 'current-menu-parent', $classes, true ) ) {
			$classes[] = 'active';
		}

		// Add some additional default classes to the item.
		$classes[] = 'menu-item-' . $item->ID;
		$classes[] = 'anky-menu-item';

		// Allow filtering the classes.
		$classes = apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth );

		// Form a string of classes in format: class="class_names".
		$class_names = join( ' ', $classes );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		/**
		 * Filters the ID applied to a menu item's list item element.
		 *
		 * @param string   $menu_id The ID that is applied to the menu item's `<li>` element.
		 * @param stdClass $args    An object of wp_nav_menu() arguments.
		 * @param WP_Post  $item    Menu item data object.
		 * @param int      $depth   Depth of menu item. Used for padding.
		 *
		 * @since WP 3.0.1
		 * @since WP 4.1.0 The `$depth` parameter was added.
		 */
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
		$id = $id ? 'id="' . esc_attr( $id ) . '"' : '';

		// Start generating menu item element.
		$output .= $indent . '<li ' . $id . $class_names . '>';

		// Initialize array for holding the $atts for the link item (title, rel, target, href).
		$atts           = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		if ( '_blank' === $item->target && empty( $item->xfn ) ) {
			$atts['rel'] = 'noopener noreferrer';
		} else {
			$atts['rel'] = ! empty( $item->xfn ) ? $item->xfn : '';
		}


		// If the item has_children add atts to <a>.
		if ( $this->has_children /*&& 0 === $depth*/ ) {
			$atts['href']          = $item->url;
			$atts['aria-haspopup'] = 'true';
			$atts['aria-expanded'] = 'false';
			$atts['class']         = 'anky-has-submenu anky-menu-item-link';
			$atts['id']            = 'anky-submenu-' . $item->ID;
		} else {
			if ( true === $this->has_schema ) {
				$atts['itemprop'] = 'url';
			}

			$atts['href'] = ! empty( $item->url ) ? $item->url : '#';

			// For items with submenus.
			if ( $depth > 0 ) {
				$atts['class'] = 'anky-menu-item-link submenu-item';
			} else {
				$atts['class'] = 'anky-menu-item-link';
			}

			/**
			 * Add active class to <a>.
			 */
			if ( $item->current ) {
				$atts['class'] = 'anky-menu-item-link anky-menu-item-link-active';
			}
		}

		$atts['aria-current'] = $item->current ? 'page' : '';

		/**
		 * Filters the HTML attributes applied to a menu item's anchor element.
		 *
		 * @param array    $atts  The HTML attributes applied to the menu item's `<a>` element, empty strings are ignored.
		 * @param WP_Post  $item  The current menu item.
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param int      $depth Depth of menu item. Used for padding.
		 *
		 * @since 3.6.0
		 * @since 4.1.0 The `$depth` parameter was added.
		 */
		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		// Start appending the internal item contents to the output.
		$item_output = $args->before ?? '';

		/**
		 * Set a standard opening <a> tag with attributes.
		 */
		$item_output .= sprintf( '<%s %s>', 'a', anky_build_atts( $atts ) );

		/** This filter is documented in wp-includes/post-template.php */
		$title = apply_filters( 'the_title', $item->title, $item->ID );

		/**
		 * Filters a menu item's title.
		 *
		 * @param string   $title The menu item's title.
		 * @param WP_Post  $item  The current menu item.
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param int      $depth Depth of menu item. Used for padding.
		 *
		 * @since WP 4.4.0
		 */
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		// Put the item contents into $output.
		$item_output .= isset( $args->link_before ) ? $args->link_before . $title . $args->link_after : '';

		/**
		 * Set a standard closing </a> tag with attributes.
		 */
		$item_output .= '</a>';

		/**
		 * Add button as a dropdown toggle for the additional availability.
		 */
		if ( $this->has_children ) {
			/**
			 * Filters submenu button classes.
			 *
			 * @param array $classes Classes for the button.
			 *
			 * @since Anky 1.0.0
			 */
			$classes = apply_filters( 'anky-submenu-button-class', array( 'anky-clean-btn', 'anky-dropdown-btn' ) );

			$item_output .= '<button class="' . implode( ' ', $classes ) . '" type="button">';
			$item_output .= '<span class="anky-icon-plus" aria-hidden="true"></span>';
			/* translators: %s: menu title. */
			$item_output .= '<span class="screen-reader-text">' . sprintf( esc_html__( 'Show submenu for %s', 'anky' ), $title ) . '</span>';
			$item_output .= '</button>';
		}

		$item_output .= $args->after ?? '';

		// END appending the internal item contents to the output.
		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}

	/**
	 * Ends the element output, if needed.
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param WP_Post  $item   Page data object. Not used
	 * @param int      $depth  Depth of page. Not Used.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 *
	 * @since 3.0.0
	 *
	 * @see   Walker::end_el()
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$n = ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) ? '' : "\n";

		$output .= "</li>{$n}";
		if ( 'header-layout-2' === $this->header_layout ) {
			$output .= $this->add_logo_in_the_middle( $item, $n );
		}
	}

	/**
	 * Filter to ensure the items_Wrap argument contains microdata.
	 *
	 * @param array $args The nav instance arguments.
	 *
	 * @return array $args The altered nav instance arguments.
	 */
	public function add_schema_to_navigation( $args ) {
		$wrap = $args['items_wrap'];
		if ( strpos( $wrap, 'SiteNavigationElement' ) === false ) {
			$args['items_wrap'] = preg_replace(
				'/(>).*>?\%3\$s/',
				' itemscope itemtype="http://www.schema.org/SiteNavigationElement"$0',
				$wrap
			);
		}

		return $args;
	}

	/**
	 * Finds center position in menu items array.
	 *
	 * @param array    $sorted_menu_items The menu items, sorted by each menu item's menu order.
	 * @param stdClass $args              An object containing wp_nav_menu() arguments.
	 *
	 * @return array sorted list of menu item objects.
	 */
	public function find_menu_center_position( $sorted_menu_items, $args ) {
		$top_level_items = array();
		foreach ( $sorted_menu_items as $menu_item ) {
			if ( 0 === intval( $menu_item->menu_item_parent ) ) {
				$top_level_items[] = $menu_item;
			}
		}

		$this->top_level_items         = $top_level_items;
		$this->center_position_in_menu = (int) floor( count( $top_level_items ) / 2 );

		return $sorted_menu_items;
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Set logo in the middle of menu.
	 *
	 * @param WP_Post $item   Page data object.
	 * @param string  $spacer Key with what to make spaces between tags.
	 *
	 * @return string
	 */
	private function add_logo_in_the_middle( $item, $spacer ) {
		$output = '';
		// make sure logo is outputted for top level only.
		if ( '0' === $item->menu_item_parent ) { // $item->menu_item_parent holds string.
			$current_position = 0;
			foreach ( $this->top_level_items as $index => $top_level_item ) {
				if ( $top_level_item->ID === $item->ID ) {
					$current_position = $index + 1;
				}
			}
			if ( $current_position === $this->center_position_in_menu ) {
				$output .= '<li class="anky-menu-item anky-menu-item-logo">' . $spacer;
				$output .= Anky_UI_Controller::get_site_identity() . $spacer;
				$output .= "</li>{$spacer}";
			}
		}

		return $output;
	}

}
