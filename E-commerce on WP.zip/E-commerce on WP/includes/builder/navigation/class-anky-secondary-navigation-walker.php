<?php
/**
 * Anky theme custom Nav Walker.
 *
 * @package    Anky/Builder
 * @subpackage Navigation
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Navigation;

use stdClass;
use Walker_Nav_Menu;
use WP_Post;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky theme custom Nav Walker.
 */
class Anky_Secondary_Navigation_Walker extends Walker_Nav_Menu {

	/**
	 * Whether the items_wrap contains schema microdata or not.
	 *
	 * @var boolean
	 */
	private $has_schema = true;

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! has_filter( 'wp_nav_menu_args', array( $this, 'add_schema_to_navigation' ) ) ) {
			add_filter( 'wp_nav_menu_args', array( $this, 'add_schema_to_navigation' ) );
		}
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Starts the list before the elements are added.
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 *
	 * @see   Walker_Nav_Menu::start_lvl()
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
	}

	/**
	 * Ends the list of after the elements are added.
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 *
	 * @see   Walker::end_lvl()
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
	}

	/**
	 * Starts the element output.
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param WP_Post  $item   Menu item data object.
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 * @param int      $id     Current item ID.
	 *
	 * @see   Walker::start_el()
	 *
	 * @since 3.0.0
	 * @since 4.4.0 The {@see 'nav_menu_item_args'} filter was added.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		// Form item spacing.
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$t = '';
			$n = '';
		} else {
			$t = "\t";
			$n = "\n";
		}
		$indent = ( $depth ) ? str_repeat( $t, $depth ) : '';

		if ( isset( $args->items_wrap ) ) {
			// Add schema before/after links.
			if ( false !== strpos( $args->items_wrap, 'itemscope' ) && false === $this->has_schema ) {
				$this->has_schema  = true;
				$args->link_before = '<span itemprop="name">' . $args->link_before;

				$args->link_after .= '</span>';
			}
		}

		// Generating CSS class.
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;

		/**
		 * Updating the CSS classes of a menu item in the WordPress Customizer preview results in all classes defined
		 *  in that particular input box to come in as one big class string.
		 *
		 * @param $class
		 *
		 * @return array|false|string[]
		 */
		$split_on_spaces = function ( $class ) {
			return preg_split( '/\s+/', $class );
		};
		$classes         = anky_array_flatten( array_map( $split_on_spaces, $classes ) );

		/**
		 * Filters the arguments for a single nav menu item.
		 *
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param WP_Post  $item  Menu item data object.
		 * @param int      $depth Depth of menu item. Used for padding.
		 *
		 * @since WP 4.4.0
		 */
		$args = apply_filters( 'nav_menu_item_args', $args, $item, $depth );

		// Add some additional default classes to the item.
		$classes[] = 'menu-item-' . $item->ID;
		$classes[] = 'anky-secondary-menu-item';

		// Allow filtering the classes.
		$classes = apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth );

		// Form a string of classes in format: class="class_names". Children class also should be removed as we need one line menu.
		$class_names = join( ' ', $classes );
		$class_names = str_replace( 'menu-item-has-children', '', $class_names );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		/**
		 * Filters the ID applied to a menu item's list item element.
		 *
		 * @param string   $menu_id The ID that is applied to the menu item's `<li>` element.
		 * @param stdClass $args    An object of wp_nav_menu() arguments.
		 * @param WP_Post  $item    Menu item data object.
		 * @param int      $depth   Depth of menu item. Used for padding.
		 *
		 * @since WP 3.0.1
		 * @since WP 4.1.0 The `$depth` parameter was added.
		 */
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
		$id = $id ? 'id="' . esc_attr( $id ) . '"' : '';

		// Start generating menu item element.
		$output .= $indent . '<li ' . $id . $class_names . '>';

		// Initialize array for holding the $atts for the link item (title, rel, target, href).
		$atts           = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		if ( '_blank' === $item->target && empty( $item->xfn ) ) {
			$atts['rel'] = 'noopener noreferrer';
		} else {
			$atts['rel'] = ! empty( $item->xfn ) ? $item->xfn : '';
		}

		if ( true === $this->has_schema ) {
			$atts['itemprop'] = 'url';
		}

		$atts['href']  = ! empty( $item->url ) ? $item->url : '#';
		$atts['class'] = 'anky-secondary-menu-item-link';

		/**
		 * Add active class to <a>.
		 */
		if ( $item->current ) {
			$atts['class']        = 'anky-secondary-menu-item-link anky-secondary-menu-item-link-active';
			$atts['aria-current'] = 'page';
		}

		/**
		 * Filters the HTML attributes applied to a menu item's anchor element.
		 *
		 * @param array    $atts  The HTML attributes applied to the menu item's `<a>` element, empty strings are ignored.
		 * @param WP_Post  $item  The current menu item.
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param int      $depth Depth of menu item. Used for padding.
		 *
		 * @since 3.6.0
		 * @since 4.1.0 The `$depth` parameter was added.
		 */
		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		// Start appending the internal item contents to the output.
		$item_output = $args->before ?? '';

		/**
		 * Set a standard opening <a> tag with attributes.
		 */
		$item_output .= sprintf( '<%s %s>', 'a', anky_build_atts( $atts ) );

		/** This filter is documented in wp-includes/post-template.php */
		$title = apply_filters( 'the_title', $item->title, $item->ID );

		/**
		 * Filters a menu item's title.
		 *
		 * @param string   $title The menu item's title.
		 * @param WP_Post  $item  The current menu item.
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param int      $depth Depth of menu item. Used for padding.
		 *
		 * @since WP 4.4.0
		 */
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		// Put the item contents into $output.
		$item_output .= isset( $args->link_before ) ? $args->link_before . $title . $args->link_after : '';

		/**
		 * Set a standard closing </a> tag with attributes.
		 */
		$item_output .= '</a>';

		$item_output .= $args->after ?? '';
		$item_output .= "</li>{$n}";

		// END appending the internal item contents to the output.
		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}

	/**
	 * Ends the element output, if needed.
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param WP_Post  $item   Page data object. Not used.
	 * @param int      $depth  Depth of page. Not Used.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 *
	 * @since 3.0.0
	 *
	 * @see   Walker::end_el()
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
	}

	/**
	 * Filter to ensure the items_Wrap argument contains microdata.
	 *
	 * @param array $args The nav instance arguments.
	 *
	 * @return array $args The altered nav instance arguments.
	 */
	public function add_schema_to_navigation( $args ) {
		$wrap = $args['items_wrap'];
		if ( strpos( $wrap, 'SiteNavigationElement' ) === false ) {
			$args['items_wrap'] = preg_replace(
				'/(>).*>?\%3\$s/',
				' itemscope itemtype="http://www.schema.org/SiteNavigationElement"$0',
				$wrap
			);
		}

		return $args;
	}

}
