<?php
/**
 * Tweaks for the <head> of the document.
 *
 * @package    Anky
 * @subpackage Builder
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder;

use Anky\Includes\Core\Anky_Options;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Tweaks for the <head> of the document.
 */
class Anky_Head {

	/**
	 * Theme Options Instance.
	 *
	 * @var Anky_Options $theme
	 * @access private
	 */
	private $options;

	/**
	 * Constructor.
	 *
	 * @param Anky_Options $options Theme options Instance.
	 */
	public function __construct( Anky_Options $options ) {
		$this->options = $options;
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Set the user agent data attribute on the HTML tag.
	 */
	public function set_user_agent() {
		?>
		<script>
			var doc = document.documentElement;
			doc.setAttribute( 'data-useragent', navigator.userAgent );
		</script>
		<?php
	}

	/**
	 * Set the document title separator.
	 *
	 * @access  public
	 */
	public function document_title_separator() {
		return $this->options->get( 'document-title-separator' );
	}

	/**
	 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
	 *
	 * @credit twentynineteen WordPress Theme
	 */
	public function head_pingback() {
		if ( is_singular() && pings_open() ) {
			printf( '<link rel="pingback" href="%s">' . "\n", esc_url( get_bloginfo( 'pingback_url' ) ) );
		}
	}

	/**
	 * Add preconnect for Google MAP Embed.
	 *
	 * @param array  $urls          URLs to print for resource hints.
	 * @param string $relation_type The relation type the URLs are printed.
	 *
	 * @return array URLs to print for resource hints.
	 */
	public function preload_map( $urls, $relation_type ) {
		if ( empty( $this->options->get( 'globals-contact-address' ) ) ) {
			return $urls;
		}

		if ( 'preconnect' === $relation_type ) {
			$urls[] = array(
				'href' => 'https://maps.googleapis.com',
				'crossorigin',
			);
			$urls[] = array(
				'href' => 'https://maps.gstatic.com',
				'crossorigin',
			);
		}

		return $urls;
	}

}
