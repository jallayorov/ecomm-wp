<?php
/**
 * Anky Colors Controller.
 *
 * @package    Anky
 * @subpackage Builder
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder;

use Anky\Includes\Core\Anky_Options;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Colors Controller.
 */
final class Anky_Colors {

	/**
	 * Color Scheme template.
	 *
	 * Scheme consists of different color that are set as global variables.
	 * Each color is used in different situations.
	 * `--anky-colors__primary` -> Text, Buttons, Icons, Interactive: Default
	 * `--anky-colors__secondary` -> Text, Icons, Interactive: Hover & Focus
	 * `--anky-colors__tertiary` -> Text, Disabled Buttons, Interactive: Active
	 * `--anky-colors__accent-primary` -> Buttons, Links, Interactive States
	 * `--anky-colors__accent-hover` -> Buttons, Links, Interactive States - Hover
	 * `--anky-colors__accent-focus` -> Buttons, Links, Interactive States - Focus
	 * `--anky-colors__inverse` -> Text, Buttons, Primary Background (Will depend on the main theme color)
	 * `--anky-colors__border-primary` -> Dividers, Input Borders, Ellipse Button Borders, Interactive States
	 * `--anky-colors__border-hover` -> Dividers, Input Borders, Ellipse Button Borders, Interactive States - Hover
	 * `--anky-colors__border-focus` -> Dividers, Input Borders, Ellipse Button Borders, Interactive States - Focus
	 * `--anky-colors__background-primary` -> Inputs, Buttons, Interactive States
	 * `--anky-colors__background-hover` -> Inputs, Buttons, Interactive States - Hover
	 * `--anky-colors__background-focus` -> Inputs, Buttons, Interactive States - Focus
	 *
	 * @var array $scheme
	 * @access private
	 */
	private $scheme = array(
		'--anky-colors__primary'           => '',
		'--anky-colors__secondary'         => '',
		'--anky-colors__tertiary'          => '',
		'--anky-colors__accent-primary'    => '',
		'--anky-colors__accent-hover'      => '',
		'--anky-colors__accent-focus'      => '',
		'--anky-colors__inverse'           => '',
		'--anky-colors__border'            => '',
		'--anky-colors__border-hover'      => '',
		'--anky-colors__border-active'     => '',
		'--anky-colors__background'        => '',
		'--anky-colors__background-hover'  => '',
		'--anky-colors__background-active' => '',
		'--anky-colors__box-shadow'        => '',
		'--anky-colors__text-shadow'       => '',
	);

	/**
	 * Current active color scheme name.
	 *
	 * @var string $current_scheme Current active color scheme name.
	 *
	 * @access private
	 */
	private $current_scheme = '';

	/**
	 * Theme Options Instance.
	 *
	 * @var Anky_Options $theme
	 * @access private
	 */
	private $options;

	/**
	 * Constructor.
	 *
	 * @param Anky_Options $options Theme options Instance.
	 */
	public function __construct( Anky_Options $options ) {
		$this->options = $options;
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Apply schema and return color options.
	 *
	 * @return array Array of colors in selected schema.
	 */
	public function apply_scheme() {
		$color_option = $this->options->get( 'globals-color-scheme', 'light' );
		$method_name  = "set_{$color_option}_scheme";

		$this->$method_name();

		return $this->get_scheme();
	}

	/**
	 * Retrieve current colors schema with colors.
	 */
	public function get_scheme() {
		return $this->scheme;
	}

	/**
	 * Retrieve current colors schema with colors.
	 *
	 * @return string
	 */
	public function get_active_scheme_name() {
		return $this->current_scheme;
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Set light schema for theme.
	 */
	private function set_light_scheme() {
		$this->scheme         = array(
			'--anky-colors__primary'           => 'hsl(240, 8%, 9%)',
			'--anky-colors__secondary'         => 'hsl(240, 2%, 50%)',
			'--anky-colors__tertiary'          => 'hsl(240, 3%, 69%)',
			'--anky-colors__accent-primary'    => 'hsl(349, 80%, 45%)',
			'--anky-colors__accent-hover'      => 'hsl(349, 80%, 42%)',
			'--anky-colors__accent-focus'      => 'hsl(349, 80%, 39%)',
			'--anky-colors__inverse'           => 'hsl(0, 0%, 100%)',
			'--anky-colors__border'            => 'hsl(0, 0%, 88%)',
			'--anky-colors__border-hover'      => 'hsl(0, 0%, 80%)',
			'--anky-colors__border-active'     => 'hsl(0, 0%, 72%)',
			'--anky-colors__background'        => 'hsl(0, 0%, 96%)',
			'--anky-colors__background-hover'  => 'hsl(0, 0%, 94%)',
			'--anky-colors__background-active' => 'hsl(0, 0%, 92%)',
			'--anky-colors__box-shadow'        => 'hsla(240, 8%, 9%, 0.12)',
			'--anky-colors__text-shadow'       => 'hsla(240, 8%, 9%, 0.4)',
		);
		$this->current_scheme = 'light';
	}

	/**
	 * Set dark schema for theme.
	 */
	private function set_dark_scheme() {
		$this->scheme         = array(
			'--anky-colors__primary'           => 'hsl(0, 0%, 100%)',
			'--anky-colors__secondary'         => 'hsl(240, 2%, 50%)',
			'--anky-colors__tertiary'          => 'hsl(240, 2%, 32%)',
			'--anky-colors__accent-primary'    => 'hsl(349, 80%, 45%)',
			'--anky-colors__accent-hover'      => 'hsl(349, 80%, 42%)',
			'--anky-colors__accent-focus'      => 'hsl(349, 80%, 39%)',
			'--anky-colors__inverse'           => 'hsl(240, 8%, 9%)',
			'--anky-colors__border'            => 'hsl(240, 8%, 19%)',
			'--anky-colors__border-hover'      => 'hsl(240, 8%, 23%)',
			'--anky-colors__border-active'     => 'hsl(240, 8%, 28%)',
			'--anky-colors__background'        => 'hsl(240, 8%, 13%)',
			'--anky-colors__background-hover'  => 'hsl(240, 8%, 15%)',
			'--anky-colors__background-active' => 'hsl(240, 8%, 17%)',
			'--anky-colors__box-shadow'        => 'hsla(0, 0%, 100%, 0.12)',
			'--anky-colors__text-shadow'       => 'hsla(0, 0%, 100%, 0.4)',
		);
		$this->current_scheme = 'dark';
	}

}
