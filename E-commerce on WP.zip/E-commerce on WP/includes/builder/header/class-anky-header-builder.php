<?php
/**
 * Header Builder.
 *
 * @package    Anky/Builder
 * @subpackage Header
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder\Header;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Builder\Navigation\Anky_Menu_Navigation_Builder;
use Anky\Includes\Builder\Widgets\Anky_Widgets_Builder;
use Anky\Includes\Core\Anky_Options;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Header Builder class.
 */
class Anky_Header_Builder {

	/**
	 * Theme Options Instance.
	 *
	 * @var Anky_Options $theme
	 * @access private
	 */
	private $options;

	/**
	 * Theme Widgets Instance.
	 *
	 * @var Anky_Widgets_Builder $theme
	 * @access private
	 */
	private $widgets;

	/**
	 * Constructor.
	 *
	 * @param Anky_Options         $options Theme options Instance.
	 * @param Anky_Widgets_Builder $widgets Theme Widgets Instance.
	 */
	public function __construct( Anky_Options $options, Anky_Widgets_Builder $widgets ) {
		$this->options = $options;
		$this->widgets = $widgets;
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Renders the header layout.
	 *
	 * @param string $layout_type Required layout type.
	 */
	public function build( $layout_type = '' ) {
		$is_customizer = is_customize_preview();
		$layout        = empty( $layout_type ) ? $this->options->get( 'header-layout-type', 'header-layout-type-1' ) : $layout_type;
		$layout_data   = array(
			'header'        => array(
				'id'    => 'masthead',
				'class' => array( 'anky-site-header', "anky-{$layout}" ),
			),
			'site_identity' => Anky_UI_Controller::get_site_identity(),
			'menu'          => Anky_Menu_Navigation_Builder::get_instance()->get_primary_menu(),
			'address'       => $this->options->get( 'globals-contact-address', ( $is_customizer ? '2823 Church Road, VA' : null ) ),
			'phone'         => $this->options->get( 'globals-contact-tel-number', ( $is_customizer ? '+1 234 567-8901' : null ) ),
			'socials'       => explode( ',', $this->options->get( 'globals-contact-social-networks', ( $is_customizer ? 'https://www.facebook.com,https://www.twitter.com,https://www.linkedin.com' : null ) ) ),
			'email'         => $this->options->get( 'globals-contact-email', ( $is_customizer ? 'info@example.com' : null ) ),
			'address_embed' => array(
				'src'             => $this->options->get(
					'globals-contact-address-map-embed',
					( $is_customizer ? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d41231.94633128963!2d-122.442852349698!3d37.75764367476565!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80859a6d00690021%3A0x4a501367f076adff!2z0KHQsNC9LdCk0YDQsNC90YbQuNGB0LrQviwg0JrQsNC70LjRhNC-0YDQvdC40Y8sINCh0KjQkA!5e0!3m2!1sru!2s!4v1626947737822!5m2!1sru!2s' : null )
				),
				'class'           => array( 'anky-contact-block-item', 'anky-contact-block-item-map' ),
				'height'          => '306',
				'width'           => '544',
				'allowfullscreen' => '',
				'style'           => 'border: 0;border-radius: 16px;',
			),
		);

		// Collect widgets for the different layouts.
		switch ( $layout ) {
			case 'header-layout-1':
			case 'header-layout-4':
				$layout_data['widgets'] = $this->widgets->get_search_widget() . "\n" . $this->widgets->get_phone_widget() . "\n" . Anky_UI_Controller::get_mobile_menu_toogler();
				break;
			case 'header-layout-3':
			case 'header-layout-2':
				$layout_data['widget_search'] = $this->widgets->get_search_widget();
				$layout_data['widgets']       = $this->widgets->get_phone_widget() . "\n" . Anky_UI_Controller::get_mobile_menu_toogler();
				break;
			case 'header-layout-5':
				$layout_data['widget_toggler'] = Anky_UI_Controller::get_mobile_menu_toogler();
				$layout_data['widgets']        = $this->widgets->get_search_widget() . "\n" . $this->widgets->get_phone_widget();
				break;
		}
		anky_load_template( 'template-parts/header/' . $layout, null, $layout_data );
	}

	/**
	 * Render header upper bar.
	 */
	public function build_upper_header() {
		/**
		 * Render in case there is something present in the bar.
		 * We also need to render the wrapper while in customizer, despite the bar is disabled.
		 * It is done to prevent iframe refresh.
		 */
		$layout        = $this->options->get( 'header-upper-bar-layout-type' );
		$is_customizer = is_customize_preview();

		if ( ! $is_customizer && 'disabled' === $layout ) {
			return;
		}

		if ( $is_customizer ) {
			echo '<div class="anky-upper-header-bar-wrap">';
		}

		if ( $is_customizer && 'disabled' === $layout ) {
			echo '</div>';

			return;
		}

		// Gather data in case its empty and previewing in customizer.
		$data = array(
			'address' => $this->options->get( 'globals-contact-address', ( $is_customizer ? '2823 Church Road, VA' : null ) ),
			'phone'   => $this->options->get( 'globals-contact-tel-number', ( $is_customizer ? '+1 234 567-8901' : null ) ),
			'socials' => explode( ',', $this->options->get( 'globals-contact-social-networks', ( $is_customizer ? 'https://www.facebook.com,https://www.twitter.com,https://www.linkedin.com' : null ) ) ),
			'email'   => $this->options->get( 'globals-contact-email', ( $is_customizer ? 'info@example.com' : null ) ),
		);

		?>
		<div class="anky-upper-header-bar anky-upper-header-bar-<?php echo esc_attr( $layout ); ?>">
			<div class="anky-container">
				<div class="anky-row<?php echo 'layout-4' === $layout ? ' anky-ai-center' : ''; ?>">
					<?php anky_load_template( "template-parts/header-bar/$layout", false, $data ); ?>
				</div>
			</div>
		</div>
		<?php
		if ( $is_customizer ) {
			echo '</div>';
		}
	}

	/**
	 * Render custom language switcher.
	 * Switcher support both `WPML` and `Polylang`.
	 * By installing one of these plugins, user can also activate or deactivate switcher.
	 */
	public function build_custom_language_switcher() {
		// Render preview container only for customizer.
		if ( is_customize_preview() ) {
			echo '<div class="anky-language-switcher-preview-container"></div>';
		}
		// Bailing if disabled.
		if ( ! $this->options->get( 'custom-switcher', false ) ) {
			return;
		}

		$output_sanitized = '<div id="anky-language-switcher-' . wp_rand( 1, 1000000 ) . '" class="anky-language-switcher">';
		$template_string  = '%5$s<li %1$s><a %2$s><span %3$s>%4$s</span></a></li>%6$s';
		// Start over WPML.
		if ( class_exists( 'SitePress' ) ) {
			$languages = apply_filters( 'wpml_active_languages', null, null );

			if ( 1 < count( $languages ) ) {
				$output_sanitized .= '<div class="anky-language-switcher-current">[ACTIVE]</div>';
				$output_sanitized .= '<div class="anky-language-switcher-list-wrapper"><ul class="anky-language-switcher-list anky-wpml-list">';

				foreach ( $languages as $lang ) {
					$atts = array(
						'li'   => array(
							'class' => array( 'anky-language-switcher-list-item' ),
						),
						'a'    => array(
							'class'    => 'anky-language-switcher-list-item-link',
							'rel'      => 'alternate',
							'hreflang' => $lang['language_code'],
							'href'     => apply_filters( 'wpml_ls_language_url', $lang['url'], $lang ),
						),
						'span' => array(
							'class' => 'anky-language-switcher-text',
						),
					);
					if ( $lang['active'] ) {
						$atts['li']['class'][] = 'anky-language-switcher-list-item-active';
						$output_sanitized      = str_replace( '[ACTIVE]', $lang['native_name'], $output_sanitized );
					}

					$output_sanitized .= sprintf(
						$template_string,
						anky_build_atts( $atts['li'] ),
						anky_build_atts( $atts['a'] ),
						anky_build_atts( $atts['span'] ),
						esc_html( $lang['native_name'] ), // translated_name or native_name.
						"\t",
						"\n"
					);
				}

				$output_sanitized .= '</ul></div>';
			}
		} elseif ( function_exists( 'pll_the_languages' ) ) {
			$languages = pll_the_languages(
				array(
					'echo'          => 0,
					'show_flags'    => 1,
					'hide_if_empty' => 0,
					'raw'           => 1,
				)
			);

			// cast array if string received.
			if ( 1 < count( (array) $languages ) ) {
				$output_sanitized .= '<div class="anky-language-switcher-current">[ACTIVE]</div>';
				$output_sanitized .= '<div class="anky-language-switcher-list-wrapper"><ul class="anky-language-switcher-list polylang-list">';

				foreach ( $languages as $lang ) {
					$atts = array(
						'li'   => array(
							'class' => array( 'anky-language-switcher-list-item' ),
						),
						'a'    => array(
							'class'    => 'anky-language-switcher-list-item-link',
							'rel'      => 'alternate',
							'lang'     => $lang['locale'],
							'hreflang' => $lang['locale'],
							'href'     => $lang['url'],
						),
						'span' => array(
							'class' => 'anky-language-switcher-text',
						),
					);
					if ( $lang['current_lang'] ) {
						$atts['li']['class'][] = 'anky-language-switcher-list-item-active';
						$output_sanitized      = str_replace( '[ACTIVE]', $lang['name'], $output_sanitized );
					}

					$output_sanitized .= sprintf(
						$template_string,
						anky_build_atts( $atts['li'] ),
						anky_build_atts( $atts['a'] ),
						anky_build_atts( $atts['span'] ),
						esc_html( $lang['name'] ),
						"\t",
						"\n"
					);
				}

				$output_sanitized .= '</ul></div>';
			}
		} else {
			if ( current_user_can( 'install_plugins' ) ) {
				$output_sanitized .= '<ul class="anky-language-switcher-list no-list">';
				$output_sanitized .= '<li class="anky-language-switcher-list-item"><a class="anky-language-switcher-list-item-link" target="_blank" href="//wordpress.org/plugins/polylang/">Polylang</a></li>';
				$output_sanitized .= '<li class="anky-language-switcher-list-item"><a class="anky-language-switcher-list-item-link" target="_blank" href="//wpml.org/">WPML</a></li>';
				$output_sanitized .= '</ul>';
			}
		}

		$output_sanitized .= '</div>';

		// All output data is properly sanitized.
		echo $output_sanitized; // phpcs:ignore WordPress.Security.EscapeOutput
	}

}
