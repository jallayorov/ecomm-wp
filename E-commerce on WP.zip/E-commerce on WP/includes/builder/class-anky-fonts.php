<?php
/**
 * Anky Fonts controller
 *
 * @package    Anky
 * @subpackage Builder
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Builder;

use Anky\Includes\Core\Anky_Options;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Fonts controller.
 */
final class Anky_Fonts {

	/**
	 * Array of fonts used in theme.
	 *
	 * @var array $font_data
	 * @access private
	 */
	private $font_data;

	/**
	 * Theme Options Instance.
	 *
	 * @var Anky_Options $theme
	 * @access private
	 */
	private $options;

	/**
	 * Constructor.
	 *
	 * @param Anky_Options $options Theme options Instance.
	 */
	public function __construct( Anky_Options $options ) {
		$this->options = $options;
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Prepare the url link to put inside link tag.
	 *
	 * @return string
	 */
	public function prepare_fonts_url() {
		$this->font_data = array(
			'main'     => json_decode( $this->options->get( 'globals-body-font-family' ), true ),
			'headings' => json_decode( $this->options->get( 'globals-headings-font-family' ), true ),
		);
		$fonts           = array();

		foreach ( $this->font_data as $item ) {
			$font_str = ! empty( $item['regularWeight'] ) ? $item['regularWeight'] . ',' : '';

			$font_str .= ! empty( $item['italicWeight'] ) ? $item['italicWeight'] . ',' : '';
			$font_str .= ! empty( $item['boldWeight'] ) ? $item['boldWeight'] : '';

			$fonts[ $item['family'] ] = rtrim( $font_str, ',' );
		}

		return $this->google_fonts_url( $fonts );
	}

	/**
	 * Google Font URL
	 * Combine multiple google font in one URL
	 *
	 * @link https://shellcreeper.com/?p=1476
	 *
	 * @param array $fonts   Google Fonts array.
	 * @param array $subsets Font's Subsets array.
	 *
	 * @return string
	 */
	public function google_fonts_url( $fonts, $subsets = array() ) {
		/* URL */
		$base_url  = '//fonts.googleapis.com/css';
		$font_args = array();
		$family    = array();

		/* Format Each Font Family in Array */
		foreach ( $fonts as $font_name => $font_weight ) {
			$font_name = str_replace( ' ', '+', $font_name );
			if ( ! empty( $font_weight ) ) {
				if ( is_array( $font_weight ) ) {
					$font_weight = implode( ',', $font_weight );
				}
				$family[] = trim( $font_name . ':' . rawurlencode( trim( $font_weight ) ) );
			} else {
				$family[] = trim( $font_name );
			}
		}

		/* Only return URL if font family defined. */
		if ( ! empty( $family ) ) {
			/* Make Font Family a String */
			$family = implode( '|', $family );

			/* Add font family in args */
			$font_args['family']  = $family;
			$font_args['display'] = 'swap';

			/* Add font subsets in args */
			if ( ! empty( $subsets ) ) {
				/* format subsets to string */
				if ( is_array( $subsets ) ) {
					$subsets = implode( ',', $subsets );
				}

				$font_args['subset'] = rawurlencode( trim( $subsets ) );
			}

			return add_query_arg( $font_args, $base_url );
		}

		return '';
	}

	/**
	 * Retrieve global font data.
	 *
	 * @return array
	 */
	public function get_global_font_data() {
		return array(
			'--anky-main-font'                    => "\"{$this->font_data['main']['family']}\", {$this->font_data['main']['category']}",
			'--anky-main-font-regular-weight'     => str_replace( 'regular', '400', $this->font_data['main']['regularWeight'] ),
			'--anky-main-font-italic-weight'      => empty( $this->font_data['main']['italicWeight'] )
				? 'var(--anky-main-font-regular-weight)'
				: filter_var( $this->font_data['main']['italicWeight'], FILTER_SANITIZE_NUMBER_INT ),
			'--anky-main-font-bold-weight'        => $this->font_data['main']['boldWeight'],
			'--anky-headings-font'                => "\"{$this->font_data['headings']['family']}\", {$this->font_data['headings']['category']}",
			'--anky-headings-font-regular-weight' => str_replace( 'regular', '400', $this->font_data['headings']['regularWeight'] ),
			'--anky-headings-font-italic-weight'  => empty( $this->font_data['headings']['italicWeight'] )
				? 'var(--anky-headings-font-regular-weight)'
				: filter_var( $this->font_data['main']['italicWeight'], FILTER_SANITIZE_NUMBER_INT ),
			'--anky-headings-font-bold-weight'    => $this->font_data['main']['boldWeight'],
		);
	}

	/**
	 * Add preconnect for Google Fonts.
	 *
	 * @param array  $urls          URLs to print for resource hints.
	 * @param string $relation_type The relation type the URLs are printed.
	 *
	 * @return array URLs to print for resource hints.
	 */
	public function preload_fonts( $urls, $relation_type ) {
		if ( 'preconnect' === $relation_type ) {
			$urls[] = array(
				'href' => 'https://fonts.gstatic.com',
				'crossorigin',
			);
		}

		return $urls;
	}

	/**
	 * Apply Font loading technique to theme fonts.
	 *
	 * @param string $tag    The link tag for the enqueued style.
	 * @param string $handle The style's registered handle.
	 * @param string $href   The stylesheet's source URL.
	 * @param string $media  The stylesheet's media attribute.
	 *
	 * @return string Filtered the HTML link tag of an enqueued style.
	 */
	public function fonts_loader_tag( $tag, $handle, $href, $media ) {
		// Bail early.
		if ( 'anky-theme-font' !== $handle ) {
			return $tag;
		}
		switch ( $this->options->get( 'globals-fonts-loading' ) ) {
			case 'standard':
				return $tag;
			case 'preload':
			default:
				$onload = 'onload="this.onload=null;this.rel=`stylesheet`"';
				$rel    = 'rel="preload" as="style"';
				break;
		}

		return preg_replace( "/rel='stylesheet' id='anky-theme-font-css'/", "$rel id='anky-theme-font-css' $onload ", $tag );
	}

}
