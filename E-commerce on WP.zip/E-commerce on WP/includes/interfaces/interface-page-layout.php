<?php
/**
 * Interface that is used by classes that needs to collect some data and render it.
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Interfaces;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

interface Interface_Page_Layout {

	/**
	 * Render Html with Related data.
	 */
	public function render();

	/**
	 * Prepare arguments or data for specific block.
	 */
	public function prepare_data();
}
