<?php
/**
 * Admin page interface.
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Interfaces;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

interface Interface_Admin {

	/**
	 * Add admin page
	 */
	public function add_page();

	/**
	 * Enqueue styles and scripts
	 */
	public function enqueue();

	/**
	 * Support page template.
	 */
	public function render();

}
