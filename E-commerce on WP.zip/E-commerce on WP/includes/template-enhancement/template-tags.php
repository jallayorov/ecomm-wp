<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package    Anky
 * @subpackage Markup
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prints HTML with meta information for the current author.
 */
if ( ! function_exists( 'anky_posted_by' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 *
	 * The author name is found by Full name, display name or login name if others are empty.
	 *
	 * @param bool $full_name Optional. Try to display full name instead of display name.
	 */
	function anky_posted_by( $full_name = false ) {
		$id = get_the_author_meta( 'ID' );
		echo '<div class="anky-entry-author">';
		echo get_avatar( $id, 48 );

		$display_name = $full_name ? get_the_author_meta( 'first_name' ) . ' ' . get_the_author_meta( 'last_name' ) : get_the_author_meta( 'display_name' );
		$display_name = empty( trim( $display_name ) ) ? get_the_author() : $display_name;

		printf(
			'<span class="anky-meta-title"><a href="%s">%s</a></span>',
			esc_url( get_author_posts_url( $id ) ),
			esc_html( $display_name )
		);

		echo '</div>';
	}
endif;

/**
 * Displays an optional post thumbnail.
 */
if ( ! function_exists( 'anky_post_thumbnail' ) ) :
	/**
	 * Displays an optional post thumbnail.
	 * Wraps the post thumbnail in an anchor element on index views, or a div
	 * element when on single views.
	 *
	 * @param string $size       Optional. Set image size. Default is set to medium.
	 * @param bool   $force_link Optional. Add link to image or not.
	 */
	function anky_post_thumbnail( $size = 'medium', $force_link = false ) {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() && ! $force_link ) :
			?>

			<div class="post-thumbnail">
				<?php
				the_post_thumbnail(
					$size,
					array(
						'alt'     => the_title_attribute(
							array(
								'echo' => false,
							)
						),
						'loading' => 'lazy',
					)
				);
				?>
			</div><!-- .post-thumbnail -->

		<?php else : ?>

			<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
				<?php
				the_post_thumbnail(
					'post-thumbnail',
					array(
						'alt'     => the_title_attribute( array( 'echo' => false ) ),
						'loading' => 'lazy',
					)
				);
				?>
			</a>
		<?php
		endif; // End is_singular().
	}
endif;

/**
 * Get the trimmed version of post excerpt.
 */
if ( ! function_exists( 'anky_the_excerpt' ) ) :
	/**
	 * Get the trimmed version of post excerpt.
	 *
	 * This is for modifying manually entered excerpts,
	 * NOT automatic ones WordPress will grab from the content.
	 *
	 * @param string $forced_style Optional. Excerpt style can be altered if required. Accept - custom_unlink or custom_link, otherwise default excerpt style is applied is applied.
	 */
	function anky_the_excerpt( $forced_style = '' ) {
		if ( $forced_style ) {
			$excerpt_style = $forced_style;
		} else {
			$excerpt_style = anky_get_option( 'blog-excerpt-style' );
		}

		switch ( $excerpt_style ) {
			case 'custom_unlink':
			case 'custom_link':
				$excerpt = wp_strip_all_tags( get_the_excerpt() );
				$excerpt = str_replace( array( ' [', '[', ']' ), '', $excerpt ); // Removing default excerpt brackets.
				$excerpt = "<p class=\"anky-custom-excerpt entry-excerpt\">$excerpt</p>";
				break;
			default:
				the_excerpt();

				return;
		}

		$link = '';
		if ( 'custom_link' === $excerpt_style ) {
			$link = sprintf(
				'<p class="link-more"><a href="%1$s" class="more-link">%2$s <span class="anky-icon-arrow-up-right" aria-hidden="true"></span></a></p>',
				esc_url( get_permalink( get_the_ID() ) ),
				sprintf(
				/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'anky' ),
					get_the_title( get_the_ID() )
				)
			);
		}

		echo wp_kses_post( $excerpt . $link );
	}
endif;

/**
 * Check if it is required to set masonry or not.
 */
if ( ! function_exists( 'anky_is_masonry_enabled' ) ) :
	/**
	 * Check if it is required to set masonry or not.
	 *
	 * Masonry should be enabled only if it is blog, archives or search page without sidebar.
	 *
	 * @return bool
	 */
	function anky_is_masonry_enabled() {
		return ( is_home() || is_search() || is_archive() ) && ! anky_get_option( 'main-blog-sidebar' );
	}
endif;

/**
 * Check if its required to set sidebar.
 */
if ( ! function_exists( 'anky_is_sidebar_enabled' ) ) :
	/**
	 * Check if its required to set sidebar.
	 *
	 * Sidebar if enabled in settings, should be on every page type excerpt for `Page`.
	 *
	 * @return bool
	 */
	function anky_is_sidebar_enabled() {
		return anky_get_option( 'main-blog-sidebar' ) && ! is_singular( 'page' );
	}
endif;
