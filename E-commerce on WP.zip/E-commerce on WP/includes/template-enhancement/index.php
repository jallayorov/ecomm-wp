<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Markup
 */

/* Silence is golden, and we agree. */
