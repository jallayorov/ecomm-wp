<?php
/**
 * Main theme class controller.
 * It is used to instantiate other and hold classes.
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes;

use Anky\Includes\Builder\Anky_Colors;
use Anky\Includes\Builder\Anky_Fonts;
use Anky\Includes\Builder\Anky_Head;
use Anky\Includes\Builder\Blog\Anky_Blog_Builder;
use Anky\Includes\Builder\Blog\Anky_Page_Header_Builder;
use Anky\Includes\Builder\Blog\Anky_Page_Sidebar_Builder;
use Anky\Includes\Builder\Blog\Anky_Related_Posts_Builder;
use Anky\Includes\Builder\Footer\Anky_Footer_Builder;
use Anky\Includes\Builder\Header\Anky_Header_Builder;
use Anky\Includes\Builder\Widgets\Anky_Widgets_Builder;
use Anky\Includes\Core\Anky_Assistent;
use Anky\Includes\Core\Anky_Options;
use Anky\Includes\Core\Anky_Setup;
use Anky\Includes\Traits\Trait_Singleton as Singleton;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Main theme class controller.
 */
class Anky extends Anky_Assistent {
	use Singleton;

	/**
	 * Settings instance.
	 *
	 * @var Anky_Options
	 * @access public
	 */
	public $options;

	/**
	 * Settings instance.
	 *
	 * @var Anky_Head
	 * @access public
	 */
	public $head;

	/**
	 * Theme Fonts instance.
	 *
	 * @var Anky_Fonts
	 * @access public
	 */
	public $fonts;

	/**
	 * Theme Colors instance.
	 *
	 * @var Anky_Colors
	 * @access public
	 */
	public $color_scheme;

	/**
	 * Theme Setup instance.
	 *
	 * @var Anky_Setup
	 */
	public $setup;

	/**
	 * Theme Plugins instance.
	 *
	 * @var Anky_Widgets_Builder
	 */
	public $widgets;

	/**
	 * Header builder instance.
	 *
	 * @var Anky_Header_Builder
	 */
	public $header;

	/**
	 * Blog builder instance.
	 *
	 * @var Anky_Blog_Builder
	 */
	public $blog;

	/**
	 * Site footer builder instance.
	 *
	 * @var Anky_Footer_Builder
	 */
	public $footer;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->setup_theme_hooks();
	}

	/**
	 * Setup the main theme hooks.
	 */
	public function setup_theme_hooks() {
		// Refresh options after customizer save.
		$this->add_action( 'after_setup_theme', $this->options, 'update' );

		$this->add_filter( 'wp_resource_hints', $this->fonts, 'preload_fonts', 10, 2 );
		$this->add_filter( 'wp_resource_hints', $this->head, 'preload_map', 10, 2 );
		$this->add_filter( 'style_loader_tag', $this->fonts, 'fonts_loader_tag', 10, 4 );

		$this->add_filter( 'document_title_separator', $this->head, 'document_title_separator' );
		$this->add_action( 'wp_head', $this->head, 'set_user_agent', 1000 );
		$this->add_action( 'wp_head', $this->head, 'head_pingback' );

		// Theme setup.
		$this->add_action( 'after_setup_theme', $this->setup, 'set_text_domain' );
		$this->add_action( 'after_setup_theme', $this->setup, 'setup_theme_support' );
		$this->add_action( 'wp_enqueue_scripts', $this->setup, 'setup_css', 4 );
		$this->add_action( 'wp_enqueue_scripts', $this->setup, 'setup_js' );
		$this->add_action( 'after_setup_theme', $this->setup, 'setup_navigation' );

		$this->add_action( 'widgets_init', $this->setup, 'setup_widgets' );
		$this->add_action( 'wp_head', $this->setup, 'set_inline_style' );
		$this->add_action( 'after_setup_theme', $this->setup, 'setup_content_width', 0 );
		$this->add_filter( 'comment_form_fields', $this->setup, 'move_comment_field_to_bottom' );
		$this->add_filter( 'frontpage_template', $this->setup, 'front_page_template' );
		$this->add_filter( 'body_class', $this->setup, 'set_body_classes' );

		// Site header.
		$this->add_action( 'anky_header_before', $this->header, 'build_upper_header' );
		$this->add_action( 'anky_header', $this->header, 'build' );
		$this->add_action( 'anky_language_section', $this->header, 'build_custom_language_switcher' );

		// Modal header.
		$this->add_action( 'anky_search_header_top', 'Anky\Includes\Builder\Anky_UI_Controller', 'render_site_identity' );
		$this->add_action( 'anky_search_header_bottom', 'Anky\Includes\Builder\Anky_UI_Controller', 'render_search_modal_close_btn' );

		// Sidebar.
		if ( 'right' === $this->options->get( 'main-blog-sidebar-position' ) ) {
			$this->add_action( 'anky_after_loop', Anky_Page_Sidebar_Builder::get_instance(), 'render' );
		} else {
			$this->add_action( 'anky_before_loop', Anky_Page_Sidebar_Builder::get_instance(), 'render' );
		}

		// Blog.
		$this->add_action( 'anky_page_header', Anky_Page_Header_Builder::get_instance(), 'render' );
		$this->add_action( 'anky_entry_header', $this->blog, 'entry_meta_template' );
		$this->add_action( 'anky_entry_header', $this->blog, 'entry_title' );
		$this->add_action( 'anky_entry_header', $this->blog, 'single_post_meta' );
		$this->add_action( 'anky_pagination', $this->blog, 'posts_pagination' );
		$this->add_action( 'anky_related_posts_entry_header', $this->blog, 'related_posts_header' );
		$this->add_action( 'anky_blog_related_post_meta', $this->blog, 'entry_meta' );
		$this->add_action( 'anky_blog_meta', $this->blog, 'entry_meta' );
		$this->add_action( 'anky_blog_post_meta', $this->blog, 'post_meta' );
		$this->add_filter( 'comment_reply_link_args', $this->blog, 'comments_reply_text', 10, 3 );
		$this->add_filter( 'the_password_form', $this->blog, 'alter_password_form' );

		// Blog Footer.
		$this->add_action( 'anky_blog_entry_footer', $this->blog, 'edit_link' );
		$this->add_action( 'anky_blog_entry_footer', $this->blog, 'footer_blog_entry_meta', 11 );

		// Singular.
		$this->add_action( 'anky_single_entry_footer', $this->blog, 'post_author' );
		$this->add_action( 'anky_single_entry_footer', $this->blog, 'post_tags', 11 );
		$this->add_action( 'anky_single_entry_footer', $this->blog, 'the_delimiter', 12 );
		$this->add_action( 'anky_single_entry_footer', $this->blog, 'posts_navigation', 13 );
		$this->add_action( 'anky_single_entry_footer', $this->blog, 'render_comments', 14 );
		$this->add_action( 'anky_single_entry_footer', Anky_Related_Posts_Builder::get_instance(), 'render', 14 );

		// Site footer.
		$this->add_action( 'anky_footer_inner_before', $this->footer, 'build_footer_widgets' );
		$this->add_action( 'anky_footer_inner', $this->footer, 'build' );
		$this->add_action( 'wp_footer', $this->footer, 'render_search_modal' );
	}

	/**
	 * Load the required dependencies for the theme.
	 */
	private function load_dependencies() {
		$this->options      = new Anky_Options();
		$this->fonts        = new Anky_Fonts( $this->options );
		$this->color_scheme = new Anky_Colors( $this->options );
		$this->widgets      = new Anky_Widgets_Builder( $this->options );
		$this->head         = new Anky_Head( $this->options );
		$this->setup        = new Anky_Setup( $this );
		$this->header       = new Anky_Header_Builder( $this->options, $this->widgets );
		$this->blog         = Anky_Blog_Builder::get_instance();
		$this->footer       = new Anky_Footer_Builder( $this->options );
	}
}
