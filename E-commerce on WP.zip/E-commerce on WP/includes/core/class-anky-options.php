<?php
/**
 * Class responsible for theme configuration and storing settings.
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Core;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Class responsible for theme configuration and storing settings.
 */
class Anky_Options {

	/**
	 * The name of database option prefix for option.
	 *
	 * @access private
	 * @var string $option_prefix
	 */
	private $option_prefix = 'anky-options';

	/**
	 * Options with no default options obtained from database.
	 *
	 * @access private
	 * @var mixed $options_no_defaults
	 */
	private $db_options;

	/**
	 * Settings data.
	 *
	 * @access private
	 * @var array
	 */
	private $options;

	/**
	 * Constructor. Setup options in the instance.
	 */
	public function __construct() {
		$this->update();
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Update theme option array.
	 */
	public function update() {
		$this->options = wp_parse_args(
			$this->get_db_options(),
			$this->set_defaults()
		);
	}

	/**
	 * Get basic theme options from database.
	 *
	 * @return array    Return array of theme options from database.
	 */
	public function get_db_options() {
		$this->db_options = get_option( $this->option_prefix );

		return $this->db_options;
	}

	/**
	 * Get all available theme options.
	 *
	 * @return array    Return array of available theme options.
	 */
	public function get_all_options() {
		return $this->options;
	}

	/**
	 * Gets the option for the given name. Returns the default value if the
	 * value does not exist.
	 *
	 * @param string $name    Option name.
	 * @param mixed  $default Option default value.
	 *
	 * @return mixed
	 */
	public function get( $name, $default = null ) {
		if ( ! $this->has( $name ) ) {
			return $default;
		}

		return $this->options[ $name ];
	}

	/**
	 * Checks if the option exists or not.
	 *
	 * @param string $name Option name.
	 *
	 * @return Boolean
	 */
	public function has( $name ) {
		return isset( $this->options[ $name ] );
	}

	/**
	 * Sets an option. Overwrites the existing option if the name is already in use.
	 * Due to chaining return, multiple Set methods allowed;
	 *
	 * @param string $name  Option name.
	 * @param mixed  $value Option value.
	 */
	public function set( $name, $value ) {
		$this->options[ $name ] = $value;

		update_option( $this->option_prefix, $this->options );
	}

	/**
	 * Retrieve the theme option prefix.
	 *
	 * @return string
	 */
	public function get_prefix() {
		return $this->option_prefix;
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Set default theme option values.
	 *
	 * @return array default values of the theme.
	 */
	private function set_defaults() {
		// Defaults list of options.
		return apply_filters(
			'anky_theme_options_defaults',
			array(
				// head.
				'document-title-separator'          => ' | ',

				// Globals->Typography.
				'globals-fonts-loading'             => 'preload',
				'globals-body-font-family'          => '{"family":"Inter","regularWeight":"regular","italicWeight":"","boldWeight":"700","category":"sans-serif"}',
				'globals-headings-font-family'      => '{"family":"Space Grotesk","regularWeight":"regular","italicWeight":"","boldWeight":"700","category":"sans-serif"}',

				// Globals->Contacts.
				'globals-contact-tel-number'        => '+1 234 567-8901',
				'globals-contact-email'             => 'info@example.com',
				'globals-contact-address'           => '2823 Church Road, VA',
				'globals-contact-address-map-embed' => '//www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d41231.94633128963!2d-122.442852349698!3d37.75764367476565!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80859a6d00690021%3A0x4a501367f076adff!2z0KHQsNC9LdCk0YDQsNC90YbQuNGB0LrQviwg0JrQsNC70LjRhNC-0YDQvdC40Y8sINCh0KjQkA!5e0!3m2!1sru!2s!4v1626947737822!5m2!1sru!2s',
				'globals-contact-social-networks'   => '//www.facebook.com,https://www.twitter.com,https://www.linkedin.com',

				// Globals->Colors.
				'globals-color-scheme'         => 'light',

				// Globals->Optimization.
				'globals-assets-loading-mode'  => 'cdn',

				// Header.
				'header-layout-type'           => 'header-layout-1',
				'header-widget-search'         => true,
				'header-widget-tel'            => true,

				// Header Upper Bar.
				'header-upper-bar-layout-type' => 'disabled',

				// Site blog.
				'main-blog-sidebar'            => false,
				'main-blog-sidebar-position'   => 'left',
				'blog-excerpt-style'           => 'custom_link',
				'blog-excerpt-length'          => 2,
				'blog-related-posts'           => true,

				// Footer.
				'footer-widgets-layout-type'   => 'disabled',
				'footer-copyright-text'        => '[copyright] [current_year] [site_title]',
				'footer-right-block-content'   => '[theme_name] theme is made with ❤️ by [theme_author]',

				// Menu.
				'custom-switcher'              => false,

				// Admin.
				'first-time-install'           => true,
			)
		);
	}

}
