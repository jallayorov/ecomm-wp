<?php
/**
 * Anky Setup Controller.
 *
 * Instance is responsible for managing theme assets widgets and supports.
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Core;

use Anky\Includes\Anky;
use Anky\Includes\Builder\Navigation\Anky_Menu_Navigation_Builder;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Setup Controller.
 */
class Anky_Setup {

	/**
	 * Theme controller Instance.
	 *
	 * @var Anky $theme
	 * @access private
	 */
	private $theme;


	/**
	 * Constructor.
	 *
	 * @param Anky $theme Theme controller Instance.
	 */
	public function __construct( Anky $theme ) {
		$this->theme = $theme;
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Setup navigation menus.
	 */
	public function setup_navigation() {
		$menus = array(
			Anky_Menu_Navigation_Builder::$primary_menu_id => esc_html__( 'Primary menu', 'anky' ),
		);

		if ( 'layout-4' === $this->theme->options->get( 'header-upper-bar-layout-type' ) || is_customize_preview() ) {
			$menus[ Anky_Menu_Navigation_Builder::$header_bar_id ] = esc_html__( 'Upper Header Menu', 'anky' );
		}

		register_nav_menus( $menus );
	}

	/**
	 * Setup Setup theme scripts.
	 */
	public function setup_js() {
		$loading_method = $this->theme->options->get( 'globals-assets-loading-mode', 'cdn' );
		$assets         = array(
			'local' => array(
				'lightgallery' => anky_get_asset( 'js/lightgallery.min.js' ),
				'select2'      => anky_get_asset( 'js/select2.min.js' ),
				'swiper'       => anky_get_asset( 'js/swiper-bundle.min.js' ),
			),
			'cdn'   => array(
				'lightgallery' => '//cdnjs.cloudflare.com/ajax/libs/lightgallery/1.10.0/js/lightgallery.min.js',
				'select2'      => '//cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js',
				'swiper'       => '//cdnjs.cloudflare.com/ajax/libs/Swiper/6.6.2/swiper-bundle.min.js',
			),
		);

		/**
		 * Registering.
		 */
		wp_register_script( 'lightgallery', $assets[ $loading_method ]['lightgallery'], array( 'jquery' ), '1.10.0', true );
		wp_register_script( 'select2', $assets[ $loading_method ]['select2'], array( 'jquery' ), '4.1.0-rc.0', true );
		wp_register_script( 'swiper', $assets[ $loading_method ]['swiper'], array( 'jquery' ), '6.6.2', true );
		wp_register_script(
			'anky-main',
			ANKY_THEME_URI . 'assets/js/main' . ( ANKY_DEV_MODE ? '.js' : '.min.js' ),
			array( 'jquery', 'lightgallery', 'select2', 'swiper' ),
			ANKY_THEME_VERSION,
			true
		);

		/**
		 * Enqueueing.
		 */
		$this->add_comment_script();
		wp_enqueue_script( 'anky-main' );

		return $this;
	}

	/**
	 * Setup theme styles.
	 */
	public function setup_css() {
		$loading_method = $this->theme->options->get( 'globals-assets-loading-mode', 'cdn' );
		$suffix         = ANKY_DEV_MODE ? '.css' : '.min.css';
		$assets         = array(
			'local' => array(
				'lightgallery' => ANKY_THEME_URI . 'assets/css/vendors/lightgallery.min.css',
				'swiper'       => ANKY_THEME_URI . 'assets/css/vendors/swiper-bundle.min.css',
			),
			'cdn'   => array(
				'lightgallery' => '//cdnjs.cloudflare.com/ajax/libs/lightgallery/1.10.0/css/lightgallery.min.css',
				'swiper'       => '//cdnjs.cloudflare.com/ajax/libs/Swiper/6.6.2/swiper-bundle.min.css',
			),
		);

		/**
		 * Registering.
		 */
		wp_register_style( 'anky-theme-font', $this->theme->fonts->prepare_fonts_url(), array(), ANKY_THEME_VERSION, 'all' );
		wp_register_style( 'anky-theme-icons', ANKY_THEME_URI . 'assets/css/icons' . $suffix, array(), ANKY_THEME_VERSION, 'all' );
		wp_register_style( 'lightgallery', $assets[ $loading_method ]['lightgallery'], array(), '1.10.0', 'all' );
		wp_register_style( 'swiper', $assets[ $loading_method ]['swiper'], array(), '6.6.2', 'all' );
		wp_register_style( 'anky-theme-styles', get_stylesheet_uri(), array(), ANKY_THEME_VERSION, 'all' );
		wp_register_style(
			'anky-theme-main-styles',
			ANKY_THEME_URI . 'assets/css/main' . $suffix,
			array( 'anky-theme-font', 'anky-theme-icons', 'lightgallery', 'swiper', 'anky-theme-styles' ),
			ANKY_THEME_VERSION,
			'all'
		);
		// Some admin preview styles.
		wp_register_style( 'anky-theme-admin-preview', ANKY_THEME_URI . 'assets/css/admin' . $suffix, array(), ANKY_THEME_VERSION );

		/**
		 * Enqueueing.
		 */
		wp_enqueue_style( 'anky-theme-main-styles' );

		if ( current_user_can( 'edit_theme_options' ) ) {
			wp_enqueue_style( 'anky-theme-admin-preview' );
		}
	}

	/**
	 * Setup theme support features.
	 */
	public function setup_theme_support() {
		add_theme_support( 'title-tag' );
		add_theme_support(
			'custom-logo',
			array(
				'width'       => null,
				'height'      => 56,
				'flex-width'  => true,
				'flex-height' => false,
			)
		);
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support(
			'custom-header',
			array(
				'default-image'         => '',
				'random-default'        => false,
				'width'                 => 0,
				'height'                => 0,
				'flex-height'           => false,
				'flex-width'            => false,
				'header-text'           => true,
				'uploads'               => true,
				'video'                 => false,
				'video-active-callback' => 'is_front_page',
			)
		);
		add_theme_support( 'custom-background' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'navigation-widgets',
				'style',
				'script',
			)
		);
		add_theme_support( 'align-wide' );
		add_image_size( 'anky-team', 99999, 350 ); // Need only height crop.
	}

	/**
	 * Add inline style with global css settings.
	 */
	public function set_inline_style() {
		$arr                                   = array_merge( $this->theme->fonts->get_global_font_data(), $this->theme->color_scheme->apply_scheme() );
		$arr['--anky-blog-excerpt-length'] = (int) $this->theme->options->get( 'blog-excerpt-length' );
		?>
		<!--Globals CSS-->
		<style id="anky-globals-setup">
			:root {
			<?php
			foreach ( $arr as $selector => $value ) {
				printf( '%1$s: %2$s;', $selector, $value ); //phpcs:ignore WordPress.Security.EscapeOutput
			}
			?>
			}
		</style>
		<!--/Globals CSS-->
		<?php
	}

	/**
	 * Setup theme widget areas.
	 */
	public function setup_widgets() {
		if ( ! empty( $this->theme->widgets->sidebars ) ) {
			foreach ( $this->theme->widgets->sidebars as $sidebar ) {
				register_sidebar( $sidebar );
			}
		}
	}

	/**
	 * Moves the comment textarea field to the bottom part of comment s form.
	 *
	 * @param array $fields The comment fields.
	 *
	 * @return array
	 * @see comment_form() `comment_form_fields` filter
	 */
	public function move_comment_field_to_bottom( $fields ) {
		$comment_field = $fields['comment'];
		unset( $fields['comment'] );

		$fields['comment'] = $comment_field;

		return $fields;
	}

	/**
	 * Set the content width in pixels, based on the theme's design and stylesheet.
	 *
	 * Priority 0 to make it available to lower priority callbacks.
	 *
	 * @return void
	 * @global int $content_width Content width.
	 */
	public function setup_content_width() {
		// This variable is intended to be overruled from themes.
		$GLOBALS['content_width'] = apply_filters( 'anky_content_width', 736 ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound.
	}

	/**
	 * Use front-page.php when Front page displays is set to a static page.
	 *
	 * @param string $template front-page.php.
	 *
	 * @return string The template to be used: blank if is_home() is true (defaults to index.php),
	 *                otherwise $template.
	 * @since Twenty Seventeen 1.0
	 */
	public function front_page_template( $template ) {
		return is_home() ? '' : $template;
	}

	/**
	 * Adds custom classes to the array of body classes.
	 *
	 * @param array $classes Classes for the body element.
	 *
	 * @return array
	 */
	public function set_body_classes( $classes ) {
		// Add class if we're viewing the Customizer for easier styling of theme options.
		if ( is_customize_preview() ) {
			$classes[] = 'anky-customizer';
		}

		// Add class on front page.
		if ( is_front_page() && 'posts' !== get_option( 'show_on_front' ) ) {
			$classes[] = 'anky-front-page';
		}

		// Add class if sidebar is used.
		if ( anky_is_sidebar_enabled() ) {
			$classes[] = 'anky-has-sidebar';
			$classes[] = 'anky-sidebar-' . $this->theme->options->get( 'main-blog-sidebar-position' );
		}

		// Add class when masonry grid is enabled.
		if ( anky_is_masonry_enabled() ) {
			$classes[] = 'anky-masonry-enabled';
		}

		// Color scheme.
		$classes[] = 'anky-' . $this->theme->color_scheme->get_active_scheme_name() . '-color-scheme';

		return $classes;
	}

	/**
	 * Set theme localization textdomain and make theme available for translation.
	 */
	public function set_text_domain() {
		load_theme_textdomain( 'anky', ANKY_THEME_DIR . '/languages' );
	}

	/**
	 * Add comments scripts for special pages.
	 */
	public function add_comment_script() {
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
			wp_add_inline_script(
				'comment-reply',
				"var commentForm = document.getElementById( 'commentform' );if ( commentForm ) {commentForm.removeAttribute( 'novalidate' );}var emailInp = document.getElementById( 'email' );if ( emailInp ) {emailInp.type = 'email';}"
			);
		}
	}

}
