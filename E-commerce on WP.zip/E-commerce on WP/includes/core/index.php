<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Core
 */

/* Silence is golden, and we agree. */
