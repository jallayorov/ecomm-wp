<?php
/**
 * Autoload Theme classes using WordPress convention.
 *
 * Namespaces must be used.
 * Core namespace level must start from theme name. Then according to directories.
 * Filename conventions must be like:
 * Namespaces:
 * Anky\includes\core\Some_Feature
 * Anky\includes\admin\Interface_Some_Feature
 * Anky\includes\front\Trait_Some_Feature
 *
 * Paths:
 * .../wp-content/themes/anky/includes/core/class-some-feature.php
 * .../wp-content/themes/anky/includes/admin/interface-some-feature.php
 * .../wp-content/themes/anky/includes/front/trait-some-feature.php
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Core;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Theme Autoloader.
 */
final class Anky_Autoloader {

	/**
	 * Path to classmap.
	 *
	 * @var string $map_file
	 * @visibility private
	 */
	private $map_file;

	/**
	 * Array map of classes with paths.
	 *
	 * @var array $map
	 * @visibility private
	 */
	private $map;

	/**
	 * Class prefix.
	 *
	 * @var string $prefix
	 * @visibility private
	 */
	private $prefix = 'Anky';

	/**
	 * Class prefix.
	 *
	 * @var string $prefix
	 * @visibility private
	 */
	private $plugin_prefix = 'Anky_Extensions';

	/**
	 * Flag for checking status classmap availability.
	 *
	 * @var bool $is_updated
	 * @visibility private
	 */
	private $is_updated = false;

	/**
	 * Theme constructor.
	 */
	public function __construct() {
		$this->map_file = trailingslashit( __DIR__ ) . 'classmap.php';
		$this->map      = file_exists( $this->map_file ) ? ( include $this->map_file ) : '';
		$this->map      = is_array( $this->map ) ? $this->map : array();

		spl_autoload_register( array( $this, 'autoload' ) );
		add_action( 'shutdown', array( $this, 'update_cache' ) );
	}

	/**
	 * Update class map caching.
	 */
	public function update_cache() {
		if ( ! $this->is_updated ) {
			return;
		}
		$map = implode(
			"\n",
			array_map(
				function ( $k, $v ) {
					return "'$k' => '$v',";
				},
				array_keys( $this->map ),
				array_values( $this->map )
			)
		);

		$filesystem = anky_filesystem();
		$filesystem->put_contents( $this->map_file, "<?php return [{$map}];\n" );
	}

	/**
	 * Autoload theme classes.
	 *
	 * @param string $class Class name.
	 */
	private function autoload( $class ) {
		// Bail early.
		if ( 0 === strpos( $class, $this->plugin_prefix ) || 0 !== strpos( $class, $this->prefix ) ) {
			return;
		}

		if ( isset( $this->map[ $class ] ) && file_exists( $this->map[ $class ] ) ) {
			require_once $this->map[ $class ]; // If is cached get form the map.
		} else {
			$this->is_updated    = true;
			$parts               = explode( '\\', $class );
			$name                = array_pop( $parts );
			$name                = preg_match( '/^(Interface|Trait)/', $name )
				? $name . '.php'
				: 'class-' . $name . '.php';
			$path                = implode( '/', $parts ) . '/' . $name;
			$path                = strtolower( str_replace( array( '\\', '_' ), array( '/', '-' ), $path ) );
			$path                = trailingslashit( get_theme_root() ) . $path;
			$this->map[ $class ] = $path;

			require_once $path;
		}
	}

}
