<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Helpers
 */

/* Silence is golden, and we agree. */
