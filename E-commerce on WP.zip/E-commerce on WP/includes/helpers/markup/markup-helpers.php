<?php
/**
 * Custom assistive functions that act independently of the theme templates.
 * Functions below are used to generate some kind of Markup for the frontend.
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package    Anky
 * @subpackage Markup
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Build list of attributes into a string.
 */
if ( ! function_exists( 'anky_build_atts' ) ) {
	/**
	 * Build list of attributes into a string.
	 *
	 * @param array $attributes Attributes list.
	 *
	 * @return string String of HTML attributes and values.
	 */
	function anky_build_atts( $attributes = array() ) {
		$atts = '';
		// Bail early.
		if ( empty( $attributes ) ) {
			return $atts;
		}

		// Attributes allowed to be empty.
		static $white_list;
		if ( ! isset( $white_list ) ) {
			$white_list = array(
				'allowfullscreen',
				'async',
				'autofocus',
				'checked',
				'compact',
				'declare',
				'default',
				'defer',
				'disabled',
				'formnovalidate',
				'hidden',
				'inert',
				'ismap',
				'itemscope',
				'multiple',
				'multiple',
				'muted',
				'nohref',
				'noresize',
				'noshade',
				'novalidate',
				'nowrap',
				'open',
				'readonly',
				'required',
				'reversed',
				'seamless',
				'selected',
				'sortable',
				'truespeed',
				'typemustmatch',
			);
		}

		// Cycle through attributes, build tag attribute string.
		foreach ( $attributes as $key => $value ) {
			if ( '' === $value && ! in_array( $value, $white_list, true ) ) {
				continue; // Avoid attributes with empty values.
			} elseif ( true === $value ) {
				$atts .= esc_html( $key ) . ' ';
			} else {
				$val = is_array( $value ) ? implode( ' ', $value ) : $value;

				$atts .= sprintf( '%1$s="%2$s" ', esc_html( $key ), ( 'href' === $key ) ? esc_url( $val ) : esc_attr( $val ) );
			}
		}

		return trim( $atts );
	}
}

/**
 * Display list of attributes.
 */
if ( ! function_exists( 'anky_the_atts' ) ) {
	/**
	 * Display attributes from array.
	 *
	 * @param array $attributes Attributes list.
	 */
	function anky_the_atts( $attributes = array() ) {
		echo anky_build_atts( $attributes ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

/**
 * Retrieve a widget are by its sidebar ID.
 */
if ( ! function_exists( 'anky_get_widget' ) ) {
	/**
	 * Retrieve a widget are by its sidebar ID.
	 *
	 * @param string $sidebar_id Sidebar Id.
	 */
	function anky_get_widget( $sidebar_id ) {
		if ( is_active_sidebar( $sidebar_id ) ) {
			dynamic_sidebar( $sidebar_id );
		} elseif ( current_user_can( 'edit_theme_options' ) ) {
			anky_get_empty_widget_templates( $sidebar_id );
		}
	}
}

/**
 * Retrieve a widget template block by provided sidebar ID.
 */
if ( ! function_exists( 'anky_get_empty_widget_templates' ) ) {
	/**
	 * Retrieve a widget template block by provided sidebar ID.
	 *
	 * @param string $sidebar_id Sidebar Id.
	 */
	function anky_get_empty_widget_templates( $sidebar_id ) {
		global $wp_registered_sidebars;
		$sidebar_name = '';

		if ( isset( $wp_registered_sidebars[ $sidebar_id ] ) ) {
			$sidebar_name = $wp_registered_sidebars[ $sidebar_id ]['name'];
		}

		// Atts for control focus trigger.
		if ( is_customize_preview() ) {
			$tag  = 'button';
			$atts = array(
				'type'                 => 'button',
				'class'                => array( 'anky-widget-handler', 'anky-js-widget-focus', 'anky-widget-handler-btn' ),
				'data-customizer-link' => "sidebar-widgets-{$wp_registered_sidebars[ $sidebar_id ]['id']}",
				'onclick'              => 'ankyCustomizeLink(this)', // Required to trigger focus after partial is re-rendered.
			);
		} else {
			$tag                         = 'a';
			$query['autofocus[section]'] = "sidebar-widgets-{$wp_registered_sidebars[ $sidebar_id ]['id']}";
			$atts                        = array(
				'href'  => add_query_arg( $query, admin_url( 'customize.php' ) ),
				'class' => array( 'anky-widget-handler', 'anky-js-widget-focus', 'anky-widget-handler-link' ),
			);
		}
		?>
		<div class="widget anky-no-widget">
			<h2 class='widget-title'><?php echo esc_html( $sidebar_name ); ?></h2>

			<p class='anky-no-widget-text'>
				<?php
				printf(
					'<%1$s %2$s>%3$s</%1$s>',
					tag_escape( $tag ),
					anky_build_atts( $atts ), // phpcs:ignore WordPress.Security.EscapeOutput
					esc_html__( 'Click here to assign Widgets for this area.', 'anky' )
				);
				?>
			</p>
		</div>
		<?php
	}
}

/**
 * Retrieve arguments for comment_form().
 * Function allows to override some default arguments.
 *
 * @return array of arguments
 * @see comment_form() for more details.
 */
if ( ! function_exists( 'anky_get_comments_form_args' ) ) :
	/**
	 * Retrieve arguments for comment_form().
	 * Function allows to override some default arguments.
	 *
	 * @return array of arguments
	 * @see comment_form() for more details.
	 */
	function anky_get_comments_form_args() {
		$input_template = '<div  class="anky-input-group"><label for="%1$s" class="field-label">%2$s</label><input id="%1$s" name="%1$s" type="text" %3$s/></div>';
		$commenter      = wp_get_current_commenter();
		$is_required    = get_option( 'require_name_email' );
		$required_mark  = ( $is_required ? '<sup class="anky-required-mark">*</sup>' : '' );
		$input_attrs    = array(
			'author'   => array(
				'class'       => 'anky-input',
				'placeholder' => esc_html__( 'Your name', 'anky' ),
				'value'       => esc_attr( $commenter['comment_author'] ),
				'required'    => 'required',
			),
			'email'    => array(
				'class'       => 'anky-input',
				'placeholder' => esc_html__( 'Your email', 'anky' ),
				'value'       => esc_attr( $commenter['comment_author_email'] ),
				'required'    => 'required',
				'type'        => 'email',
			),
			'website'  => array(
				'class'       => 'anky-input',
				'placeholder' => esc_html__( 'Your website', 'anky' ),
				'value'       => esc_attr( $commenter['comment_author_url'] ),
			),
			'comments' => array(
				'id'            => 'comment',
				'class'         => array( 'anky_comments-textarea', 'anky-input' ),
				'placeholder'   => esc_html__( 'Your comment', 'anky' ),
				'name'          => 'comment',
				'cols'          => '40',
				'rows'          => '8',
				'aria-required' => 'true',
			),
		);

		// Add aria-required attributes.
		if ( $is_required ) {
			$input_attrs['author']['aria-required'] = 'true';
			$input_attrs['email']['aria-required']  = 'true';
		}

		return array(
			'title_reply_before' => '<h2 id="reply-title" class="comment-reply-title">',
			'title_reply_after'  => '</h2>',
			'title_reply'        => wp_kses_post(
				sprintf(
				/* translators: %s: post title. Only visible to screen readers*/
					__( 'Post a comment <span class="screen-reader-text">for %s</span>', 'anky' ),
					get_the_title()
				)
			),
			/* translators: %s: Author of the comment being replied to. */
			'title_reply_to'     => esc_html__( 'Post a Reply to "%s"', 'anky' ),
			'cancel_reply_link'  => esc_html__( 'Click here to cancel reply', 'anky' ),
			'label_submit'       => esc_html_x( 'Post', 'comment', 'anky' ),
			'fields'             => array(
				'author' => '<div class="anky-input-block"><div class="input-wrap">' .
							sprintf(
								$input_template,
								'author',
								esc_html__( 'Name', 'anky' ) . $required_mark,
								anky_build_atts( $input_attrs['author'] )
							),
				'email'  => sprintf(
					$input_template,
					'email',
					esc_html__( 'Email', 'anky' ) . $required_mark,
					anky_build_atts( $input_attrs['email'] )
				),
				'url'    => sprintf(
								$input_template,
								'url',
								esc_html__( 'Website', 'anky' ),
								anky_build_atts( $input_attrs['website'] )
							)
							. '</div><!--.input-wrap--></div><!--.anky-input-block-->',
			),
			'comment_field'      => '<label for="' . $input_attrs['comments']['id'] . '" class="field-label"><textarea ' . anky_build_atts( $input_attrs['comments'] ) . '></textarea></label>',
			'submit_button'      => '<button name="%1$s" type="submit" id="%2$s" class="AnkySM-button submit-comment %3$s" value="%4$s">%4$s</button>',
		);
	}
endif;
