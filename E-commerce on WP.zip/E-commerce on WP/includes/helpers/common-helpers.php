<?php
/**
 * Theme functions that assists in various occasions.
 *
 * @package    Anky
 * @subpackage Helpers
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Get a specific property of an array without needing to check if that property exists.
 */
if ( ! function_exists( 'anky_get_prop' ) ) :
	/**
	 * Get a specific property of an array without needing to check if that property exists.
	 *
	 * Provide a default value if you want to return a specific value if the property is not set.
	 *
	 * @param array  $array   Array from which the property's value should be retrieved.
	 * @param string $prop    Name of the property to be retrieved.
	 * @param string $default Optional. Value that should be returned if the property is not set or empty. Defaults to null.
	 *
	 * @return null|string|mixed The value
	 * @author Gravity Forms - Easiest Tool to Create Advanced Forms for Your WordPress-Powered Website.
	 * @link   https://www.gravityforms.com/
	 *
	 * @since  1.0.0
	 * @access public
	 */
	function anky_get_prop( $array, $prop, $default = null ) {
		if ( ! is_array( $array ) && ! ( is_object( $array ) && $array instanceof ArrayAccess ) ) {
			return $default;
		}

		if ( isset( $array[ $prop ] ) ) {
			$value = $array[ $prop ];
		} else {
			$value = '';
		}

		return empty( $value ) && null !== $default ? $default : $value;
	}
endif;

/**
 * Load template part with fallback support.
 */
if ( ! function_exists( 'anky_load_template' ) ) :
	/**
	 * Loads a template part into a template.
	 *
	 * @param string $slug The slug name for the generic template.
	 * @param string $name The name of the specialised template.
	 * @param array  $args Optional. Additional arguments passed to the template.
	 *                     Default empty array.
	 *
	 * @return void|false Void on success, false if the template does not exist.
	 * @see get_template_part
	 */
	function anky_load_template( $slug, $name = null, $args = array() ) {
		global $wp_version;
		if ( (float) $wp_version < 5.5 ) {
			set_query_var( 'anky_template_args', $args );
			get_template_part( $slug, $name );
		} else {
			get_template_part( $slug, $name, $args );
		}
	}
endif;

/**
 * Only allow values between a certain minimum & maximum range
 *
 * @param number $input Input to be evaluated.
 * @param number $min   Min value expected.
 * @param number $max   Max value expected.
 *
 * @return number    Sanitized input
 */
if ( ! function_exists( 'anky_in_range' ) ) :
	function anky_in_range( $input, $min, $max ) {
		if ( $input < $min ) {
			$input = $min;
		}
		if ( $input > $max ) {
			$input = $max;
		}

		return $input;
	}
endif;

/**
 * Retrieve filepath or file url to stated asset.
 *
 * @param string $path Path to file in asset directory.
 * @param string $type Decide to retrieve filepath or url. Default is `path`.
 * @param string $echo Display the path. Default is `false`.
 *
 * @return string Escaped file path or url.
 */
if ( ! function_exists( 'anky_asset_dir' ) ) :
	/**
	 * Retrieve filepath or file url to stated asset.
	 *
	 * @param string $path Path to file in asset directory.
	 * @param string $type Decide to retrieve filepath or url. Default is `url`.
	 *
	 * @return string Escaped file path or url.
	 */
	function anky_get_asset( $path = '', $type = 'url' ) {
		$return = '';
		if ( 'path' === $type ) {
			$return = wp_normalize_path( ANKY_THEME_DIR . 'assets/' . $path );
		} elseif ( 'url' === $type ) {
			$return = esc_url( ANKY_THEME_URI . 'assets/' . $path );
		}

		return $return;
	}
endif;

/**
 * Gets unique ID.
 */
if ( ! function_exists( 'anky_unique_id' ) ) :
	/**
	 * Gets unique ID.
	 *
	 * This is a PHP implementation of Underscore's uniqueId method. A static variable
	 * contains an integer that is incremented with each call. This number is returned
	 * with the optional prefix. As such the returned value is not universally unique,
	 * but it is unique across the life of the PHP process.
	 *
	 * @param string $prefix Prefix for the returned ID.
	 *
	 * @return string Unique ID.
	 * @credits Twenty Seventeen 2.0
	 *
	 * @see     wp_unique_id() Themes requiring WordPress 5.0.3 and greater should use this instead.
	 */
	function anky_unique_id( $prefix = '' ) {
		static $id_counter = 0;
		if ( function_exists( 'wp_unique_id' ) ) {
			return wp_unique_id( $prefix );
		}

		return $prefix . (string) ++ $id_counter;
	}
endif;

/**
 * Retrieve the iframe source.
 */
if ( ! function_exists( 'anky_get_iframe_src' ) ) :
	/**
	 * Retrieve the iframe source.
	 *
	 * @param string $input Required. The input string to search in.
	 *
	 * @return string|bool
	 */
	function anky_get_iframe_src( $input ) {
		preg_match_all( "/<iframe[^>]*src=[\"|']([^'\"]+)[\"|'][^>]*>/i", $input, $output );

		return $output[1][0] ?? false;
	}
endif;

/**
 * Flattens a multidimensional array to a simple array.
 */
if ( ! function_exists( 'anky_array_flatten' ) ) :
	/**
	 * Flattens a multidimensional array to a simple array.
	 *
	 * @param array $array a multidimensional array.
	 *
	 * @return array a simple array
	 */
	function anky_array_flatten( $array ) {
		$result = array();
		foreach ( $array as $element ) {
			if ( is_array( $element ) && ! empty( $element ) ) {
				array_push( $result, ...anky_array_flatten( $element ) );
			} else {
				$result[] = $element;
			}
		}

		return $result;
	}
endif;

/**
 * Initialises and connects the WordPress Filesystem.
 */
if ( ! function_exists( 'anky_filesystem' ) ) :
	/**
	 * Initialises and connects the WordPress Filesystem.
	 *
	 * @return WP_Filesystem_Base
	 */
	function anky_filesystem() {
		if ( ! defined( 'FS_METHOD' ) ) {
			require_once wp_normalize_path( ABSPATH . '/wp-admin/includes/file.php' );
			define( 'FS_METHOD', 'direct' );
			WP_Filesystem();
		}

		if ( ! defined( 'FS_CHMOD_DIR' ) ) {
			define( 'FS_CHMOD_DIR', ( 0755 & ~umask() ) );
		}

		if ( ! defined( 'FS_CHMOD_FILE' ) ) {
			define( 'FS_CHMOD_FILE', ( 0644 & ~umask() ) );
		}

		global $wp_filesystem;

		if ( empty( $wp_filesystem ) ) {
			require_once wp_normalize_path( ABSPATH . '/wp-admin/includes/file.php' );
			WP_Filesystem();
		}

		return $wp_filesystem;
	}
endif;

/**
 *  Retrieve an array of available Contact Form 7 registered forms.
 */
if ( ! function_exists( 'anky_get_contact_forms_list' ) ) :
	/**
	 * Retrieve an array of available Contact Form 7 registered forms.
	 * Returning value is array of available form.
	 * If nothing is found that the first key of array will be string with `nothing found` text.
	 *
	 * @return array List of contact forms or array with string `nothing found`
	 */
	function anky_get_contact_forms_list() {
		$forms_posts = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

		$return = array();

		if ( $forms_posts ) {
			foreach ( $forms_posts as $form_post ) {
				$return[ $form_post->ID ] = $form_post->post_title;
			}
		} else {
			$return[0] = esc_html__( 'Contact forms not founded', 'anky' );
		}

		return $return;
	}
endif;

/**
 *  Check if the specified post type exists.
 */
if ( ! function_exists( 'anky_post_type_exists' ) ) :
	/**
	 * Check if the specified post type exists.
	 *
	 * @param string $post_type Post type name that must be checked.
	 *
	 * @return bool
	 */
	function anky_post_type_exists( $post_type = '' ) {
		return in_array( $post_type, get_post_types( array( 'public' => true ) ) );
	}
endif;

/**
 * Retrieve unslashed value from $_GET/$_POST array.
 */
if ( ! function_exists( 'anky_get_gp_value' ) ) :
	/**
	 * Retrieve unslashed value from $_GET/$_POST array.
	 *
	 * @param string $name    Required. Value key name.
	 * @param string $default Optional. Default value that will be returned if nothing found.
	 *
	 * @return mixed
	 */
	function anky_get_gp_value( $name, $default = '' ) {
		$output = $default;
		// @codingStandardsIgnoreStart
		if ( isset( $_GET[ $name ] ) ) {
			$output = wp_unslash( $_GET[ $name ] );
		} elseif ( isset( $_POST[ $name ] ) ) {
			$output = wp_unslash( $_POST[ $name ] );
		}

		// @codingStandardsIgnoreEnd

		return $output;
	}
endif;
