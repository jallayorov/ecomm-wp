<?php
/**
 * Functions that are used to access class methods.
 *
 * @package    Anky
 * @subpackage Core/Helpers
 * @author     Anky (Andrew Black)
 */

use Anky\Includes\Anky;
use Anky\Includes\Builder\Anky_UI_Controller;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Instantiates and return the main Anky class.
 *
 * @return object Anky
 */
if ( class_exists( 'Anky\Includes\Anky' ) ) :
	/**
	 * Instantiates and return the main Anky class.
	 *
	 * @return object Anky
	 */
	function Anky() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName
		return Anky::get_instance();
	}
endif;

/**
 * Gets the option for the given name. Returns the default value if the
 * value does not exist.
 */
if ( function_exists( 'Anky' ) ) :
	/**
	 * Gets the option for the given name. Returns the default value if the
	 * value does not exist.
	 *
	 * @param string $name    Required. Option name.
	 * @param mixed  $default Optional. Option default value.
	 *
	 * @return mixed
	 */
	function anky_get_option( $name, $default = null ) {
		return Anky()->options->get( $name, $default );
	}
endif;

/**
 *  Sets an option. Overwrites the existing option if the name is already in use.
 */
if ( function_exists( 'Anky' ) ) :
	/**
	 *  Sets an option. Overwrites the existing option if the name is already in use.
	 *
	 * @param string $name  Option name.
	 * @param mixed  $value Option value.
	 *
	 * @return mixed
	 */
	function anky_set_option( $name, $value ) {
		return Anky()->options->set( $name, $value );
	}
endif;

/**
 * Retrieve a list of available widget areas.
 *
 * @param string $sidebar_name Sidebar ID.
 *
 * @return array
 */
if ( function_exists( 'Anky' ) ) :
	/**
	 * Retrieve a list of available widget areas.
	 *
	 * @param string $sidebar_name Sidebar ID.
	 *
	 * @return array
	 */
	function anky_get_sidebars( $sidebar_name = '' ) {
		$sidebars = Anky()->widgets->sidebars;

		if ( '' !== $sidebar_name ) {
			$sidebars = array_filter(
				$sidebars,
				function ( $arr ) use ( $sidebar_name ) {
					return strpos( $arr['id'], $sidebar_name ) !== false;
				}
			);
		}

		return $sidebars;
	}
endif;

/**
 * Retrieve a list of available widget areas.
 *
 * @param string $sidebar_name Sidebar ID.
 *
 * @return array
 */
if ( function_exists( 'Anky' ) ) :
	/**
	 * Retrieve a list of available widget areas.
	 *
	 * @param string $sidebar_name Sidebar ID.
	 *
	 * @return array
	 */
	function anky_get_sidebar( $sidebar_name = '' ) {
		return anky_get_prop( Anky()->widgets->sidebars, $sidebar_name, false );
	}
endif;

/**
 * Render search form.
 */
if ( function_exists( 'Anky' ) ) :
	/**
	 * Render search form.
	 */
	function anky_render_search_form() {
		Anky()->footer->render_search_modal();
	}
endif;

/**
 * Render sanitized svg icons.
 *
 * @param array $args Required. Params used for generating svg.
 *                    Passed as array of:
 *                    icon - The icon ID.
 *                    width - Dimensions of svg
 *                    height - Dimensions of svg
 *                    class - Css classes array.
 */
if ( class_exists( 'Anky\Includes\Builder\Anky_UI_Controller' ) ) :
	/**
	 * Render sanitized svg icons.
	 *
	 * @param array $args Required. Params used for generating svg.
	 *                    Passed as array of:
	 *                    icon - The icon ID.
	 *                    width - Dimensions of svg
	 *                    height - Dimensions of svg
	 *                    class - Css classes array.
	 */
	function anky_the_svg( $args ) {
		Anky_UI_Controller::the_svg( $args );
	}
endif;
