<?php
/**
 * Anky hooks.
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

// ======================================================
// HEADER
// ======================================================

/**
 * Action triggered before the site header tag.
 */
function anky_header_before() {
	do_action( 'anky_header_before' );
}

/**
 * Action triggered the header content.
 */
function anky_header() {
	do_action( 'anky_header' );
}

/**
 * Action triggered after the site header tag.
 */
function anky_header_after() {
	do_action( 'anky_header_after' );
}

/**
 * Action triggered in header menu section.
 * Mainly used to display language switcher or alternative.
 */
function anky_language_section() {
	do_action( 'anky_language_section' );
}

// ======================================================
// SEARCH MODAL
// ======================================================

/**
 * Action triggered inside search modal top section.
 */
function anky_search_header_top() {
	do_action( 'anky_search_header_top' );
}

/**
 * Action triggered inside search modal top section.
 */
function anky_search_header_bottom() {
	do_action( 'anky_search_header_bottom' );
}

// ======================================================
// FOOTER
// ======================================================

/**
 * Action triggered right after Footer opening tag.
 */
function anky_footer_inner_before() {
	do_action( 'anky_footer_inner_before' );
}

/**
 * Action triggered Inside Footer.
 */
function anky_footer_inner() {
	do_action( 'anky_footer_inner' );
}

/**
 * Action triggered right before Footer closing tag.
 */
function anky_footer_inner_after() {
	do_action( 'anky_footer_inner_after' );
}

// ======================================================
// LOOP
// ======================================================

/**
 * Action triggered right before the main loop.
 */
function anky_before_loop() {
	do_action( 'anky_before_loop' );
}

/**
 * Action triggered right after the main loop.
 */
function anky_after_loop() {
	do_action( 'anky_after_loop' );
}

// ======================================================
// BLOG
// ======================================================

/**
 * Action triggered in blog meta.
 * Used to display various blog meta information after the entry content.
 */
function anky_page_header() {
	do_action( 'anky_page_header' );
}

/**
 * Action triggered inside page header.
 */
function anky_page_header_inner() {
	do_action( 'anky_page_header_inner' );
}

/**
 * Action triggered inside Entry Header.
 * Used to display various information about the post.
 */
function anky_entry_header() {
	do_action( 'anky_entry_header' );
}

/**
 * Action triggered in blog entry meta.
 * Used to display various blog meta information before the entry.
 */
function anky_blog_entry_meta() {
	do_action( 'anky_blog_meta' );
}

/**
 * Action triggered in blog meta.
 * Used to display various blog meta information after the entry content.
 */
function anky_blog_post_meta() {
	do_action( 'anky_blog_post_meta' );
}

/**
 * Action triggered in blog entry footer.
 */
function anky_entry_footer() {
	do_action( 'anky_blog_entry_footer' );
}

/**
 * Action triggered in blog entry footer on single page.
 */
function anky_single_entry_footer() {
	do_action( 'anky_single_entry_footer' );
}

/**
 * Action triggered in page pagination wrapper.
 */
function anky_pagination() {
	do_action( 'anky_pagination' );
}

// ======================================================
// RELATED POSTS
// ======================================================

/**
 *  Action triggered in `Related Posts` header.
 */
function anky_related_posts_entry_header() {
	do_action( 'anky_related_posts_entry_header' );
}

/**
 * Action triggered in `Related Posts` header.
 * Main used to display meta information.
 */
function anky_blog_related_post_meta() {
	do_action( 'anky_blog_related_post_meta' );
}

// ======================================================
// ADMIN
// ======================================================

/**
 * Action triggered in admin dashboard pages.
 */
function anky_admin_header() {
	do_action( 'anky_admin_header' );
}

/**
 * Action triggered in admin header section.
 * Mainly used to display theme update button trigger.
 */
function anky_theme_update_trigger() {
	do_action( 'anky_theme_update_trigger' );
}

/**
 * Action triggered in admin dashboard.
 * Mainly used to display license manipulation form.
 */
function anky_theme_licence_form() {
	do_action( 'anky_theme_licence_form' );
}

/**
 * Action triggered in Welcome page.
 * Mainly used to display Plugins install and activate button.
 */
function anky_plugins_button() {
	do_action( 'anky_plugins_button' );
}

/**
 * Action triggered in Welcome page.
 * Mainly used to display assistive plugins install/active list.
 */
function anky_welcome_notes() {
	do_action( 'anky_welcome_notes' );
}
