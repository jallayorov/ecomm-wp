<?php
/**
 * Theme bootstrap file. All Classes, Files & functions are hooked here.
 *
 * @package    Anky
 * @subpackage Core
 * @author     Anky (Andrew Black)
 */

use Anky\Includes\Anky;
use Anky\Includes\Admin\Anky_Admin;
use Anky\Includes\Compatibility\Elementor\Anky_Elementor_Extension;
use Anky\Includes\Core\Anky_Autoloader;
use Anky\Includes\Customizer\Anky_Customizer;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

// Theme assistive functions.
require_once ANKY_THEME_DIR . 'includes/helpers/common-helpers.php';
require_once ANKY_THEME_DIR . 'includes/template-enhancement/template-tags.php';
require_once ANKY_THEME_DIR . 'includes/helpers/markup/markup-helpers.php';

// Theme hooks.
require_once ANKY_THEME_DIR . 'includes/helpers/anky-hooks.php';

// Autoloader.
require_once ANKY_THEME_DIR . 'includes/core/class-anky-autoloader.php';

new Anky_Autoloader();

// Theme API assistant.
require_once ANKY_THEME_DIR . 'includes/helpers/api.php';

// Theme initialization.
$theme = new Anky();

// Customizer.
if ( is_customize_preview() ) {
	new Anky_Customizer( $theme );
}

// Admin.
if ( is_admin() ) {
	$admin = new Anky_Admin();
	$admin->run();
}

$theme->run();

if ( class_exists( 'Elementor\Plugin' ) ) {
	$elementor_extension = new Anky_Elementor_Extension();
	$elementor_extension->run();
}
