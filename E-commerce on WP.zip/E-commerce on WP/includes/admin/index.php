<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Admin
 */

/* Silence is golden, and we agree. */
