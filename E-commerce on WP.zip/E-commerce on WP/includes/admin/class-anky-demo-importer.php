<?php
/**
 * Anky Theme Demo import controller.
 * Controller is an add-on for OCDI plugin.
 * In later releases it will be completely independent feature.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin;

use Anky\Includes\Builder\Navigation\Anky_Menu_Navigation_Builder;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Theme Demo import controller.
 */
class Anky_Demo_Importer {

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Define Demo data.
	 *
	 * @return array Demo data
	 */
	public function demo_data() {
		/**
		 * Allow temporarily SVG import and change user-agent default header.
		 * All data fill be restored after import is done.
		 *
		 * @important Do not change this as this is required to import demo data from server.
		 */
		add_filter(
			'upload_mimes',
			function ( $mimes ) {
				$mimes['svg'] = 'image/svg+xml';

				return $mimes;
			},
			9
		);
		add_filter(
			'http_headers_useragent',
			function () {
				return 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
			},
			9
		);

		return array(
			array(
				'import_file_name'             => 'Architectural bureau',
				'categories'                   => array( 'Corporate', 'Architecture' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/1/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/1/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/1/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/1/1.png',
				'preview_url'                  => '//ankythemes.com/demo1',
			),
			array(
				'import_file_name'             => 'Shopping center',
				'categories'                   => array( 'Corporate', 'Shop' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/2/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/2/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/2/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/2/2.png',
				'preview_url'                  => '//ankythemes.com/demo2',
			),
			array(
				'import_file_name'             => 'Interior design',
				'categories'                   => array( 'Corporate', 'Design' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/3/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/3/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/3/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/3/3.png',
				'preview_url'                  => '//ankythemes.com/demo3',
			),
			array(
				'import_file_name'             => 'Coffee house',
				'categories'                   => array( 'Corporate', 'Shop' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/4/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/4/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/4/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/4/4.png',
				'preview_url'                  => '//ankythemes.com/demo4',
			),
			array(
				'import_file_name'             => 'Multifunctional clinic',
				'categories'                   => array( 'Medical', 'Clinic' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/5/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/5/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/5/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/5/5.png',
				'preview_url'                  => '//ankythemes.com/demo5',
			),
			array(
				'import_file_name'             => 'Web/Mobile development agency',
				'categories'                   => array( 'Corporate', 'Agency' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/6/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/6/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/6/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/6/6.png',
				'preview_url'                  => '//ankythemes.com/demo6',
			),
			array(
				'import_file_name'             => 'Beauty salon',
				'categories'                   => array( 'Corporate', 'Salon' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/7/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/7/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/7/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/7/7.png',
				'preview_url'                  => '//ankythemes.com/demo7',
			),
			array(
				'import_file_name'             => 'Wedding agency',
				'categories'                   => array( 'Corporate', 'Agency', 'Wedding' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/8/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/8/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/8/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/8/8.png',
				'preview_url'                  => '//ankythemes.com/demo8',
			),
			array(
				'import_file_name'             => 'Dental clinic',
				'categories'                   => array( 'Medical', 'Clinic' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/9/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/9/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/9/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/9/9.png',
				'preview_url'                  => '//ankythemes.com/demo9',
			),
			array(
				'import_file_name'             => 'Kindergarten',
				'categories'                   => array( 'Corporate' ),
				'local_import_file'            => ANKY_THEME_DIR . 'includes/admin/demo/10/demo.xml',
				'local_import_widget_file'     => ANKY_THEME_DIR . 'includes/admin/demo/10/demo-widgets.wie',
				'local_import_customizer_file' => ANKY_THEME_DIR . 'includes/admin/demo/10/customizer.dat',
				'import_preview_image_url'     => ANKY_THEME_URI . 'includes/admin/demo/10/10.png',
				'preview_url'                  => '//ankythemes.com/demo10',
			),
		);
	}

	/**
	 * Before Import Custom Code Execution.
	 *
	 * @param array $selected_import The filtered import files defined in `pt-ocdi/import_files` filter.
	 */
	public function before_content_import( $selected_import ) {
		if ( 'Demo 7' !== $selected_import['import_file_name'] ) {
			anky_set_option( 'footer-widgets-layout-type', 'layout-1' );
		}
	}

	/**
	 * After Import Custom Code Execution.
	 *
	 * @param array $selected_import The filtered import files defined in `pt-ocdi/import_files` filter.
	 */
	public function after_import_setup( $selected_import ) {
		// Assign menus to their locations.
		$main_menu = get_term_by( 'name', 'Primary', 'nav_menu' );
		set_theme_mod(
			'nav_menu_locations',
			array( Anky_Menu_Navigation_Builder::$primary_menu_id => $main_menu->term_id )
		);

		// Assign front page and posts page (blog page).
		$front_page_id = get_page_by_title( 'Home' );
		$blog_page_id  = get_page_by_title( 'Blog' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );
		update_option( 'page_for_posts', $blog_page_id->ID );

		$this->update_elementor_settings();

		// Returning back to defaults.
		add_filter(
			'http_headers_useragent',
			function () {
				return 'WordPress/' . get_bloginfo( 'version' ) . '; ' . get_bloginfo( 'url' );
			}
		);
		add_filter(
			'upload_mimes',
			function ( $mimes ) {
				if ( isset( $mimes['svg'] ) ) {
					unset( $mimes['svg'] );
				}

				return $mimes;
			}
		);
	}

	/**
	 * Disables generation of multiple image sizes (thumbnails) in the content import step.
	 */
	public function regenerate_thumbnails_in_content_import() {
		return false;
	}

	/**
	 * Updated attachment GUIDs to the new URL
	 *
	 * @param array $data Required. Default options.
	 *
	 * @return array Options data
	 */
	public function update_attachment_guids( $data ) {
		$data['update_attachment_guids'] = true;

		return $data;
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Update elementor settings.
	 */
	private function update_elementor_settings() {
		$elementor_settings = array(
			'elementor_font_display'               => 'swap',
			'elementor_load_fa4_shim'              => 'yes',
			'elementor_cpt_support'                => array( 'post', 'page', 'portfolio' ),
			'elementor_disable_color_schemes'      => 'yes',
			'elementor_disable_typography_schemes' => 'yes',
			'elementor_css_print_method'           => 'external',
			'elementor_container_width'            => '1152',
			'elementor_viewport_lg'                => '1087',
			'elementor_viewport_mobile'            => '736',
		);

		foreach ( $elementor_settings as $key => $value ) {
			update_option( $key, $value );
		}
	}

}
