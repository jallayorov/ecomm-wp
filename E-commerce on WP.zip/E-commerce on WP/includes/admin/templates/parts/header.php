<?php
/**
 * Template part for displaying admin page header content.
 *
 * @package    Anky
 * @subpackage Admin/Templates/Parts
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>
<h1 class="screen-reader-text">ANKY Theme</h1>

<div class="anky-admin-header-wrap">
	<div class="about-text">
		<h2><?php esc_html_e( 'Welcome to ANKY', 'anky' ); ?></h2>
		<p>
			<?php
			printf(
				wp_kses_data(
				/* translators: 1: Link to prebuild sites, 2: Link to plugins installation. */
					__( 'Discover <a href="%1$s">pre-built websites</a>, auto updates and much more.', 'anky' )
				),
				'admin.php?page=anky-websites'
			);
			?>
		</p>
	</div>
	<div class="anky-logo-wrap">
		<div class="logo">
			<?php
			anky_the_svg(
				array(
					'icon'   => 'theme_logo',
					'width'  => 90,
					'height' => 90,
				)
			);
			?>
			<span class="version"><?php echo esc_html( ANKY_THEME_VERSION ); ?></span>
		</div>

		<?php anky_theme_update_trigger(); ?>
	</div>
</div>
