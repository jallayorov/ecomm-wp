<?php
/**
 * Template part for displaying admin mini status content.
 *
 * @package    Anky
 * @subpackage Admin/Templates/Parts
 * @author     Anky (Andrew Black)
 * @version    1.0.0
 */

// Exit if accessed directly.
use Anky\Includes\Admin\Pages\Anky_System_Status;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
$system = Anky_System_Status::get_instance();
$system->get_status_data();
?>

<table class="system-status mini form-table">
	<tr>
		<td class="label"><?php esc_html_e( 'Uploads folder writable', 'anky' ); ?>
			<a href="javascript:void(0)" class="info-tip" data-help-tip="<?php esc_attr_e( 'Uploads folder directory writable status. Must be writable to download files', 'anky' ); ?>">?</a>
		</td>
		<td class="desc">
			<?php if ( $system->get_status( 'uploads' ) ) : ?>
				<span class="status yes dashicons dashicons-yes"></span>
			<?php else : ?>
				<span class="status no dashicons dashicons-no"></span>
				<span class="status-notice status-error"><?php esc_html_e( 'Uploads folder must be writable. Please set write permission to your wp-content/uploads folders', 'anky' ); ?></span>
			<?php endif; ?>
		</td>
	</tr>
	<tr>
		<td class="label"><?php esc_html_e( 'WP File System', 'anky' ); ?>
			<a href="javascript:void(0)" class="info-tip" data-help-tip="<?php esc_attr_e( 'File System access is required for pre-built websites and plugins installation.', 'anky' ); ?>">?</a>
		</td>
		<td class="desc">
			<?php if ( $system->get_status( 'fs' ) ) : ?>
				<span class="status yes dashicons dashicons-yes"></span>
			<?php else : ?>
				<span class="status no dashicons dashicons-no"></span>
				<span class="status-notice status-error"><?php esc_html_e( 'File System is unavailable. Please contact your hosting provider.', 'anky' ); ?></span>
			<?php endif; ?>
		</td>
	</tr>
	<tr>
		<td class="label"><?php esc_html_e( 'ZipArchive', 'anky' ); ?>
			<a href="javascript:void(0)"
				class="info-tip"
				data-help-tip="<?php esc_attr_e( 'ZipArchive is required for importing demos. They are used to import and export zip files.', 'anky' ); ?>">
				?
			</a>
		</td>
		<td class="desc">
			<?php if ( $system->get_status( 'zip' ) ) : ?>
				<span class="status yes dashicons dashicons-yes"></span>
			<?php else : ?>
				<span class="status no dashicons dashicons-no"></span>
				<span class="status-notice status-error"><?php esc_html_e( 'ZipArchive is not installed on your server, but is required if you need to import demo content.', 'anky' ); ?></span>
			<?php endif; ?>
		</td>
	</tr>
	<?php if ( $system->get_status( 'suhosin' ) ) : ?>
		<tr>
			<td class="label"><?php esc_html_e( 'SUHOSIN Installed', 'anky' ); ?></td>
			<td class="desc">
				<span class="status info dashicons dashicons-info"></span>
				<span class="status-notice"><?php esc_html_e( 'Suhosin may need to be configured to increase its data submission limits.', 'anky' ); ?></span>
			</td>
		</tr>
	<?php endif; ?>
	<tr>
		<td class="label"><?php esc_html_e( 'PHP Memory Limit', 'anky' ); ?>
			<a href="javascript:void(0)"
				class="info-tip"
				data-help-tip="<?php esc_attr_e( 'The maximum amount of memory (RAM) that your site can use at one time.', 'anky' ); ?>">?</a>
		</td>
		<td class="desc">
			<?php if ( $system->get_data( 'memory_limit' ) >= $system->get_data( 'req_memory_limit' ) ) : ?>
				<span class="status yes dashicons dashicons-yes"></span>
				<span class="desc"><?php echo esc_html( size_format( $system->get_data( 'memory_limit' ) ) ); ?></span>
			<?php elseif ( $system->get_data( 'memory_limit' ) < $system->get_data( 'min_memory_limit' ) ) : ?>
				<span class="status no dashicons dashicons-no"></span>
				<span class="desc"><?php echo esc_html( size_format( $system->get_data( 'memory_limit' ) ) ); ?></span>
				<p class="status-notice status-error">
					<?php
					printf(
					/* translators: %1$s: Minimum PHP Memory limit. %2$s: .Recommended PHP Memory limit. */
						esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
						'<strong>' . esc_html( size_format( $system->get_data( 'min_memory_limit' ) ) ) . '</strong>',
						'<strong>' . esc_html( size_format( $system->get_data( 'req_memory_limit' ) ) ) . '</strong>'
					);
					?>
				</p>
			<?php else : ?>
				<span class="status info dashicons dashicons-info"></span>
				<span class="desc"><?php echo esc_html( size_format( $system->get_data( 'memory_limit' ) ) ); ?></span>
				<p class="status-notice status-error">
					<?php
					printf(
					/* translators: %s: Recommended PHP Memory limit. */
						esc_html__( 'Current memory limit is OK, however %s and above is recommended. ', 'anky' ),
						'<strong>' . esc_html( size_format( $system->get_data( 'req_memory_limit' ) ) ) . '</strong>'
					);
					?>
				</p>
			<?php endif; ?>
		</td>
	</tr>
	<tr>
		<td class="label"><?php esc_html_e( 'PHP Time Limit', 'anky' ); ?>
			<a href="javascript:void(0)"
				class="info-tip"
				data-help-tip="<?php esc_attr_e( 'The amount of time (in seconds) that your site will spend on a single operation before timing out (to avoid server lockups)', 'anky' ); ?>">
				?
			</a>
		</td>
		<td class="desc">
			<?php if ( $system->get_status( 'time_limit' ) ) : ?>
				<span class="status yes dashicons dashicons-yes"></span>
				<span class="desc"><?php echo esc_html( $system->get_data( 'time_limit' ) ); ?></span>
			<?php elseif ( $system->get_data( 'time_limit' ) < $system->get_data( 'min_time_limit' ) ) : ?>
				<span class="status no dashicons dashicons-no"></span>
				<span class="desc"><?php echo esc_html( $system->get_data( 'time_limit' ) ); ?></span>
				<p class="status-notice status-error">
					<?php
					printf(
					/* translators: %1$s: Minimum PHP Time Limit. %2$s: .Recommended PHP Time Limit. */
						esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
						'<strong>' . esc_html( $system->get_data( 'min_time_limit' ) ) . '</strong>',
						'<strong>' . esc_html( $system->get_data( 'max_time_limit' ) ) . '</strong>'
					);
					?>
				</p>
			<?php else : ?>
			<span class="status info dashicons dashicons-info"></span>
			<span class="desc"><?php echo esc_html( $system->get_data( 'time_limit' ) ); ?></span>
			<p class="status-notice status-error">
				<?php
				printf(
				/* translators: %s: Recommended PHP Time Limit. */
					esc_html__( 'Current Time Limit is OK, however %s and above is recommended. ', 'anky' ),
					'<strong>' . esc_html( $system->get_data( 'max_time_limit' ) ) . '</strong>'
				);
				?>
			</p>
		</td>
		<?php endif; ?>
	</tr>
	<tr>
		<td class="label"><?php esc_html_e( 'PHP Max Input Vars', 'anky' ); ?>
			<a href="javascript:void(0)"
				class="info-tip"
				data-help-tip="<?php esc_attr_e( 'The maximum number of variables your server can use for a single function to avoid overloads.', 'anky' ); ?>">?</a>
		</td>
		<td class="desc">
			<?php if ( $system->get_status( 'max_input_vars' ) ) : ?>
				<span class="status yes dashicons dashicons-yes"></span>
				<span class="desc"><?php echo esc_html( $system->get_data( 'max_input_vars' ) ); ?></span>
			<?php elseif ( $system->get_data( 'max_input_vars' ) < $system->get_data( 'max_input_vars_min' ) ) : ?>
				<span class="status no dashicons dashicons-no"></span>
				<span class="desc"><?php echo esc_html( $system->get_data( 'max_input_vars' ) ); ?></span>
				<p class="status-notice status-error">
					<?php
					printf(
					/* translators: %1$s: Minimum PHP Max Input Vars. %2$s: Recommended PHP Max Input Vars */
						esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
						'<strong>' . esc_html( $system->get_data( 'max_input_vars_min' ) ) . '</strong>',
						'<strong>' . esc_html( $system->get_data( 'max_input_vars_required' ) ) . '</strong>'
					);
					?>
				</p>
			<?php else : ?>
				<span class="status info dashicons dashicons-info"></span>
				<span class="desc"><?php echo esc_html( $system->get_data( 'max_input_vars' ) ); ?></span>
				<p class="status-notice status-error">
					<?php
					printf(
					/* translators: %s: Recommended PHP Max Input Vars */
						esc_html__( 'Current Max Input Vars value is OK, however %s and above is recommended.', 'anky' ),
						'<strong>' . esc_html( $system->get_data( 'max_input_vars_required' ) ) . '</strong>'
					);
					?>
				</p>
			<?php endif; ?>
		</td>
	</tr>
	<tr>
		<td class="info" colspan="2">
			<span>
			<?php
			printf(
				wp_kses(
				/* translators: %s link to PHP documentation. */
					__( 'php.ini values are shown above. Real values may vary, please check your limits using <a target="_blank" href="%s">php_info()</a>', 'anky' ),
					array(
						'a' => array(
							'_target' => array(),
							'href'    => array(),
						),
					)
				),
				'//php.net/manual/en/function.phpinfo.php'
			);
			?>
			</span>
		</td>
	</tr>
	<tr>
		<td class="info" colspan="2">
			<a href="admin.php?page=anky-status" class="anky-more-button">
				<?php esc_html_e( 'More details', 'anky' ); ?>
				<span class="anky-more-button-icon anky-icon-arrow-up-right" aria-hidden="true"></span>
			</a>
		</td>
	</tr>
</table>
