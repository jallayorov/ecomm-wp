<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Admin/Templates/Parts
 */

/* Silence is golden, and we agree. */
