<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Admin/Templates
 */

/* Silence is golden, and we agree. */
