<?php
/**
 * Template part for displaying admin dashboard.
 *
 * @package    Anky
 * @subpackage Admin/Templates
 * @author     Anky (Andrew Black)
 */

use Anky\Includes\Admin\Anky_Status;
use Anky\Includes\Builder\Anky_UI_Controller;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>
<div id="anky_dashboard" class="wrap">
	<?php anky_admin_header(); ?>
	<div class="anky_wrap">
		<?php Anky_UI_Controller::render_admin_nav_tabs(); ?>
		<div class="dashboard-tab register">
			<div class="col col-left">
				<h3 class="primary"><?php esc_html_e( 'Thank you for choosing Anky', 'anky' ); ?></h3>
				<p>
					<?php
					esc_html_e(
						'Here you can build your own website, even if you are not an IT professional. Simple and convenient instructions will help you analyze, design and choose the best solution for you in the further management of your own website.',
						'anky'
					);
					?>
				</p>
			</div>

			<div class="col col-right">

				<h3><?php esc_html_e( 'System Status', 'anky' ); ?></h3>
				<div class="anky-mini-status">
					<?php include_once ANKY_THEME_DIR . 'includes/admin/templates/parts/mini-status.php'; ?>
				</div>

				<h3><?php esc_html_e( 'Useful links', 'anky' ); ?></h3>

				<ul class="links">
					<li><a class="anky-admin-link-1" href="admin.php?page=anky-plugins"><?php esc_html_e( 'Install Plugins', 'anky' ); ?></a></li>
					<li><a class="anky-admin-link-1" href="admin.php?page=anky-websites"><?php esc_html_e( 'Pre-built websites', 'anky' ); ?></a></li>
				</ul>

			</div>
		</div>
	</div>
</div>
