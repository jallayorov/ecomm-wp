<?php
/**
 * Template part for displaying Manual and Support content.
 *
 * @package    Anky
 * @subpackage Admin/Templates
 * @author     Anky (Andrew Black)
 * @version    1.0.0
 */

use Anky\Includes\Builder\Anky_UI_Controller;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<div id="anky_dashboard" class="wrap">
	<?php anky_admin_header(); ?>
	<div class="anky_wrap">
		<?php Anky_UI_Controller::render_admin_nav_tabs(); ?>
		<div class="dashboard-tab support">
			<div class="col col-left">

				<h3><?php esc_html_e( 'Documentation', 'anky' ); ?></h3>

				<div class="anky-support-accordion">
					<div class="anky-support-accordion-item" id="anky-support-accordion-item-1">
						<div class="anky-support-accordion-item-title">
							<h4 class="anky-support-question-title">How to Install Theme?</h4>
							<div class="anky-support-accordion-icon">
								<div class="anky-support-accordion-icons anky-support-accordion-open-icon">
									<span class="anky-icon-plus" aria-hidden="true"></span>
								</div>
							</div>
						</div>
						<div class="anky-support-accordion-content">
							When you switch to a subscription you can redeem $9 in credit for each remaining month on any non-educational license you own.
							If you store documents and/or Libraries in an existing Personal Workspace, we’ll help you move them to your new Workspace when you start your subscription.
							Switch to a subscription or learn more.
						</div>
					</div>

					<div class="anky-support-accordion-item" id="anky-support-accordion-item-2">
						<div class="anky-support-accordion-item-title">
							<h4 class="anky-support-question-title">Which payment methods do you accept? </h4>
							<div class="anky-support-accordion-icon">
								<div class="anky-support-accordion-icons anky-support-accordion-open-icon">
									<span class="anky-icon-plus" aria-hidden="true"></span>
								</div>
							</div>
						</div>
						<div class="anky-support-accordion-content">
							When you switch to a subscription you can redeem $9 in credit for each remaining month on any non-educational license you own.
							If you store documents and/or Libraries in an existing Personal Workspace, we’ll help you move them to your new Workspace when you start your subscription.
							Switch to a subscription or learn more.
						</div>
					</div>

					<div class="anky-support-accordion-item" id="anky-support-accordion-item-3">
						<div class="anky-support-accordion-item-title">
							<h4 class="anky-support-question-title">I have a license. Can I switch to a subscription?</h4>
							<div class="anky-support-accordion-icon">
								<div class="anky-support-accordion-icons anky-support-accordion-open-icon">
									<span class="anky-icon-plus" aria-hidden="true"></span>
								</div>
							</div>
						</div>
						<div class="anky-support-accordion-content">
							When you switch to a subscription you can redeem $9 in credit for each remaining month on any non-educational license you own.
							If you store documents and/or Libraries in an existing Personal Workspace, we’ll help you move them to your new Workspace when you start your subscription.
							Switch to a subscription or learn more.
						</div>
					</div>
				</div>

				<ul class="videos">
					<li>
						<a class="anky-admin-link-1" href="//docs.ankythemes.com/"><?php esc_html_e( 'How to install theme', 'anky' ); ?></a>
					</li>
				</ul>


			</div>

			<div class="col col-right">

				<div class="support__center">
					<h3><?php esc_html_e( 'Support Center', 'anky' ); ?></h3>

					<div class="support__center-inner">
						<h4><?php esc_html_e( 'Item support includes', 'anky' ); ?>:</h4>

						<ul>
							<li>
								<span class="status yes dashicons dashicons-yes"></span>
								<?php esc_html_e( 'Responding to questions or problems regarding the item and its features', 'anky' ); ?>
							</li>
							<li>
								<span class="status yes dashicons dashicons-yes"></span>
								<?php esc_html_e( 'Fixing bugs and reported issues', 'anky' ); ?>
							</li>
							<li>
								<span class="status yes dashicons dashicons-yes"></span>
								<?php esc_html_e( 'Providing updates to ensure compatibility with new WordPress versions', 'anky' ); ?>
							</li>
						</ul>
					</div>

					<div class="support__center-inner">
						<h4><?php esc_html_e( 'However, item support does not include', 'anky' ); ?>:</h4>

						<ul>
							<li>
								<span class="status no dashicons dashicons-no"></span>
								<?php esc_html_e( 'Customization and installation services', 'anky' ); ?>
							</li>
							<li>
								<span class="status no dashicons dashicons-no"></span>
								<?php esc_html_e( 'Support for third party software and plugins', 'anky' ); ?>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
