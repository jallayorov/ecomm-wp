<?php
/**
 * Template part for displaying theme Welcome page.
 *
 * @package    Anky
 * @subpackage Admin/Templates
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>
<div id="anky_welcome" class="wrap anky-welcome-page">

	<div class="anky-logo">
		<?php
		anky_the_svg(
			array(
				'icon'   => 'theme_logo',
				'width'  => 320,
				'height' => 320,
				'class'  => array( 'anky-logo-icon' ),
			)
		);
		?>
	</div>

	<p class="anky-title">
		<?php esc_html_e( 'Welcome to Anky', 'anky' ); ?>
		<sup>v.<?php echo esc_html( ANKY_THEME_VERSION ); ?></sup>
	</p>

	<div class="anky-description">
		<?php
		echo wp_kses_post(
			sprintf(
				'<p>%s<sup>*</sup>. %s.</p>',
				__( 'In order to provide best experience, please install and activate all <b>assistive plugin</b>', 'anky' ),
				__( 'It should only take a few minutes', 'anky' )
			)
		);
		?>
	</div>

	<div class="anky-button-wrap"><?php anky_plugins_button(); ?></div>

	<hr>
	<div class="anky-notes">
		<?php anky_welcome_notes(); ?>
	</div>
</div>
