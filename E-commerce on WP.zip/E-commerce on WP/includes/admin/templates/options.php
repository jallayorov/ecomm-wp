<?php
/**
 * Template part for displaying theme options links in dashboard.
 *
 * @package    Anky
 * @subpackage Admin/Templates
 * @author     Anky (Andrew Black)
 */

use Anky\Includes\Builder\Anky_UI_Controller;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<div id="anky_dashboard" class="wrap">
	<?php anky_admin_header(); ?>
	<div class="anky_wrap">
		<?php Anky_UI_Controller::render_admin_nav_tabs(); ?>
		<h3 class="primary"><?php esc_html_e( 'Links to Customizer Settings', 'anky' ); ?>:</h3>

		<section class="anky-options-links-section">
			<div>
				<?php
				if ( isset( $this ) && ( $this instanceof Anky\Includes\Admin\Pages\Anky_Admin_Options ) ) :
					$options = $this->get_options_data();
					if ( ! empty( $options ) ) :
						?>
						<ul class="global-settings">
							<?php
							foreach ( $options as $slug => $data ) {
								printf(
									'<li class="global-settings__item %1$s"><a href="%2$s" target="_blank" rel="noopener"><span class="dashicons %3$s"></span><strong>%4$s</strong><span>%5$s</span></a></li>',
									esc_attr( $slug ),
									esc_url( admin_url( $data['url'] ) ),
									esc_attr( $data['icon'] ),
									esc_html( $data['title'] ),
									esc_html( $data['description'] )
								);
							}
							?>
						</ul>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</section>
	</div>
</div>
