<?php
/**
 * Pre-build demo websites content.
 *
 * @package    Anky
 * @subpackage Admin/Templates
 * @author     Anky (Andrew Black)
 */

use Anky\Includes\Builder\Anky_UI_Controller;
use OCDI\Helpers;
use OCDI\OneClickDemoImport;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<div id="anky_dashboard" class="wrap">
	<?php anky_admin_header(); ?>
	<div class="anky_wrap">
		<?php
		Anky_UI_Controller::render_admin_nav_tabs();
		$ocdi_exists    = class_exists( 'OCDI\OneClickDemoImport' );
		if ( $ocdi_exists ) :
			$ocdi = OneClickDemoImport::get_instance();
			$categories = Helpers::get_all_demo_import_categories( $ocdi->import_files );
			?>
			<div class="anky-websites">
				<h3 class="primary"><?php esc_html_e( 'Import a Prebuilt Website', 'anky' ); ?></h3>
				<p class="anky-websites__description">
					<?php
					esc_html_e( 'Import any of the prebuilt websites below. Once done, your site will have th exact same look and feel as the sites in the preview.', 'anky' );
					echo ' ';
					echo wp_kses_data(
						sprintf(
						/* translators: link to OCDI plugin page */
							__( 'If you prefer manual demo import data, you can import data using <a href="%s">Manual Demo Tool of OCDI Plugin</a>.', 'anky' ),
							'themes.php?page=one-click-demo-import&import-mode=manual'
						)
					);
					?>
				</p>
				<div class="anky-websites__notice">
					<div class="anky-websites__notice-title">
						<div class="anky-websites__notice-title-icon dashicons-info"></div>
						<?php esc_html_e( 'Prebuilt website imports can vary in time.', 'anky' ); ?>
					</div>
					<div class="anky-websites__notice-description">
						<?php
						echo wp_kses_post(
							sprintf(
							/* translators: %s link to system status page */
								__(
									'Please check your <a href="%s">system stats</a> to ensure your server meets all requirements for a successful import. Setting that needs attention will be marked red.',
									'anky'
								),
								'admin.php?page=anky-status'
							)
						);
						?>
					</div>
				</div>

				<?php if ( ! empty( $categories ) ) : ?>
					<div class="anky-websites__header">
						<nav class="anky-websites__header-navigation">
							<ul>
								<li class="active"><a href="#all" class="anky-websites__header-navigation js-anky-nav-link"><?php esc_html_e( 'All', 'anky' ); ?></a></li>
								<?php foreach ( $categories as $key => $name ) : ?>
									<li><a href="#<?php echo esc_attr( $key ); ?>" class="anky-websites__header-navigation js-anky-nav-link"><?php echo esc_html( $name ); ?></a></li>
								<?php endforeach; ?>
							</ul>
						</nav>
						<label class="anky-websites__header-search">
							<span class="screen-reader-text"><?php esc_html_e( 'Search demos', 'anky' ); ?></span>
							<input type="search"
								class="anky-websites__header-search-input js-anky-websites-search"
								name="anky-websites-search"
								value=""
								placeholder="<?php esc_html_e( 'Search demos', 'anky' ); ?>">
						</label>
					</div>
				<?php endif; ?>

				<div class="anky-websites__list js-anky-websites__list-container">

					<?php foreach ( $ocdi->import_files as $index => $import_file ) : ?>
						<?php
						// Prepare import item display data.
						$img_src = $import_file['import_preview_image_url'] ?? '';

						// Default to the theme screenshot, if a custom preview image is not defined.
						if ( empty( $img_src ) ) {
							$theme   = wp_get_theme();
							$img_src = $theme->get_screenshot();
						}
						?>
						<div class="anky-websites__item js-anky-websites__item"
							data-categories="<?php echo esc_attr( Helpers::get_demo_import_item_categories( $import_file ) ); ?>"
							data-name="<?php echo esc_attr( strtolower( $import_file['import_file_name'] ) ); ?>">
							<div class="anky-websites-item__img-wrap">
								<?php if ( ! empty( $img_src ) ) : ?>
									<img class="anky-websites-item-img"
										src="<?php echo esc_url( $img_src ); ?>"
										alt="<?php esc_attr( sprintf( 'Screenshot for %s', $import_file['import_file_name'] ) ); ?>">
								<?php else : ?>
									<div class="anky-websites-item-img--no-image"><?php esc_html_e( 'No preview image.', 'anky' ); ?></div>
								<?php endif; ?>
							</div>
							<div class="anky-websites-item__title-wrap">
								<h4 class="anky-websites-item__title"><?php echo esc_html( $import_file['import_file_name'] ); ?></h4>
							</div>
							<div class="anky-websites-item__view-wrap">
								<?php if ( isset( $import_file['preview_url'] ) ) : ?>
									<a href="<?php echo esc_url( $import_file['preview_url'] ); ?>" class="anky-websites-item__view-btn" target="_blank"><?php esc_html_e( 'View', 'anky' ); ?></a>
								<?php endif; ?>
								<button type="button"
									class="anky-websites-item__view-btn js-anky-import"
									data-import="<?php echo esc_attr( $index ); ?>">
									<?php esc_html_e( 'Import', 'anky' ); ?>
								</button>
							</div>
						</div>
					<?php endforeach; ?>

				</div>
			</div>
		<?php else : ?>
			<div class="anky-websites">
				<h3 class="primary"><?php esc_html_e( 'Please install and activate One Click Demo Import Plugin', 'anky' ); ?>.</h3>
			</div>
		<?php endif; ?>
	</div>
</div>

<?php if ( $ocdi_exists ) : ?>
	<!--Modal -->
	<div class="anky-import-modal thickbox" id="anky_import_modal" style="display: none;">
		<div class="anky-import js-anky-importing">
			<div class="anky-import__header">
				<h2><?php esc_html_e( 'Importing Content', 'anky' ); ?></h2>
				<p><?php esc_html_e( 'Please wait until import is done. Do not refresh the page or hit the close button.', 'anky' ); ?></p>
			</div>
			<div class="anky-import__content">
				<?php
				anky_the_svg(
					array(
						'icon'   => 'cog',
						'class'  => 'anky-import__content-icon',
						'width'  => '100',
						'height' => '100',
					)
				);
				?>
			</div>
		</div>
		<div class="anky-import js-anky-imported" style="display: none;">
			<div class="anky-import__header">
				<h2 class="js-anky-ajax-response-title"><?php esc_html_e( 'Import Complete!', 'anky' ); ?></h2>
				<div class="js-anky-ajax-response-subtitle">
					<p><?php esc_html_e( 'Congrats, your demo was imported successfully. You can now begin editing your site.', 'anky' ); ?></p>
				</div>
			</div>
			<div class="anky-import__content">
				<div class="anky-import-content__response js-anky-ajax-response"></div>
			</div>
			<div class="anky-import__footer">
				<a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button anky-import-modal__link"><?php esc_html_e( 'Customize', 'anky' ); ?></a>
				<a href="<?php echo esc_url( get_home_url() ); ?>" class="button anky-import-modal__link"><?php esc_html_e( 'Visit Site', 'anky' ); ?></a>
			</div>
		</div>

		<div class="anky-ajax-loader js-anky-ajax-loader">
			<?php
			anky_the_svg(
				array(
					'icon'  => 'loading',
					'class' => 'anky-ajax-loader__spinner',
				)
			);
			?>
			<span class="anky-ajax-loader__text"><?php esc_html_e( 'Importing, please wait!', 'anky' ); ?></span>
		</div>
	</div>
<?php endif; ?>
