<?php
/**
 * Template part for displaying system status information.
 *
 * @package    Anky
 * @subpackage Admin/Templates
 * @author     Anky (Andrew Black)
 * @version    1.0.0
 */

use Anky\Includes\Builder\Anky_UI_Controller;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<div id="anky_dashboard" class="wrap">
	<?php anky_admin_header(); ?>
	<div class="anky_wrap">
		<?php Anky_UI_Controller::render_admin_nav_tabs(); ?>
		<div class="dashboard-tab status">
			<?php if ( isset( $this ) && ( $this instanceof Anky\Includes\Admin\Pages\Anky_System_Status ) ) : ?>
				<div class="col-left">
					<section class="col">

						<h3 class="primary"><?php esc_html_e( 'Server Environment', 'anky' ); ?></h3>

						<table class="system-status form-table">
							<tr>
								<td class="label"><?php esc_html_e( 'Server Info', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'Information about the web server that is currently hosting your site.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( empty( $this->get_data( 'server' ) ) ) : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php esc_html_e( 'Unknown', 'anky' ); ?></span>
									<?php else : ?>
										<?php echo esc_html( $this->get_data( 'server' ) ); ?>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'PHP Version', 'anky' ); ?>
									<a href="javascript:void(0)" class="info-tip" data-help-tip="<?php esc_attr_e( 'The version of PHP installed on your hosting server.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( version_compare( $this->get_data( 'php' ), $this->get_data( 'php_required' ) ) >= 0 ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
										<span class="desc"><?php echo esc_html( PHP_VERSION ); ?></span>
									<?php elseif ( version_compare( $this->get_data( 'php_min' ), $this->get_data( 'php_min' ) ) >= 0 ) : ?>
										<span class="status info dashicons dashicons-info"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'php' ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: Recommended PHP Version. */
												esc_html__( 'Current PHP version is OK, however %s version and above is recommended.', 'anky' ),
												'<strong>' . esc_html( $this->get_data( 'php_required' ) ) . '</strong>'
											);
											?>
										</p>
									<?php else : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo PHP_VERSION; ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %1$s: Recommended PHP version. %2$s: "WordPress Requirements" link. */
												esc_html__( 'WordPress recommendation: %1$s or above. See %2$s for details.', 'anky' ),
												esc_html( $this->get_data( 'php_required' ) ),
												'<a href="https://wordpress.org/about/requirements/" target="_blank">' . esc_html__( 'WordPress Requirements', 'anky' ) . '</a>'
											)
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'MySQL Version', 'anky' ); ?>
									<a href="javascript:void(0)" class="info-tip" data-help-tip="<?php esc_attr_e( 'The version of MySQL installed on your hosting server.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc"><?php echo esc_html( $this->get_data( 'mysql' ) ); ?></td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'SUHOSIN Installed', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="
										<?php
										esc_attr_e(
											'Suhosin is an advanced protection system for PHP installations. It was designed to protect your servers on the one hand against a number of well known problems in PHP applications and on the other hand against potential unknown vulnerabilities within these applications or the PHP core itself. If enabled on your server, Suhosin may need to be configured to increase its data submission limits.',
											'anky'
										);
										?>
										">
										?
									</a>
								</td>
								<td class="desc">
									<?php printf( '<span class="status %1$s dashicons dashicons-%1$s"></span>', ( $this->get_status( 'suhosin' ) ) ? 'yes' : 'no' ); ?>
								</td>
							</tr>
							<?php if ( $this->get_status( 'suhosin' ) ) : ?>
								<tr>
									<td class="label"><?php esc_html_e( 'Suhosin Post Max Vars:', 'anky' ); ?>
										<a href="javascript:void(0)"
											class="info-tip"
											data-help-tip="<?php esc_attr_e( 'The maximum number of variables your server can use for a single function to avoid overloads.', 'anky' ); ?>">?
										</a>
									</td>
									<td class="desc">
										<?php if ( $this->get_data( 'suhosin_max_vars' ) < $this->get_data( 'suhosin_required_input_vars' ) ) : ?>
											<span class="status no dashicons dashicons-no"></span>
											<span class="desc">
												<?php
												echo wp_kses(
													sprintf(
													/* translators: %1$s: Current value. $2%s: Recommended value. %3$s: URL. */
														__(
															'%1$s - Recommended Value: %2$s.<br />Max input vars limitation will truncate POST data such as menus. See: <a href="%3$s" target="_blank" rel="noopener noreferrer nofollow">Increasing max input vars limit.</a>',
															'anky'
														),
														$this->get_data( 'suhosin_max_vars' ),
														'<strong>' . $this->get_data( 'suhosin_required_input_vars' ) . '</strong>',
														'//sevenspark.com/docs/ubermenu-3/faqs/menu-item-limit'
													),
													array(
														'br'     => array(),
														'strong' => array(),
														'a'      => array(
															'href'   => array(),
															'target' => array(),
															'rel'    => array(),
														),
													)
												);
												?>
											</span>
										<?php else : ?>
											<span class="status yes dashicons dashicons-yes"></span>
											<span class="desc"><?php echo esc_html( $this->get_data( 'suhosin_max_vars' ) ); ?></span>
										<?php endif; ?>
									</td>
								</tr>

								<tr>
									<td class="label"><?php esc_html_e( 'Suhosin Request Max Vars:', 'anky' ); ?>
										<a href="javascript:void(0)"
											class="info-tip"
											data-help-tip="<?php esc_attr_e( 'The maximum number of variables your server can use for a single function to avoid overloads.', 'anky' ); ?>">
											?
										</a>
									</td>
									<td class="desc">
										<?php if ( $this->get_data( 'suhosin_request_max_vars' ) < $this->get_data( 'suhosin_request_required_input_vars' ) ) : ?>
											<span class="status no dashicons dashicons-no"></span>
											<span class="desc">
												<?php
												echo wp_kses(
													sprintf(
													/* translators: %1$s: Current value. $2%s: Recommended value. %3$s: URL. */
														__(
															'%1$s - Recommended Value: %2$s.<br />Max input vars limitation will truncate POST data such as menus. See: <a href="%3$s" target="_blank" rel="noopener noreferrer nofollow">Increasing max input vars limit.</a>',
															'anky'
														),
														$this->get_data( 'suhosin_request_max_vars' ),
														'<strong>' . $this->get_data( 'suhosin_request_required_input_vars' ) . '</strong>',
														'//sevenspark.com/docs/ubermenu-3/faqs/menu-item-limit'
													),
													array(
														'br'     => array(),
														'strong' => array(),
														'a'      => array(
															'href'   => array(),
															'target' => array(),
															'rel'    => array(),
														),
													)
												);
												?>
											</span>
										<?php else : ?>
											<span class="status yes dashicons dashicons-yes"></span>
											<span class="desc"><?php echo esc_html( $this->get_data( 'suhosin_request_max_vars' ) ); ?></span>
										<?php endif; ?>
									</td>
								</tr>

								<tr>
									<td class="label"><?php esc_html_e( 'Suhosin Post Max Value Length:', 'anky' ); ?>
										<a href="javascript:void(0)"
											class="info-tip"
											data-help-tip="<?php esc_attr_e( 'Defines the maximum length of a variable that is registered through a POST request.', 'anky' ); ?>">
											?
										</a>
									</td>
									<td class="desc">
										<?php if ( $this->get_data( 'suhosin_max_value_length' ) < $this->get_data( 'suhosin_recommended_max_value_length' ) ) : ?>
											<span class="status no dashicons dashicons-no"></span>
											<span class="desc">
												<?php
												echo wp_kses(
													sprintf(
													/* translators: %1$s: Current value. $2%s: Recommended value. %3$s: URL. */
														__(
															'%1$s - Recommended Value: %2$s.<br />Post Max Value Length limitation may prohibit the Global Options data from being saved to your database. See: <a href="%3$s" target="_blank" rel="noopener noreferrer no follow">Suhosin Configuration Info</a>',
															'anky'
														),
														$this->get_data( 'suhosin_max_value_length' ),
														'<strong>' . $this->get_data( 'suhosin_recommended_max_value_length' ) . '</strong>',
														'//suhosin.org/stories/configuration.html'
													),
													array(
														'br'     => array(),
														'strong' => array(),
														'a'      => array(
															'href'   => array(),
															'target' => array(),
															'rel'    => array(),
														),
													)
												);
												?>
											</span>
										<?php else : ?>
											<span class="status yes dashicons dashicons-yes"></span>
											<span class="desc"><?php echo esc_html( $this->get_data( 'suhosin_max_value_length' ) ); ?></span>
										<?php endif; ?>
									</td>
								</tr>
							<?php endif; // Suhosin. ?>

							<tr>
								<td class="label"><?php esc_html_e( 'PHP Memory Limit', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The maximum amount of memory (RAM) that your site can use at one time.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_data( 'memory_limit' ) >= $this->get_data( 'req_memory_limit' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'memory_limit' ) ) ); ?></span>
									<?php elseif ( $this->get_data( 'memory_limit' ) < $this->get_data( 'min_memory_limit' ) ) : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'memory_limit' ) ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %1$s: Minimum PHP Memory limit. %2$s: .Recommended PHP Memory limit. */
												esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
												'<strong>' . esc_html( size_format( $this->get_data( 'min_memory_limit' ) ) ) . '</strong>',
												'<strong>' . esc_html( size_format( $this->get_data( 'req_memory_limit' ) ) ) . '</strong>'
											);
											?>
										</p>
									<?php else : ?>
										<span class="status info dashicons dashicons-info"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'memory_limit' ) ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %s: Recommended PHP Memory limit. */
												esc_html__( 'Current memory limit is OK, however %s and above is recommended. ', 'anky' ),
												'<strong>' . esc_html( size_format( $this->get_data( 'req_memory_limit' ) ) ) . '</strong>'
											);
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'PHP Time Limit', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="
										<?php esc_attr_e( 'The amount of time (in seconds) that your site will spend on a single operation before timing out (to avoid server lockups)', 'anky' ); ?>">
										?
									</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'time_limit' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'time_limit' ) ); ?></span>
									<?php elseif ( $this->get_data( 'time_limit' ) < $this->get_data( 'min_time_limit' ) ) : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'time_limit' ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %1$s: Minimum PHP Time Limit. %2$s: .Recommended PHP Time Limit. */
												esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
												'<strong>' . esc_html( $this->get_data( 'min_time_limit' ) ) . '</strong>',
												'<strong>' . esc_html( $this->get_data( 'max_time_limit' ) ) . '</strong>'
											);
											?>
										</p>
									<?php else : ?>
									<span class="status info dashicons dashicons-info"></span>
									<span class="desc"><?php echo esc_html( $this->get_data( 'time_limit' ) ); ?></span>
									<p class="status-notice status-error">
										<?php
										printf(
										/* translators: %s: Recommended PHP Time Limit. */
											esc_html__( 'Current Time Limit is OK, however %s and above is recommended. ', 'anky' ),
											'<strong>' . esc_html( $this->get_data( 'max_time_limit' ) ) . '</strong>'
										);
										?>
									</p>
								</td>
								<?php endif; ?>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'PHP Max Input Vars', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The maximum number of variables your server can use for a single function to avoid overloads.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'max_input_vars' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'max_input_vars' ) ); ?></span>
									<?php elseif ( $this->get_data( 'max_input_vars' ) < $this->get_data( 'max_input_vars_min' ) ) : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'max_input_vars' ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %1$s: Minimum PHP Max Input Vars. %2$s: Recommended PHP Max Input Vars */
												esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
												'<strong>' . esc_html( $this->get_data( 'max_input_vars_min' ) ) . '</strong>',
												'<strong>' . esc_html( $this->get_data( 'max_input_vars_required' ) ) . '</strong>'
											);
											?>
										</p>
									<?php else : ?>
										<span class="status info dashicons dashicons-info"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'max_input_vars' ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %s: Recommended PHP Max Input Vars */
												esc_html__( 'Current Max Input Vars value is OK, however %s and above is recommended.', 'anky' ),
												'<strong>' . esc_html( $this->get_data( 'max_input_vars_required' ) ) . '</strong>'
											);
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'WP Max Upload Size', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The largest file size that can be uploaded to your WordPress installation.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'max_upload_size' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'max_upload_size' ) ) ); ?></span>
									<?php elseif ( $this->get_data( 'max_upload_size' ) < $this->get_data( 'max_upload_size_min' ) ) : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'max_upload_size' ) ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %1$s: Minimum Upload Size. %2$s: Recommended Upload Size */
												esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
												'<strong>' . esc_html( size_format( $this->get_data( 'max_upload_size_min' ) ) ) . '</strong>',
												'<strong>' . esc_html( size_format( $this->get_data( 'max_upload_size_required' ) ) ) . '</strong>'
											);
											?>
										</p>
									<?php else : ?>
										<span class="status info dashicons dashicons-info"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'max_upload_size' ) ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %s: Recommended Upload Size */
												esc_html__( 'Current upload size is OK, however %s and above is recommended. ', 'anky' ),
												'<strong>' . esc_html( size_format( $this->get_data( 'max_upload_size_required' ) ) ) . '</strong>'
											);
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'PHP Post Max Size', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The largest file size that can be contained in one post.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'post_size' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'max_upload_size' ) ) ); ?></span>
									<?php elseif ( $this->get_data( 'post_size' ) < $this->get_data( 'post_size_min' ) ) : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'post_size' ) ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %1$s: Minimum Post Max Size, %2$s: Recommended Post Max Size */
												esc_html__( 'Minimum %1$s is required, %2$s and above is recommended.', 'anky' ),
												'<strong>' . esc_html( size_format( $this->get_data( 'post_size_min' ) ) ) . '</strong>',
												'<strong>' . esc_html( size_format( $this->get_data( 'post_size_required' ) ) ) . '</strong>'
											);
											?>
										</p>
									<?php else : ?>
										<span class="status info dashicons dashicons-info"></span>
										<span class="desc"><?php echo esc_html( size_format( $this->get_data( 'post_size' ) ) ); ?></span>
										<p class="status-notice status-error">
											<?php
											printf(
											/* translators: %s: Recommended Post Max Size */
												esc_html__( 'Current max post size is OK, however %s and above is recommended. ', 'anky' ),
												'<strong>' . esc_html( size_format( $this->get_data( 'post_size_required' ) ) ) . '</strong>'
											);
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'ZipArchive', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'ZipArchive is required for importing demos. They are used to import and export zip files.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'zip' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
									<?php else : ?>
										<span class="status no dashicons dashicons-no"></span>
										<p class="status-notice status-error">
											<?php esc_html_e( 'ZipArchive is not installed on your server, but is required if you need to import demo content.', 'anky' ); ?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'WP Remote Get', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'Anky uses this method to communicate with different APIs.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'wp_remote_get' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
									<?php else : ?>
										<span class="status no dashicons dashicons-no"></span>
										<p class="status-notice status-error">
											<?php
											esc_html_e(
												'wp_remote_get() failed. Some theme features may not work. Please contact your hosting provider and make sure that https://build.envato.com/api/ is not blocked.',
												'anky'
											);
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'WP Remote Post', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'Anky uses this method to communicate with different APIs.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'wp_remote_get' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
									<?php else : ?>
										<span class="status no dashicons dashicons-no"></span>
										<p class="status-notice status-error">
											<?php
											esc_html_e(
												'wp_remote_post() failed. Some theme features may not work. Please contact your hosting provider and make sure that https://www.google.com/recaptcha/api/siteverify is not blocked.',
												'anky'
											);
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'DOMDocument', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'DOMDocument is required for the WordPress Importer to properly function.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'dom' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
									<?php else : ?>
										<span class="status no dashicons dashicons-no"></span>
										<p class="status-notice status-error">
											<?php
											esc_html_e( 'DOMDocument is not installed on your server, but is required if you need to import demo data. Please contact your hosting provider.', 'anky' );
											?>
										</p>
									<?php endif; ?>
								</td>
							</tr>
						</table>

					</section>
				</div>
				<div class="col-right">
					<section class="col">

						<h3 class="primary"><?php esc_html_e( 'WordPress Environment', 'anky' ); ?></h3>

						<table class="system-status form-table">

							<tr>
								<td class="label"><?php esc_html_e( 'Home URL', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The URL of your site\'s homepage.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc"><?php echo esc_html( $this->get_data( 'home' ) ); ?></td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'Site URL', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The root URL of your site.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'siteurl' ) ) : ?>
										<span class="desc"><?php echo esc_html( $this->get_data( 'siteurl' ) ); ?></span>
									<?php else : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'siteurl' ) ); ?></span>
										<p class="status-notice status-error"><?php esc_html_e( 'Home URL host must be the same as Site URL host.', 'anky' ); ?></p>
									<?php endif; ?>
								</td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'WP Version', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The version of WordPress installed on your site.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc">
									<?php if ( $this->get_status( 'wp_version' ) ) : ?>
										<span class="status yes dashicons dashicons-yes"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'wp_version' ) ); ?></span>
									<?php else : ?>
										<span class="status no dashicons dashicons-no"></span>
										<span class="desc"><?php echo esc_html( $this->get_data( 'wp_version' ) ); ?></span>
										<p class="status-notice status-error"><?php esc_html_e( 'Please update WordPress to the latest version.', 'anky' ); ?></p>
									<?php endif; ?>
								</td>
							</tr>

							<tr class="secondary">
								<td class="label"><?php esc_html_e( 'WP Multisite', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'Whether or not you have WordPress Multisite enabled.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc"><?php printf( '<span class="status %1$s dashicons dashicons-%1$s"></span>', $this->get_status( 'multisite' ) ? 'yes' : 'no' ); ?></td>
							</tr>

							<tr class="secondary">
								<td class="label"><?php esc_html_e( 'WP Debug', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'Displays whether or not WordPress is in Debug Mode.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc"><?php printf( '<span class="status %1$s dashicons dashicons-%1$s"></span>', $this->get_status( 'debug' ) ? 'yes' : 'no' ); ?></td>
							</tr>

							<tr>
								<td class="label"><?php esc_html_e( 'Language', 'anky' ); ?>
									<a href="javascript:void(0)"
										class="info-tip"
										data-help-tip="<?php esc_attr_e( 'The current language used by WordPress. Default = English.', 'anky' ); ?>">?</a>
								</td>
								<td class="desc"><?php printf( '%1$s, text direction: %2$s', esc_html( $this->get_data( 'language' ) ), esc_html( $this->get_data( 'rtl' ) ) ); ?></td>
							</tr>

						</table>

					</section>

					<section class="col">
						<h3 class="primary"><?php esc_html_e( 'Active plugins', 'anky' ); ?></h3>

						<table class="system-status form-table">
							<?php
							foreach ( $this->get_data( 'plugins' ) as $plugin_file ) :
								$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file );

								if ( ! empty( $plugin_data['Name'] ) ) :
									// Link the plugin name to the plugin url if available.
									if ( ! empty( $plugin_data['PluginURI'] ) ) {
										$plugin_name = sprintf(
											'<a href="%1$s" title="%2$s" target="_blank">%3$s</a>',
											esc_url( $plugin_data['PluginURI'] ),
											esc_attr__( 'Visit plugin homepage', 'anky' ),
											$plugin_data['Name']
										);
									} else {
										$plugin_name = $plugin_data['Name'];
									}
									?>
									<tr>
										<td class="label">
											<?php echo wp_kses_post( $plugin_name ); ?>
										</td>
										<td class="desc">
											<?php
											$author_name = preg_replace( '#<a.*?>([^>]*)</a>#i', '$1', $plugin_data['AuthorName'] );
											echo wp_kses_post(
												sprintf(
												/* translators: plugin author. */
													'<span>' . __( 'by %s', 'anky' ) . '</span>',
													'<a href="' . esc_url( $plugin_data['AuthorURI'] ) . '" target="_blank">' . esc_html( $author_name ) . '</a> &ndash; ' . esc_html( $plugin_data['Version'] )
												)
											);
											?>
										</td>
									</tr>
								<?php endif; ?>
							<?php endforeach; ?>
						</table>
					</section>
				</div>
			<?php else : ?>
				<p><?php esc_html_e( 'System status is currently unavailable. Refer to system administrator or support team.', 'anky' ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</div>
