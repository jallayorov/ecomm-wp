<?php
/**
 * Anky theme Admin Options controller.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 * @version    1.0.0
 */

namespace Anky\Includes\Admin\Pages;

use Anky\Includes\Interfaces\Interface_Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Admin Options Controller.
 */
class Anky_Admin_Options implements Interface_Admin {

	/**
	 * Add admin page
	 */
	public function add_page() {
		$title = __( 'Theme Options', 'anky' );

		add_submenu_page(
			'anky',
			$title,
			$title,
			'edit_theme_options',
			'anky-theme-options',
			array( $this, 'render' )
		);
	}

	/**
	 * Support page template.
	 */
	public function render() {
		require_once ANKY_THEME_DIR . 'includes/admin/templates/options.php';
	}

	/**
	 * Enqueue styles and scripts
	 */
	public function enqueue() {
		wp_enqueue_style( 'anky-theme-admin' );
		wp_enqueue_script( 'anky-theme-admin' );
	}

	/**
	 * Retrieve data for rendering theme options cards.
	 *
	 * @return array Options data
	 */
	public function get_options_data() {
		return array(
			'typography'        => array(
				'url'         => 'customize.php?autofocus[section]=section-globals-typography',
				'icon'        => 'dashicons-editor-textcolor',
				'title'       => __( 'Typography', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
			'colors'            => array(
				'url'         => 'customize.php?autofocus[panel]=panel-globals&autofocus[section]=colors',
				'icon'        => 'dashicons-admin-customizer',
				'title'       => __( 'Color Scheme', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
			'contacts'          => array(
				'url'         => 'customize.php?autofocus[section]=section-globals-contact',
				'icon'        => 'dashicons-email',
				'title'       => __( 'Site contacts', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
			'site-identity'     => array(
				'url'         => 'customize.php?autofocus[section]=title_tagline',
				'icon'        => 'dashicons-format-image',
				'title'       => __( 'Site Identity', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
			'header'            => array(
				'url'         => 'customize.php?autofocus[section]=section-header-layout',
				'icon'        => 'dashicons-align-center',
				'title'       => __( 'Header Options', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
			'blog'              => array(
				'url'         => 'customize.php?autofocus[section]=section-main-blog',
				'icon'        => 'dashicons-align-wide',
				'title'       => __( 'Blog Settings', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
			'footer'            => array(
				'url'         => 'customize.php?autofocus[section]=section-footer-widgets',
				'icon'        => 'dashicons-align-wide',
				'title'       => __( 'Footer Settings', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
			'language-switcher' => array(
				'url'         => 'customize.php?autofocus[section]=section-language-switcher',
				'icon'        => 'dashicons-translation',
				'title'       => __( 'Custom language switcher', 'anky' ),
				'description' => 'Our UX & UI experts produce a unique design specifically for a particular app',
			),
		);
	}

}
