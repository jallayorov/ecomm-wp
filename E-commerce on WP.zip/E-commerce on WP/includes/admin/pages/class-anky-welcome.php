<?php
/**
 * Anky theme Welcome page controller.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin\Pages;

use Anky\Includes\Interfaces\Interface_Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky theme Welcome page controller.
 */
class Anky_Welcome implements Interface_Admin {

	/**
	 * Add admin page & enqueue styles
	 */
	public function add_page() {
		$title = __( 'Welcome to ANKY', 'anky' );

		add_theme_page(
			$title,
			$title,
			'edit_theme_options',
			'anky_welcome',
			array( $this, 'render' )
		);
	}

	/**
	 * Dashboard template
	 */
	public function render() {
		include_once ANKY_THEME_DIR . 'includes/admin/templates/welcome.php';
	}

	/**
	 * Enqueue styles and scripts
	 */
	public function enqueue() {
		wp_enqueue_style( 'anky-theme-admin' );
		wp_enqueue_script( 'anky-theme-admin' );

		// Hide all notifications on welcome page.
		$current_screen = get_current_screen();
		if ( 'appearance_page_anky_welcome' === $current_screen->base ) {
			wp_add_inline_style( 'anky-theme-admin', '.notice, .update-nag, .updated, .error, .is-dismissible { display: none !important; }' );
		}
	}

	/**
	 * Welcome page instruction notices.
	 */
	public function instruction_notices() {
		echo wp_kses_post(
			sprintf(
				'<p>%s. %s.<br>%s.<br>%s.</p>',
				__( 'This procedure will allow one time ease install/activate all necessary plugins. After it is done, you can manage plugins yourself', 'anky' ),
				__( 'You can also Skip installation/activation process and do one manually or via <b>Install Plugins</b> page', 'anky' ),
				__(
					'<b>NOTE</b>: After successful installation/activation/skip action done, the page will redirect you to another page. If you were not redirected or any error occurred, you can still install recommended plugins manually',
					'anky'
				),
				__( '<b>NOTE</b>: Ignoring installation of recommended plugins will disable some theme features that rely on specific plugin', 'anky' )
			)
		);
	}

}
