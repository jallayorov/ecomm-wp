<?php
/**
 * Anky theme Support & Manual admin page controller.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin\Pages;

use Anky\Includes\Interfaces\Interface_Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky theme Support & Manual admin page controller.
 */
class Anky_Support implements Interface_Admin {

	/**
	 * Add admin page
	 */
	public function add_page() {
		$title = __( 'Manual & Support', 'anky' );

		add_submenu_page(
			'anky',
			$title,
			$title,
			'edit_theme_options',
			'anky-support',
			array( $this, 'render' )
		);
	}

	/**
	 * Enqueue styles and scripts
	 */
	public function enqueue() {
		wp_enqueue_style( 'anky-theme-admin' );
	}

	/**
	 * Support page template.
	 */
	public function render() {
		require_once ANKY_THEME_DIR . 'includes/admin/templates/support.php';
	}

}
