<?php
/**
 * Anky System status controller.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin\Pages;

use Anky\Includes\Interfaces\Interface_Admin;
use Anky\Includes\Traits\Trait_Singleton as Singleton;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky System status controller.
 */
class Anky_System_Status implements Interface_Admin {
	use Singleton;

	/**
	 * System data collection.
	 *
	 * @var array
	 * @access private
	 */
	protected $data = array();

	/**
	 * System status collection.
	 *
	 * @var array
	 * @access private
	 */
	protected $status = array();

	/**
	 * Retrieve a value from `Data` data array by key.
	 * If key is not found default value is retrieved.
	 *
	 * @param string $key     Required. Data key.
	 * @param mixed  $default Optional. Value is returned if provided key is not found.
	 *
	 * @return mixed
	 */
	public function get_data( $key, $default = '' ) {
		return $this->data[ $key ] ?? $default;
	}

	/**
	 * Retrieve a value from `Status` data array by key.
	 * If key is not found default value is retrieved.
	 *
	 * @param string $key     Required. Data key.
	 * @param mixed  $default Optional. Value is returned if provided key is not found.
	 *
	 * @return mixed
	 */
	public function get_status( $key, $default = '' ) {
		return $this->status[ $key ] ?? $default;
	}

	/**
	 * Add admin page and set statuses.
	 */
	public function add_page() {
		$title = __( 'System Status', 'anky' );

		add_submenu_page(
			'anky',
			$title,
			$title,
			'edit_theme_options',
			'anky-status',
			array( $this, 'render' )
		);
	}

	/**
	 * Status template
	 */
	public function render() {
		$this->get_status_data();
		include_once ANKY_THEME_DIR . 'includes/admin/templates/status.php';
	}

	/**
	 * Enqueue styles and scripts
	 */
	public function enqueue() {
		wp_enqueue_style( 'tiptip' );
		wp_enqueue_script( 'tiptip' );
		wp_enqueue_style( 'anky-theme-admin' );
		wp_enqueue_script( 'anky-theme-admin' );
	}

	/**
	 * Get system status array
	 */
	public function get_status_data() {
		global $wpdb;

		$data = array(
			'php'                      => false,
			'php_min'                  => '7.0',
			'php_required'             => '7.3',
			'mysql'                    => $wpdb->db_version(),
			'memory_limit'             => 0,
			'min_memory_limit'         => 134217728, // 128mb
			'req_memory_limit'         => 268435456, // 256mb
			'time_limit'               => ini_get( 'max_execution_time' ),
			'min_time_limit'           => 120,
			'max_time_limit'           => 300,
			'max_input_vars'           => ini_get( 'max_input_vars' ),
			'max_input_vars_min'       => 1000,
			'max_input_vars_required'  => 3000,
			'max_upload_size'          => wp_max_upload_size(),
			'max_upload_size_min'      => 134217728, // 128mb
			'max_upload_size_required' => 268435456, // 256mb
			'server'                   => isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : false,
			'post_size'                => wp_convert_hr_to_bytes( ini_get( 'post_max_size' ) ),
			'post_size_min'            => 134217728, // 128mb
			'post_size_required'       => 268435456, // 256mb
			'home'                     => home_url(),
			'siteurl'                  => get_option( 'siteurl' ),
			'wp_version'               => get_bloginfo( 'version' ),
			'language'                 => get_locale(),
			'rtl'                      => is_rtl() ? 'RTL' : 'LTR',
			'wp_uploads'               => wp_get_upload_dir(),
		);

		if ( defined( 'PHP_VERSION' ) ) {
			$data['php'] = PHP_VERSION;
		} elseif ( function_exists( 'phpversion' ) ) {
			$data['php'] = phpversion();
		}

		// Get the memory from PHP's configuration.
		$data['memory_limit'] = ini_get( 'memory_limit' );
		// If we can't get it, fallback to WP_MEMORY_LIMIT.
		if ( ! $data['memory_limit'] || ( - 1 === $data['memory_limit'] ) ) {
			$data['memory_limit'] = wp_convert_hr_to_bytes( WP_MEMORY_LIMIT );
		}
		// Make sure the value is properly formatted in bytes.
		if ( ! is_numeric( $data['memory_limit'] ) ) {
			$data['memory_limit'] = wp_convert_hr_to_bytes( $data['memory_limit'] );
		}

		$wp_remote_get  = wp_safe_remote_get(
			'https://build.envato.com/api/',
			array(
				'decompress' => false,
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . network_site_url(),
			)
		);
		$wp_remote_post = wp_safe_remote_post(
			'https://www.google.com/recaptcha/api/siteverify',
			array(
				'decompress' => false,
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . network_site_url(),
			)
		);

		$status = array(
			'suhosin'         => extension_loaded( 'suhosin' ),
			'time_limit'      => ( ( $data['time_limit'] >= $data['max_time_limit'] ) || ( 0 === $data['time_limit'] ) ),
			'max_input_vars'  => $data['max_input_vars'] >= $data['max_input_vars_required'],
			'max_upload_size' => $data['max_upload_size'] >= $data['max_upload_size_required'],
			'post_size'       => $data['post_size'] >= $data['post_size_required'],
			'wp_remote_get'   => ( ! is_wp_error( $wp_remote_get ) && $wp_remote_get['response']['code'] >= 200 && $wp_remote_get['response']['code'] < 300 ),
			'wp_remote_post'  => ( ! is_wp_error( $wp_remote_post ) && $wp_remote_post['response']['code'] >= 200 && $wp_remote_post['response']['code'] < 300 ),
			'dom'             => class_exists( 'DOMDocument' ),
			'zip'             => class_exists( 'ZipArchive' ),
			'siteurl'         => false,
			'wp_version'      => version_compare( get_bloginfo( 'version' ), '5.0' ) >= 0,
			'multisite'       => is_multisite(),
			'debug'           => ANKY_DEV_MODE,
			'uploads'         => wp_is_writable( $data['wp_uploads']['basedir'] ),
			'fs'              => (bool) WP_Filesystem(),
		);

		if ( $status['suhosin'] ) {
			$data['suhosin_max_vars']                     = ini_get( 'suhosin.post.max_vars' );
			$data['suhosin_request_max_vars']             = ini_get( 'suhosin.request.max_vars' );
			$data['suhosin_max_value_length']             = ini_get( 'suhosin.post.max_value_length' );
			$data['suhosin_recommended_max_value_length'] = 2000000;

			$registered_navs  = get_nav_menu_locations();
			$menu_items_count = array(
				'0' => '0',
			);

			foreach ( $registered_navs as $registered_nav ) {
				$menu_obj = wp_get_nav_menu_object( $registered_nav );
				if ( $menu_obj ) {
					$menu_items_count[] = $menu_obj->count;
				}
			}

			$max_items                                   = max( $menu_items_count );
			$required_input_vars                         = $max_items * 12;
			$required_input_vars                         = $required_input_vars + 1500;
			$data['suhosin_required_input_vars']         = $required_input_vars;
			$data['suhosin_request_required_input_vars'] = $max_items + 1500;
		}

		$active_plugins = (array) get_option( 'active_plugins', array() );

		if ( $status['multisite'] ) {
			$active_plugins = array_merge( $active_plugins, array_keys( get_site_option( 'active_sitewide_plugins', array() ) ) );
		}

		$data['plugins'] = $active_plugins;


		$parse = array(
			'home'    => wp_parse_url( $data['home'] ),
			'siteurl' => wp_parse_url( $data['siteurl'] ),
		);

		if ( isset( $parse['home']['host'] ) && isset( $parse['siteurl']['host'] ) ) {
			if ( $parse['home']['host'] === $parse['siteurl']['host'] ) {
				$status['siteurl'] = true;
			}
		} elseif ( isset( $parse['home']['path'] ) && isset( $parse['siteurl']['path'] ) ) {
			if ( $parse['home']['path'] === $parse['siteurl']['path'] ) {
				$status['siteurl'] = true;
			}
		}

		$this->data   = apply_filters( 'anky_system_status_data', $data );
		$this->status = apply_filters( 'anky_system_status_status', $status );
	}

}
