<?php
/**
 * Anky theme Prebuild Demo websites admin page controller.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin\Pages;

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Interfaces\Interface_Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky theme Prebuild Demo websites admin page controller.
 */
class Anky_Websites implements Interface_Admin {

	/**
	 * Add admin page.
	 */
	public function add_page() {
		$title = __( 'Pre-built Websites', 'anky' );

		add_submenu_page(
			'anky',
			$title,
			$title,
			'edit_theme_options',
			'anky-websites',
			array( $this, 'render' )
		);
	}

	/**
	 * Enqueue styles and scripts.
	 */
	public function enqueue() {
		wp_enqueue_style( 'anky-theme-admin' );
		wp_enqueue_script( 'anky-theme-admin' );
		wp_localize_script(
			'anky-theme-admin',
			'Anky',
			array(
				'ajaxUrl'              => admin_url( 'admin-ajax.php' ),
				'ajaxNonce'            => wp_create_nonce( 'ocdi-ajax-verification' ),
				'assetsUrl'            => anky_get_asset(),
				'errorSvg'             => wp_kses(
					Anky_UI_Controller::get_svg(
						array(
							'icon'   => 'error',
							'class'  => array( 'anky-imported-content-imported', 'anky-imported-content-imported--error' ),
							'width'  => '100',
							'height' => '100',
						)
					),
					Anky_UI_Controller::allowed_svg_html()
				),
				'resetDb'              => sprintf(
				/* translators: 1 - Line break (must be omitted in translation), 2 - DB fields string */
					esc_html__( 'You are about to reset your database. %1$s Field like %2$s will be cleared. %1$s%1$s Proceed?', 'anky' ),
					"\n",
					'`posts`, `postmeta`, `comments`, `commentmeta`, `terms`, `termmeta`,`term_taxonomy`,`term_relationships`, `links'
				),
				'replaceGUIDs'         => esc_html__( 'You are about to replace GUIDs. Proceed?', 'anky' ),
				'importFailed'         => esc_html__( 'Import Failed', 'anky' ),
				'importFailedSubtitle' => esc_html__( 'Whoops, there was a problem importing your content.', 'anky' ),
				'errorTitle'           => esc_html__( 'Error', 'anky' ),
			)
		);
	}

	/**
	 * Support page template.
	 */
	public function render() {
		require_once ANKY_THEME_DIR . 'includes/admin/templates/websites.php';
	}

}
