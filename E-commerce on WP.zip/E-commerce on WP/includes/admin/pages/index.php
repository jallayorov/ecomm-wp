<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Admin/Pages
 */

/* Silence is golden, and we agree. */
