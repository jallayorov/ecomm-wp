<?php
/**
 * Anky theme Main dashboard admin page controller.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin\Pages;

use Anky\Includes\Interfaces\Interface_Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky theme Main dashboard admin page controller.
 */
class Anky_Dashboard implements Interface_Admin {

	/**
	 * Add admin page & enqueue styles
	 */
	public function add_page() {
		$title = array(
			'title'     => 'Anky',
			'dashboard' => __( 'Dashboard', 'anky' ),
		);
		$icon  = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5MCA5MCIgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIj48cGF0aCBmaWxsPSJibGFjayIgZD0iTTcwIDEuNlYyMUwyNS42IDEuNkgyLjF2ODYuN2gyMy41TDcwIDY5djE5LjRoMTcuOVYxLjZINzB6TTIwIDcxLjdWMTguM2w1MCAyNC4ydjUuM0wyMCA3MS43eiIvPjwvc3ZnPg0K';

		add_menu_page(
			$title['title'],
			$title['title'],
			'edit_theme_options',
			'anky',
			array( $this, 'render' ),
			$icon,
			3
		);

		add_submenu_page(
			'anky',
			$title['dashboard'],
			$title['dashboard'],
			'edit_theme_options',
			'anky',
			array( $this, 'render' )
		);
	}

	/**
	 * Dashboard template
	 */
	public function render() {
		include_once ANKY_THEME_DIR . 'includes/admin/templates/dashboard.php';
	}

	/**
	 * Enqueue styles and scripts
	 */
	public function enqueue() {
		wp_enqueue_style( 'anky-theme-admin' );
	}

}
