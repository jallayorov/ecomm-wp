<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Admin/Plugins
 */

/* Silence is golden, and we agree. */
