<?php
/**
 * Class responsible for TGMPA configuration and initialization.
 *
 * @package    Anky
 * @subpackage Admin/TGMPA
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin\Plugins;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * TGMPA configuration and initialization class.
 */
class Anky_TGMPA {

	/**
	 * Currency inactive or not installed plugins.
	 * If not empty may contain keys:
	 * - install - array of plugins to install
	 * - activate - array of plugins to activate
	 *
	 * @var array $inactive_plugins
	 * @access public
	 */
	public $inactive_plugins = array();

	/**
	 * Flag to know whether all recommend plugins are present and activated.
	 *
	 * @var bool $plugins_active
	 * @access public
	 */
	public $plugins_active = false;

	/**
	 * Array of all currently active plugins.
	 *
	 * @var array $active_plugins
	 * @access public
	 */
	public $active_plugins = array();

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! $this->has_tgmpa() ) {
			require_once 'class-tgm-plugin-activation.php';
		}

		$this->plugins_active = $this->is_all_plugins_active();
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Array of plugin arrays. Required keys are name and slug.
	 *
	 * @return array TGMPA plugins array
	 */
	public static function get_plugins_list() {
		return array(
			array(
				'name'     => 'Anky Extensions',
				'slug'     => 'anky-extensions',
				'required' => false,
				'source'   => ANKY_THEME_DIR . 'plugins/anky-extensions.zip',
			),
			array(
				'name'     => 'One Click Demo Import',
				'slug'     => 'one-click-demo-import',
				'required' => false,
			),
			array(
				'name'              => 'Contact Form 7',
				'slug'              => 'contact-form-7',
				'required'          => false,
				'plugin_start_name' => 'wp-contact-form-7',
			),
			array(
				'name'     => 'Elementor',
				'slug'     => 'elementor',
				'version'  => '3.3.1',
				'required' => false,
			),
		);
	}

	/**
	 * Define all active plugins.
	 */
	public function set_active_plugins() {
		$this->active_plugins = get_option( 'active_plugins', array() );
	}

	/**
	 * Render button for handling inactive plugins.
	 */
	public function plugins_installer_button() {
		$data_to_send = array(
			'action'  => 'anky_plugins',
			'wpnonce' => wp_create_nonce( 'anky_install_plugins' ),
		);
		$strings      = array(
			'name'       => '',
			'processing' => '',
		);
		$relocate     = admin_url( 'themes.php?page=anky_welcome' );

		if ( ! empty( $this->inactive_plugins['install'] ) ) {
			$data_to_send['type']    = 'install';
			$data_to_send['plugins'] = array_map( array( $this, 'get_slug' ), $this->inactive_plugins['install'] );
			$strings['name']         = __( 'Install', 'anky' );
			$strings['processing']   = __( 'Installing ...', 'anky' );
		} elseif ( ! empty( $this->inactive_plugins['activate'] ) ) {
			$data_to_send['type']    = 'activate';
			$data_to_send['plugins'] = array_map( array( $this, 'get_slug' ), $this->inactive_plugins['activate'] );
			$strings['name']         = __( 'Activate', 'anky' );
			$strings['processing']   = __( 'Activating ...', 'anky' );
			$relocate                = admin_url( 'admin.php?page=anky' );
		}

		printf(
			'<a class="anky-about-link anky-plugins-installer-link button anky-admin-btn-1" href="%1$s" data-ajax="%2$s" data-name="%3$s" data-processing="%4$s" data-location="%5$s">%3$s</a>',
			esc_url( admin_url( 'admin-ajax.php' ) ),
			esc_attr( wp_json_encode( $data_to_send ) ),
			esc_html( $strings['name'] ),
			esc_attr( $strings['processing'] ),
			esc_url( $relocate )
		);

		// The skip button.
		$data_to_send['type']  = 'skip';
		$strings['name']       = __( 'Skip part', 'anky' );
		$strings['processing'] = __( 'Skipping...', 'anky' );
		$relocate              = admin_url( 'admin.php?page=anky' ); // ensure correct relocation.
		printf(
			'<a class="anky-about-link anky-plugins-installer-link button anky-admin-btn-1" href="%1$s" data-ajax="%2$s" data-name="%3$s" data-processing="%4$s" data-location="%5$s">%3$s</a>',
			esc_url( admin_url( 'admin-ajax.php' ) ),
			esc_attr( wp_json_encode( $data_to_send ) ),
			esc_html( $strings['name'] ),
			esc_attr( $strings['processing'] ),
			esc_url( $relocate )
		);
	}

	/**
	 * Welcome page notice that describes list of plugins to install/activate.
	 */
	public function install_plugins_notice() {
		$text         = '';
		$plugins_list = array();

		if ( ! empty( $this->inactive_plugins['install'] ) ) {
			$plugins_list = array_map( array( $this, 'get_name' ), $this->inactive_plugins['install'] );
			$text         = __( 'Clicking the <b>Install</b> button, the following plugins will be installed', 'anky' );
		} elseif ( ! empty( $this->inactive_plugins['activate'] ) ) {
			$plugins_list = array_map( array( $this, 'get_name' ), $this->inactive_plugins['activate'] );
			$text         = __( 'Clicking the <b>Activate</b> button, the following plugins will be activated', 'anky' );
		}

		if ( ! empty( $plugins_list ) ) {
			$list = '<b>' . implode( '</b>, <b>', $plugins_list ) . '</b>';
			echo wp_kses_post( sprintf( '<p>%s: %s.</p>', $text, $list ) );
		}
	}

	/**
	 * Check for all recommended plugin are set.
	 *
	 * @return bool
	 */
	public function is_all_plugins_active() {
		$plugins = self::get_plugins_list();
		if ( empty( $this->active_plugins ) ) {
			$this->active_plugins = get_option( 'active_plugins' );
		}

		foreach ( $plugins as $item ) {
			$this->inactive_plugins[ $this->check_plugin_state( $item['slug'] . '/' . ( $item['plugin_start_name'] ?? $item['slug'] ) . '.php' ) ][] = $item;
		}

		$active_plugins  = ( isset( $this->inactive_plugins['activate'] ) && is_array( $this->inactive_plugins['activate'] ) ) ? count( $this->inactive_plugins['activate'] ) : 0;
		$install_plugins = ( isset( $this->inactive_plugins['install'] ) && is_array( $this->inactive_plugins['install'] ) ) ? count( $this->inactive_plugins['install'] ) : 0;

		// There is no active plugins now.
		if ( empty( $this->active_plugins ) ) {
			return false;
		}

		return ! ( $active_plugins > 0 || $install_plugins > 0 );
	}

	/**
	 * Register TGMPA.
	 */
	public function register_tgmpa() {
		tgmpa( self::get_plugins_list(), $this->get_plugins_config() );
	}

	/**
	 * Handle Ajax requests for managing plugins.
	 * Retrieve Ajax requests for Installing and Activating recommend plugins.
	 */
	public function ajax_plugins_handler() {
		if ( ! check_ajax_referer( 'anky_install_plugins', 'wpnonce' ) || empty( $_POST['type'] ) ) {
			exit();
		}

		$json      = array();
		$tgmpa_url = admin_url( 'themes.php?page=anky-plugins' );

		if ( 'skip' === $_POST['type'] ) {
			$json = array(
				'skip'    => 1,
				'message' => esc_html__( 'Step skipped. You can still manage plugins via "Install Plugins" page. You will now be redirected to Theme Dashboard.', 'anky' ),
			);
			anky_set_option( 'first-time-install', false );
		} elseif ( 'install' === $_POST['type'] ) {
			$json = array(
				'url'           => $tgmpa_url,
				'plugin'        => anky_get_gp_value( 'plugins' ),
				'tgmpa-page'    => 'anky-plugins',
				'plugin_status' => 'all',
				'_wpnonce'      => wp_create_nonce( 'bulk-plugins' ),
				'action'        => 'tgmpa-bulk-install',
				'action2'       => - 1,
				'message'       => esc_html__( 'Plugins are installing. This should not take much time.', 'anky' ),
			);
		} elseif ( 'activate' === $_POST['type'] ) {
			$json = array(
				'url'           => $tgmpa_url,
				'plugin'        => anky_get_gp_value( 'plugins' ),
				'tgmpa-page'    => 'anky-plugins',
				'plugin_status' => 'all',
				'_wpnonce'      => wp_create_nonce( 'bulk-plugins' ),
				'action'        => 'tgmpa-bulk-activate',
				'action2'       => - 1,
				'message'       => esc_html__( 'Activating plugins. This should not take much time.', 'anky' ),
			);
			anky_set_option( 'first-time-install', false );
		}

		if ( $json ) {
			wp_send_json( $json );
		} else {
			wp_send_json(
				array(
					'done'    => 1,
					'message' => esc_html__( 'Success', 'anky' ),
				)
			);
		}

		exit;
	}

	/**
	 * Remove TGMPA notices on particular page.
	 *
	 * @param string $cap Current capabilities.
	 *
	 * @return string
	 */
	public function disable_notice( $cap ) {
		if ( 'anky_welcome' === anky_get_gp_value( 'page' ) ) {
			$cap = 'unfiltered_upload';
		}

		return $cap;
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Check plugin state.
	 * States are following:
	 * - install - Plugin is not installed in system
	 * - activate - Plugin is installed but not activated
	 * - activated - Plugin is installed and activated
	 *
	 * @param string $plugin_path Required. Plugin path.
	 *
	 * @return string
	 */
	private function check_plugin_state( $plugin_path ) {
		$state = 'install';
		if ( file_exists( WP_PLUGIN_DIR . '/' . $plugin_path ) ) {
			$state = in_array( $plugin_path, $this->active_plugins, true ) ? 'activated' : 'activate';
		}

		return $state;
	}

	/**
	 * Check whether a TGMPA plugin is present and active.
	 *
	 * @return boolean
	 */
	private function has_tgmpa() {
		return class_exists( 'TGM_Plugin_Activation' ) && function_exists( 'tgmpa' );
	}

	/**
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * @return array TGMPA config array
	 */
	private function get_plugins_config() {
		return array(
			'id'           => 'anky-tgmpa-plugins',                                             // Unique ID for hashing notices for multiple instances of TGMPA.
			'menu'         => 'anky-plugins',                                                   // Menu slug.
			'parent_slug'  => 'anky',                                                           // Parent menu slug.
			'has_notices'  => true,                                                                 // Show admin notices or not.
			'dismissable'  => true,                                                                 // If false, a user cannot dismiss the nag message.
			'is_automatic' => false,                                                                // Automatically activate plugins after installation or not.
			'message'      => '<div class="notice notice-warning is-dismissible"><p>'            // Message to output right before the plugins table.
							  . sprintf(
							  /*translators: %s Link to WordPress Codex page */
								  __( '<strong>Important:</strong> before updating, please <a href="%s">back up your database and files</a>.', 'anky' ),
								  esc_url( '//codex.wordpress.org/WordPress_Backups' )
							  )
							  . '</p></div><div class="notice notice-info is-dismissible"><p>'
							  . __( '<strong>Server limits:</strong> if you are not sure about server`s settings and limits, please activate necessary plugins only.', 'anky' ) . '</p></div>',
			'strings'      => array(
				array(
					'page_title'                      => __( 'Install Required Plugins', 'anky' ),
					'menu_title'                      => __( 'Install Plugins', 'anky' ),
					/* translators: %s: plugin name. */
					'installing'                      => __( 'Installing Plugin: %s', 'anky' ),
					/* translators: %s: plugin name. */
					'updating'                        => __( 'Updating Plugin: %s', 'anky' ),
					'oops'                            => __( 'Something went wrong with the plugin API.', 'anky' ),
					/* translators: 1: plugin name(s). */
					'notice_can_install_required'     => _n_noop(
						'This theme requires the following plugin: %1$s.',
						'This theme requires the following plugins: %1$s.',
						'anky'
					),
					/* translators: 1: plugin name(s). */
					'notice_can_install_recommended'  => _n_noop(
						'This theme recommends the following plugin: %1$s.',
						'This theme recommends the following plugins: %1$s.',
						'anky'
					),
					/* translators: 1: plugin name(s). */
					'notice_ask_to_update'            => _n_noop(
						'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.',
						'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.',
						'anky'
					),
					/* translators: 1: plugin name(s). */
					'notice_ask_to_update_maybe'      => _n_noop(
						'There is an update available for: %1$s.',
						'There are updates available for the following plugins: %1$s.',
						'anky'
					),
					/* translators: 1: plugin name(s). */
					'notice_can_activate_required'    => _n_noop(
						'The following required plugin is currently inactive: %1$s.',
						'The following required plugins are currently inactive: %1$s.',
						'anky'
					),
					/* translators: 1: plugin name(s). */
					'notice_can_activate_recommended' => _n_noop(
						'The following recommended plugin is currently inactive: %1$s.',
						'The following recommended plugins are currently inactive: %1$s.',
						'anky'
					),
					'install_link'                    => _n_noop(
						'Begin installing plugin',
						'Begin installing plugins',
						'anky'
					),
					'update_link'                     => _n_noop(
						'Begin updating plugin',
						'Begin updating plugins',
						'anky'
					),
					'activate_link'                   => _n_noop(
						'Begin activating plugin',
						'Begin activating plugins',
						'anky'
					),
					'return'                          => __( 'Return to Required Plugins Installer', 'anky' ),
					'plugin_activated'                => __( 'Plugin activated successfully.', 'anky' ),
					'activated_successfully'          => __( 'The following plugin was activated successfully:', 'anky' ),
					/* translators: 1: plugin name. */
					'plugin_already_active'           => __( 'No action taken. Plugin %1$s was already active.', 'anky' ),
					/* translators: 1: plugin name. */
					'plugin_needs_higher_version'     => __( 'Plugin not activated. A higher version of %s is needed for this theme. Please update the plugin.', 'anky' ),
					/* translators: 1: dashboard link. */
					'complete'                        => __( 'All plugins installed and activated successfully. %1$s', 'anky' ),
					'dismiss'                         => __( 'Dismiss this notice', 'anky' ),
					'notice_cannot_install_activate'  => __( 'There are one or more required or recommended plugins to install, update or activate.', 'anky' ),
					'contact_admin'                   => __( 'Please contact the administrator of this site for help.', 'anky' ),
				),
			),
		);
	}

	/**
	 * Get plugin slug from array if it exists.
	 *
	 * @used in array_map
	 *
	 * @param mixed $item Value passed from array_map.
	 *
	 * @return string
	 */
	private function get_slug( $item ) {
		return $item['slug'] ?? '';
	}

	/**
	 * Get plugin name from array if it exists.
	 *
	 * @used in array_map
	 *
	 * @param mixed $item Value passed from array_map.
	 *
	 * @return string
	 */
	private function get_name( $item ) {
		return $item['name'] ?? '';
	}

}
