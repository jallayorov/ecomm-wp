<?php
/**
 * Anky Admin controller.
 *
 * @package    Anky
 * @subpackage Admin
 * @author     Anky (Andrew Black)
 */

namespace Anky\Includes\Admin;

use Anky\Includes\Admin\Pages\Anky_Admin_Options;
use Anky\Includes\Admin\Pages\Anky_Dashboard;
use Anky\Includes\Admin\Pages\Anky_Support;
use Anky\Includes\Admin\Pages\Anky_System_Status;
use Anky\Includes\Admin\Pages\Anky_Websites;
use Anky\Includes\Admin\Pages\Anky_Welcome;
use Anky\Includes\Admin\Plugins\Anky_TGMPA;
use Anky\Includes\Core\Anky_Assistent;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Anky Admin Dashboard controller.
 */
class Anky_Admin extends Anky_Assistent {

	/**
	 * TGMPA Registration instance.
	 *
	 * @var Anky_TGMPA
	 * @access private
	 */
	private $tgmpa;

	/**
	 * System status instance.
	 *
	 * @var Anky_System_Status
	 * @access private
	 */
	private $status_page;

	/**
	 * Theme support instance.
	 *
	 * @var Anky_Websites
	 * @access private
	 */
	private $websites_page;

	/**
	 * Theme support instance.
	 *
	 * @var Anky_Support
	 * @access private
	 */
	private $support_page;

	/**
	 * Admin options page instance.
	 *
	 * @var Anky_Admin_Options
	 * @access private
	 */
	private $options_page;

	/**
	 * Main Dashboard page instance.
	 *
	 * @var Anky_Dashboard
	 * @access private
	 */
	private $dashboard_page;

	/**
	 * Theme Welcome page instance.
	 *
	 * @var Anky_Welcome
	 * @access private
	 */
	private $welcome_page;

	/**
	 * Demo importer instance.
	 *
	 * @var Anky_Demo_Importer
	 * @access private
	 */
	private $demo_importer;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->setup_hooks();
	}

	// ======================================================
	// PUBLIC
	// ======================================================

	/**
	 * Registering assets that would be required by admin pages.
	 */
	public function register_admin_assets() {
		wp_register_style( 'anky-theme-admin', anky_get_asset( 'css/admin' . ( ANKY_DEV_MODE ? '.css' : '.min.css' ) ), array(), ANKY_THEME_VERSION );
		wp_register_script( 'anky-theme-admin', anky_get_asset( 'js/admin' . ( ANKY_DEV_MODE ? '.js' : '.min.js' ) ), array( 'jquery' ), ANKY_THEME_VERSION, true );

		$loading_method = anky_get_option( 'globals-assets-loading-mode', 'cdn' );
		$assets         = array(
			'local' => array(
				'tiptip_css' => anky_get_asset( 'css/vendors/tiptip.min.css' ),
				'tiptip_js'  => anky_get_asset( 'js/tiptip.jquery.min.js' ),
			),
			'cdn'   => array(
				'tiptip_css' => '//cdnjs.cloudflare.com/ajax/libs/jquery.tiptip/1.3/tipTip.min.css',
				'tiptip_js'  => '//cdnjs.cloudflare.com/ajax/libs/jquery.tiptip/1.3/jquery.tipTip.minified.js',
			),
		);
		wp_register_style( 'tiptip', $assets[ $loading_method ]['tiptip_css'], array(), '1.3' );
		wp_register_script( 'tiptip', $assets[ $loading_method ]['tiptip_js'], array( 'jquery' ), '1.3', true );
	}

	/**
	 * Redirect after switch theme
	 */
	public function after_switch_theme() {
		$redirect_url = anky_get_option( 'first-time-install' ) && ! $this->tgmpa->plugins_active ? 'themes.php?page=anky_welcome' : 'admin.php?page=anky';

		wp_safe_redirect( admin_url( $redirect_url ) );
	}

	/**
	 * Admin notice.
	 * Set notice if theme is not registered.
	 *
	 * @return bool
	 */
	public function notices() {
		// Current screen is not always available, most notably on the customizer screen.
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}

		$current_screen = get_current_screen();

		$whitelist = array(
			'toplevel_page_anky',
			'appearance_page_anky_welcome',
		);

		if ( in_array( $current_screen->base, $whitelist, true ) ) {
			return false;
		}

		// First time plugins activation.
		if ( ! ( $this->tgmpa->plugins_active && anky_get_option( 'first-time-install' ) ) )  :
			$plugins_url = admin_url( 'themes.php?page=anky_welcome' );
			?>
			<div class="notice notice-info is-dismissible">
				<div class="anky-notice-wrapper">
					<div class="anky-notice-logo">
						<?php
						anky_the_svg(
							array(
								'icon'   => 'theme_logo',
								'width'  => 60,
								'height' => 60,
							)
						);
						?>
					</div>
					<div>
						<p><?php esc_html_e( 'Anky is premium theme with many options available. We provide support for plugins and various theme options.', 'anky' ); ?></p>
						<p>
							<?php
							printf(
								wp_kses_data(
								/* translators: %s link to themeforest licensing standards */
									__(
										'<strong>Important!</strong> We found that some recommended plugins were not installed or activated. To provide you with full spectre of convenient usage, please <a href="%s">install and activate</a> recommended plugins.',
										'anky'
									)
								),
								esc_url( $plugins_url )
							);
							?>
						</p>
						<p>
							<a href="<?php echo esc_url( $plugins_url ); ?>" class="button button-primary">
								<span><?php esc_html_e( 'Install and activate', 'anky' ); ?></span>
								<span class="dashicons dashicons-plugins-checked" aria-hidden="true"></span>
							</a>
						</p>
					</div>
				</div>
			</div>
		<?php
		endif;

		return false;
	}

	/**
	 * Render all admin page headers.
	 */
	public function page_header() {
		require_once ANKY_THEME_DIR . 'includes/admin/templates/parts/header.php';
	}

	// ======================================================
	// PRIVATE
	// ======================================================

	/**
	 * Load required dependencies.
	 */
	private function load_dependencies() {
		$this->tgmpa          = new Anky_TGMPA();
		$this->status_page    = Anky_System_Status::get_instance();
		$this->welcome_page   = new Anky_Welcome();
		$this->dashboard_page = new Anky_Dashboard();
		$this->support_page   = new Anky_Support();
		$this->websites_page  = new Anky_Websites();
		$this->options_page   = new Anky_Admin_Options();
		$this->demo_importer  = new Anky_Demo_Importer();
	}

	/**
	 * Setup the main theme hooks.
	 */
	private function setup_hooks() {
		// Admin features.
		$this->add_action( 'after_switch_theme', $this, 'after_switch_theme' );
		$this->add_action( 'admin_notices', $this, 'notices', 1 );

		$this->add_action( 'anky_admin_header', $this, 'page_header' );

		// TGMPA.
		$this->add_action( 'admin_init', $this->tgmpa, 'set_active_plugins' );
		$this->add_action( 'tgmpa_register', $this->tgmpa, 'register_tgmpa' );
		$this->add_action( 'wp_ajax_anky_plugins', $this->tgmpa, 'ajax_plugins_handler', 10, 0 );
		$this->add_filter( 'tgmpa_show_admin_notice_capability', $this->tgmpa, 'disable_notice' );
		$this->add_filter( 'anky_plugins_button', $this->tgmpa, 'plugins_installer_button' );
		$this->add_filter( 'anky_welcome_notes', $this->tgmpa, 'install_plugins_notice' );

		$this->add_action( 'admin_enqueue_scripts', $this, 'register_admin_assets', 9 );

		// Only add page we now need and prevent trying to add another.
		if ( ! ( $this->tgmpa->plugins_active && anky_get_option( 'first-time-install' ) ) ) {
			$this->add_action( 'admin_menu', $this->welcome_page, 'add_page' );
			$this->add_action( 'admin_enqueue_scripts', $this->welcome_page, 'enqueue' );
			$this->add_filter( 'anky_welcome_notes', $this->welcome_page, 'instruction_notices', 11 );

			return;
		}

		// Admin pages.
		$this->add_action( 'admin_menu', $this->dashboard_page, 'add_page' );
		$this->add_action( 'admin_menu', $this->status_page, 'add_page', 11 );
		$this->add_action( 'admin_menu', $this->websites_page, 'add_page', 12 );
		$this->add_action( 'admin_menu', $this->support_page, 'add_page', 13 );
		$this->add_action( 'admin_menu', $this->options_page, 'add_page', 14 );

		$this->add_action( 'admin_enqueue_scripts', $this->dashboard_page, 'enqueue' );
		$this->add_action( 'admin_enqueue_scripts', $this->status_page, 'enqueue' );
		$this->add_action( 'admin_enqueue_scripts', $this->websites_page, 'enqueue' );
		$this->add_action( 'admin_enqueue_scripts', $this->support_page, 'enqueue' );
		$this->add_action( 'admin_enqueue_scripts', $this->options_page, 'enqueue' );

		// Demo importer.
		$this->add_filter( 'ocdi/import_files', $this->demo_importer, 'demo_data' );
		$this->add_filter( 'ocdi/before_content_import', $this->demo_importer, 'before_content_import' );
		$this->add_action( 'ocdi/after_import', $this->demo_importer, 'after_import_setup' );
		$this->add_action( 'pt-ocdi/importer_options', $this->demo_importer, 'update_attachment_guids', 11 );
		$this->add_filter( 'pt-ocdi/regenerate_thumbnails_in_content_import', $this->demo_importer, 'regenerate_thumbnails_in_content_import' );
		$this->add_action( 'wp_ajax_anky_db_reset', $this->demo_importer, 'db_reset' );
		$this->add_action( 'wp_ajax_anky_replace_guids', $this->demo_importer, 'replace_guids' );
	}

}
