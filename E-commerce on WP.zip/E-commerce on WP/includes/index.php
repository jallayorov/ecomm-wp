<?php
/**
 * Index file
 *
 * @package Anky
 */

/* Silence is golden, and we agree. */
