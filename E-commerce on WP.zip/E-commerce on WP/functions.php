<?php
/**
 * Anky functions and definitions.
 * This file is a bootstrap file for the theme.
 *
 * @link    https://developer.wordpress.org/themes/basics/theme-functions/
 * @author  Anky (Andrew Black)
 * @package Anky
 * @since   1.0.0
 */

namespace Anky;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

/**
 * Theme Constants.
 */
define( 'ANKY_THEME_VERSION', '1.0.0' );
define( 'ANKY_THEME_DIR', trailingslashit( wp_normalize_path( get_template_directory() ) ) );
define( 'ANKY_THEME_URI', trailingslashit( get_template_directory_uri() ) );

if ( ! defined( 'ANKY_DEV_MODE' ) ) {
	define( 'ANKY_DEV_MODE', defined( 'WP_DEBUG' ) && WP_DEBUG );
}

require_once ANKY_THEME_DIR . 'includes/bootstrap.php';
