<?php
/**
 * Template part for displaying results in search pages
 *
 * @link       https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package    Anky
 * @subpackage Template_Parts
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'anky-content-container' ); ?>>
	<header class="entry-header">
		<?php anky_entry_header(); ?>
	</header><!-- .entry-header -->

	<div class="entry-summary">
		<?php anky_the_excerpt(); ?>
	</div><!-- .entry-summary -->

	<footer class="entry-footer">
		<?php anky_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
