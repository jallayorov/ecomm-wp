<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Template_Parts
 */

/* Silence is golden, and we agree. */
