<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link       https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package    Anky
 * @subpackage Template_Parts
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<section class="no-results not-found">
	<div class="page-content">
		<?php
		anky_the_svg(
			array(
				'icon'   => 'not_found',
				'width'  => 250,
				'height' => 165,
				'class'  => array( 'anky-page-thumbnail' ),
			)
		);

		if ( is_home() && current_user_can( 'publish_posts' ) ) :

			printf(
				'<p class="anky-content-title">' . wp_kses(
				/* translators: %s: link to WP admin new post page. */
					__( 'Ready to publish your first post? <a href="%s">Get started here</a>.', 'anky' ),
					array(
						'a' => array(
							'href' => array(),
						),
					)
				) . '</p>',
				esc_url( admin_url( 'post-new.php' ) )
			);

		elseif ( is_search() ) :
			?>

			<p class="anky-content-title">
				<?php
				echo wp_kses(
					sprintf(
					/* translators: %s: search query. */
						__( 'We couldn&rsquo;t find %s', 'anky' ),
						'<span class="anky-text-muted">&quot;' . get_search_query() . '&quot;</span>'
					),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				);
				?>
			</p>

		<?php else : ?>
			<p class="anky-content-title"><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for', 'anky' ); ?></p>
			<p class="anky-text-muted"><?php esc_html_e( 'Try searching again using different spelling or keyword', 'anky' ); ?></p>
			<button
				<?php
				anky_the_atts(
					array(
						'class'       => array( 'anky-clean-btn', 'anky-js-trigger-search-modal', 'anky-search-btn', 'anky-btn', 'anky-btn-dark' ),
						'type'        => 'button',
						'aria-label'  => __( 'Toggle search modal', 'anky' ),
						'data-toggle' => 'modal',
						'data-target' => '#search-modal-wrap',
					)
				);
				?>
			><?php esc_html_e( 'Search Again', 'anky' ); ?></button>
			<?php
			// In case Header search widget is disabled.
			if ( ! anky_get_option( 'header-widget-search' ) ) {
				anky_render_search_form();
			}
		endif;
		?>
	</div><!-- .page-content -->
</section><!-- .no-results -->
