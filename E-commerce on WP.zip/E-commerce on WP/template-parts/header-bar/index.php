<?php
/**
 * Index file
 *
 * @package    Anky
 * @subpackage Template_Parts/Header_Bar
 */

/* Silence is golden, and we agree. */
