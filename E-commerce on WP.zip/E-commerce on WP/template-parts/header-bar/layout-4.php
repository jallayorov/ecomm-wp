<?php
/**
 * Header upper bar layout 4 template.
 *
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @package    Anky
 * @subpackage Template_Parts/Header_Bar
 * @author     Anky (Andrew Black)
 */

use Anky\Includes\Builder\Navigation\Anky_Menu_Navigation_Builder;
use Anky\Includes\Customizer\Anky_Sanitizer;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>

<div class="anky-col-3">
	<ul class="anky-link-list anky-list-unstyled">
		<?php if ( ! empty( $args['address'] ) ) : ?>
			<li class="anky-link-list-item-wrap">
				<span class="anky-link-list-item-text"><?php echo esc_html( $args['address'] ); ?></span>
			</li>
		<?php endif; ?>
		<?php if ( ! empty( $args['phone'] ) ) : ?>
			<li class="anky-link-list-item-wrap">
				<a href="tel:<?php echo esc_attr( Anky_Sanitizer::sanitize_phone_number( $args['phone'] ) ); ?>"
					class="anky-link-list-item anky-link-list-item-phone">
					<?php echo esc_html( $args['phone'] ); ?>
				</a>
			</li>
		<?php endif; ?>
	</ul>
</div>
<div class="anky-col-3">
	<?php echo Anky_Menu_Navigation_Builder::get_instance()->get_header_bar_menu(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
</div>
