<?php
/**
 * Header upper bar layout 1 template.
 *
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @package    Anky
 * @subpackage Template_Parts/Header_Bar
 * @author     Anky (Andrew Black)
 */

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Customizer\Anky_Sanitizer;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>

<div class="anky-col">
	<ul class="anky-link-list anky-list-unstyled">
		<?php if ( ! empty( $args['address'] ) ) : ?>
			<li class="anky-link-list-item-wrap">
				<span class="anky-link-list-item-text"><?php echo esc_html( $args['address'] ); ?></span>
			</li>
		<?php endif; ?>
		<?php if ( ! empty( $args['phone'] ) ) : ?>
			<li class="anky-link-list-item-wrap">
				<a href="tel:<?php echo esc_attr( Anky_Sanitizer::sanitize_phone_number( $args['phone'] ) ); ?>"
					class="anky-link-list-item anky-link-list-item-phone">
					<?php echo esc_html( $args['phone'] ); ?>
				</a>
			</li>
		<?php endif; ?>
		<?php
		foreach ( $args['socials'] as $item ) :
			if ( empty( $item ) ) {
				continue;
			}
			?>
			<li class="anky-link-list-item-wrap">
				<a href="<?php echo esc_url( $item ); ?>"
					class="anky-link-list-item anky-link-list-item-social-network"
					rel="noindex nofollow"
					target="_blank">
					<?php Anky_UI_Controller::render_social_link_icon( $item ); ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
