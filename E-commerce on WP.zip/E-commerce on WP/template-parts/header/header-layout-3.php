<?php
/**
 * Template part for Header.
 * This template is template for Header layout 3.
 * This template displays all the <header> section and everything up until <div id="content">
 *
 * @see         https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @package     Anky
 * @subpackage  Template_Parts/Header
 * @author      Anky (Andrew Black)
 */

use Anky\Includes\Builder\Anky_UI_Controller;
use Anky\Includes\Customizer\Anky_Sanitizer;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>

<header <?php anky_the_atts( $args['header'] ); ?>>
	<div class="anky-header-inner-wrapper">
		<div class="anky-container">
			<div class="anky-row">
				<?php
				echo anky_get_prop( $args, 'widget_search', '' ); // phpcs:ignore WordPress.Security.EscapeOutput
				echo anky_get_prop( $args, 'site_identity', '' ); // phpcs:ignore WordPress.Security.EscapeOutput
				?>
				<div class="anky-header-widgets">
					<?php echo anky_get_prop( $args, 'widgets', '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
				<div class="anky-menu-wrapper">
					<div class="anky-inner-row">
						<?php echo anky_get_prop( $args, 'menu', '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<div class="anky-col-3 anky-contact-block-wrap">
							<div class="anky-contact-block">
								<?php
								if ( ! empty( $args['address_embed']['src'] ) ) {
									echo '<iframe ';
									anky_the_atts( $args['address_embed'] );
									echo '></iframe>';
								}
								if ( ! empty( $args['address'] ) ) {
									printf( '<span class="anky-contact-block-item anky-contact-block-item-address">%s</span>', esc_html( $args['address'] ) );
								}
								if ( ! empty( $args['email'] ) ) {
									printf(
										'<a href="%1$s" class="anky-contact-block-item anky-contact-block-item-email">%2$s</a>',
										esc_attr( 'mailto:' . $args['email'] ),
										esc_html( $args['email'] )
									);
								}
								if ( ! empty( $args['phone'] ) ) {
									printf(
										'<a href="%1$s" class="anky-contact-block-item anky-contact-block-item-phone">%2$s</a>',
										esc_attr( Anky_Sanitizer::sanitize_phone_number( $args['phone'] ) ),
										esc_html( $args['phone'] )
									);
								}
								?>
							</div>
						</div>
					</div>
					<div class="anky-inner-row anky-dropdown-bot">
						<div class="anky-col-3">
							<?php if ( ! empty( $args['socials'][0] ) ) : ?>
								<ul class="anky-link-list anky-list-unstyled anky-social-network-list">
									<?php
									foreach ( $args['socials'] as $item ) :
										if ( empty( $item ) ) {
											continue;
										}
										?>
										<li class="anky-link-list-item-wrap">
											<a href="<?php echo esc_url( $item ); ?>"
												class="anky-link-list-item anky-link-list-item-social-network"
												rel="external noindex nofollow noopener noreferrer"
												target="_blank">
												<?php Anky_UI_Controller::render_social_link_icon( $item ); ?>
											</a>
										</li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
						</div>
						<div class="anky-col-3">
							<?php anky_language_section(); ?>
						</div>
					</div><!-- .anky-inner-row-->
				</div>
			</div><!-- .anky-row-->
		</div><!-- .anky-container-->
	</div><!-- .anky-header-inner-wrapper-->
</header>
