<?php
/**
 * Template part for displaying related posts slider.
 *
 * @package    Anky
 * @subpackage Template_Parts
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'anky-related-post' ); ?>>
	<header class="entry-header">
		<?php anky_related_posts_entry_header(); ?>
	</header><!-- .entry-header -->
	<?php anky_post_thumbnail(); ?>
</article><!-- #post-<?php the_ID(); ?> -->
