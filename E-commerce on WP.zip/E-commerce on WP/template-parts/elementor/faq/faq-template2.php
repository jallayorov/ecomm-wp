<?php
/**
 * Template part for Elementor FAQ widget #2.
 *
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @package    Anky
 * @subpackage Template_Parts/Elementor
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>

<div class="anky-faq-accordion-item" id="anky-faq-accordion-item-<?php echo esc_attr( $args['id'] ); ?>">
	<div class="anky-faq-accordion-item-title">
		<h4 class="anky-faq-question-title"><?php echo esc_html( $args['title'] ); ?></h4>
		<div class="anky-faq-accordion-icon">
			<div class="anky-faq-accordion-icons anky-faq-accordion-open-icon">
				<span class="anky-icon-plus" aria-hidden="true"></span>
			</div>
		</div>
	</div>
	<div class="anky-faq-accordion-content">
		<?php echo wp_kses_post( $args['content'] ); ?>
	</div>
</div>
