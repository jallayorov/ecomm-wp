<?php
/**
 * Template part for Elementor Portfolio widget #3.
 *
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @package    Anky
 * @subpackage Template_Parts/Elementor
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>

<div class="anky-portfolio-section-item <?php echo esc_attr( implode( ' ', $args['wrapper_classes'] ) ); ?>">
	<?php
	if ( has_post_thumbnail() ) {
		anky_post_thumbnail( true );
	} elseif ( ! empty( $args['placeholder_url'] ) ) {
		printf(
			'<a class="post-thumbnail" href="%s" aria-hidden="true" tabindex="-1"><img src="%s" alt="%s" loading="lazy"></a>',
			esc_url( get_permalink() ),
			esc_url( $args['placeholder_url'] ),
			esc_attr__( 'Post with no image', 'anky' )
		);
	}
	?>
	<div class="anky-portfolio-item-info">
		<?php
		the_title( '<h2 class="anky-portfolio-item-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' );
		if ( ! empty( $args['term_links'] ) ) :
			?>
			<div class="anky-portfolio-item-cats">
				<?php echo wp_kses_post( rtrim( $args['term_links'], ', ' ) ); ?>
			</div>
		<?php endif; ?>
	</div>
</div>
