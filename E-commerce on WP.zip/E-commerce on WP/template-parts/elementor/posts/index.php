<?php
/**
 * Index file
 *
 * @package     Anky
 * @subpackage  Template_Parts/Elementor
 */

/* Silence is golden, and we agree. */
