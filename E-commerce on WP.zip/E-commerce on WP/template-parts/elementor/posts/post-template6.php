<?php
/**
 * Template part for Elementor Posts widget #6.
 *
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @see         https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package     Anky
 * @subpackage  Template_Parts/Elementor
 * @author      Anky (Andrew Black)
 */

use Anky\Includes\Builder\Blog\Anky_Blog_Builder;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'anky-posts-item' ); ?>>
	<?php
	if ( has_post_thumbnail() ) {
		anky_post_thumbnail( true );
	} elseif ( ! empty( $args['placeholder_url'] ) ) {
		printf(
			'<a class="post-thumbnail" href="%s" aria-hidden="true" tabindex="-1"><img src="%s" alt="%s" loading="lazy"></a>',
			esc_url( get_permalink() ),
			esc_url( $args['placeholder_url'] ),
			esc_attr__( 'Post with no image', 'anky' )
		);
	}
	?>
	<div class="anky-post-text-wrapper">
		<?php
		Anky_Blog_Builder::get_instance()->entry_custom_title();
		Anky_Blog_Builder::get_instance()->entry_meta_template();
		?>
	</div>
</article>
