<?php
/**
 * Template part for Elementor Partners widget #1.
 *
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @package    Anky
 * @subpackage Template_Parts/Elementor
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>

<div class="anky-col-<?php echo esc_attr( $args['col'] ); ?>">
	<?php
	if ( empty( $args['link'] ) ) {
		echo wp_kses_post( $args['logo'] );
	} else {
		echo wp_kses_post( sprintf( '<a %s>%s</a>', $args['link'], $args['logo'] ) );
	}
	?>
</div>
