<?php
/**
 * Template part for Elementor Partners widget #2.
 *
 * @var array $args                   Arguments passed by get_template_part
 * @var array $anky_template_args Arguments passed by get_template_part as a fallback if WP below 5.5.0
 * @package    Anky
 * @subpackage Template_Parts/Elementor
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

$args = $anky_template_args ?? $args;
?>

<div class="anky-partners-section-item">
	<h2 class="anky-partners-item-title"><?php echo esc_html( $args['title'] ); ?></h2>
	<div class="anky-partners-item-image-wrapper">
		<?php
		if ( empty( $args['link'] ) ) {
			echo wp_kses_post( $args['logo'] );
		} else {
			echo wp_kses_post( sprintf( '<a %s>%s</a>', $args['link'], $args['logo'] ) );
		}
		?>
	</div>
</div>
