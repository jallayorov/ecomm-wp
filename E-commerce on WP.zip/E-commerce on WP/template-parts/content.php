<?php
/**
 * Template part for displaying posts
 *
 * @link       https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package    Anky
 * @subpackage Template_Parts
 * @author     Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'anky-content-container' ); ?>>
	<header class="entry-header">
		<?php anky_entry_header(); ?>
	</header><!-- .entry-header -->

	<?php
	if ( is_single() ) {
		anky_post_thumbnail( 'large' );
	}
	?>

	<div class="entry-content">
		<?php
		if ( ! is_singular() ) :
			anky_the_excerpt();
		else :
			the_content(
				sprintf(
					wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
						__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'anky' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				)
			);
		endif;
		if ( is_singular() ) {
			wp_link_pages(
				array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'anky' ),
					'after'  => '</div>',
				)
			);
		}
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php
		anky_entry_footer();
		if ( is_singular() ) {
			anky_single_entry_footer();
		}
		?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
