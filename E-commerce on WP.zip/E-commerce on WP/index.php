<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Anky
 * @author  Anky (Andrew Black)
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'No direct access allowed' );
}

get_header();

$masonry_enabled = anky_is_masonry_enabled();
$sidebar_enabled = anky_is_sidebar_enabled();
$is_search       = is_search();
?>

	<main id="primary" class="site-main">
		<div class="anky-container">
			<?php
			anky_page_header();
			if ( have_posts() ) :
				?>
				<div class="anky-row">
					<?php anky_before_loop(); ?>
					<div class="anky-col<?php echo $sidebar_enabled ? '-4' : ''; ?>">
						<?php
						echo $masonry_enabled ? '<div class="anky-row-masonry">' : '';

						/* Start the Loop */
						while ( have_posts() ) :
							echo $masonry_enabled ? '<div class="anky-masonry-item">' : '';

							the_post();

							get_template_part( 'template-parts/content', $is_search ? 'search' : get_post_type() );

							echo $masonry_enabled ? '</div>' : '';
						endwhile;

						echo $masonry_enabled ? '</div><!-- .anky-row-masonry-->' : '';
						?>

						<div class="anky-posts-pagination">
							<?php anky_pagination(); ?>
						</div><!--.anky-posts-pagination-->
					</div><!-- .anky-col -->

					<?php anky_after_loop(); ?>
				</div><!--.anky-row-->
			<?php else : ?>
				<div class="anky-row">
					<?php anky_before_loop(); ?>
					<div class="anky-col<?php echo $sidebar_enabled ? '-4' : ''; ?>">
						<?php get_template_part( 'template-parts/content', 'none' ); ?>
					</div>
					<?php anky_after_loop(); ?>
				</div><!--.anky-row-->
			<?php endif; // check have_posts(). ?>
		</div><!-- .anky-container -->
	</main><!-- #main -->

<?php
get_footer();
