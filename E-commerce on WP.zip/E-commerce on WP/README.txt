
Anky Theme
===

Hi. I'm Anky.

Some description.

Installation
---------------

### Requirements

Some text.

### Quick Start

Some text in here.

### Setup

Some text in here.

### Credits
ADD VENDORS LINK
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* [Theme Hook Alliance](https://github.com/zamoose/themehookalliance) under [GNU General Public License, v2 (or newer)](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html)